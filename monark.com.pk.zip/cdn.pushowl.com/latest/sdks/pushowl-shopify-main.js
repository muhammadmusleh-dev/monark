function e(e, t) {
    var i = {};
    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (i[n] = e[n]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var o = 0;
        for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (i[n[o]] = e[n[o]])
    }
    return i
}

function t(e, t, i, n) {
    return new(i || (i = Promise))(function(o, r) {
        function s(e) {
            try {
                c(n.next(e))
            } catch (e) {
                r(e)
            }
        }

        function a(e) {
            try {
                c(n.throw(e))
            } catch (e) {
                r(e)
            }
        }

        function c(e) {
            var t;
            e.done ? o(e.value) : (t = e.value, t instanceof i ? t : new i(function(e) {
                e(t)
            })).then(s, a)
        }
        c((n = n.apply(e, t || [])).next())
    })
}
var i, n;
"function" == typeof SuppressedError && SuppressedError,
    function(e) {
        e.CHROME = "chrome", e.FIREFOX = "firefox", e.SAFARI = "safari", e.OTHER = "other"
    }(i || (i = {})),
    function(e) {
        e.ONE_STEP = "oneStep", e.TWO_STEP = "twoStep", e.OFF = "off"
    }(n || (n = {}));
var o, r, s, a, c, l;
! function(e) {
    e.CUSTOM_BUTTONS = "custom-buttons", e.FLYOUT_WIDGET = "flyout-widget", e.PARTNER_JS_API = "partner-js-api"
}(o || (o = {})),
function(e) {
    e.NOT_SHOPIFY = "not_shopify", e.STORAGE_NOT_DEFINED = "storage_not_defined", e.LOCALSTORAGE_NOT_AVAILABLE = "localstorage_not_available", e.IN_COMAPTIBLE_BROWSER = "incompatible_browser", e.NO_SERVICE_WORKER = "no_service_worker", e.NO_SUBDOMAIN = "no_subdomain", e.OLD_IOS_DEVICE = "old_ios_device", e.MICROSOFT_EDGE = "microsoft_edge", e.NOT_ADDED_TO_HOME_SCREEN = "not_added_to_home_screen", e.INCOGNITO = "incognito", e.NOTIFICATION_NOT_DEFINED = "notification_not_defined", e.NO_FILE_SYSTEM = "no_file_system", e.DISABLED_RESYNC = "disable_resync"
}(r || (r = {})),
function(e) {
    e.NO_SUBSCRIBER_TOKEN = "no_subsriber_token", e.INVALID_SUBSCRIBER_TOKEN = "invalid_subscriber_token", e.PERMISSION_DENIED = "permission_denied", e.PERMISSION_NOT_GRANTED = "permission_not_granted", e.INVALID_STATE_ERROR = "InvalidStateError", e.UNKNOWN_EVENT = "unknown_event"
}(s || (s = {})),
function(e) {
    e.BACK_IN_STOCK = "back_in_stock", e.PRICE_DROP = "price_drop"
}(a || (a = {})),
function(e) {
    e.SILENT = "silent", e.DEBUG = "debug"
}(c || (c = {})),
function(e) {
    e.CART_DELETED = "cart_deleted", e.CART_UPDATED = "cart_updated", e.PRODUCT_VIEWED = "product_viewed"
}(l || (l = {}));
const u = [{
        name: "track"
    }, {
        name: "identify"
    }, {
        name: "trackLink"
    }, {
        name: "page"
    }, {
        name: "viewProduct",
        isEcommerce: !0
    }, {
        name: "viewCategory",
        isEcommerce: !0
    }, {
        name: "search",
        isEcommerce: !0
    }],
    d = {
        WIDGET_CONFIG_KEY: {
            HOME: "home",
            PRICE_DROP: "price_drop",
            BACK_IN_STOCK: "back_in_stock"
        },
        EVENT_API_PATH: {
            PRICE_DROP: "price-drop",
            BACK_IN_STOCK: "back-in-stock"
        },
        ENVIRONMENT: {
            staging: "staging",
            production: "production"
        },
        STORAGE_KEYS: {
            NETWORK_REQUEST_QUEUE: "pushowl_network_request_queue",
            VISITOR_TOKEN: "pushowl_visitor_token",
            SESSION_TOKEN: "pushowl_session_token",
            SUBSCRIBER_TOKEN: "pushowl_subscriber_token",
            EMBEDDED_SUBSCRIBER_TOKEN: "pushowl_embedded_subscriber_token",
            OPTIN_SUBSCRIBER_TOKEN: "pushowl_optin_subscriber_token",
            SUBSCRIPTION: "pushowl_subscription",
            SW_SUBSCRIPTION: "pushowl_sw_subscription",
            SW_SUBSCRIBER_TOKEN: "pushowl_sw_subscriber_token",
            EMAIL: "pushowl_email",
            BACK_IN_STOCK_SUBSCRIPTIONS: "pushowl_back_in_stock_subscriptions",
            PRICE_DROP_SUBSCRIPTIONS: "pushowl_price_drop_subscriptions",
            SYNCED_CART_JSON: "pushowl_synced_cart_json",
            SYNCED_CUSTOMER_ID: "pushowl_synced_customer_id",
            SYNCED_AC_EVENTS: "pushowl_ac_events",
            SESSION_PAGEVIEW_COUNT: "pushowl_session_pageview_count",
            SESSION_SUBSCRIBER_CHECK: "pushowl_session_subscriber_check",
            OPTIN_DEFERRED_UNTIL: "pushowl_optin_deferred_until",
            LOG_LEVEL: "pushowl_log_level",
            HAS_RAISED_UNSUBSCRIPTION_EVENT: "pushowl_has_raised_unsubscription_event",
            IS_PERMISSION_GRANTED: "pushowl_is_permission_granted",
            REFERRER: "pushowl_referrer",
            LANDING_PAGE_URL: "pushowl_landing_page_url",
            LANDING_PAGE_URL_PARAMS: "pushowl_landing_page_url_params",
            ORIGINAL_URL_PARAMS: "pushowl_original_url_params",
            IOS_STANDALONE_MODE_LOG: "pushowl_ios_standalone_mode_log",
            INSTALL_PROMPT_SEEN_COUNT: "pushowl_install_prompt_seen_count",
            INSTALL_PROMPT_DISMISSED: "pushowl_install_prompt_dismissed",
            CONSENT: "pushowl_channels_consent",
            PUSHOWL_SUBDOMAIN: "pushowl_subdomain",
            PUSHOWL_ENVIRONMENT: "pushowl_environment",
            CURRENT_CONFIG_KEY: "pushowl_current_config_key",
            PHONE: "pushowl_phone",
            BREVO_BACK_IN_STOCK_PRODUCT_SUBSCRIPTIONS: "pushowl_brevo_back_in_stock_product_subscriptions"
        },
        NOTIFICATION_PERMISSION: {
            DEFAULT: "default",
            GRANTED: "granted",
            DENIED: "denied",
            DISMISSED: "dismissed",
            SERVICE_WORKER_FAILURE: "service_worker_failure"
        },
        DEFAULT_TIMEOUT: {
            DEFAULT: 0,
            MOBILE: 10
        }
    },
    p = {
        EVENTS: {
            CLICK: "click",
            ANIMATION_END: "animationend",
            TRANSITION_END: "transitionend"
        },
        WIDGET_CLASSES: {
            MINIMIZE: "minimize",
            MAXIMIZE: "maximize"
        }
    },
    h = {
        [d.ENVIRONMENT.staging]: "https://api-staging.powl.io",
        [d.ENVIRONMENT.production]: "https://api.powl.io"
    },
    g = {
        [d.ENVIRONMENT.staging]: "https://cdn-staging.powl.io/config",
        [d.ENVIRONMENT.production]: "https://cdn.powl.io/config"
    },
    m = {
        [d.ENVIRONMENT.staging]: "web.com.pushowl.staging",
        [d.ENVIRONMENT.production]: "web.com.pushowl.prod"
    },
    f = {
        HOME: "home",
        COLLECTION: "collection",
        PRODUCT: "product",
        CART: "cart",
        CHECKOUT: "checkout",
        ORDER: "order",
        ORDERS: "orders",
        THANK_YOU: "thank_you"
    },
    w = {
        CART: "cart",
        ACCOUNT: "account",
        ORDERS: "orders"
    },
    b = "subscribe",
    _ = "unsubscribe",
    S = "debug",
    v = "disabled",
    y = "browser-prompt",
    E = "custom-prompt",
    I = "optin-flyout",
    T = "price-drop-flyout",
    O = "back-in-stock-flyout",
    N = "wordpress",
    C = "prestashop";

function M(e) {
    return new Promise(function(t, i) {
        e.oncomplete = e.onsuccess = function() {
            return t(e.result)
        }, e.onabort = e.onerror = function() {
            return i(e.error)
        }
    })
}

function A(e, t) {
    var i;
    return function(n, o) {
        return function() {
            if (i) return i;
            var n = indexedDB.open(e);
            return n.onupgradeneeded = function() {
                return n.result.createObjectStore(t)
            }, (i = M(n)).then(function(e) {
                e.onclose = function() {
                    return i = void 0
                }
            }, function() {}), i
        }().then(function(e) {
            return o(e.transaction(t, n).objectStore(t))
        })
    }
}
var L;

function P() {
    return L || (L = A("keyval-store", "keyval")), L
}
const k = Object.prototype.toString,
    D = new Set(["network error", "Failed to fetch", "NetworkError when attempting to fetch resource.", "The Internet connection appears to be offline.", "Load failed", "Network request failed", "fetch failed", "terminated"]);

function R(e) {
    var t;
    return !(!e || (t = e, "[object Error]" !== k.call(t)) || "TypeError" !== e.name || "string" != typeof e.message) && ("Load failed" === e.message ? void 0 === e.stack : D.has(e.message))
}
class j {
    constructor(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this.key = e, this.isSessionStorage = t, this.isSessionStorage ? window.sessionStorage.getItem(e) ? this.subscriptions = window.sessionStorage.getItem(this.key).split(",") : this.subscriptions = [] : window.localStorage.getItem(e) ? this.subscriptions = window.localStorage.getItem(this.key).split(",") : this.subscriptions = []
    }
    subscribe(e) {
        this.isSubscribed(e) || (this.subscriptions.push(e.id.toString()), this.isSessionStorage ? window.sessionStorage[this.key] = this.subscriptions : window.localStorage[this.key] = this.subscriptions)
    }
    isSubscribed(e) {
        return this.subscriptions.indexOf(e.id.toString()) > -1
    }
    refresh() {
        this.isSessionStorage ? this.subscriptions = window.sessionStorage.getItem(this.key).split(",") : this.subscriptions = window.localStorage.getItem(this.key).split(",")
    }
}
class x {
    constructor() {
        this.back_in_stock = new j(d.STORAGE_KEYS.BACK_IN_STOCK_SUBSCRIPTIONS), this.price_drop = new j(d.STORAGE_KEYS.PRICE_DROP_SUBSCRIPTIONS), this.brevo_back_in_stock = new j(d.STORAGE_KEYS.BREVO_BACK_IN_STOCK_PRODUCT_SUBSCRIPTIONS, !0), Promise.all([G.get(d.STORAGE_KEYS.SW_SUBSCRIPTION), G.get(d.STORAGE_KEYS.SW_SUBSCRIBER_TOKEN)]).then(e => {
            var [t, i] = e;
            t && i && (this.sw_subscription_data = t, this.sw_subscriber_token = i, x.sw_subscriber_token = i)
        }).catch(e => {
            ye("Error while fetching subscription data", e)
        })
    }
    static getOrCreateToken(e, t) {
        var i = e.getItem(t);
        if (i) return i;
        var n = function() {
                return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
            },
            o = "".concat(n() + n(), "-").concat(n(), "-4").concat(n().substr(0, 3), "-").concat(n(), "-").concat(n()).concat(n()).concat(n()).toLowerCase();
        return e.setItem(t, o), o
    }
    static get queue() {
        try {
            var e = localStorage.getItem(d.STORAGE_KEYS.NETWORK_REQUEST_QUEUE);
            return e ? JSON.parse(e) : []
        } catch (e) {
            return []
        }
    }
    static set queue(e) {
        e ? localStorage.setItem(d.STORAGE_KEYS.NETWORK_REQUEST_QUEUE, JSON.stringify(e)) : localStorage.removeItem(d.STORAGE_KEYS.NETWORK_REQUEST_QUEUE)
    }
    static get email() {
        return localStorage.getItem(d.STORAGE_KEYS.EMAIL)
    }
    static set email(e) {
        localStorage.setItem(d.STORAGE_KEYS.EMAIL, e)
    }
    static get phone() {
        return localStorage.getItem(d.STORAGE_KEYS.PHONE)
    }
    static set phone(e) {
        localStorage.setItem(d.STORAGE_KEYS.PHONE, e)
    }
    static set pushowlEnvironment(e) {
        localStorage.setItem(d.STORAGE_KEYS.PUSHOWL_ENVIRONMENT, e)
    }
    static get consent() {
        var e = localStorage.getItem(d.STORAGE_KEYS.CONSENT);
        if (e) try {
            return JSON.parse(e)
        } catch (e) {
            return []
        }
        return []
    }
    static set consent(e) {
        localStorage.setItem(d.STORAGE_KEYS.CONSENT, JSON.stringify(e))
    }
    static get embeddedSubscriberToken() {
        return localStorage.getItem(d.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN)
    }
    static set embeddedSubscriberToken(e) {
        e ? (localStorage.setItem(d.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN, e), G.set(d.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN, e)) : (localStorage.removeItem(d.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN), G.del(d.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN))
    }
    static get optinSubscriberToken() {
        return localStorage.getItem(d.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN)
    }
    static set optinSubscriberToken(e) {
        e ? (localStorage.setItem(d.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN, e), G.set(d.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN, e)) : (localStorage.removeItem(d.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN), G.del(d.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN))
    }
    static get subscriberToken() {
        return this.sw_subscriber_token || this.optinSubscriberToken || this.embeddedSubscriberToken || localStorage.getItem(d.STORAGE_KEYS.SUBSCRIBER_TOKEN)
    }
    static set subscriberToken(e) {
        e ? (localStorage.setItem(d.STORAGE_KEYS.SUBSCRIBER_TOKEN, e), G.set(d.STORAGE_KEYS.SUBSCRIBER_TOKEN, e)) : (localStorage.removeItem(d.STORAGE_KEYS.SUBSCRIBER_TOKEN), G.del(d.STORAGE_KEYS.SUBSCRIBER_TOKEN))
    }
    static get installPromptDismissed() {
        return Boolean(localStorage.getItem(d.STORAGE_KEYS.INSTALL_PROMPT_DISMISSED))
    }
    static set installPromptDismissed(e) {
        localStorage.setItem(d.STORAGE_KEYS.INSTALL_PROMPT_DISMISSED, "".concat(e))
    }
    static get hasLoggediOSStandaloneMode() {
        return localStorage.getItem(d.STORAGE_KEYS.IOS_STANDALONE_MODE_LOG)
    }
    static set hasLoggediOSStandaloneMode(e) {
        localStorage.setItem(d.STORAGE_KEYS.IOS_STANDALONE_MODE_LOG, e)
    }
    static get originalURLParams() {
        return localStorage.getItem(d.STORAGE_KEYS.ORIGINAL_URL_PARAMS)
    }
    static set originalURLParams(e) {
        localStorage.setItem(d.STORAGE_KEYS.ORIGINAL_URL_PARAMS, e)
    }
    static get visitorToken() {
        return z() ? this.getOrCreateToken(localStorage, d.STORAGE_KEYS.VISITOR_TOKEN) : (localStorage.removeItem(d.STORAGE_KEYS.VISITOR_TOKEN), null)
    }
    static get sessionToken() {
        return z() ? this.getOrCreateToken(sessionStorage, d.STORAGE_KEYS.SESSION_TOKEN) : (localStorage.removeItem(d.STORAGE_KEYS.SESSION_TOKEN), null)
    }
    static get syncedCustomerId() {
        return localStorage.getItem(d.STORAGE_KEYS.SYNCED_CUSTOMER_ID)
    }
    static set syncedCustomerId(e) {
        localStorage.setItem(d.STORAGE_KEYS.SYNCED_CUSTOMER_ID, e.toString())
    }
    static get synced_cart_json() {
        var e = localStorage.getItem(d.STORAGE_KEYS.SYNCED_CART_JSON);
        return e ? JSON.parse(e) : void 0
    }
    static set synced_cart_json(e) {
        e && ("[object String]" !== Object.prototype.toString.call(e) && (e = JSON.stringify(e)), localStorage.setItem(d.STORAGE_KEYS.SYNCED_CART_JSON, e))
    }
    static get ac_events() {
        try {
            return JSON.parse(localStorage.getItem(d.STORAGE_KEYS.SYNCED_AC_EVENTS)) || []
        } catch (e) {
            return []
        }
    }
    static set ac_events(e) {
        var t = "string" == typeof e ? e : JSON.stringify(e);
        localStorage.setItem(d.STORAGE_KEYS.SYNCED_AC_EVENTS, t)
    }
    static get subscription() {
        var e = this.sw_subscription_data || localStorage.getItem(d.STORAGE_KEYS.SUBSCRIPTION),
            t = null;
        if (e) try {
            t = JSON.parse(e)
        } catch (i) {
            t = e
        }
        return t
    }
    static set subscription(e) {
        var t = "string" == typeof e ? e : JSON.stringify(e);
        localStorage.setItem(d.STORAGE_KEYS.SUBSCRIPTION, t), G.set(d.STORAGE_KEYS.SW_SUBSCRIPTION, t)
    }
    static get optinDeferredUntil() {
        return parseInt(localStorage.getItem(d.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL) || 0, 10)
    }
    static set optinDeferredUntil(e) {
        null === e ? localStorage.removeItem(d.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL) : localStorage.setItem(d.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL, e)
    }
    static get logLevel() {
        return localStorage.getItem(d.STORAGE_KEYS.LOG_LEVEL)
    }
    static set logLevel(e) {
        localStorage.setItem(d.STORAGE_KEYS.LOG_LEVEL, e)
    }
    static get hasRaisedUnsubscriptionEvent() {
        return localStorage.getItem(d.STORAGE_KEYS.HAS_RAISED_UNSUBSCRIPTION_EVENT)
    }
    static set hasRaisedUnsubscriptionEvent(e) {
        localStorage.setItem(d.STORAGE_KEYS.HAS_RAISED_UNSUBSCRIPTION_EVENT, e)
    }
    static get isPermissionGranted() {
        return "true" === localStorage.getItem(d.STORAGE_KEYS.IS_PERMISSION_GRANTED)
    }
    static set isPermissionGranted(e) {
        e ? localStorage.setItem(d.STORAGE_KEYS.IS_PERMISSION_GRANTED, e) : localStorage.removeItem(d.STORAGE_KEYS.IS_PERMISSION_GRANTED)
    }
    static handlePostSubscription(e, t) {
        x.subscription = e, x.subscriberToken = t, x.hasRaisedUnsubscriptionEvent = ""
    }
}
x.sw_subscriber_token = null;
const U = () => {
        const {
            subdomain: e
        } = H;
        return `${H.apiEndpoint}/api/v1/${e}`
    },
    B = () => {
        const e = new Error("network error");
        return e.name = "TypeError", e
    },
    F = ({
        path: e,
        method: i,
        appendPlatform: n = !0,
        url: o = null,
        payload: r = null,
        contentType: s = "application/json",
        acceptType: a = "application/json",
        retryCount: c = null
    }) => t(void 0, void 0, void 0, function*() {
        const t = o ? new URL(o) : new URL(`${U()}${e}`);
        return n && t.searchParams.append("platform", H.platform), c && t.searchParams.append("retry_count", `${c}`), new Promise((n, o) => {
            let l = new XMLHttpRequest;
            l.open(i, t.href, !0), l.setRequestHeader("Content-Type", s), l.setRequestHeader("Accept", a), r ? l.send(s.match(/json/) ? JSON.stringify(r) : r) : l.send(), l.onload = function() {
                let u = l.responseText;
                if (429 === l.status && o(B()), l.status >= 200 && l.status < 400) try {
                    const e = a.match(/json/) ? JSON.parse(u) : u;
                    n(e)
                } catch (e) {
                    n(u)
                } else {
                    const n = new Error(`HTTP Error: ${l.status} ${t.href}`);
                    n.name = "HttpError", Object.assign(n, {
                        status: l.status,
                        responseBody: u,
                        url: t.href,
                        method: i,
                        path: e,
                        payload: r,
                        contentType: s,
                        acceptType: a,
                        retryCount: c
                    }), o(n)
                }
            }, l.onerror = function() {
                o(B())
            }, l.onabort = function() {
                const n = new Error(`Request Aborted ${t.href}`);
                n.name = "AbortError", Object.assign(n, {
                    url: t.href,
                    method: i,
                    path: e,
                    payload: r,
                    contentType: s,
                    acceptType: a,
                    retryCount: c
                }), o(n)
            }
        })
    });
class Y {
    static run() {
        (x.queue || []).forEach(e => {
            setTimeout(() => {
                this._request(e)
            }, 1e3 * e.retryCount)
        })
    }
    static _enqueue(e) {
        let t = e;
        return void 0 === e.id && (t = Object.assign({
            id: me()
        }, e)), x.queue = [...x.queue.slice(0, 5), t], t
    }
    static _retryRequest(e) {
        return t(this, void 0, void 0, function*() {
            const t = Object.assign(Object.assign({}, e), {
                retryCount: ((null == e ? void 0 : e.retryCount) || 0) + 1
            });
            if (t.retryCount > 5) {
                return Te("APIRequestEventually", {
                    request: t,
                    connectionType: navigator.connection ? navigator.connection.effectiveType : "NA"
                }), Promise.reject()
            }
            const i = this._enqueue(t);
            setTimeout(() => {
                this._request(i)
            }, 1e3 * i.retryCount)
        })
    }
    static _dequeue(e) {
        x.queue = x.queue.filter(t => t.id !== e.id)
    }
    static _request(e) {
        return t(this, void 0, void 0, function*() {
            try {
                this._dequeue(e);
                return yield F(e)
            } catch (t) {
                return R(t) ? this._retryRequest(e) : (Te("APIRequestEventuallyError", {
                    error: t,
                    request: e
                }), Promise.reject(t))
            }
        })
    }
    static get(e) {
        const t = this._enqueue(e);
        return this._request(Object.assign(Object.assign({}, t), {
            method: "GET"
        }))
    }
    static post(e) {
        const t = this._enqueue(e);
        return this._request(Object.assign(Object.assign({}, t), {
            method: "POST"
        }))
    }
    static put(e) {
        const t = this._enqueue(e);
        return this._request(Object.assign(Object.assign({}, t), {
            method: "PUT"
        }))
    }
}
class H {
    static get scriptUrl() {
        const e = Array.from(document.getElementsByTagName("script"));
        for (const {
                src: i = ""
            } of e) {
            if (!/pushowl-\w+\.js/.test(i)) continue;
            const e = i.startsWith("http") ? i : `https:${i}`;
            if (e.includes("pushowl-shopify")) return e;
            var t = e
        }
        return t || window.location.href
    }
    static get environment() {
        if (!H.scriptUrl) return d.ENVIRONMENT.production;
        let e = le(new URL(H.scriptUrl).search.substring(1)).environment;
        e && (e = d.ENVIRONMENT[e]);
        const t = window.pushowlEnvironment || e || d.ENVIRONMENT.production;
        return t !== d.ENVIRONMENT.production && (x.pushowlEnvironment = t), t
    }
    static get isProduction() {
        return H.environment == d.ENVIRONMENT.production
    }
    static get apiEndpoint() {
        return h[H.environment] || h[d.ENVIRONMENT.production]
    }
    static get configApiEndpoint() {
        return g[H.environment] || g[d.ENVIRONMENT.production]
    }
    static get subdomain() {
        var e, t, i, n, o;
        if (window.pushowlSubdomain) return window.pushowlSubdomain;
        const r = null !== (t = null === (e = null === window || void 0 === window ? void 0 : window.pushowl) || void 0 === e ? void 0 : e.subdomain) && void 0 !== t ? t : null,
            s = (() => {
                if (!H.scriptUrl) return null;
                return le(new URL(H.scriptUrl).search.substring(1)).subdomain
            })(),
            a = (null === (i = null === window || void 0 === window ? void 0 : window.Shopify) || void 0 === i ? void 0 : i.shop) ? window.Shopify.shop.replace(".myshopify.com", "") : null,
            c = (() => {
                if ("shopline" === H.platform) {
                    const e = window.location.hostname;
                    if (e && "localhost" !== e) {
                        const t = e.split(".");
                        if (t.length > 2) return t[0]
                    }
                }
                return null
            })();
        let l = null !== (o = null !== (n = null != r ? r : s) && void 0 !== n ? n : a) && void 0 !== o ? o : c;
        return l || ye("Subdomain not found. Checked sources:", {
            fromPushowl: r,
            fromQuery: s,
            fromShopify: a,
            fromShopline: c,
            scriptUrl: H.scriptUrl,
            platform: H.platform
        }), window.pushowlSubdomain = l, l
    }
    static get platform() {
        if (!H.scriptUrl) return "shopify";
        const e = le(new URL(H.scriptUrl).search.substring(1)).platform;
        return e && !["shopify", "sendinblue", "bigcommerce", "shopline"].includes(e) && H.logToServer({
            message: "unknown platform detected",
            subdomain: H.subdomain,
            data: {
                platform: e,
                script_url: H.scriptUrl
            }
        }), e || "shopify"
    }
    static get plugin() {
        if (!H.scriptUrl) return null;
        return le(new URL(H.scriptUrl).search.substring(1)).plugin
    }
    static get guid() {
        if ("fnova" === H.subdomain) try {
            return (new Date).toISOString().split("T")[0]
        } catch (e) {
            return
        }
        if (!H.scriptUrl) return null;
        let e = le(new URL(H.scriptUrl).search.substring(1));
        return window.pushowlGUID || e.guid
    }
    static get visitorId() {
        if (!H.scriptUrl) return null;
        return le(new URL(H.scriptUrl).search.substring(1)).visitor_id
    }
    static get shopUrl() {
        return location.protocol + "//" + location.host
    }
    static serviceWorkerUrl(e = {}) {
        if (e.custom_sw_path && "disabled" !== e.custom_sw_path) return `${H.shopUrl}${e.custom_sw_path}?v=2&subdomain=${this.subdomain}`;
        if ("bigcommerce" === H.platform) return `${H.shopUrl}/pushowl-service-worker.js?v=2&subdomain=${this.subdomain}`;
        if ("headless" === H.mode) {
            const t = H.platform,
                i = H.plugin;
            return "enabled" === e.root_service_worker ? `${window.location.origin}/service-worker.js?v=2&subdomain=${this.subdomain}` : "sendinblue" === t && window.__st && window.Shopify ? `${H.shopUrl}/apps/sendinblue/service-worker.js?v=2&subdomain=${this.subdomain}` : "sendinblue" === t && i === N ? `${H.shopUrl}/wp-content/plugins/mailin/js/service-worker.js?v=2&subdomain=${this.subdomain}` : "sendinblue" === t && i === C ? `${H.shopUrl}/modules/sendinblue/views/js/service-worker.js?v=2&subdomain=${this.subdomain}` : `${H.shopUrl}/${"sendinblue"===t?"sendinblue":"pushowl"}/service-worker.js?v=2&subdomain=${this.subdomain}`
        }
        return "enabled" === e.should_log ? `${H.shopUrl}/apps/pushowl/sdks/service-worker-logsink.js?v=2&subdomain=${this.subdomain}` : `${H.shopUrl}/apps/pushowl/sdks/service-worker.js?v=2&subdomain=${this.subdomain}`
    }
    static get isWorkerAvailable() {
        return pe().isApnsSafari ? Promise.resolve(!0) : new Promise(e => {
            const t = ((new V).config || {}).flags,
                i = H.serviceWorkerUrl(t),
                n = "enabled" === t.sw_get_request;
            fetch(i, {
                method: n ? "GET" : "HEAD"
            }).then(t => {
                if (t.status >= 200 && t.status < 300) return e(!0);
                e(!1)
            })
        })
    }
    static get webPushId() {
        return m[this.environment] || m[d.ENVIRONMENT.production]
    }
    static getServiceWorkerUrlWithIntergrations(e, t = {}) {
        const i = Object.keys(t).filter(e => "enabled" === t[e].status);
        if (!i.length) return e;
        return `${e}${new URL(e).search?"&":"?"}integrations=${i.join(",")}`
    }
    static logToServer({
        message: e,
        subdomain: t,
        sessionHash: i = "session",
        data: n
    }) {
        return Y.post({
            url: `${H.apiEndpoint}/logs/v1/`,
            acceptType: "text/plain",
            payload: [{
                level: "warn",
                subscriber_token: x.subscriberToken,
                subdomain: t,
                message: e,
                session_hash: i,
                timestamp: (new Date).toISOString(),
                data: Object.assign({
                    release: "8a6826f"
                }, n)
            }]
        })
    }
    static getPreviewLib(e) {
        const t = H.getPreviewBranch();
        return sessionStorage.setItem("pushowl_branch", t), "local" === t ? `https://localhost:3008/latest/sdks/${e}?environment=staging&platform=${H.platform}` : null
    }
    static loadPreviewLib(e) {
        const t = document.createElement("script"),
            i = this.getPreviewLib(e);
        t.onload = () => {}, i && (t.src = i, t.setAttribute("async", ""), document.head.appendChild(t), window.pushowlPreviewLoaded = !0)
    }
    static getPreviewBranch() {
        const e = new URLSearchParams(window.location.search).get("pushowl_branch") || sessionStorage.getItem("pushowl_branch");
        return window.pushowlPreviewLoaded ? null : e
    }
    static isDisabled() {
        const e = new URLSearchParams(window.location.search).get("poTaskType") || sessionStorage.getItem("poTaskType");
        e && sessionStorage.setItem("pushowl_task_type", e);
        return e === v
    }
}
const z = () => "shopify" !== H.platform || !H.guid || "fnova" === H.subdomain || !!window.Shopify.customerPrivacy && window.Shopify.customerPrivacy.userCanBeTracked(),
    K = () => !!window.indexedDB;
class G {
    static set(e, i) {
        return t(this, void 0, void 0, function*() {
            if (K()) try {
                ! function(e, t) {
                    (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : P())("readwrite", function(i) {
                        return i.put(t, e), M(i.transaction)
                    })
                }(e, i)
            } catch (e) {
                ye("error in indexedDBUtil", e)
            }
        })
    }
    static get(e) {
        return t(this, void 0, void 0, function*() {
            if (K()) try {
                return function(e) {
                    return (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : P())("readonly", function(t) {
                        return M(t.get(e))
                    })
                }(e)
            } catch (e) {
                return ye("error in indexedDBUtil", e), Promise.reject(e)
            }
        })
    }
    static del(e) {
        return t(this, void 0, void 0, function*() {
            if (K()) try {
                ! function(e) {
                    (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : P())("readwrite", function(t) {
                        return t.delete(e), M(t.transaction)
                    })
                }(e)
            } catch (e) {
                ye("error in indexedDBUtil", e)
            }
        })
    }
}
class V {
    constructor() {
        this.configKey = "pushowl_shopify_config-".concat(1.5, "-").concat(H.guid), this.permissionKey = "pushowl_permission_not_granted-".concat(1.5, "-").concat(H.guid), this.subscriptionVerifiedKey = "pushowl_subscription_verified-".concat(1.5, "-").concat(H.guid), this.optinSeenCountKey = "pushowl_optin_seen_count", this.embedded_form_viewed_key_prefix = "pushowl_embedded_form_viewed", this.bis_form_viewed_key_prefix = "pushowl_bis_form_viewed"
    }
    get config() {
        var e = window.sessionStorage.getItem(this.configKey),
            t = null;
        if (e) try {
            t = JSON.parse(e)
        } catch (e) {
            t = null
        }
        return t
    }
    set config(e) {
        var t = "string" == typeof e ? e : JSON.stringify(e);
        window.sessionStorage.setItem(this.configKey, t), window.sessionStorage.setItem(d.STORAGE_KEYS.CURRENT_CONFIG_KEY, this.configKey)
    }
    get isPermissionNotGranted() {
        return "true" === window.sessionStorage.getItem(this.permissionKey)
    }
    set isPermissionNotGranted(e) {
        window.sessionStorage.setItem(this.permissionKey, e), window.localStorage.setItem(this.permissionKey, e)
    }
    get subscriptionVerified() {
        return !!window.sessionStorage.getItem(this.subscriptionVerifiedKey)
    }
    set subscriptionVerified(e) {
        window.sessionStorage.setItem(this.subscriptionVerifiedKey, e)
    }
    get optinSeenCount() {
        return parseInt(window.sessionStorage.getItem(this.optinSeenCountKey) || 0, 10)
    }
    set optinSeenCount(e) {
        window.sessionStorage.setItem(this.optinSeenCountKey, e)
    }
    mark_embedded_form_viewed(e) {
        window.sessionStorage.setItem("".concat(this.embedded_form_viewed_key_prefix, "-").concat(e), !0)
    }
    mark_bis_form_viewed(e) {
        window.sessionStorage.setItem("".concat(this.bis_form_viewed_key_prefix, "-").concat(e), !0)
    }
    has_viewed_embedded_form(e) {
        return "true" === window.sessionStorage.getItem("".concat(this.embedded_form_viewed_key_prefix, "-").concat(e))
    }
    has_viewed_bis_form(e) {
        return "true" === window.sessionStorage.getItem("".concat(this.bis_form_viewed_key_prefix, "-").concat(e))
    }
    static get installPromptSeenCount() {
        return parseInt(window.sessionStorage.getItem(d.STORAGE_KEYS.INSTALL_PROMPT_SEEN_COUNT) || 0, 10)
    }
    static set installPromptSeenCount(e) {
        window.sessionStorage.setItem(d.STORAGE_KEYS.INSTALL_PROMPT_SEEN_COUNT, e)
    }
    static get landingPageURL() {
        return sessionStorage.getItem(d.STORAGE_KEYS.LANDING_PAGE_URL)
    }
    static set landingPageURL(e) {
        sessionStorage.setItem(d.STORAGE_KEYS.LANDING_PAGE_URL, e)
    }
    static get referrer() {
        return sessionStorage.getItem(d.STORAGE_KEYS.REFERRER)
    }
    static set referrer(e) {
        sessionStorage.setItem(d.STORAGE_KEYS.REFERRER, e)
    }
    static get landingPageURLParams() {
        return sessionStorage.getItem(d.STORAGE_KEYS.LANDING_PAGE_URL_PARAMS)
    }
    static set landingPageURLParams(e) {
        sessionStorage.setItem(d.STORAGE_KEYS.LANDING_PAGE_URL_PARAMS, e)
    }
    static set windowVariablesForOwly(e) {
        (window.Shopify && window.Shopify.customerPrivacy && window.Shopify.customerPrivacy.userCanBeTracked() || !window.Shopify) && sessionStorage.setItem(d.STORAGE_KEYS.PUSHOWL_SUBDOMAIN, e)
    }
}
class q {
    constructor() {
        this.product = null
    }
    static get section() {
        return "home"
    }
    static get productAlias() {
        return "all"
    }
    static get customerId() {}
    static getCart() {}
    getProductDetails(e = !1, t) {}
    getRawCurrentProductDetails() {}
}
class $ {
    constructor() {}
    currentVariant() {}
}
class W {
    constructor() {}
}
const Q = e => e.startsWith("https://") ? e : e.replace("//cdn.shopify.com", "https://cdn.shopify.com"),
    J = e => "object" == typeof e && null !== e && "src" in e ? Q(e.src) : "string" == typeof e ? Q(e) : null;
class X extends W {
    constructor(e) {
        super(), this.id = e.id, this.name = e.name, this.price = e.price / 100, this.available = e.available, this.featured_image = J(e.featured_image)
    }
}
class Z extends $ {
    constructor(e) {
        super(), this.id = e.id, this.title = e.title, this.featured_image = J(e.featured_image), this.price = Oe(e.price);
        const t = e.variants;
        this.variants = t.map(e => new X(e))
    }
    getVariant(e) {
        return e = parseInt(e), this.variants.find(t => t.id == e)
    }
    currentVariant() {
        const e = ue("variant");
        if (!e) {
            for (const e of this.variants)
                if (e.available) return e;
            return this.variants[0]
        }
        return this.getVariant(e)
    }
}
const ee = /checkouts\/c\/([^\/]*)\/thank_you/;
class te extends q {
    constructor() {
        super(), this.productCache = {}
    }
    static get section() {
        try {
            let {
                pageType: e
            } = window.ShopifyAnalytics.meta.page;
            if (e) return e !== f.PRODUCT && /\/products\/(\S)/.test(location.pathname) && (e = f.PRODUCT), e
        } catch (e) {}
        if (void 0 !== window.Shopify && window.Shopify.Checkout && ("thank_you" === window.Shopify.Checkout.page || "checkout_one_thank_you" === window.Shopify.Checkout.page)) return f.THANK_YOU;
        const {
            hostname: e
        } = location, t = location.pathname, i = t.split("/")[0], n = t.split("/")[1];
        if (ee.test(t)) return f.THANK_YOU;
        if ("" === i) return f.HOME;
        if (i === w.CART) return f.CART;
        if (i === w.ACCOUNT && n === w.ORDERS) return f.ORDER;
        if ("account" === i && !i) return f.ORDERS;
        if ("checkout.shopify.com" === e || "checkouts" === n || t.indexOf("checkouts") >= 0) return f.CHECKOUT;
        if (void 0 !== window.__st && window.__st.s) {
            const e = window.__st.s.split("-")[0];
            if ("collections" === e) return f.COLLECTION;
            if ("products" === e) return f.PRODUCT
        }
    }
    static get productAlias() {
        let e = location.pathname.split("/");
        e = e.filter(e => e);
        const t = e.map(e => e.toLocaleLowerCase()).lastIndexOf("products");
        return -1 === t ? "" : e[t + 1]
    }
    static get customerId() {
        if ("headless" === H.mode) return window.pushowl ? window.pushowl.customerId : "";
        let e = null;
        return void 0 !== window.__st && window.__st.cid ? e = window.__st.cid : void 0 !== window.Shopify && void 0 !== window.Shopify.checkout && window.Shopify.checkout.customer_id && (e = window.Shopify.checkout.customer_id.toString()), e
    }
    static getCart() {
        return ge({
            url: `/cart.js?random=${Date.now()}`
        }).then(e => (e.updated_at = (new Date).toISOString(), e), () => "Cart API failed")
    }
    static getVisitorCountry() {
        var e, i;
        return t(this, void 0, void 0, function*() {
            try {
                const t = yield ge({
                    url: "/browsing_context_suggestions.json"
                });
                return (null === (i = null === (e = null == t ? void 0 : t.detected_values) || void 0 === e ? void 0 : e.country) || void 0 === i ? void 0 : i.handle) || null
            } catch (e) {
                return null
            }
        })
    }
    static get pageName() {
        const e = window.location.pathname.match(/\/pages\/([a-z0-9_-]+)$/);
        return e ? e[1] : void 0
    }
    static get collectionName() {
        const e = window.location.pathname.match(/collections\/([a-z0-9_-]+)$/);
        return e ? e[1] : void 0
    }
    static get collectionId() {
        return window.ShopifyAnalytics && window.ShopifyAnalytics.meta && window.ShopifyAnalytics.meta.page ? window.ShopifyAnalytics.meta.page.resourceId : null
    }
    getProductDetails(e = !1, t) {
        const i = t || te.productAlias;
        return this.productCache[i] && !e ? Promise.resolve(this.productCache[i]) : ge({
            url: `/products/${i}.js`
        }).then(e => this.productCache[i] = new Z(e))
    }
    getRawCurrentProductDetails() {
        return Promise.resolve(window.ShopifyAnalytics.meta.product)
    }
}

function ie(e, t) {
    window.sib && window.sib[e] ? window.sib[e](...t) : window.sib.equeue.push({
        [e]: t
    })
}
class ne {
    static loadTracker({
        isNewTracker: e,
        maKey: t
    }) {
        if (e) {
            const e = document.createElement("script");
            return e.type = "text/javascript", e.async = !0, e.src = "https://cdn.brevo.com/js/sdk-loader.js", document.body.appendChild(e), window.Brevo = window.Brevo || [], window.Brevo.push(["init", {
                client_key: t,
                do_not_track_page: !0
            }]), !0
        }
        return window.sib = {
            equeue: [],
            client_key: t
        }, window.sendinblue = {
            ecommerce: {}
        }, u.forEach(function(e) {
            const t = e.name;
            e.isEcommerce ? window.sendinblue.ecommerce[t] = (...e) => {
                ie(t, e)
            } : window.sendinblue[t] = (...e) => {
                ie(t, e)
            };
            const i = document.createElement("script");
            i.type = "text/javascript", i.id = "sendinblue-js", i.async = !0, i.src = `https://sibautomation.com/sa.js?key=${window.sib.client_key}`, document.body.appendChild(i)
        }), !0
    }
    static set emailId(e) {
        e && "undefined" !== e && (window.sib ? window.sib.email_id = e : window.Brevo && (window.Brevo.email_id = e))
    }
    static get emailId() {
        return window.sib ? window.sib.email_id : window.Brevo ? window.Brevo.email_id : null
    }
    static setPropertiesPayload(e) {
        var t;
        const i = new V;
        if ("enabled" !== i.config.flags.brevo_email) return !1;
        i.config.privacy && te.customerId && (e.customerId = te.customerId), !(null === (t = null == i ? void 0 : i.config) || void 0 === t ? void 0 : t.subscription_confirmation) && x.email && "undefined" !== x.email && (e.email = x.email), x.phone && "undefined" !== x.phone && (e.sms = x.phone)
    }
}
ne.track = ({
    eventName: e,
    eventData: t
}) => {
    try {
        const i = new V,
            n = {};
        if (i.config.privacy && te.customerId && (n.customerId = te.customerId), ne.setPropertiesPayload(n), "enabled" !== i.config.flags.brevo_email) return;
        window.sendinblue ? window.sendinblue.track(e, n, t) : window.Brevo && window.Brevo.push(["track", e, n, t])
    } catch (e) {
        ye("Error in brevoTrack", e)
    }
}, ne.identify = (e, t) => {
    if (e) try {
        const i = new V;
        if (!i.config.brevo_ma_key || "enabled" !== i.config.flags.brevo_email) return;
        window.sendinblue ? window.sendinblue.identify(e, t) : window.Brevo && window.Brevo.push(function() {
            window.Brevo.identify({
                identifiers: {
                    email_id: e
                },
                attributes: t
            })
        })
    } catch (e) {
        ye("Error in BrevoUtils.identify", e)
    }
}, ne.viewPage = e => {
    const t = {};
    ne.setPropertiesPayload(t) && (window.sendinblue ? window.sendinblue.page(e) : window.Brevo && window.Brevo.push(["page", e || window.location.pathname, t]))
}, ne.viewCategory = e => {
    const t = {};
    ne.setPropertiesPayload(t) && (window.sendinblue ? window.sendinblue.ecommerce.viewCategory(String(e)) : window.Brevo && window.Brevo.push(["viewCategory", String(e), t]))
}, ne.search = (e, t) => {
    const i = {};
    ne.setPropertiesPayload(i) && (window.sendinblue ? window.sendinblue.ecommerce.search(e, t) : window.Brevo && window.Brevo.push(["search", e, t, i]))
}, ne.viewProduct = e => {
    const t = {};
    ne.setPropertiesPayload(t) && (window.sendinblue ? window.sendinblue.ecommerce.viewProduct(String(e)) : window.Brevo && window.Brevo.push(["viewProduct", String(e), t]))
};
const oe = function() {
    function e(e) {
        e = e || {};
        const t = {
            url: location.href,
            headers: {
                "User-Agent": navigator.userAgent
            }
        };
        return {
            event_id: "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                var t = 16 * Math.random() | 0;
                return ("x" === e ? t : 3 & t | 8).toString(16)
            }),
            platform: "javascript",
            release: "8a6826f",
            extra: e,
            request: t
        }
    }

    function t(e) {
        return Math.random() < .95 ? Promise.resolve() : (ye("Logging error to Sentry:", e), fetch("https://o79286.ingest.sentry.io/api/1527936/store/?sentry_version=7&sentry_key=8f53de1cdf86490fb8e55518e1a5d035", {
            method: "post",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(e)
        }))
    }

    function i(i, n) {
        const o = e(n);
        return o.message = i, t(o)
    }
    return {
        log: i,
        logException: function(n, o) {
            if (n) try {
                (o = o || {}).errorDump = {
                    str: String(n),
                    stack: n && n.stack
                };
                const i = e(o);
                return i.exception = function(e) {
                    const t = e.stack || "";
                    if (!t) return;
                    const i = t.split("\n").map(e => e.trim()).filter(e => e.startsWith("at")).map(function(e) {
                        let t = "",
                            i = 0,
                            n = 0,
                            o = "";
                        const r = e.split(/[ ]+/);
                        if ("at" === r[0].trim() && r.length > 1) {
                            let e = "";
                            r.length > 2 ? (t = r[1], e = r[2]) : e = r[1], e = e.replace("(", "").replace(")", "");
                            const s = e.split(":");
                            s.length > 1 && (i = parseInt(s[s.length - 1], 0), n = parseInt(s[s.length - 2], 0), o = s.slice(0, s.length - 2).join(":"))
                        }
                        return {
                            in_app: !0,
                            function: t,
                            colno: Number(i) || i,
                            lineno: Number(n) || n,
                            filename: o
                        }
                    });
                    return i.reverse(), {
                        values: [{
                            type: e.name || "Error",
                            value: e.message || String(e),
                            stacktrace: {
                                frames: i
                            }
                        }]
                    }
                }(n), t(i)
            } catch (e) {
                i(String(e), e), i(String(n), n)
            }
        }
    }
}();

function re({
    position: e,
    device: t,
    customConfig: i,
    isExpanded: n
}) {
    if ("desktop" === t) {
        const t = "15px",
            o = "15px",
            r = "15px",
            s = "15px",
            a = 68,
            c = `calc(50% - ${568}px / 2)`,
            l = `calc(50% - ${a}px / 2)`,
            u = `calc(50% - ${a}px / 2)`;
        if (i.hasOwnProperty("bottom") && 25 === i.bottom && 15 === i.left && "auto" === i.right) switch (e) {
            case "bottom-left":
                return {
                    bottom: o,
                    left: r
                };
            case "bottom-right":
                return {
                    bottom: o,
                    right: s
                };
            case "bottom-center":
                return n ? {
                    bottom: o,
                    left: c
                } : {
                    bottom: o,
                    left: l
                };
            case "top-left":
                return {
                    top: t,
                    left: r
                };
            case "top-right":
                return {
                    top: t,
                    right: s
                };
            case "top-center":
                return n ? {
                    top: t,
                    left: c
                } : {
                    top: t,
                    left: l
                };
            case "center-left":
                return {
                    top: u,
                    left: r
                };
            case "center-right":
                return {
                    top: u,
                    right: s
                };
            default:
                return i
        }
        let d = {
            left: r
        };
        for (let e in i) d[e] = `${i[e]}px`;
        return d
    }
    if ("mobile" === t) {
        const t = "8px",
            n = "8px",
            o = "8px",
            r = "8px",
            s = `calc(50% - ${48}px / 2)`;
        if (i.hasOwnProperty("bottom") && i.hasOwnProperty("left") && 15 === i.bottom && 15 === i.left) switch (e) {
            case "bottom-left":
                return {
                    bottom: n,
                    left: o
                };
            case "bottom-right":
                return {
                    bottom: n,
                    right: r
                };
            case "top-left":
                return {
                    top: t,
                    left: o
                };
            case "top-right":
                return {
                    top: t,
                    right: r
                };
            case "center-left":
                return {
                    top: s,
                    left: o
                };
            case "center-right":
                return {
                    top: s,
                    right: r
                };
            default:
                return i
        }
        let a = {
            isCustomConfig: !0
        };
        for (let e in i) a[e] = `${i[e]}px`;
        return a
    }
}

function se(e) {
    let t = document.implementation.createHTMLDocument();
    return t.body.innerHTML = e, t.body.children[0]
}

function ae() {
    let e = navigator.userAgent;
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|mobile|CriOS/i.test(e)
}

function ce() {
    try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone
    } catch (e) {
        return null
    }
}

function le(e) {
    return [...new URLSearchParams(e).entries()].reduce((e, [t, i]) => Object.assign(Object.assign({}, e), {
        [t]: i
    }), {})
}

function ue(e, t = null) {
    t || (t = window.location.href);
    return le(new URL(t).search)[e]
}
const de = ({
    ua: e,
    maxTouchPoints: t
}) => {
    if (!(/iPad|iPhone|iPod|Mac OS X/.test(e) && t > 0)) return !1;
    const i = e.match(/EdgiOS\/(\d+\.\d+)/);
    if (i && i.length >= 2) {
        return parseFloat(i[1]) >= 112
    }
    const n = e.match(/Version\/(\d+\.\d+)/);
    if (n && n.length >= 2) {
        return parseFloat(n[1]) >= 16.4
    }
    const o = e.match(/CPU iPhone OS (\d+_\d+)/);
    if (o && o.length >= 2) {
        return parseFloat(o[1].replace("_", ".")) >= 16.4
    }
    return !1
};

function pe() {
    let e = navigator.userAgent,
        t = e.search("Firefox") >= 0,
        n = !!window.chrome;
    const o = void 0 !== window.PushManager,
        r = de({
            ua: e,
            maxTouchPoints: navigator.maxTouchPoints
        });
    let s = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream && !r,
        a = !!window.safari;
    return {
        isiOS: r,
        isSafari: a,
        isApnsSafari: a && !o,
        isFirefox: t,
        isChrome: n,
        isOldIOS: s,
        name: n ? i.CHROME : a ? i.SAFARI : t ? i.FIREFOX : i.OTHER,
        isAndroid: /(android)/i.test(e.toLowerCase())
    }
}

function he(e) {
    const t = (e + "=".repeat((4 - e.length % 4) % 4)).replace(/\-/g, "+").replace(/_/g, "/"),
        i = window.atob(t),
        n = new Uint8Array(i.length);
    for (let e = 0; e < i.length; ++e) n[e] = i.charCodeAt(e);
    return n
}

function ge({
    method: e = "GET",
    url: t,
    contentType: i = "application/json",
    acceptType: n = "application/json",
    payload: o
}) {
    return new Promise((r, s) => {
        let a = new XMLHttpRequest;
        a.open(e, t, !0), a.setRequestHeader("Content-Type", i), a.setRequestHeader("Accept", n), o ? a.send(i.match(/json/) ? JSON.stringify(o) : o) : a.send(), a.onload = function() {
            let e = a.responseText;
            if (a.status >= 200 && a.status < 400) {
                const t = n.match(/json/) ? JSON.parse(e) : e;
                r(t)
            } else s(e)
        }
    })
}

function me(e = 7) {
    for (var t = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-", i = "", n = e; n--;) i += t[~~(64 * Math.random())];
    return i
}

function fe({
    name: e,
    value: t
}) {
    document.cookie = `${e}=${encodeURIComponent(t)};domain=${window.location.hostname}`
}

function we({
    name: e,
    value: t,
    days: i = 1,
    path: n = "/"
}) {
    const o = new Date(Date.now() + 864e5 * i).toUTCString();
    document.cookie = e + "=" + encodeURIComponent(t) + "; expires=" + o + "; path=" + n
}

function be(e) {
    return document.cookie.split("; ").reduce((t, i) => {
        const n = i.split("=");
        return n[0] === e ? decodeURIComponent(n[1]) : t
    }, "")
}

function _e(e, t) {
    we({
        name: e,
        value: "",
        days: -1,
        path: t
    })
}

function Se() {
    const e = document.createElement("div");
    return document.body.appendChild(e), "rtl" === window.getComputedStyle(e).direction
}
const ve = [];

function ye(...e) {
    const t = console;
    ve.push(e);
    const i = "undefined" != typeof localStorage,
        n = "undefined" != typeof location;
    (i && localStorage.getItem("pushowl_log_level") === c.DEBUG || n && location.href.match(/poTaskType=debug/)) && t.log("%c🦉PushOwl", "background: #fb446a; color: white; padding: 2px 0.5em; border-radius: 0.5em;", ...e)
}

function Ee(e, t) {
    const i = console;
    ve.push([e, t]);
    const n = "undefined" != typeof localStorage,
        o = "undefined" != typeof location;
    (n && localStorage.getItem("pushowl_log_level") === c.DEBUG || o && location.href.match(/poTaskType=debug/)) && (e && ye(e), i.table(t))
}

function Ie() {
    const [e, t] = navigator.language.split("-");
    return {
        language: e,
        region: t
    }
}

function Te(e, t = {}) {
    if (navigator.userAgent.match(/Instagram|FBAN/)) return;
    if (R(e)) return;
    if ([d.NOTIFICATION_PERMISSION.DEFAULT, d.NOTIFICATION_PERMISSION.DENIED, r.NOTIFICATION_NOT_DEFINED, r.OLD_IOS_DEVICE, r.MICROSOFT_EDGE, r.NO_SERVICE_WORKER, r.INCOGNITO, r.NO_FILE_SYSTEM, r.LOCALSTORAGE_NOT_AVAILABLE].includes(e)) return;
    let i, n = "";
    window.pushowl && (n = window.pushowl.getSubdomain ? window.pushowl.getSubdomain() : window.pushowl.subdomain), "string" == typeof e ? (i = new Error(e), i.name = e) : i = e, oe.logException(i, Object.assign({
        breadcrumbs: ve,
        subdomain: n,
        url: window.location.href
    }, t))
}
const Oe = (e, t = !1) => {
        if (t) {
            let t;
            return t = e < 1e3 && e % 1 != 0 ? Math.round(100 * e) : Math.round(e), t
        }
        return "number" == typeof e ? e / 100 : e
    },
    Ne = e => {
        const t = (e => 2 === Object.keys(e).length && e.hasOwnProperty("items") && (e.hasOwnProperty("token") || e.hasOwnProperty("checkout_token")))(e),
            i = {
                id: void 0,
                data: void 0,
                checkout_url: void 0
            },
            n = 0 === e.item_count ? l.CART_DELETED : l.CART_UPDATED,
            o = !t && e.id ? e.id : e.token || e.checkout_token;
        if (o && (i.id = `cart:${o}`, i.data = e.id && !t ? e : (e => ({
                affiliation: H.subdomain,
                currency: Oe(e.currency),
                discount: Oe(e.total_discount),
                total: Oe(e.total_price),
                discount_taxinc: "",
                items: e.items.map(e => ({
                    available_now: !0,
                    category: null,
                    description_short: e.product_description,
                    disc_amount: Oe(e.discounted_price),
                    disc_amount_taxinc: "",
                    disc_rate: "",
                    id: e.id,
                    image: e.image,
                    name: e.title,
                    price: Oe(e.price),
                    price_predisc: "",
                    price_predisc_taxinc: "",
                    price_taxinc: "",
                    quantity: e.quantity,
                    size: "",
                    sku: e.sku,
                    tax_amount: "",
                    tax_name: "",
                    tax_rate: "",
                    url: `${window.location.origin}${e.url}`,
                    variant_id: e.variant_id,
                    variant_id_name: e.variant_title
                })),
                shipping: "",
                shipping_taxinc: "",
                subtotal: "",
                subtotal_predisc: "",
                subtotal_predisc_taxinc: "",
                subtotal_taxinc: "",
                tax: "",
                total_before_tax: "",
                url: `${window.location.origin}/cart`
            }))(e)), n === l.CART_UPDATED && (i || {}).data) {
            const e = i.data.items.reduce((e, t) => e ? `${e},${t.variant_id}:${t.quantity}` : `${t.variant_id}:${t.quantity}`, "");
            i.data.checkout_url = `${window.location.origin}/cart/${e}`
        }
        ne.track({
            eventName: n,
            eventData: i
        })
    },
    Ce = e => {
        try {
            const t = new URL(e),
                i = new URLSearchParams(t.search),
                n = new URLSearchParams;
            return i.forEach((e, t) => {
                t.startsWith("utm_") || n.append(t, e)
            }), t.search = n.toString(), t.toString()
        } catch (t) {
            return e
        }
    },
    Me = new RegExp("^(?:https?:)?//[^/]+|[?#].*$|/(?:\\d+|[0-9a-f]{24}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}|(?!v\\d+$)(?=\\d*[a-z])(?=[a-z]*\\d)[a-z\\d]{4,})(?=/|[?#]|$)", "gi"),
    Ae = () => `${window.location.origin}/policies/privacy-policy`,
    Le = () => `${window.location.origin}/policies/terms-of-service`;
var Pe;
class ke {
    static subscriptionConfirmation(e, t, i) {
        return "email" !== e ? null : i.subscriptionConfirmation ? {
            shouldIdentify: !1,
            channels: ["email"],
            identifier: "email",
            reason: "Subscription confirmation is enabled"
        } : null
    }
    static primaryIdentifier(e, t, i) {
        const {
            identifiers: n
        } = i, o = {
            email: 1,
            phone: 2
        }, r = {
            email: ["email"],
            phone: ["sms"]
        };
        let s = null,
            a = 1 / 0;
        for (const [e, t] of Object.entries(o)) {
            const i = e;
            n[i] && t < a && (s = i, a = t)
        }
        if (s && !(s === e)) {
            if ("phone" === e && !i.currentStoredEmail) {
                return {
                    shouldIdentify: !0,
                    channels: r[e],
                    identifier: e,
                    reason: "Primary identifier not available"
                }
            }
            return {
                shouldIdentify: !1,
                channels: [t[0]],
                identifier: e,
                reason: `Primary identifier '${s}' is available`
            }
        }
        return {
            shouldIdentify: !0,
            channels: r[e],
            identifier: e,
            reason: `Primary identifier '${e}' - will identify`
        }
    }
    static deduplication(e, t, i) {
        const n = i.identifiers[e];
        if (!n) return null;
        const o = [];
        for (const i of t) {
            const t = `${e}:${i}`;
            this.identifiedCombinations.get(t) !== n && (o.push(i), this.identifiedCombinations.set(t, n))
        }
        return o.length > 0 ? {
            shouldIdentify: !0,
            channels: o,
            identifier: e,
            reason: `New value detected for channels: ${o.join(", ")}`
        } : {
            shouldIdentify: !1,
            channels: [],
            identifier: e,
            reason: "Already identified with this value"
        }
    }
}
Pe = ke, ke.identifiedCombinations = new Map, ke.rules = [Pe.subscriptionConfirmation, Pe.primaryIdentifier, Pe.deduplication];
class De {
    static evaluate(e, t, i) {
        const n = ke.rules;
        for (const o of n) {
            const n = o(e, t, i);
            if (null !== n) return n
        }
        return {
            shouldIdentify: !0,
            channels: t,
            identifier: e,
            reason: "Default: No rules matched, identifying on all available channels"
        }
    }
}
class Re {
    static identify(e, i) {
        return t(this, void 0, void 0, function*() {
            try {
                const {
                    email: t,
                    cuid: n,
                    properties: o = {}
                } = e, r = i.brevo_ma_key;
                if (!r || "enabled" !== i.flags.brevo_email) return;
                const s = i.cuid || n;
                yield fetch("https://in-automate.brevo.com/p", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        key: r,
                        email_id: t,
                        contact: Object.assign({
                            email: t
                        }, o),
                        cuid: s,
                        sib_type: "identify"
                    })
                })
            } catch (e) {}
        })
    }
}
class je {
    constructor() {
        this.type = "email"
    }
    normalize(e) {
        return (e || "").trim().toLowerCase()
    }
    hasChanged(e, t) {
        return e !== t.currentStoredEmail
    }
    store(e, t) {
        t.localStorage ? t.localStorage.setItem("pushowl_email", e) : x.email = e
    }
    getAvailableChannels() {
        return ["email"]
    }
    identify(e, i, n) {
        var o, r;
        return t(this, void 0, void 0, function*() {
            const t = Array.isArray(i) ? i : [i];
            if ("email" !== t[0]) throw new Error(`Email identifier does not support ${t[0]} channel`);
            const s = Object.assign({
                subscribe_url: (null === (r = null === (o = n.window) || void 0 === o ? void 0 : o.location) || void 0 === r ? void 0 : r.href) || ""
            }, n.properties);
            n.brevoConfig ? yield Re.identify({
                email: e,
                properties: s
            }, n.brevoConfig): ne.identify(e, s)
        })
    }
    setIdentifier(e, t) {
        if ("email" !== t) throw new Error(`Email identifier does not support ${t} channel`);
        ne.emailId = e
    }
}

function xe(e, t, i, n, o, r, s) {
    try {
        var a = e[r](s),
            c = a.value
    } catch (e) {
        return void i(e)
    }
    a.done ? t(c) : Promise.resolve(c).then(n, o)
}

function Ue(e) {
    return function() {
        var t = this,
            i = arguments;
        return new Promise(function(n, o) {
            var r = e.apply(t, i);

            function s(e) {
                xe(r, n, o, s, a, "next", e)
            }

            function a(e) {
                xe(r, n, o, s, a, "throw", e)
            }
            s(void 0)
        })
    }
}

function Be(e, t, i) {
    return (t = function(e) {
        var t = function(e, t) {
            if ("object" != typeof e || !e) return e;
            var i = e[Symbol.toPrimitive];
            if (void 0 !== i) {
                var n = i.call(e, t || "default");
                if ("object" != typeof n) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return ("string" === t ? String : Number)(e)
        }(e, "string");
        return "symbol" == typeof t ? t : t + ""
    }(t)) in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e
}

function Fe(e, t) {
    var i = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        t && (n = n.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        })), i.push.apply(i, n)
    }
    return i
}

function Ye(e) {
    for (var t = 1; t < arguments.length; t++) {
        var i = null != arguments[t] ? arguments[t] : {};
        t % 2 ? Fe(Object(i), !0).forEach(function(t) {
            Be(e, t, i[t])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : Fe(Object(i)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
        })
    }
    return e
}
class He {
    static _request(e) {
        return t(this, void 0, void 0, function*() {
            return yield F(e)
        })
    }
    static get(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "GET"
        }))
    }
    static post(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "POST"
        }))
    }
    static put(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "PUT"
        }))
    }
}
class ze {
    static createRequestObj(e) {
        let t = e;
        return void 0 === e.id && (t = Object.assign({
            id: me()
        }, e)), t
    }
    static _retryRequest(e) {
        return t(this, void 0, void 0, function*() {
            const t = Object.assign(Object.assign({}, e), {
                retryCount: ((null == e ? void 0 : e.retryCount) || 0) + 1
            });
            if (t.retryCount > 5) {
                return Te("APIRequestSimpleRetry", {
                    request: t,
                    connectionType: navigator.connection ? navigator.connection.effectiveType : "NA"
                }), Promise.reject()
            }
            const i = this.createRequestObj(t);
            setTimeout(() => {
                this._request(i)
            }, 1e3 * i.retryCount)
        })
    }
    static _request(e) {
        var i, n, o;
        return t(this, void 0, void 0, function*() {
            try {
                return yield F(e)
            } catch (t) {
                if (R(t)) return this._retryRequest(e); {
                    const r = null !== (i = null == t ? void 0 : t.status) && void 0 !== i ? i : "n/a",
                        s = (e => {
                            try {
                                if (!e) return "/";
                                const i = e.replace(Me, e => e.startsWith("/") ? "/:id" : "").replace(/\/\/+/g, "/"),
                                    n = H.subdomain;
                                return (t = n ? i.replace(new RegExp(`/${n}(?=/|$)`, "g"), "/:subdomain") : i).length > 1 && t.endsWith("/") ? t.slice(0, -1) : t || "/"
                            } catch (e) {
                                return Te(e), "/"
                            }
                            var t
                        })(null !== (n = e.url) && void 0 !== n ? n : `${U()}${null!==(o=e.path)&&void 0!==o?o:""}`);
                    Te(`APIRequestSimpleRetryError [${e.method}] ${s} (status=${r})`, {
                        request: e,
                        status: r,
                        responseBody: null == t ? void 0 : t.responseBody,
                        url: null == t ? void 0 : t.url,
                        method: null == t ? void 0 : t.method,
                        path: null == t ? void 0 : t.path,
                        payload: null == t ? void 0 : t.payload,
                        contentType: null == t ? void 0 : t.contentType,
                        acceptType: null == t ? void 0 : t.acceptType,
                        retryCount: null == t ? void 0 : t.retryCount
                    }), Promise.reject(t)
                }
            }
        })
    }
    static get(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "GET"
        }))
    }
    static post(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "POST"
        }))
    }
    static put(e) {
        return this._request(Object.assign(Object.assign({}, e), {
            method: "PUT"
        }))
    }
}
class Ke {
    constructor() {
        var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
            i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        this.window = t || ("undefined" != typeof window ? window : null), this.document = i || (null === (e = this.window) || void 0 === e ? void 0 : e.document) || ("undefined" != typeof document ? document : null);
        var {
            subdomain: n
        } = H;
        this.endpoint = H.apiEndpoint, this.subscriber_refresh_endpoint = "".concat(this.endpoint, "/api/v1/accounts/").concat(n, "/subscriber/refresh/"), this.checkout_sync_endpoint = "".concat(this.endpoint, "/api/v1/").concat(n, "/subscriber/event/checkout-sync/")
    }
    initStorage() {
        var e, t, i, n;
        (G.set("subscriber_refresh_endpoint", this.subscriber_refresh_endpoint), V.landingPageURL) || (V.landingPageURL = (null === (e = this.document) || void 0 === e ? void 0 : e.URL) || "");
        V.referrer || (V.referrer = (null === (t = this.document) || void 0 === t ? void 0 : t.referrer) || "");
        V.landingPageURLParams || (V.landingPageURLParams = (null === (i = this.window) || void 0 === i || null === (i = i.location) || void 0 === i ? void 0 : i.search) || "");
        x.originalURLParams || (x.originalURLParams = (null === (n = this.window) || void 0 === n || null === (n = n.location) || void 0 === n ? void 0 : n.search) || "")
    }
    config() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
            t = "undefined" != typeof window ? window.pushowlConfigUrl : null,
            i = t && t.length > 0 && ((e, t) => {
                try {
                    return new URL(e).hostname.includes(t)
                } catch (e) {
                    return !1
                }
            })(t, "cdn.shopify.com"),
            n = "shopify" === ("undefined" != typeof window ? window.pushowlConfigSource : "pushowl") && i,
            o = "headless" === H.mode,
            r = ["fnova"],
            s = () => o && r.includes(H.subdomain) ? ze.get({
                url: "".concat(H.configApiEndpoint, "/api/v1/").concat(H.subdomain, "/subscriber/config/widget/?guid=").concat(H.guid)
            }) : o ? He.get({
                path: "/subscriber/config/widget/?guid=".concat(H.guid)
            }) : ze.get({
                url: "".concat(H.configApiEndpoint, "/api/v1/").concat(H.subdomain, "/subscriber/config/widget/?guid=").concat(H.guid)
            });
        return o || e ? s() : n ? ze.get({
            url: t,
            appendPlatform: !1,
            contentType: "text/plain",
            acceptType: "text/plain"
        }).then(e => {
            try {
                return e && "object" == typeof e && void 0 !== e.result ? {
                    result: "string" == typeof e.result ? JSON.parse(e.result) : e.result
                } : {
                    result: "string" == typeof e ? JSON.parse(e) : e
                }
            } catch (e) {
                var i = {
                    cdnUrl: t,
                    source: "fetchCDNConfig",
                    message: "CDN config JSON parse failed"
                };
                try {
                    Te(e, i)
                } catch (t) {
                    ye("Error logging parse failure", t, e, i)
                }
                return s()
            }
        }).catch(e => {
            var i = new Error("Error fetching CDN config from " + t);
            e && (i.message = "Error fetching CDN config from " + t + ": " + e.message, i.stack = e.stack);
            var n = {
                cdnUrl: t,
                source: "fetchCDNConfig",
                subdomain: H.subdomain,
                originalError: JSON.stringify(e)
            };
            try {
                Te(i, n)
            } catch (e) {
                ye("Error logging failed", e, i, n)
            }
            return s()
        }) : s()
    }
    sendSubscription(e) {
        var t, i, n, o, s, a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            c = arguments.length > 2 ? arguments[2] : void 0,
            l = arguments.length > 3 ? arguments[3] : void 0,
            u = arguments.length > 4 ? arguments[4] : void 0,
            d = new V;
        if (d.config && d.config.flags && "enabled" === d.config.flags.disable_resync && a) return Promise.reject(r.DISABLED_RESYNC);
        var p = {};
        V.landingPageURLParams.slice(1).split("&").filter(e => e.includes("utm_")).forEach(e => {
            var [t, i] = e.split("=");
            p[t] = i
        });
        var h = {};
        x.originalURLParams.slice(1).split("&").filter(e => e.includes("po_")).forEach(e => {
            var [t, i] = e.split("=");
            h[t] = i
        });
        var g = (null === (t = this.window) || void 0 === t || null === (t = t.location) || void 0 === t ? void 0 : t.href) || "",
            m = new URLSearchParams((null === (i = this.window) || void 0 === i || null === (i = i.location) || void 0 === i ? void 0 : i.search) || ""),
            f = !0;
        if (m.get("po_url") && (f = !1, g = m.get("po_url")), pe().isOldIOS) return ye("PushOwl does not support iOS before 16.4", "platform: ".concat(navigator.platform), "Browser: ".concat(pe().name)), Promise.reject(r.OLD_IOS_DEVICE);
        var w = {
            subscription: e,
            browser: pe().name,
            previous_token: x.subscriberToken,
            website_push_id: c || H.webPushId,
            customer_id: d.config.privacy ? te.customerId : null,
            language: (null === (n = this.window) || void 0 === n || null === (n = n.navigator) || void 0 === n ? void 0 : n.language) || "",
            timezone: ce(),
            dispatch_method: pe().isApnsSafari ? "apns" : "vapid",
            user_agent: navigator.userAgent,
            guid: H.guid,
            optin_seen_count: d.optinSeenCount,
            context: Ye(Ye({
                isPushowlThemeAppExtentionEnabled: !(null === (o = this.window) || void 0 === o || !o.isPushowlThemeAppExtentionEnabled),
                isiOS: pe().isiOS,
                is_resync: a,
                subscribe_url: g,
                session_token: x.sessionToken,
                visitor_token: x.visitorToken,
                sib_visitor_id: H.visitorId,
                widget_source: null === (s = this.window) || void 0 === s ? void 0 : s.poSubscriptionSource,
                worker_available: f
            }, p), {}, {
                permanent: Ye({}, h),
                temporary: {
                    referrer: V.referrer,
                    landing_url: V.landingPageURL
                }
            }),
            source: l,
            source_id: u
        };
        return ze.post({
            url: "".concat(H.apiEndpoint, "/api/v2/accounts/").concat(H.subdomain, "/subscribers/webpush/"),
            payload: w
        }).then(e => (e && e.result || ye("Invalid /subscribe response. response:", e), e.result.token)).catch(() => Promise.reject("Send Subscription API Failed"))
    }
    refreshSubscription(e, t, i) {
        var n, o = {
            previous_token: e,
            previous_subscription: t,
            current_subscription: i
        };
        return o.context = {
            subscribe_url: (null === (n = this.window) || void 0 === n || null === (n = n.location) || void 0 === n ? void 0 : n.href) || "",
            session_token: x.sessionToken,
            visitor_token: x.visitorToken,
            sib_visitor_id: H.visitorId
        }, pe().isOldIOS ? (ye("PushOwl does not support iOS before 16.4", "platform: ".concat(navigator.platform), "Browser: ".concat(pe().name)), Promise.reject(r.OLD_IOS_DEVICE)) : He.post({
            url: this.subscriber_refresh_endpoint,
            payload: o
        }).then(e => e.result.token).catch(() => Promise.reject("Refresh Subscription API Failed"))
    }
    syncSubscriber(e) {
        var t, i = {
            data: [{
                key: "customer_id",
                value: e || te.customerId
            }],
            token: x.subscriberToken,
            context: {
                subscribe_url: (null === (t = this.window) || void 0 === t || null === (t = t.location) || void 0 === t ? void 0 : t.href) || "",
                session_token: x.sessionToken,
                visitor_token: x.visitorToken
            }
        };
        return ze.put({
            url: "".concat(H.apiEndpoint, "/api/v1/accounts/").concat(H.subdomain, "/subscriber/"),
            payload: i
        })
    }
    syncCart(e, t) {
        var i, n, o = {
            customer_id: (new V).config.privacy && (t || te.customerId || x.syncedCustomerId) || null,
            cart_json: e,
            browser: pe().name,
            origin: (null === (i = this.window) || void 0 === i || null === (i = i.location) || void 0 === i ? void 0 : i.origin) || "",
            subscriber_token: x.subscriberToken,
            store_root: (((null === (n = this.window) || void 0 === n ? void 0 : n.Shopify) || {}).routes || {}).root || "/"
        };
        return o.subscriber_token ? He.post({
            path: "/subscriber/event/cart-sync/",
            payload: o
        }) : Promise.reject(s.NO_SUBSCRIBER_TOKEN)
    }
    syncProductView(e) {
        var t;
        e.variants && e.variants.length > 0 && (e.variants[0].price = Oe(e.variants[0].price));
        var i = {
            subscriber_token: x.subscriberToken,
            session: x.sessionToken,
            viewed_time: ~~(Date.now() / 1e3),
            product_data: e,
            store_root: (((null === (t = this.window) || void 0 === t ? void 0 : t.Shopify) || {}).routes || {}).root || "/"
        };
        return He.post({
            path: "/subscriber/event/product-view/",
            payload: i
        })
    }
    sendEvent(e, t) {
        return Ue(function*() {
            return ze.post({
                path: "/subscriber/event/".concat(e, "/"),
                payload: t
            }).catch(e => Promise.reject("Event Update failed"))
        })()
    }
    unsubscribe(e) {
        return e ? Y.post({
            url: "".concat(H.apiEndpoint, "/api/v1/accounts/").concat(H.subdomain, "/subscriber/unsubscribe/"),
            payload: {
                token: e,
                sib_visitor_id: H.visitorId
            }
        }) : Promise.reject(s.NO_SUBSCRIBER_TOKEN)
    }
    syncSubscriberTokenAndCheckoutId(e) {
        var t = JSON.stringify({
            subscriber_token: x.subscriberToken,
            checkout_token: e
        });
        navigator.sendBeacon(this.checkout_sync_endpoint, t)
    }
    debugLog(e) {
        return Y.post({
            path: "/subscriber/debug/",
            payload: e
        })
    }
    subscribeThroughPopup(e) {
        var t, {
            subscriptionData: i,
            flowId: n,
            nodeId: o,
            source: r = "optin_flows"
        } = e;
        (t = "embedded_forms" === r ? x.embeddedSubscriberToken : x.optinSubscriberToken) || (t = localStorage.getItem(d.STORAGE_KEYS.SUBSCRIBER_TOKEN));
        var s = {
            subscription_data: i,
            token: t,
            source: r,
            source_id: o
        };
        return He.post({
            path: "/dashboard/optin-flows/".concat(n, "/subscribers/"),
            payload: s
        })
    }
    subscribeThroughBISForm(e) {
        var {
            channel: t,
            subscriptionData: i,
            variantId: n
        } = e, o = Ye({
            channel: t,
            variant_id: n
        }, i);
        return He.post({
            url: "".concat(H.apiEndpoint, "/api/v1/").concat(H.subdomain, "/subscriptions/back-in-stock/"),
            payload: o
        })
    }
    identifyBrevoContactThroughPhoneNumber(e, t) {
        var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
            n = (new V).config.brevo_ma_key,
            o = be("sib_cuid"),
            r = {
                sms: "mailin-sms.com",
                whatsapp: "mailin-wa.com"
            },
            s = Array.isArray(t) ? t : [t];
        if (n && o && e && s.length > 0) {
            var a, c = s.includes("sms") ? r.sms : r[s[0]],
                l = x.email ? x.email : "".concat(e.replace(/\D/g, ""), "@").concat(c);
            ne.emailId || (ne.emailId = l);
            var u = {};
            return s.forEach(t => {
                "sms" === t ? u.sms = e : "whatsapp" === t && (u.whatsapp = e)
            }), He.post({
                url: "https://in-automate.brevo.com/p",
                appendPlatform: !1,
                payload: {
                    key: n,
                    sib_type: "identify",
                    cuid: o,
                    ma_url: (null === (a = this.document) || void 0 === a || null === (a = a.location) || void 0 === a ? void 0 : a.href) || "",
                    contact: Ye(Ye({}, i), u),
                    email_id: l
                }
            })
        }
    }
}
class Ge {
    constructor() {
        this.type = "phone"
    }
    normalize(e) {
        const t = (e || "").trim();
        if (!t) return "";
        return t.replace(/^\+/, "").replace(/\D/g, "").length < 10 ? "" : t
    }
    hasChanged(e, t) {
        return e !== t.currentStoredPhone
    }
    store(e, t) {
        t.localStorage ? t.localStorage.setItem("pushowl_phone", e) : x.phone = e
    }
    getAvailableChannels() {
        return ["sms"]
    }
    identify(e, i, n) {
        var o, r, s;
        return t(this, void 0, void 0, function*() {
            const t = Object.assign({
                    subscribe_url: (null === (r = null === (o = n.window) || void 0 === o ? void 0 : o.location) || void 0 === r ? void 0 : r.href) || ""
                }, n.properties),
                a = Array.isArray(i) ? i : [i];
            for (const e of a)
                if ("sms" !== e && "whatsapp" !== e) throw new Error(`Phone identifier does not support ${e} channel`);
            const c = new Ke(n.window, null === (s = n.window) || void 0 === s ? void 0 : s.document);
            try {
                yield c.identifyBrevoContactThroughPhoneNumber(e, a, t)
            } catch (e) {}
        })
    }
    setIdentifier(e, t) {}
}
const Ve = new class {
    constructor(e = null, t = null) {
        var i;
        this.identifierRegistry = new Map([
            ["email", new je],
            ["phone", new Ge]
        ]), this.window = e || ("undefined" != typeof window ? window : null), this.localStorage = t || (null === (i = this.window) || void 0 === i ? void 0 : i.localStorage) || ("undefined" != typeof localStorage ? localStorage : null)
    }
    identify(e, i = {}, n) {
        var o;
        return t(this, void 0, void 0, function*() {
            ye("[ChannelIdentityManager] identify() called", {
                identifiers: e,
                properties: i,
                hasBrevoConfig: !!(null == n ? void 0 : n.brevoConfig)
            });
            const t = new V,
                r = Boolean(null === (o = null == t ? void 0 : t.config) || void 0 === o ? void 0 : o.subscription_confirmation),
                s = this.localStorage ? this.localStorage.getItem("pushowl_email") : x.email,
                a = this.localStorage ? this.localStorage.getItem("pushowl_phone") : x.phone;
            ye("[ChannelIdentityManager] Context setup", {
                subscriptionConfirmation: r,
                currentStoredEmail: s,
                currentStoredPhone: a
            });
            const c = {
                identifiers: e,
                properties: i,
                subscriptionConfirmation: r,
                currentStoredEmail: s,
                currentStoredPhone: a,
                window: this.window,
                brevoConfig: null == n ? void 0 : n.brevoConfig,
                localStorage: this.localStorage
            };
            for (const [e, t] of this.identifierRegistry) yield this.processIdentifier(e, t, c);
            ye("[ChannelIdentityManager] identify() completed")
        })
    }
    processIdentifier(e, i, n) {
        return t(this, void 0, void 0, function*() {
            const t = n.identifiers[e];
            if (ye(`[ChannelIdentityManager] Processing ${e}`, {
                    rawValue: t,
                    hasRawValue: !!t
                }), !t) return void ye(`[ChannelIdentityManager] Skipping ${e} - no raw value`);
            const o = i.normalize(t);
            if (ye(`[ChannelIdentityManager] Normalized ${e}`, {
                    normalizedValue: o,
                    isValid: !!o
                }), !o) return void ye(`[ChannelIdentityManager] Skipping ${e} - normalization failed`);
            const r = i.hasChanged(o, n);
            ye(`[ChannelIdentityManager] ${e} change detection`, {
                hasChanged: r
            }), r && (ye(`[ChannelIdentityManager] Storing ${e}`, {
                value: o
            }), i.store(o, n));
            const s = i.getAvailableChannels(),
                a = De.evaluate(e, s, n);
            ye(`[ChannelIdentityManager] Rule evaluation for ${e}`, Object.assign(Object.assign({}, a), {
                availableChannels: s
            })), a.shouldIdentify && a.channels.length > 0 ? (ye(`[ChannelIdentityManager] Identifying ${e} on channels`, {
                channels: a.channels
            }), yield i.identify(o, a.channels, n)) : !a.shouldIdentify && a.channels.length > 0 ? (ye(`[ChannelIdentityManager] Setting ${e} identifier only (no identify call)`, {
                channel: a.channels[0]
            }), i.setIdentifier(o, a.channels[0])) : ye(`[ChannelIdentityManager] No action taken for ${e}`, {
                reason: "No channels available or should not identify"
            })
        })
    }
};
class qe {
    constructor(e) {
        this.inclusions = e.inclusions, this.exclusions = e.exclusions
    }
}
class $e {
    constructor(e) {
        this.url = new qe(e.url)
    }
    processCondition(e, t) {
        var i = t.inclusions,
            n = t.exclusions;
        return i.some(t => new RegExp(t).test(e)) && !n.some(t => new RegExp(t).test(e))
    }
    processUrlActivationRule() {
        try {
            var e = this.url,
                t = window.location.href,
                i = this.processCondition(t, e);
            return ye("[Checking page url condition]", "Condition: ", this.url, " / Result: ".concat(i ? "✅" : "❌")), i
        } catch (e) {
            return !0
        }
    }
}
class We {
    constructor(e) {
        this.sku = e.sku || [], this.url = new qe(e.url)
    }
    processCondition(e, t) {
        var i = t.inclusions,
            n = t.exclusions;
        return i.some(t => new RegExp(t).test(e)) && !n.some(t => new RegExp(t).test(e))
    }
    processUrlActivationRule() {
        try {
            var e = this.url,
                t = window.location.href,
                i = this.processCondition(t, e);
            return ye("[Checking page url condition]", "Condition: ", this.url, " / Result: ".concat(i ? "✅" : "❌")), i
        } catch (e) {
            return !0
        }
    }
    processSKU(e) {
        return this.sku.includes(e)
    }
}
class Qe {
    constructor(e) {
        this.flyout = new at(e.flyout)
    }
}
class Je {
    constructor(e) {
        this.type = e.type, e.config && (this.config = e.config, this.config.overlay = new Xe(this.config.overlay))
    }
}
class Xe {
    constructor(e) {
        this.enabled = e.enabled, this.title = e.title, this.subtitle = e.description || e.subtitle, this.branding = e.branding
    }
}
class Ze {
    constructor(e) {
        this.money_format = e.money_format
    }
}
class et {
    constructor(e) {
        this.enabled = e.enabled, this.text = e.text
    }
}
class tt {
    constructor(e) {
        this.unsubscribe = new et(e.unsubscribe), this.access_data = new et(e.access_data), this.delete_data = new et(e.delete_data)
    }
}
class it {
    constructor(e) {
        this.enabled = e.enabled, this.message = e.message, this.actions = new tt(e.actions)
    }
}
class nt {
    constructor(e) {
        this.notification_preference = new it(e.notification_preference), this.customer_id = e.customer_id
    }
}
class ot {
    constructor(e) {
        this.bottom = e.bottom || 15, this.diameter = e.diameter || 68, this.left = e.left || 15, this.right = e.right || "auto"
    }
}
class rt {
    constructor(e) {
        this.bottom = e.bottom || 15, this.left = e.left || 15, this.diameter = e.diameter || 48
    }
}
class st {
    constructor(e) {
        this.desktop = new ot(e.desktop), this.mobile = new rt(e.mobile), this.color = e.color || "rgb(51, 51, 51)", this.overlay = e.overlay
    }
}
class at {
    constructor() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        this.enabled = e.enabled, this.is_viewed = e.is_viewed, this.title = e.title, this.buttonText = e.button_text || e.buttonText, this.postSubscriptionTitle = e.post_subscription_message || e.postSubscriptionTitle, this.theme = e.theme, this.position = e.position, this.overlay = e.overlay
    }
    static create_instance(e) {
        var t = new at;
        t.enabled = e.enabled, t.is_viewed = e.is_viewed;
        var i = e.metadata;
        return t.metadata = i, t.title = e.title || i.title, t.buttonText = e.buttonText || i.yes_button.text, t.postSubscriptionTitle = e.postSubscriptionTitle || i.post_subscription.post_subscription_widget.title, t
    }
}
class ct {
    constructor(e) {
        var t;
        e = this.preProcess(e), this.home = new Qe(e.home), this.optin = e.optin ? new Je(e.optin) : null, this.brevo_ma_key = e.brevo_ma_key, this.price_drop = at.create_instance(e.price_drop), this.back_in_stock = at.create_instance(e.back_in_stock), this.shop = new Ze(e.shop), this.abandoned_cart_enabled = e.abandoned_cart_enabled, this.browse_abandonment_enabled = e.browse_abandonment_enabled, this.optin_report_enabled = e.optin_report_enabled, this.is_beta = e.is_beta || !1, this.privacy = new nt(e.privacy), this.vapid_public_key = e.vapid_public_key, this.activation_rule = e.activation_rule && new $e(e.activation_rule), this.automation_rule = e.automation_rule && new We(e.automation_rule), this.flyout_config = e.flyout_config && new st(e.flyout_config), this.branding = void 0 === e.branding || e.branding, this.logo = e.logo, this.flags = e.flags, this.wid = e.wid, this.integrations = e.integrations, this.website_push_id = e.website_push_id, this.service_worker = e.service_worker, this.ios_prompt = e.ios_prompt, this.optin_flows = e.optin_flows, this.subscription_confirmation = e.subscription_confirmation, this.embedded_forms = e.embedded_forms, this.bis_embedded_forms = e.bis_embedded_forms, this.is_free_plan = null !== (t = e.is_free_plan) && void 0 !== t && t
    }
    preProcess(e) {
        var t = void 0 === e.branding || e.branding;
        return e.optin && e.optin.config && e.optin.config.overlay && (e.optin.config.overlay.branding = t), e
    }
}
var lt = {
    get(e) {
        var t = new V,
            i = new Ke;
        return new Promise(n => {
            var o = e ? null : t.config,
                r = e => "enabled" === e.flags.load_after_consent && window.Shopify && window.Shopify.customerPrivacy && window.Shopify.customerPrivacy.userCanBeTracked() || "enabled" !== e.flags.load_after_consent ? (t.config = e, i.initStorage(), n(e), !0) : "enabled" === e.flags.load_after_consent && (document.addEventListener("visitorConsentCollected", o => {
                    o.detail.marketingAllowed && (t.config = e, i.initStorage(), n(e))
                }), !0),
                s = () => i.config().then(e => {
                    var t = e && e.result ? e.result : e;
                    ye("Config fetched.", {
                        response: t
                    });
                    try {
                        var n = new ct(t),
                            o = r(n);
                        return ye(o ? "Config applied." : "Config not applied.", {
                            config: n
                        }), o
                    } catch (e) {
                        return ye("Invalid config payload from CDN; retrying via backend.", e), Te(e, {
                            message: "Invalid config payload from CDN"
                        }), i.config(!0).then(e => {
                            var t = e && e.result ? e.result : e;
                            ye("Config fetched via Backend after CDN failure.", {
                                response: t
                            });
                            var i = new ct(t),
                                n = r(i);
                            return ye(n ? "Config applied via Backend after CDN failure." : "Config not applied via Backend after CDN failure.", {
                                config: i
                            }), n
                        }).catch(e => (ye("Error on backend fetch/apply after CDN failure", e), Te(e, {
                            message: "Error on backend fetch/apply after CDN failure"
                        }), !1))
                    }
                }).catch(e => (ye("Error on fetching/applying config", e), Te(e), !1));
            if (o) {
                ye("Config fetched: from local cache.", o);
                try {
                    n(new ct(o))
                } catch (e) {
                    s()
                }
            } else s()
        })
    }
};

function ut(e) {
    var {
        subdomain: t
    } = e;
    return new Promise((e, i) => {
        "undefined" == typeof Storage && i(r.STORAGE_NOT_DEFINED), !0 !== function() {
            let e = "test";
            try {
                return localStorage.setItem(e, e), localStorage.removeItem(e), !0
            } catch (e) {
                return !1
            }
        }() && i(r.LOCALSTORAGE_NOT_AVAILABLE), /Edge/.test(navigator.userAgent) && i(r.MICROSOFT_EDGE), t || i(r.NO_SUBDOMAIN), e()
    })
}
var dt = () => void 0 === window.Notification ? (ye(r.NOTIFICATION_NOT_DEFINED), !1) : pe().isOldIOS || pe().isApnsSafari || "serviceWorker" in navigator ? pe().isOldIOS ? (ye(r.OLD_IOS_DEVICE), !1) : !(pe().isiOS && !navigator.standalone) || (ye(r.NOT_ADDED_TO_HOME_SCREEN), !1) : (ye(r.NO_SERVICE_WORKER), !1);

function pt(e, t, i) {
    var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
        o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
        r = new Ke;
    return new Promise((s, a) => {
        r.sendSubscription(e, t, i, n, o).then(t => {
            x.handlePostSubscription(e, t), fe({
                name: d.STORAGE_KEYS.SUBSCRIBER_TOKEN,
                value: t
            }), s(t)
        }).catch(e => {
            ye("🔴 Send Subscription Failed", e), a(e)
        })
    })
}
var ht = {
        validateOrSyncSubscription(e) {
            var {
                subscription: t,
                websitePushId: i
            } = e;
            return new Promise((e, n) => {
                var o = x.subscription;
                if (o)
                    if (t.endpoint === o.endpoint) e();
                    else {
                        var r = new Ke;
                        ye("Refreshing old subscription on server..."), r.refreshSubscription(x.subscriberToken, o, t).then(i => {
                            x.handlePostSubscription(t, i), fe({
                                name: d.STORAGE_KEYS.SUBSCRIBER_TOKEN,
                                value: i
                            }), e()
                        }).catch(e => {
                            n(e)
                        })
                    }
                else ye("Syncing new subscription to server"), pt(t, !1, i).then(e)
            })
        },
        verifySubscriber(e) {
            var {
                browserHandler: t
            } = e, i = new V;
            return ye("Verifying subscriber..."), new Promise((e, n) => {
                x.subscriberToken ? x.subscriberToken.match(/failed/i) ? (ye("🔴 Subscriber could not be verified. Reason: ", s.INVALID_SUBSCRIBER_TOKEN), n(s.INVALID_SUBSCRIBER_TOKEN)) : i.subscriptionVerified ? e() : pe().isApnsSafari ? t.isPermissionGranted ? e() : n() : H.isWorkerAvailable.then(i => {
                    i ? t.getSubscription().then(t => {
                        this.validateOrSyncSubscription({
                            subscription: t
                        }).then(() => {
                            e(), ye("🟢 Subscriber verified.")
                        }).catch(() => {
                            n(), ye("🔴 Subscriber could not be verified.")
                        })
                    }).catch((e, t) => {
                        n(e, t), ye("🔴 Subscription could not be fetched.", e, t)
                    }) : t.isPermissionGranted ? e() : n()
                }) : (n(s.NO_SUBSCRIBER_TOKEN), ye("🔴 Subscriber could not be verified. Reason: ", s.NO_SUBSCRIBER_TOKEN))
            })
        },
        handleSubscription(e) {
            var {
                browserHandler: t,
                resolve: i,
                reject: n,
                areWeResyncing: o,
                websitePushId: r,
                showHintScreenOnError: s,
                hintscreenHandler: a,
                enableHintScreen: c,
                source: l,
                source_id: u
            } = e, d = new V, p = new Date;
            t.getSubscription().then(e => {
                c && a.purge(), pt(e, o, r, l, u).then(() => {
                    var {
                        subscriberToken: e
                    } = x;
                    i({
                        subscriberToken: e
                    }), new BroadcastChannel("pushowl").postMessage({
                        subscriberToken: e,
                        subdomain: H.subdomain
                    })
                }).catch(n), o ? ye("🟢 Resync-subscription successfull. (bcoz permission was granted but didn't have a valid subscription)", e) : (ye("🟢 Subscription successfull", e), document.dispatchEvent(new Event("SubscribedToPushOwl")), this.trackBrowserPromptAnalytics(new Date - p, "allowed"))
            }).catch(e => {
                a && a.purge(), s && a.show(), d.isPermissionNotGranted = !0, ye("🔴 Subscription failed", e), o || this.trackBrowserPromptAnalytics(new Date - p, e), n(e)
            })
        },
        subscribe(e) {
            var {
                enableHintScreen: t = !1,
                hintScreenData: i = null,
                showHintScreenOnError: n = !1,
                websitePushId: o,
                browserHandler: r,
                source: s,
                source_id: a
            } = e, c = new V, l = r.isPermissionGranted;
            return new Promise((e, u) => {
                var d;
                t ?
                    import ("./PushowlHintScreenHandler.js").then(p => {
                        var {
                            PushowlHintScreenHandler: h
                        } = p;
                        (d = new h({
                            onDismiss: () => {
                                c.isPermissionNotGranted = !0, c.config.optin_report_enabled && window.poAnalytics.track("BrowserPromptOverlayDismissed", {
                                    optinSeenCount: c.optinSeenCount
                                })
                            }
                        })).show(i), this.handleSubscription({
                            browserHandler: r,
                            resolve: e,
                            reject: u,
                            areWeResyncing: l,
                            websitePushId: o,
                            showHintScreenOnError: n,
                            hintscreenHandler: d,
                            enableHintScreen: t,
                            source: s,
                            source_id: a
                        })
                    }) : this.handleSubscription({
                        browserHandler: r,
                        resolve: e,
                        reject: u,
                        areWeResyncing: l,
                        websitePushId: o,
                        showHintScreenOnError: n,
                        hintscreenHandler: null,
                        enableHintScreen: t,
                        source: s,
                        source_id: a
                    })
            }).catch(e => {
                ye("Error encountered in loading Pushowl Hint Screen: ".concat(e.message))
            })
        },
        subscribeIfNotAlready(e) {
            var {
                enableHintScreen: t = !1,
                showHintScreenOnError: i = !0,
                websitePushId: n,
                browserHandler: o,
                hintScreenData: r = null
            } = e;
            return new Promise((e, s) => {
                o.isPermissionGranted ? x.subscriberToken ? e(!0) : this.subscribe({
                    enableHintScreen: !1,
                    showHintScreenOnError: !1,
                    websitePushId: n,
                    browserHandler: o,
                    hintScreenData: r
                }).then(() => e(!0)).catch(e => s(e)) : this.subscribe({
                    enableHintScreen: t,
                    showHintScreenOnError: i,
                    websitePushId: n,
                    browserHandler: o,
                    hintScreenData: r
                }).then(() => e(!0)).catch(e => s(e))
            })
        },
        update(e, t) {
            var i = new Ke;
            return t.subscriber_token = x.subscriberToken, t.subscriber_token ? i.sendEvent(e, t) : Promise.reject(s.NO_SUBSCRIBER_TOKEN)
        },
        subscribeProduct(e) {
            var {
                context: t,
                automation: i,
                product: n,
                variant: o,
                source: r
            } = e;
            return this.subscribeIfNotAlready({
                enableHintScreen: !0,
                websitePushId: t.config.website_push_id,
                browserHandler: t.browserHandler
            }).then(() => this.update(i, {
                product_id: n.id,
                product: n,
                variant: o,
                source: r,
                permission: window.Notification && window.Notification.permission
            }).then(e => {
                var {
                    token: t
                } = e.result;
                t && (x.subscriberToken = t), ye("Product subscribed for ".concat(i, ". Product ").concat(n.id, ". Variant ").concat(o.id, ". Source: ").concat(r))
            }).catch(Te))
        },
        unsubscribe(e) {
            var t = new Ke;
            e.isPermissionGranted ? t.unsubscribe(x.subscriberToken).then(() => {
                ye("🟢 Unsubscription successfull")
            }).catch(e => {
                ye("🔴 Unsubscription failed", e)
            }) : ye("🟢 Unsubscription successfull")
        },
        trackBrowserPromptAnalytics(e, t) {
            var i = new V;
            if (i.config.optin_report_enabled) {
                window.poAnalytics.track("BrowserPromptShown", {
                    delay: e,
                    optinSeenCount: i.optinSeenCount
                });
                var n = {
                    allowed: "BrowserPromptAllowClicked",
                    denied: "BrowserPromptDenyClicked",
                    default: "BrowserPromptCloseClicked"
                };
                n[t] && window.poAnalytics.track(n[t], {
                    delay: e,
                    optinSeenCount: i.optinSeenCount
                })
            }
        }
    },
    gt = ["type"];
var mt = {
    isSubscribed(e) {
        var {
            context: t,
            product: i,
            featureStorageManager: n
        } = e;
        if (!i) return t.browserHandler.isPermissionGranted;
        if (n) {
            var o = i.currentVariant();
            return t.browserHandler.isPermissionGranted && n.isSubscribed(o)
        }
        return !1
    },
    handlePushOwlButtons(e) {
        var {
            buttons: t,
            onClick: i,
            isSubscribed: n
        } = e;
        if (!(pe().isiOS && !navigator.standalone || pe().isOldIOS))
            for (var o of Array.from(t)) {
                var r = o.dataset.pushowlPreDisplay,
                    s = o.dataset.pushowlPreVisibility,
                    a = o.dataset.pushowlPostDisplay,
                    c = o.dataset.pushowlPostVisibility,
                    l = o.dataset.pushowlPostSubscriptionMessage;
                n ? (a && (o.style.display = a), c && (o.style.visibility = c), l && (o.innerText = l)) : ("none" === o.style.display && (o.style.display = r || "block"), "hidden" === o.style.visibility && (o.style.visibility = s || "visible")), o.addEventListener("click", i)
            }
    },
    subscribeButtons(e) {
        var {
            context: t
        } = e, i = document.querySelectorAll(".js-pushowl--subscribe");
        ye("".concat(i.length, " custom subscribe button(s) detected."), i), document.addEventListener("SubscribedToPushOwl", () => {
            i.forEach(e => {
                var t = e.dataset.pushowlPostSubscriptionMessage;
                t && (e.innerText = t)
            })
        }), this.handlePushOwlButtons({
            buttons: i,
            onClick: e => {
                ht.subscribeIfNotAlready({
                    enableHintScreen: "false" !== e.target.dataset.pushowlOverlay,
                    websitePushId: t.config.website_push_id,
                    browserHandler: t.browserHandler
                }).then(() => {
                    var t = e.target.dataset.pushowlPostSubscriptionMessage;
                    t && (e.target.innerText = t)
                }, null)
            },
            isSubscribed: this.isSubscribed({
                context: t
            })
        })
    },
    priceDropButtons(e) {
        var {
            context: t,
            onSuccess: i
        } = e, n = document.querySelectorAll(".js-pushowl--pd");
        n.length && (ye("".concat(n.length, " custom price drop button(s) detected."), n), t.storeLib.getProductDetails().then(e => {
            this.handlePushOwlButtons({
                buttons: n,
                onClick: n => {
                    var r = e.currentVariant();
                    ht.subscribeProduct({
                        context: t,
                        automation: d.EVENT_API_PATH.PRICE_DROP,
                        product: e,
                        variant: r,
                        source: o.CUSTOM_BUTTONS
                    }).then(() => {
                        t.storageManager.price_drop.subscribe(r);
                        var o = n.target.dataset.pushowlPostSubscriptionMessage;
                        o && (n.target.innerText = o), i(e)
                    }).catch(Te)
                },
                isSubscribed: this.isSubscribed({
                    context: t,
                    product: e,
                    featureStorageManager: t.storageManager.price_drop
                })
            })
        }))
    },
    backInStockButtons(e) {
        var {
            context: t,
            onSuccess: i
        } = e, n = document.querySelectorAll(".js-pushowl--bis");
        n.length && (ye("".concat(n.length, " custom back-in-stock button(s) detected."), n), t.storeLib.getProductDetails().then(e => {
            this.handlePushOwlButtons({
                buttons: n,
                onClick: n => {
                    var r = e.currentVariant();
                    ht.subscribeProduct({
                        context: t,
                        automation: d.EVENT_API_PATH.BACK_IN_STOCK,
                        product: e,
                        variant: r,
                        source: o.CUSTOM_BUTTONS
                    }).then(() => {
                        t.storageManager.back_in_stock.subscribe(r);
                        var o = n.target.dataset.pushowlPostSubscriptionMessage;
                        o && (n.target.innerText = o), i(e)
                    }).catch(Te)
                },
                isSubscribed: this.isSubscribed({
                    context: t,
                    product: e,
                    featureStorageManager: t.storageManager.back_in_stock
                })
            })
        }))
    }
};
class ft {
    constructor() {
        this.trackedForms = new Set, this.emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/, this.phonePattern = /^[\d\s\-+()]+$/, this.sessionManager = new V, ye("[FormTracker] Initialized")
    }
    init() {
        var e, {
            config: t
        } = this.sessionManager;
        "enabled" === (null == t || null === (e = t.flags) || void 0 === e ? void 0 : e.allow_form_tracking) ? (this.trackExistingForms(), this.observeNewForms(), ye("[FormTracker] Tracking started")) : ye("[FormTracker] Tracking not enabled by backend config flag")
    }
    trackExistingForms() {
        document.querySelectorAll("form").forEach(e => this.attachFormListener(e)), this.trackShadowDOMForms()
    }
    trackShadowDOMForms() {
        document.querySelectorAll("*").forEach(e => {
            e.shadowRoot && e.shadowRoot.querySelectorAll("form").forEach(e => this.attachFormListener(e))
        })
    }
    observeNewForms() {
        new MutationObserver(e => {
            e.forEach(e => {
                e.addedNodes.forEach(e => {
                    if (e.nodeType === Node.ELEMENT_NODE) {
                        var t;
                        "FORM" === e.tagName && this.attachFormListener(e);
                        var i = null === (t = e.querySelectorAll) || void 0 === t ? void 0 : t.call(e, "form");
                        if (null == i || i.forEach(e => this.attachFormListener(e)), e.shadowRoot) e.shadowRoot.querySelectorAll("form").forEach(e => this.attachFormListener(e))
                    }
                })
            })
        }).observe(document.body, {
            childList: !0,
            subtree: !0
        })
    }
    attachFormListener(e) {
        this.trackedForms.has(e) || this.shouldSkipForm(e) || (this.trackedForms.add(e), e.addEventListener("submit", t => {
            this.handleFormSubmit(t, e)
        }), ye("[FormTracker] Attached listener to form:", e))
    }
    shouldSkipForm(e) {
        var t;
        return !!e.hasAttribute("data-po-skip-tracking") || (!(null === (t = e.action) || void 0 === t || !t.includes("/checkout")) || !(!e.classList.contains("pushowl-form") && !e.closest("[data-pushowl-form-id]")))
    }
    handleFormSubmit(e, t) {
        try {
            var i = new FormData(t),
                n = this.extractFormData(i, t);
            ye("[FormTracker] Form submitted:", n), (n.email || n.phone) && this.processIdentityData(n)
        } catch (e) {}
    }
    extractFormData(e, t) {
        var i = {
            email: null,
            phone: null,
            otherFields: {},
            formId: t.id || t.name || "unknown",
            formAction: t.action,
            formMethod: t.method,
            timestamp: (new Date).toISOString()
        };
        return Array.from(e.entries()).forEach(e => {
            var [t, n] = e, o = t.toLowerCase();
            this.isEmailField(o, n) ? i.email = n : this.isPhoneField(o, n) ? i.phone = this.normalizePhone(n) : i.otherFields[t] = n
        }), t.querySelectorAll("input, textarea, select").forEach(e => {
            var t = e.name || e.id,
                {
                    type: n
                } = e,
                o = e.getAttribute("inputmode"),
                {
                    value: r
                } = e;
            r && (i.email || ("email" === n || "email" === o || this.isEmailField((null == t ? void 0 : t.toLowerCase()) || "", r)) && (i.email = r), i.phone || ("tel" === n || "tel" === o || this.isPhoneField((null == t ? void 0 : t.toLowerCase()) || "", r)) && (i.phone = this.normalizePhone(r)))
        }), i
    }
    isEmailField(e, t) {
        var i = ["email", "e-mail", "mail"].some(t => e.includes(t)),
            n = this.emailPattern.test(t);
        return i || n
    }
    isPhoneField(e, t) {
        var i = ["phone", "tel", "mobile", "cell"].some(t => e.includes(t)),
            n = this.phonePattern.test(t) && t.length >= 10;
        return i || n
    }
    normalizePhone(e) {
        return e.replace(/[^\d+]/g, "")
    }
    processIdentityData(e) {
        return Ue(function*() {
            try {
                var {
                    email: t,
                    phone: i
                } = e;
                if (!t && !i) return;
                yield Ve.identify({
                    email: t || void 0,
                    phone: i || void 0
                }, {
                    source: "form_tracker",
                    form_id: e.formId
                }), ye("[FormTracker] Identity sent to ChannelIdentityManager:", {
                    email: t,
                    phone: i
                })
            } catch (e) {}
        })()
    }
    manualTrack(e) {
        ye("[FormTracker] Manual tracking:", e), this.processIdentityData(e)
    }
}
var wt = null;
const bt = "po_visitor";
class _t {
    constructor({
        endpoint: e,
        props: t
    }) {
        this.endpoint = e, this.meta = {}, this.initVisitor(), this.setVisitorProperties(t);
        let i = null;
        z() ? i = be(bt) : _e(bt, "/"), this.setVisitorProperties({
            sessionId: i,
            language: navigator.language
        })
    }
    initVisitor() {
        let e = null;
        z() ? e = be(bt) : _e(bt, "/"), e || (this.meta.isNewVisitor = !0, e = me(12), z() && we({
            name: bt,
            value: e,
            days: 365
        })), this.visitorId = e
    }
    setVisitorProperties(e) {
        this.properties = Object.assign(Object.assign({}, this.properties), e)
    }
    track(e, t, i) {
        if (z() && this.visitorId && this.properties.visitorToken)
            if (this.properties.wid) {
                if (i) {
                    const i = {
                            sessionId: this.visitorId,
                            sessionToken: this.properties.sessionToken,
                            visitorToken: x.visitorToken,
                            subdomain: H.subdomain,
                            wid: this.properties.wid,
                            language: this.properties.language,
                            flowId: t.flowId,
                            formId: t.formId,
                            nodeId: t.nodeId,
                            channelType: t.channelType,
                            optinType: t.optinType,
                            formStepType: t.formStepType,
                            event: e,
                            platform: H.platform,
                            timestamp: (new Date).toISOString(),
                            uuid: me()
                        },
                        n = new URL(this.endpoint);
                    return n.searchParams.set("subdomain", i.subdomain), n.searchParams.set("event", i.event), void He.post({
                        url: n.toString(),
                        payload: i,
                        acceptType: "text/plain"
                    })
                }
                He.post({
                    url: this.endpoint,
                    payload: Object.assign(Object.assign({
                        event: e,
                        sessionId: this.visitorId,
                        uuid: me(15),
                        properties: t
                    }, this.properties), {
                        platform: H.platform,
                        timestamp: (new Date).toISOString()
                    }),
                    acceptType: "text/plain"
                })
            } else H.logToServer({
                message: "wid empty",
                subdomain: H.subdomain,
                data: Object.assign(Object.assign({}, t), {
                    breadcrumbs: ve
                })
            })
    }
}
const St = (e, t, i) => {
    let n = i.replace("{{amount}}", parseFloat(t).toFixed(2));
    return e.replace("{{product_price}}", n).replace("{{variant_price}}", n)
};
var vt = {
    renderFlyout(e) {
        var {
            flyoutHandler: t,
            title: i,
            buttonText: n,
            automationType: o,
            buttonListener: r,
            theme: s,
            position: a,
            overlay: c
        } = e;
        document.querySelectorAll(".pushowl-widget-node").forEach(e => {
            e && e.remove()
        }), i && (t.setState({
            title: i,
            buttonText: n,
            buttonListener: r,
            theme: s,
            position: a,
            overlay: c
        }), ye("Product flyout shown for: ", o), ye("🟠 Optin prompt was not shown. Reason: Product flyout shown"))
    },
    renderOptin(e) {
        var {
            rootContext: t,
            flyoutHandler: i
        } = e, n = t.config.home.flyout, {
            title: o,
            theme: r,
            position: s,
            buttonText: a,
            overlay: c
        } = n;
        window.Notification && window.Notification.permission === d.NOTIFICATION_PERMISSION.DEFAULT ? (i.setState({
            title: o,
            buttonText: a,
            theme: r,
            position: s,
            overlay: c,
            buttonListener: () => {
                window.poSubscriptionSource = I, ht.subscribeIfNotAlready({
                    enableHintScreen: c && c.enabled,
                    websitePushId: t.config.website_push_id,
                    browserHandler: t.browserHandler,
                    hintScreenData: c
                }).then(() => {
                    i.setState({
                        title: n.postSubscriptionTitle,
                        position: s,
                        theme: r
                    })
                }).catch(e => {
                    Te(e)
                })
            }
        }), ye("Flyout shown.", "Config: ", n)) : ye("Flyout not shown.", "Config: ", n, "Permission: ", window.Notification.permission)
    },
    renderBackInStock(e) {
        var {
            rootContext: t,
            flyoutHandler: i,
            product: n,
            variant: r
        } = e, s = new x, {
            back_in_stock: c,
            flyout_config: l
        } = t.config, u = c.enabled, p = s.back_in_stock.isSubscribed(r);
        if (u)
            if (window.Notification && window.Notification.permission === d.NOTIFICATION_PERMISSION.GRANTED && p) {
                var h = St(c.postSubscriptionTitle, r.price, t.config.shop.money_format),
                    {
                        theme: g,
                        position: m,
                        overlay: f
                    } = c.metadata;
                this.renderFlyout({
                    flyoutHandler: i,
                    title: h,
                    theme: g,
                    position: m,
                    overlay: f,
                    automationType: a.BACK_IN_STOCK
                })
            } else {
                var {
                    theme: w,
                    position: b,
                    overlay: _
                } = c.metadata;
                this.renderFlyout({
                    flyoutHandler: i,
                    title: c.title,
                    buttonText: c.buttonText,
                    theme: w,
                    position: b,
                    overlay: _,
                    buttonListener: () => {
                        i.setState({
                            title: c.postSubscriptionTitle,
                            position: b,
                            theme: w
                        });
                        var {
                            overlay: e
                        } = c.metadata;
                        window.Notification && "default" === window.Notification.permission && (window.poSubscriptionSource = O), ht.subscribeIfNotAlready({
                            enableHintScreen: !!l.overlay,
                            showHintScreenOnError: !!l.overlay,
                            websitePushId: t.config.website_push_id,
                            browserHandler: t.browserHandler,
                            hintScreenData: e
                        }).then(() => {
                            ht.update(d.EVENT_API_PATH.BACK_IN_STOCK, {
                                product_id: n.id,
                                product: n,
                                variant: r,
                                source: o.FLYOUT_WIDGET,
                                permission: window.Notification && window.Notification.permission
                            }).then(e => {
                                s.back_in_stock.subscribe(r);
                                var {
                                    token: t
                                } = e.result;
                                t && (x.subscriberToken = t), ye("Product subscribed for ".concat(d.EVENT_API_PATH.BACK_IN_STOCK, ". Product ").concat(n.id, ". Variant ").concat(r.id, ". Source: ").concat(o.FLYOUT_WIDGET))
                            }).catch(e => {
                                Te(e)
                            })
                        })
                    },
                    automationType: a.BACK_IN_STOCK
                })
            }
    },
    renderPriceDrop(e) {
        var {
            rootContext: t,
            flyoutHandler: i,
            product: n,
            variant: r
        } = e, s = new x, {
            price_drop: c,
            flyout_config: l
        } = t.config, u = c.enabled, p = s.price_drop.isSubscribed(r), h = c.is_viewed;
        if (u && !h)
            if (window.Notification && window.Notification.permission === d.NOTIFICATION_PERMISSION.GRANTED && p) {
                var {
                    theme: g,
                    position: m,
                    overlay: f
                } = c.metadata;
                this.renderFlyout({
                    flyoutHandler: i,
                    theme: g,
                    position: m,
                    overlay: f,
                    title: c.postSubscriptionTitle,
                    automationType: a.PRICE_DROP
                })
            } else {
                var w = t.config.price_drop.metadata,
                    {
                        theme: b,
                        position: _,
                        overlay: S
                    } = w;
                this.renderFlyout({
                    theme: b,
                    position: _,
                    overlay: S,
                    flyoutHandler: i,
                    title: St(c.title, r.price, t.config.shop.money_format),
                    buttonText: c.buttonText,
                    buttonListener: () => {
                        i.setState({
                            title: c.postSubscriptionTitle,
                            position: _,
                            theme: b
                        });
                        var {
                            overlay: e
                        } = c.metadata;
                        window.Notification && "default" === window.Notification.permission && (window.poSubscriptionSource = T), ht.subscribeIfNotAlready({
                            enableHintScreen: !!l.overlay,
                            showHintScreenOnError: !!l.overlay,
                            websitePushId: t.config.website_push_id,
                            browserHandler: t.browserHandler,
                            hintScreenData: e
                        }).then(() => {
                            ht.update(d.EVENT_API_PATH.PRICE_DROP, {
                                product_id: n.id,
                                product: n,
                                variant: r,
                                subscribed_price: r.price,
                                source: o.FLYOUT_WIDGET,
                                permission: window.Notification && window.Notification.permission
                            }).then(e => {
                                s.price_drop.subscribe(r);
                                var {
                                    token: t
                                } = e.result;
                                t && (x.subscriberToken = t), ye("Product subscribed for ".concat(d.EVENT_API_PATH.PRICE_DROP, ". Product ").concat(n.id, ". Variant ").concat(r.id, ". Source: ").concat(o.FLYOUT_WIDGET))
                            }).catch(e => {
                                Te(e)
                            })
                        })
                    },
                    automationType: a.PRICE_DROP
                })
            }
    }
};
const yt = {
        name: "Pushowl Web Notifications",
        short_name: "PushOwl",
        description: "",
        icons: [],
        start_url: "/",
        scope: "/",
        display: "standalone",
        orientation: "portrait",
        background_color: "#fff",
        theme_color: "#000000"
    },
    Et = e => e ? Array.isArray(e) ? e.map(e => "string" == typeof e ? e.trim() : "").filter(Boolean) : "string" == typeof e ? e.split(",").map(e => e.trim()).filter(Boolean) : [] : [],
    It = () => {
        var e, t;
        try {
            const i = document.querySelector('link[rel="manifest"]');
            if ((t = i) && ("true" === t.dataset.pushowlManifest || (t.getAttribute("href") || "").startsWith("blob:"))) {
                const e = null == i ? void 0 : i.getAttribute("href");
                null == i || i.remove(), (e => {
                    e && e.startsWith("blob:") && URL.revokeObjectURL(e)
                })(e)
            }
            const n = document.querySelector('link[rel="apple-touch-icon"]');
            n && ("true" === n.dataset.pushowlManifest || (null === (e = n.getAttribute("href")) || void 0 === e ? void 0 : e.startsWith("blob:"))) && n.remove()
        } catch (e) {
            ye("Unable to remove manifest")
        }
    };
class Tt {
    constructor(e) {
        this.syncTriggerManager = e, this.activeFlows = new Map, this.triggeredFlows = new Set, this.triggerSources = new Map
    }
    setup(e, t) {
        var i = this;
        if (e && t && !this.triggeredFlows.has(e.id)) {
            var n = e.id,
                o = {
                    flow: e,
                    callback: function() {
                        for (var e = i.triggerSources.get(n), o = arguments.length, r = new Array(o), s = 0; s < o; s++) r[s] = arguments[s];
                        t(e, ...r)
                    },
                    triggered: !1,
                    enabledConditions: {
                        exitIntent: Boolean(e.exitIntent),
                        scrollDepth: Boolean(e.scrollDepthEnabled),
                        timeSpent: Boolean(e.timeSpentEnabled)
                    },
                    metConditions: {
                        exitIntent: !1,
                        scrollDepth: !1,
                        timeSpent: !1
                    }
                };
            this.activeFlows.set(n, o), e.exitIntent && this._setupExitIntent(n, e.requireAllConditions), e.scrollDepthEnabled && this._setupScrollDepth(n, e.requireAllConditions), e.timeSpentEnabled && this._setupTimeSpent(n, e.requireAllConditions)
        }
    }
    _setupExitIntent(e, t) {
        var i = this.activeFlows.get(e),
            n = n => {
                n.clientY <= 0 && (t ? (i.metConditions.exitIntent = !0, this._checkEnabledConditions(e)) : this._triggerFlow(e, "exitIntent"))
            };
        i.exitIntentHandler = n, document.documentElement.addEventListener("mouseleave", n)
    }
    _setupScrollDepth(e, t) {
        var i, n = this.activeFlows.get(e),
            o = n.flow.scrollDepth,
            r = () => {
                clearTimeout(i), i = setTimeout(() => {
                    var i = this._calculateScrollPercentage();
                    ye("[AsyncTriggerManager] Current scroll depth: ".concat(i.toFixed(2), "%, Target: ").concat(o, "%")), i >= o && (t ? (n.metConditions.scrollDepth = !0, this._checkEnabledConditions(e)) : this._triggerFlow(e, "scrollDepth"))
                }, 100)
            };
        n.scrollHandler = r, window.addEventListener("scroll", r)
    }
    _setupTimeSpent(e, t) {
        var i = this.activeFlows.get(e),
            n = setTimeout(() => {
                t ? (i.metConditions.timeSpent = !0, this._checkEnabledConditions(e)) : this._triggerFlow(e, "timeSpent")
            }, 1e3 * i.flow.timeSpent);
        i.timeoutId = n
    }
    _checkEnabledConditions(e) {
        var t = this.activeFlows.get(e);
        t && !t.triggered && (Object.entries(t.enabledConditions).every(e => {
            var [i, n] = e;
            return !n || t.metConditions[i]
        }) && this._triggerFlow(e, "allConditions"))
    }
    _triggerFlow(e, t) {
        var i = this.activeFlows.get(e);
        !i || i.triggered || this.triggeredFlows.has(e) || (ye("[AsyncTriggerManager] Flow ".concat(e, " triggered by: ").concat(t)), this.triggerSources.set(e, t), i.triggered = !0, this.triggeredFlows.add(e), i.callback(), this._cleanupFlowListeners(e), this.activeFlows.delete(e))
    }
    _calculateScrollPercentage() {
        var e = window.innerHeight,
            t = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.body.clientHeight, document.documentElement.clientHeight);
        return (window.pageYOffset || document.documentElement.scrollTop) / (t - e) * 100
    }
    _cleanupFlowListeners(e) {
        var t = this.activeFlows.get(e);
        t && (t.exitIntentHandler && document.documentElement.removeEventListener("mouseleave", t.exitIntentHandler), t.scrollHandler && window.removeEventListener("scroll", t.scrollHandler), t.timeoutId && clearTimeout(t.timeoutId))
    }
    getTriggerSource(e) {
        return this.triggerSources.get(e)
    }
    cleanup(e) {
        this._cleanupFlowListeners(e), this.activeFlows.delete(e), this.triggeredFlows.delete(e)
    }
    cleanupAll() {
        this.activeFlows.forEach((e, t) => {
            this.cleanup(t)
        })
    }
}
class Ot {
    constructor() {
        this.conditions = new Map, ye("🪵 SyncTriggerManager initialized")
    }
    setup(e) {
        ye("🪵 Setting up sync conditions for flow:", e.id), this.conditions.set(e.id, {
            urlTargeting: {
                inclusionUrls: e.inclusionUrls || [],
                exclusionUrls: e.exclusionUrls || [],
                inclusionUrlsEnabled: e.inclusionUrlsEnabled || !1,
                exclusionUrlsEnabled: e.exclusionUrlsEnabled || !1
            },
            deviceType: this._normalizeDeviceType(e.deviceType)
        })
    }
    _normalizeDeviceType(e) {
        return !e || 0 === e.length || e.includes("all") ? [] : e
    }
    checkAllConditions(e) {
        var t = this.conditions.get(e.id);
        if (ye("🪵 Checking conditions for flow:", {
                flowId: e.id,
                conditions: t
            }), !t) return ye("🪵 No conditions found for flow:", e.id), !0;
        var i = this.checkUrlConditions(t.urlTargeting),
            n = this.checkDeviceTargetingConditions(t.deviceType);
        return ye("🪵 Condition check results:", {
            flowId: e.id,
            urlCheck: i,
            deviceCheck: n
        }), i && n
    }
    checkUrlConditions(e) {
        var t, i, n = window.location.href,
            o = !e.inclusionUrlsEnabled;
        if (e.exclusionUrlsEnabled && (null === (t = e.exclusionUrls) || void 0 === t ? void 0 : t.length) > 0)
            for (var r of e.exclusionUrls)
                if (this._matchUrl(r, n)) return !1;
        if (e.inclusionUrlsEnabled && (null === (i = e.inclusionUrls) || void 0 === i ? void 0 : i.length) > 0)
            for (var s of (o = !1, e.inclusionUrls))
                if (this._matchUrl(s, n)) {
                    o = !0;
                    break
                }
        return o
    }
    _matchUrl(e, t) {
        var i = t.replace(/^https?:\/\//, ""),
            n = e.url.replace(/^https?:\/\//, "");
        switch (e.type) {
            case "contains":
                return i.includes(n);
            case "exact":
                return i === n;
            default:
                return !1
        }
    }
    checkDeviceTargetingConditions(e) {
        return null == e || !e.length || e.some(e => {
            switch (e) {
                case "mobile":
                    return ae();
                case "desktop":
                    return !ae();
                case "mobile_ios":
                    return pe().isiOS || pe().isOldIOS;
                case "mobile_android":
                    return pe().isAndroid;
                default:
                    return !0
            }
        })
    }
}
class Nt {
    constructor(e) {
        this.config = e, this.flows = new Map, this.syncTriggerManager = new Ot, this.asyncTriggerManager = new Tt(this.syncTriggerManager), ye("🪵 OptinFlowManager initialized")
    }
    addOptinFlow(e, t) {
        ye("🪵 Adding flow:", e.id), this.flows.set(e.id, {
            flow: e,
            renderCallback: t
        }), this.syncTriggerManager.setup(e)
    }
    initialize() {
        ye("🪵 Initializing flows, total flows:", this.flows.size), te.getVisitorCountry().then(e => {
            ye("🪵 Visitor country:", e), this._processFlows(e)
        }).catch(() => {
            ye("🪵 Failed to fetch visitor country, processing flows without country check"), this._processFlows(null)
        })
    }
    _processFlows(e) {
        this.flows.forEach(t => {
            var {
                flow: i,
                renderCallback: n
            } = t;
            if (ye("🪵 Processing flow:", i.id), e && i.exclusion_countries_enabled && i.exclusion_countries.includes(e)) ye("🪵 User in restricted country, skipping flow:", i.id);
            else if (e && i.inclusion_countries_enabled && !i.inclusion_countries.includes(e)) ye("🪵 User not in included country, skipping flow:", i.id);
            else {
                var o = i.exitIntent || i.scrollDepthEnabled || i.timeSpentEnabled,
                    r = i.inclusionUrlsEnabled || i.exclusionUrlsEnabled || i.deviceType && i.deviceType.length > 0;
                if (ye("🪵 Flow triggers:", {
                        hasAsyncTriggers: o,
                        hasSyncConditions: r,
                        flow: i.id
                    }), !o && !r) return ye("🪵 No triggers configured, rendering immediately for flow:", i.id), void n();
                if (r) {
                    var s = this.syncTriggerManager.checkAllConditions(i);
                    if (ye("🪵 Sync conditions check result:", {
                            flowId: i.id,
                            passed: s
                        }), !s) return void ye("🪵 Sync conditions failed for flow:", i.id)
                }
                o ? (ye("🪵 Setting up async triggers for flow:", i.id), this.asyncTriggerManager.setup(i, n)) : r && (ye("🪵 Only sync conditions exist and passed, rendering flow:", i.id), n())
            }
        })
    }
}
var Ct, Mt, At;

function Lt(e, t) {
    if (At = new Date, e.nodeType !== Node.ELEMENT_NODE) throw new Error("Can't generate CSS selector for non-element node type.");
    if ("html" === e.tagName.toLowerCase()) return "html";
    var i = {
        root: document.body,
        idName: e => !0,
        className: e => !0,
        tagName: e => !0,
        attr: (e, t) => !1,
        seedMinLength: 1,
        optimizedMinLength: 2,
        threshold: 1e3,
        maxNumberOfTries: 1e4,
        timeoutMs: void 0
    };
    Ct = Ye(Ye({}, i), t), Mt = function(e, t) {
        if (e.nodeType === Node.DOCUMENT_NODE) return e;
        if (e === t.root) return e.ownerDocument;
        return e
    }(Ct.root, i);
    var n = Pt(e, "all", () => Pt(e, "two", () => Pt(e, "one", () => Pt(e, "none"))));
    if (n) {
        var o = Ht(zt(n, e));
        return o.length > 0 && (n = o[0]), Dt(n)
    }
    throw new Error("Selector was not found.")
}

function Pt(e, t, i) {
    for (var n = null, o = [], r = e, s = 0, a = function() {
            var e = (new Date).getTime() - At.getTime();
            if (void 0 !== Ct.timeoutMs && e > Ct.timeoutMs) throw new Error("Timeout: Can't find a unique selector after ".concat(e, "ms"));
            var a = Bt(function(e) {
                    var t = e.getAttribute("id");
                    if (t && Ct.idName(t)) return {
                        name: "#" + CSS.escape(t),
                        penalty: 0
                    };
                    return null
                }(r)) || Bt(... function(e) {
                    var t = Array.from(e.attributes).filter(e => Ct.attr(e.name, e.value));
                    return t.map(e => ({
                        name: "[".concat(CSS.escape(e.name), '="').concat(CSS.escape(e.value), '"]'),
                        penalty: .5
                    }))
                }(r)) || Bt(... function(e) {
                    var t = Array.from(e.classList).filter(Ct.className);
                    return t.map(e => ({
                        name: "." + CSS.escape(e),
                        penalty: 1
                    }))
                }(r)) || Bt(function(e) {
                    var t = e.tagName.toLowerCase();
                    if (Ct.tagName(t)) return {
                        name: t,
                        penalty: 2
                    };
                    return null
                }(r)) || [{
                    name: "*",
                    penalty: 3
                }],
                c = function(e) {
                    var t = e.parentNode;
                    if (!t) return null;
                    var i = t.firstChild;
                    if (!i) return null;
                    var n = 0;
                    for (; i && (i.nodeType === Node.ELEMENT_NODE && n++, i !== e);) i = i.nextSibling;
                    return n
                }(r);
            if ("all" == t) c && (a = a.concat(a.filter(Ut).map(e => xt(e, c))));
            else if ("two" == t) a = a.slice(0, 1), c && (a = a.concat(a.filter(Ut).map(e => xt(e, c))));
            else if ("one" == t) {
                var [l] = a = a.slice(0, 1);
                c && Ut(l) && (a = [xt(l, c)])
            } else "none" == t && (a = [{
                name: "*",
                penalty: 3
            }], c && (a = [xt(a[0], c)]));
            for (var u of a) u.level = s;
            if (o.push(a), o.length >= Ct.seedMinLength && (n = kt(o, i))) return 1;
            r = r.parentElement, s++
        }; r && !a(););
    return n || (n = kt(o, i)), !n && i ? i() : n
}

function kt(e, t) {
    var i = Ht(Yt(e));
    if (i.length > Ct.threshold) return t ? t() : null;
    for (var n of i)
        if (jt(n)) return n;
    return null
}

function Dt(e) {
    for (var t = e[0], i = t.name, n = 1; n < e.length; n++) {
        var o = e[n].level || 0;
        i = t.level === o - 1 ? "".concat(e[n].name, " > ").concat(i) : "".concat(e[n].name, " ").concat(i), t = e[n]
    }
    return i
}

function Rt(e) {
    return e.map(e => e.penalty).reduce((e, t) => e + t, 0)
}

function jt(e) {
    var t = Dt(e);
    switch (Mt.querySelectorAll(t).length) {
        case 0:
            throw new Error("Can't select any node with this selector: ".concat(t));
        case 1:
            return !0;
        default:
            return !1
    }
}

function xt(e, t) {
    return {
        name: e.name + ":nth-child(".concat(t, ")"),
        penalty: e.penalty + 1
    }
}

function Ut(e) {
    return "html" !== e.name && !e.name.startsWith("#")
}

function Bt() {
    for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++) t[i] = arguments[i];
    var n = t.filter(Ft);
    return n.length > 0 ? n : null
}

function Ft(e) {
    return null != e
}

function Yt(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
    return function*() {
        if (e.length > 0)
            for (var i of e[0]) yield* Yt(e.slice(1, e.length), t.concat(i));
        else yield t
    }()
}

function Ht(e) {
    return [...e].sort((e, t) => Rt(e) - Rt(t))
}

function zt(e, t) {
    var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
        counter: 0,
        visited: new Map
    };
    return function*() {
        if (e.length > 2 && e.length > Ct.optimizedMinLength)
            for (var n = 1; n < e.length - 1; n++) {
                if (i.counter > Ct.maxNumberOfTries) return;
                i.counter += 1;
                var o = [...e];
                o.splice(n, 1);
                var r = Dt(o);
                if (i.visited.has(r)) return;
                jt(o) && Kt(o, t) && (yield o, i.visited.set(r, !0), yield* zt(o, t, i))
            }
    }()
}

function Kt(e, t) {
    return Mt.querySelector(Dt(e)) === t
}
const Gt = "pushowl-optin-container",
    Vt = "pushowl-bis-form-container",
    qt = "pushowl-embedded-form-container";
var $t;
! function(e) {
    e.CONSENT_EMAIL_COPY = "consent-email-copy", e.CONSENT_SMS_COPY = "consent-sms-copy", e.CONSENT_EMAIL_SMS_COPY = "consent-email-sms-copy", e.CONSENT_SMS_COPY_TERMS = "consent-sms-copy-terms", e.CONSENT_SMS_CHECKBOX_TERMS = "consent-sms-checkbox-terms"
}($t || ($t = {}));
const Wt = {
        root: "root",
        containers: ["form_fields", "text_content", "image"],
        nodes: ["email", "phone", "image", "flyout", "consent-email-checkbox", "consent-sms-checkbox", "consent-email-sms-checkbox", [$t.CONSENT_EMAIL_COPY],
            [$t.CONSENT_SMS_COPY],
            [$t.CONSENT_EMAIL_SMS_COPY],
            [$t.CONSENT_SMS_COPY_TERMS],
            [$t.CONSENT_SMS_CHECKBOX_TERMS]
        ],
        logo: "logo",
        wheel: "wheel",
        trigger: "trigger",
        switcher: "switcher"
    },
    Qt = {
        email: "Enter your Email address",
        phone: "9123456789"
    },
    Jt = {
        0: 0,
        xs: 10,
        sm: 12,
        md: 16,
        lg: 20,
        xl: 26,
        "2xl": 30,
        "3xl": 36,
        "4xl": 42,
        "5xl": 48,
        "6xl": 54
    },
    Xt = "#0475fd",
    Zt = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MiIgaGVpZ2h0PSIxNiIgZmlsbD0ibm9uZSI+PG1hc2sgaWQ9ImEiIHdpZHRoPSI2MiIgaGVpZ2h0PSIxNiIgeD0iMCIgeT0iMCIgbWFza1VuaXRzPSJ1c2VyU3BhY2VPblVzZSIgc3R5bGU9Im1hc2stdHlwZTpsdW1pbmFuY2UiPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik02MS44NyAwSDB2MTUuNzg2aDYxLjg3eiIvPjwvbWFzaz48ZyBmaWxsPSIjZmZmIiBtYXNrPSJ1cmwoI2EpIj48cGF0aCBkPSJNNi40MiAwYzEuNTU3IDAgMi43MTcuNjU4IDMuNzA1IDEuNDMyLjQ2LjM2LjgzNy43OTQgMS4xNzEgMS4yNy4wNDcuMDY2LjA1OS4xMi4wMTYuMTg2LS4zMzUuNTYxLS41MTQgMS4xNzctLjY1NCAxLjgwNy0uMDA0LjAyNC0uMDE1LjA0Ny0uMDIzLjA2NiAwIC4wMDQtLjAxMi4wMDgtLjAyLjAwOC0uODEzLTIuNTY2LTMuNDE2LTMuNjM1LTUuNTQtMy4wOTMtMi4yMTkuNTY1LTMuNTc3IDIuNDItMy41MjIgNC41NzYuMDU4IDIuMzQ1IDEuNzI3IDQuMTEgMy45MDMgNC40NCAyLjM0Ni4zNTIgNC40Mi0uOTcyIDUuMTUyLTMuMTQ3LjA1LjA0Ni4wNTQuMTA4LjA2Ni4xNjYuMjQxIDEuMTUuNzY2IDIuMTU2IDEuNTIxIDMuMDU0YTcuMSA3LjEgMCAwIDAgMi40MzYgMS44NjJjLjA4Mi4wMzkuMjA2LjA3LjIzNC4xMzYuMDMuMDc3LS4wODYuMTQ3LS4xMzcuMjItLjY4NC45Ni0xLjUwNSAxLjc4OS0yLjQyNCAyLjUyOC0uMDkuMDc0LS4xODMuMTQzLS4yNzIuMjI1LS4wNjMuMDU4LS4xMTMuMDYxLS4xODcuMDA3YTEzLjQgMTMuNCAwIDAgMS0yLjEyNS0yLjAxNyAxMS40IDExLjQgMCAwIDEtMS4yNDUtMS43NjljLS4wMzktLjA3LS4wNzgtLjA4OS0uMTU1LS4wNTgtLjg2NC4zNTctMS43NzUuNDM0LTIuNjkzLjM4LS43NTUtLjA0Ny0xLjQ3MS0uMjY3LTIuMTQ4LS41OTZBNi4wOCA2LjA4IDAgMCAxIC42MSA4LjgzMyA1LjggNS44IDAgMCAxIDAgNi4wODljLjAxNS0uNi4wNy0xLjE4OC4yNjQtMS43NjEuMTItLjM2LjI2NC0uNzA5LjM1NC0xLjA3NkMuODk5IDIuMTQ1LjcxNiAxLjExNS4wOTcuMTU1QTMgMyAwIDAgMSAuMDA3IDB6Ii8+PHBhdGggZD0iTTIzLjg4OCAwYy0uMTc1LjMxLS4zNzMuNi0uNDk4LjkzN2EzLjkzIDMuOTMgMCAwIDAtLjAzMSAyLjY1MWMuMTQ4LjQzOC4zMy44NjQuNDEyIDEuMzI0LjEzMy43NDcuMTgzIDEuNDk0LjA0NyAyLjI0NS0uMjM3IDEuMzEzLS44MiAyLjQ0Ny0xLjc4MiAzLjM3Ni0uOTk2Ljk2NC0yLjE5IDEuNTUyLTMuNTc2IDEuNzIzLTEuMzI3LjE2Mi0yLjU5Mi0uMDctMy43NTktLjczNi0xLjYzLS45MjktMi42NTgtMi4zLTMuMDQ3LTQuMTM0YTUuOSA1LjkgMCAwIDEtLjEyLTEuNzg5Yy4wNjYtLjY3LjIyNS0xLjMxNi41MDUtMS45MjcuNTg0LTEuMjcgMS41MDItMi4yMzQgMi43Mi0yLjkxOUMxNS41MTEuMzI5IDE2LjU4MiAwIDE3LjU3MyAwek0xMy4wOTQgNi4xNTljMCAyLjYwMSAyLjEwOSA0LjcgNC44NDUgNC41ODcgMi40MDQtLjEgNC40ODYtMi4wMzIgNC40MTItNC43NjUtLjA2Mi0yLjM0Mi0xLjk3Ny00LjQ3MS00LjcyLTQuNDMzLTIuNDA5LjAzNS00LjUzNyAxLjkyNC00LjUzNyA0LjYxWm0tNS43NC42MTVjLS4xNC4wMi0uMjY0LjAwOC0uMzkzLjAwOC0uMDc0IDAtLjExMi0uMDE2LS4xMjQtLjEwNS0uMDM5LS4zMDItLjM2Mi0uNTU3LS42NzMtLjU1M2EuNjcuNjcgMCAwIDAtLjY0Mi41NjljLS4wMDguMDYyLS4wMjguMDg1LS4wOS4wODVINC42MnEtLjA5Mi4wMDItLjA3OC0uMDg5YTEuNjYgMS42NiAwIDAgMSAxLjMwNy0xLjQ4NmMuODE0LS4xODYgMS44MjIuMzkgMS45MzggMS4zNDcuMDI4LjIyOC4wMzEuMjI4LS4yMDYuMjI4aC0uMjN6Ii8+PHBhdGggZD0iTTE4Ljg2NSA2Ljc3NGgtLjQwMWMtLjA1OCAwLS4wODItLjAxNS0uMDktLjA4MS0uMDMtLjMwMi0uMzE5LS41NTgtLjYzOC0uNTdhLjY1LjY1IDAgMCAwLS42NzMuNTQzYy0uMDE2LjA5Ny0uMDQ3LjExNi0uMTM2LjExNmEyMyAyMyAwIDAgMC0uNzI4IDBjLS4wOSAwLS4xMTctLjAzMS0uMTA5LS4xMi4wNTktLjY0My40MDUtMS4wOTYuOTgtMS4zNTEuNTgtLjI2IDEuMTQ1LS4xNzQgMS42NTQuMjE3LjM4Ni4yOTQuNTczLjY5Ni42MzUgMS4xNjUuMDA4LjA2Ni0uMDEyLjA4NS0uMDc0LjA4NWgtLjQxM3ptMTAuOTc2LTEuOTZxLjIyMy0uMzEzLjYxMS0uNTE4LjM5Ny0uMjE0LjkwMS0uMjE0YTEuOTkgMS45OSAwIDAgMSAxLjgxIDEuMTFxLjI4LjUyNi4yOCAxLjIyNCAwIC42OTktLjI4IDEuMjQyYTIuMDQgMi4wNCAwIDAgMS0uNzUyLjgzIDEuOTUgMS45NSAwIDAgMS0xLjA1OC4yOTYgMS45IDEuOSAwIDAgMS0uODkyLS4yMDYgMS45IDEuOSAwIDAgMS0uNjItLjUxOHYyLjgyaC0xLjE1N1Y0LjE1NmgxLjE1N3ptMi40MiAxLjYwMnEwLS40MTEtLjE3Mi0uNzA3YTEuMTMgMS4xMyAwIDAgMC0uNDQ3LS40NiAxLjE4IDEuMTggMCAwIDAtMS4xOS4wMDggMS4yIDEuMiAwIDAgMC0uNDQ2LjQ2cS0uMTY1LjMwNS0uMTY1LjcxNiAwIC40MS4xNjUuNzE1LjE3NC4zMDUuNDQ2LjQ2OGExLjIgMS4yIDAgMCAwIC41OTUuMTU3IDEuMTkgMS4xOSAwIDAgMCAxLjA0MS0uNjMzcS4xNzQtLjMwNC4xNzQtLjcyNFptNi4xMjEtMi4yNlY4LjcxaC0xLjE2NXYtLjU3NmExLjU1IDEuNTUgMCAwIDEtLjU4Ni40NjlxLS4zNTYuMTY0LS43NzcuMTY0LS41MzcgMC0uOTUtLjIyMmExLjY2IDEuNjYgMCAwIDEtLjY1My0uNjY2cS0uMjMxLS40NDMtLjIzMS0xLjA1MlY0LjE1NmgxLjE1N3YyLjUwN3EwIC41NDMuMjcyLjgzOC4yNzMuMjg4Ljc0NC4yODguNDggMCAuNzUyLS4yODguMjcyLS4yOTUuMjcyLS44MzhWNC4xNTZ6bTIuNjcgNC42MjhxLS41NjEgMC0xLjAwOC0uMTk4YTEuODUgMS44NSAwIDAgMS0uNzEtLjU1IDEuNCAxLjQgMCAwIDEtLjI4MS0uNzY1aDEuMTY1cS4wMzMuMjYzLjI1Ni40MzZhLjkzLjkzIDAgMCAwIC41Ny4xNzJxLjMzIDAgLjUxMi0uMTMxLjE5LS4xMzIuMTktLjMzNyAwLS4yMjItLjIzLS4zMjktLjIyNS0uMTE1LS43Mi0uMjQ2YTYgNiAwIDAgMS0uODQzLS4yNTUgMS41IDEuNSAwIDAgMS0uNTYxLS40MDNxLS4yMzItLjI3LS4yMzItLjczMiAwLS4zNzguMjE1LS42OS4yMjMtLjMxMi42MjgtLjQ5My40MTQtLjE4Ljk2Ny0uMTgxLjgxOCAwIDEuMzA1LjQxMS40ODcuNDAyLjUzOCAxLjA5M2gtMS4xMDhhLjU4LjU4IDAgMCAwLS4yMzEtLjQyN3EtLjE5OC0uMTY1LS41MzctLjE2NS0uMzE1IDAtLjQ4OC4xMTVhLjM3LjM3IDAgMCAwLS4xNjUuMzIxcTAgLjIzLjIzMS4zNTMuMjMxLjExNi43Mi4yMzkuNDk1LjEyMy44MTcuMjU1LjMyMy4xMy41NTQuNDEuMjQuMjcyLjI0OC43MjQgMCAuMzk1LS4yMjMuNzA3YTEuNDQgMS40NCAwIDAgMS0uNjI4LjQ5M3EtLjQwNS4xNzMtLjk1LjE3M1ptNS4xMDYtNC42OTRxLjUyMSAwIC45MjUuMjMuNDA1LjIyMi42MjkuNjY2LjIzLjQzNS4yMyAxLjA1MlY4LjcxaC0xLjE1NlY2LjE5NHEwLS41NDItLjI3My0uODMtLjI3Mi0uMjk2LS43NDMtLjI5Ni0uNDggMC0uNzYuMjk2LS4yNzMuMjg4LS4yNzMuODNWOC43MUg0My41OFYyLjYyN2gxLjE1N3YyLjA5NmExLjUgMS41IDAgMCAxIC41OTUtLjQ2cS4zNzItLjE3My44MjYtLjE3M200LjY5NCA0LjY5NGEyLjQ1IDIuNDUgMCAwIDEtMS4xOS0uMjg4IDIuMTcgMi4xNyAwIDAgMS0uODM0LS44MyAyLjUgMi41IDAgMCAxLS4yOTctMS4yMzNxMC0uNjk5LjMwNS0xLjIzMy4zMTUtLjUzNC44NTEtLjgyMmEyLjQ0IDIuNDQgMCAwIDEgMS4xOTgtLjI5NnEuNjYxIDAgMS4xOTkuMjk2LjUzNy4yODguODQyLjgyMi4zMTUuNTM0LjMxNCAxLjIzMyAwIC42OTktLjMyMiAxLjIzM2EyLjIgMi4yIDAgMCAxLS44Ni44M3EtLjUzNi4yODgtMS4yMDYuMjg4bTAtMS4wMDNxLjMxNCAwIC41ODctLjE0OGExLjEzIDEuMTMgMCAwIDAgLjQ0Ni0uNDZxLjE2NS0uMzA1LjE2NS0uNzQgMC0uNjUtLjM0Ny0uOTk1YTEuMSAxLjEgMCAwIDAtLjgzNC0uMzUzcS0uNDk1IDAtLjgzNS4zNTMtLjMzLjM0NS0uMzMuOTk1dC4zMjIgMS4wMDNxLjMzLjM0NS44MjYuMzQ1bTkuMzYtMy42MjVMNTguODczIDguNzFoLTEuMjQ4bC0uODM0LTMuMTgxLS44MzUgMy4xOEg1NC43bC0xLjM0Ny00LjU1M2gxLjE3NGwuODEgMy40NjkuODc1LTMuNDdoMS4yMjNsLjg2IDMuNDYxLjgxLTMuNDZ6bTEuNTU5LTEuNTI5VjguNzFoLTEuMTU3VjIuNjI3eiIvPjwvZz48L3N2Zz4=",
    ei = 370,
    ti = 20;
var ii, ni;
! function(e) {
    e.BOX = "BOX", e.TEXT = "TEXT", e.INPUT = "INPUT", e.IMAGE = "IMAGE", e.BUTTON = "BUTTON", e.CHECKBOX = "CHECKBOX", e.DATE = "DATE", e.HTML = "HTML", e.DISCOUNT = "DISCOUNT", e.CATEGORY = "CATEGORY", e.MULTI_SELECT = "MULTI_SELECT", e.WHEEL = "WHEEL"
}(ii || (ii = {})),
function(e) {
    e.CENTERED = "centered", e.BOTTOM_LEFT = "bottom_left", e.BOTTOM_CENTERED = "bottom_centered", e.BOTTOM_RIGHT = "bottom_right", e.TOP_LEFT = "top_left", e.TOP_CENTERED = "top_centered", e.TOP_RIGHT = "top_right"
}(ni || (ni = {}));
const oi = e => {
        switch (e) {
            case "email":
                return "email";
            case "phone":
                return "tel";
            default:
                return
        }
    },
    ri = (e, t = 14) => {
        const i = {
            textOverflow: "ellipsis",
            overflow: "hidden",
            fontSize: `${t}px`,
            lineHeight: 1.2 * t + "px",
            paddingBlockEnd: "0px"
        };
        if (!e) return i;
        const n = {
                "4xl": "10px",
                "3xl": "10px",
                "2xl": "8px",
                xl: "6px",
                lg: "2px",
                md: "0px",
                sm: "0px",
                xs: "0px",
                0: "0px"
            }[e] || "0px",
            o = Jt[e] || t,
            r = o > 16 ? "bold" : "normal";
        return Object.assign(Object.assign({}, i), {
            fontSize: `${o}px`,
            lineHeight: 1.2 * o + "px",
            fontWeight: r,
            paddingBlockEnd: n
        })
    },
    si = e => {
        var t;
        if (!e) return 0;
        return null !== (t = {
            0: 0,
            xs: 1,
            sm: 2,
            md: 3,
            lg: 4,
            xl: 5,
            "2xl": 6,
            "3xl": 7,
            "4xl": 8,
            "5xl": 9,
            "6xl": 10
        }[e]) && void 0 !== t ? t : 0
    },
    ai = (e, t) => e && t ? {
        border: `${si(t)}px solid ${e}`
    } : {},
    ci = e => {
        if ("full" === e) return "100%";
        return `${{0:0,xs:2,sm:4,md:6,lg:8,xl:10,"2xl":12,"3xl":14,"4xl":16,"5xl":20,"6xl":26}[e]||0}px`
    },
    li = e => {
        var t, i;
        const n = !(null == e ? void 0 : e.type) || "auto" === (null == e ? void 0 : e.type) || !(null == e ? void 0 : e.zoom);
        return {
            backgroundPosition: `${(null===(t=null==e?void 0:e.pos)||void 0===t?void 0:t[0])||0}% ${(null===(i=null==e?void 0:e.pos)||void 0===i?void 0:i[1])||0}%`,
            backgroundSize: n ? "cover" : `${null==e?void 0:e.zoom}%`
        }
    },
    ui = (e, t, i, n) => {
        var o;
        if (e.id === Wt.switcher && !(null == n ? void 0 : n.shouldShowSwitcher)) return {
            display: "none"
        };
        const {
            align: r,
            dir: s,
            bgUrl: a,
            pad: c,
            bgColor: l,
            css: u,
            fill: d,
            borderCol: p,
            borderWidth: h,
            radius: g,
            hidden: m,
            bgDims: f,
            bgHidden: w,
            redirectURL: b
        } = e.attr || {}, _ = ((e, t) => {
            if (!e || 0 === (null == e ? void 0 : e.length)) return {};
            const i = {},
                n = "string" == typeof e ? ["left", e] : e;
            return "LR" === t ? (n.forEach((e, t) => {
                switch (e) {
                    case "center":
                        i.alignItems = "center", 0 === t && (i.textAlign = "center");
                        break;
                    case "left":
                        i.justifyContent = "flex-start", 0 === t && (i.textAlign = "left");
                        break;
                    case "right":
                        i.justifyContent = "flex-end", 0 === t && (i.textAlign = "right");
                        break;
                    case "bottom":
                        i.alignItems = "flex-end";
                        break;
                    case "top":
                        i.alignItems = "flex-start";
                        break;
                    default:
                        return i
                }
                return {}
            }), i) : (n.forEach((e, t) => {
                switch (e) {
                    case "center":
                        i.justifyContent = "center", 0 === t && (i.textAlign = "center", i.alignItems = "center");
                        break;
                    case "left":
                        i.alignItems = "flex-start", 0 === t && (i.textAlign = "left");
                        break;
                    case "right":
                        i.alignItems = "flex-end", 0 === t && (i.textAlign = "right");
                        break;
                    case "bottom":
                        i.justifyContent = "flex-end";
                        break;
                    case "top":
                        i.justifyContent = "flex-start";
                        break;
                    default:
                        return i
                }
                return {}
            }), i)
        })(r, s), S = ((e, t, i) => e ? {
            flexDirection: i === Wt.switcher ? "row" : "column"
        } : {
            flexDirection: "LR" === t ? "row" : "column"
        })(t, s, e.id), v = (({
            url: e,
            bgColor: t,
            bgHidden: i,
            isRootNode: n,
            bgDims: o
        }) => {
            const r = n ? t || "#fff" : t || "inherit",
                s = o ? li(o) : {};
            return !e || i ? {
                background: r,
                backgroundImage: "unset"
            } : e ? Object.assign({
                backgroundImage: `url("${e}") ${n?`, linear-gradient(to right, ${r}, ${r})`:""}`,
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                backgroundPosition: "center center"
            }, s) : {}
        })({
            url: a,
            bgColor: l,
            bgHidden: w,
            isRootNode: e.id === Wt.root,
            bgDims: f
        }), y = ((e, t = !1) => {
            var i;
            return e ? {
                padding: `${null!==(i={0:0,xs:2,sm:4,md:6,lg:8,xl:10,"2xl":12,"3xl":14,"4xl":16,"5xl":20,"6xl":26}[e])&&void 0!==i?i:6}px`
            } : {
                padding: t ? "2px" : "6px"
            }
        })(c, e.id === Wt.root), E = (e => "string" == typeof e ? e : "boolean" == typeof e ? e ? "50%" : "" : "50%")(d);
        let I = 0;
        const T = ai(p || "#ffffff", h || "0");
        let O = "flex";
        const N = "boolean" == typeof m && m;
        return e.id !== Wt.root ? (N && (O = "none"), !a || (null == i ? void 0 : i.pad) && "0" === (null == i ? void 0 : i.pad) || !(null == i ? void 0 : i.radius) || "0" === (null == i ? void 0 : i.radius) ? a || (I = ci(g || "0")) : I = ((e, t) => {
            const i = parseInt(ci(e).split("px")[0], 10),
                n = parseInt(ci(t).split("px")[0], 10),
                o = Math.abs(i - n);
            return 0 === o ? n / 2 : o
        })((null == i ? void 0 : i.radius) || "0", (null == i ? void 0 : i.pad) || "0")) : I = ci(g || "0"), Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({
            position: "relative",
            borderRadius: I,
            display: O,
            flex: E,
            flexShrink: a ? 0 : 1,
            minHeight: a ? "200px" : "unset",
            minWidth: 0,
            width: "text_content" === e.id ? "100%" : "unset",
            overflow: e.id === Wt.root ? "hidden" : "unset",
            transform: `scale(${(null===(o=null==i?void 0:i.theme)||void 0===o?void 0:o.scale)/100||1})`,
            cursor: b ? "pointer" : "unset"
        }, T), S), y), _), v), u || {})
    },
    di = e => ({
        whiteSpace: e ? "nowrap" : "normal",
        width: e ? "calc(100% - 25px)" : "unset"
    }),
    pi = (e, t, i, n = !1) => {
        if (n) return e ? {
            width: "100%",
            alignItems: "center",
            margin: "0 auto",
            height: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "unset"
        } : {
            width: "100%",
            maxWidth: "600px",
            margin: "0 auto",
            height: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "unset"
        };
        if (e) switch (t) {
            case "step_1":
                return {
                    minWidth: "90%",
                    minHeight: "450px"
                };
            case "step_2":
                return {
                    minWidth: "90%",
                    minHeight: "unset"
                };
            case "teaser":
                return {
                    width: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "360px",
                    minHeight: "72px"
                };
            case "step_1_a":
            case "step_1_b":
                return {
                    minWidth: "90%",
                    height: "auto"
                };
            default:
                return {
                    minWidth: "100%",
                    minHeight: "450px"
                }
        }
        switch (t) {
            case "teaser":
                return {
                    width: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "360px",
                    minHeight: "72px"
                };
            case "step_1_a":
            case "step_1_b":
                return {
                    maxWidth: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "530px",
                    minWidth: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "530px",
                    minHeight: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "240px",
                    height: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "unset"
                };
            default:
                return {
                    maxWidth: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "530px",
                    minWidth: (null == i ? void 0 : i.width) ? `${null==i?void 0:i.width}px` : "530px",
                    minHeight: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "500px",
                    height: (null == i ? void 0 : i.fixedHeight) ? `${null==i?void 0:i.height}px` : "unset"
                }
        }
    },
    hi = e => {
        const t = "12px",
            i = "50%";
        switch (e) {
            case ni.CENTERED:
                return {
                    left: i,
                    top: i,
                    transform: "translate(-50%, -50%)"
                };
            case ni.BOTTOM_LEFT:
                return {
                    left: t,
                    bottom: t
                };
            case ni.BOTTOM_RIGHT:
                return {
                    right: t,
                    bottom: t
                };
            case ni.TOP_RIGHT:
                return {
                    right: t,
                    top: t
                };
            case ni.TOP_LEFT:
                return {
                    left: t,
                    top: t
                };
            case ni.TOP_CENTERED:
                return {
                    top: t,
                    left: i,
                    transform: "translateX(-50%)"
                };
            case ni.BOTTOM_CENTERED:
                return {
                    bottom: t,
                    left: i,
                    transform: "translateX(-50%)"
                };
            default:
                return {
                    left: i,
                    top: i,
                    transform: "translate(-50%, -50%)"
                }
        }
    },
    gi = e => {
        const {
            height: t
        } = e.attr;
        return t || (e.id === Wt.logo ? 24 : 50)
    },
    mi = (e, t, i) => {
        const n = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        let o = "",
            r = t.replace(/\D/g, "");
        const s = (e, t, i, n = !1) => (e.length === (n ? 4 : 2) || !n && 1 === e.length && parseInt(e) > Math.floor(i / 10) ? (e = Math.min(parseInt(e), i).toString().padStart(n ? 4 : 2, "0"), o += e + (t < 2 ? "/" : "")) : e.length > 0 && (o += e), e.length),
            a = (e, t) => 2 === e && (e => e % 4 == 0 && e % 100 != 0 || e % 400 == 0)(t) ? 29 : n[e - 1];
        let c = [0, 0, 0];
        if ("MM/DD/YYYY" === e) {
            let e = r.slice(0, 2),
                t = r.slice(2, 4),
                i = r.slice(4, 8);
            c[0] = s(e, 0, 12), 2 === e.length ? c[1] = s(t, 1, a(parseInt(e), parseInt(i) || (new Date).getFullYear())) : (o += t, c[1] = t.length), o += i, c[2] = i.length
        } else if ("DD/MM/YYYY" === e) {
            let e = r.slice(0, 2),
                t = r.slice(2, 4),
                i = r.slice(4, 8);
            if (c[0] = s(e, 0, 31), c[1] = s(t, 1, 12), 2 === e.length && 2 === t.length) {
                let n = a(parseInt(t), parseInt(i) || (new Date).getFullYear());
                parseInt(e) > n && (e = n.toString(), o = e + "/" + o.split("/")[1] + "/", c[0] = 2)
            }
            o += i, c[2] = i.length
        } else if ("YYYY/MM/DD" === e) {
            let e = r.slice(0, 4),
                t = r.slice(4, 6),
                i = r.slice(6, 8);
            if (c[0] = s(e, 0, 9999, !0), c[1] = s(t, 1, 12), 4 === e.length && 2 === t.length) {
                let n = a(parseInt(t), parseInt(e));
                c[2] = s(i, 2, n)
            } else o += i, c[2] = i.length
        }
        let l = i;
        for (let e = 0; e < 3; e++) {
            if (i > r.length - c[2] - c[1]) {
                l = o.length;
                break
            }
            if (i > r.length - c[2] - c[1] - c[0]) {
                l = o.length - c[2];
                break
            }
            if (i > 0) {
                l = o.length - c[2] - c[1];
                break
            }
        }
        return {
            formattedValue: o,
            cursorPosition: l
        }
    },
    fi = e => {
        const t = {},
            i = n => {
                if (n.id.startsWith("custom_field") && (t[n.id] = n.attr), n.children) {
                    if (!Array.isArray(n.children) || e.type === ii.HTML) return t;
                    n.children.forEach(e => "string" != typeof e && i(e))
                }
            };
        return i(e), t
    },
    wi = e => {
        switch (e) {
            case "DD/MM/YYYY":
                return "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/([0-9]{4})$";
            case "MM/DD/YYYY":
                return "^(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/([0-9]{4})$";
            case "YYYY/MM/DD":
                return "^([0-9]{4})/(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])$"
        }
    },
    bi = e => {
        const t = parseInt(e.slice(1), 16);
        return .299 * (t >> 16 & 255) + .587 * (t >> 8 & 255) + .114 * (255 & t) < 128
    },
    _i = e => e.replace(/\D/g, "");

function Si(e) {
    return "type" in e
}
const vi = (e, t, i = 8, n) => {
        if (!Array.isArray(e)) {
            if (n ? n(e.id, t) : e.id === t) return e;
            if (0 === i || !e.children) return null;
            const o = Array.isArray(e.children) ? e.children : [e.children];
            for (const e of o)
                if ("string" != typeof e && Si(e)) {
                    const o = vi(e, t, i - 1, n);
                    if (o) return o
                }
        }
        return null
    },
    yi = (e, t) => {
        if (t) {
            const t = vi(e, Wt.wheel),
                i = vi(e, "image");
            if (e.attr = Object.assign(Object.assign({}, e.attr), {
                    dir: "TB"
                }), t && (t.attr = Object.assign(Object.assign({}, t.attr), {
                    pos: "top"
                })), i && "string" != typeof e.children) {
                i.attr = Object.assign(Object.assign({}, i.attr), {
                    fill: "40%"
                });
                const t = e.children.filter(e => "string" != typeof e && "image" !== e.id);
                e.children = [i, ...t]
            }
        }
        return e
    },
    Ei = ({
        nodeId: e,
        flowId: t,
        channelType: i,
        optinType: n
    }) => ({
        formId: o,
        event: r,
        stepType: s
    }) => {
        window.poAnalytics.track(r, {
            flowId: t,
            nodeId: e,
            formId: o,
            channelType: i,
            optinType: n,
            formStepType: s
        }, !0)
    },
    Ii = ({
        event: e,
        optinType: t,
        flowId: i,
        nodeId: n,
        formId: o
    }) => {
        Ei({
            optinType: t,
            channelType: ["webpush"],
            flowId: i,
            nodeId: n
        })({
            stepType: "step_1",
            event: e,
            formId: o
        })
    },
    Ti = (e, t, i = !1) => {
        const n = {};
        return Object.keys(e).forEach(o => {
            t[o] && ("date" === e[o].fieldType && i ? n[e[o].mapAttribute] = (e => {
                const t = e.split("/");
                let i, n, o;
                return 4 === t[0].length ? [i, n, o] = t : 4 === t[2].length && (i = t[2], parseInt(t[1]) <= 12 ? [o, n] = t : [n, o] = t), n = n.padStart(2, "0"), o = o.padStart(2, "0"), `${i}-${n}-${o}`
            })(t[o]) : n[e[o].mapAttribute] = t[o])
        }), n
    },
    Oi = e => {
        const t = (new DOMParser).parseFromString(e, "text/html");
        return null == t ? void 0 : t.body
    },
    Ni = e => "HTML" === (null == e ? void 0 : e.type),
    Ci = (e, t) => {
        const i = e.children[t];
        if (!i) return "";
        const n = Oi(i),
            o = (e => {
                const t = (new DOMParser).parseFromString(e, "text/html").head.getElementsByTagName("style");
                let i = "";
                for (const e of t) i += e.textContent;
                return i
            })(i),
            r = document.createElement("style");
        r.textContent = o, n.appendChild(r);
        const s = e.attr.button,
            a = e.attr.input;
        if (s) {
            const e = s.submit;
            if (e) {
                const t = Object.keys(e);
                n.querySelectorAll("button").forEach(e => {
                    const i = Lt(e, {
                        root: n
                    });
                    if (t.includes(i)) {
                        n.querySelector(i).setAttribute("type", "submit")
                    } else e.setAttribute("type", "button")
                })
            }
        }
        if (a) {
            let e = [],
                t = [];
            a.email && (e = Object.keys(a.email)), a.phone && (t = Object.keys(a.phone));
            const i = Object.keys(a).filter(e => "email" !== e && "phone" !== e);
            n.querySelectorAll("input:not([type=radio]), input:not([type=checkbox])").forEach(o => {
                const r = Lt(o, {
                    root: n
                });
                e.includes(r) ? (o.setAttribute("type", "email"), o.setAttribute("name", "email")) : t.includes(r) ? (o.setAttribute("type", "tel"), o.setAttribute("name", "phone")) : i.forEach(e => {
                    Object.keys(a[e]).includes(r) && o.setAttribute("name", e)
                })
            })
        }
        return n.innerHTML
    },
    Mi = ({
        event: e,
        attributes: t,
        handleDismiss: i,
        DOMTree: n,
        handleSubmit: o
    }) => {
        var r;
        if (!(null === (r = Object.keys(t || {})) || void 0 === r ? void 0 : r.length)) return;
        const s = e.target,
            a = Lt(s, {
                root: n
            });
        Object.entries(t).forEach(([t, n]) => {
            switch (t) {
                case "dismiss":
                    Object.keys(n).forEach(e => {
                        e === a && i()
                    });
                    break;
                case "submit":
                    Object.keys(n).forEach(t => {
                        if (t === a) {
                            const t = s.closest("form");
                            if (t) {
                                if (!t.reportValidity()) return;
                                e.preventDefault(), e.stopPropagation();
                                const i = {};
                                t.querySelectorAll("input, select, textarea").forEach(e => {
                                    const t = e.getAttribute("name");
                                    if (t) i[t] = e.value;
                                    else {
                                        const t = e.getAttribute("id");
                                        i[t] = e.value
                                    }
                                }), o(null, i)
                            }
                        }
                    })
            }
        })
    },
    Ai = ({
        event: e,
        attributes: t,
        DOMTree: i
    }) => {
        var n;
        if (!(null === (n = Object.keys(t || {})) || void 0 === n ? void 0 : n.length)) return;
        const o = e.target;
        if ("submit" === o.getAttribute("type")) return;
        const r = Lt(o, {
            root: i
        });
        Object.entries(t).forEach(([e, t]) => {
            if ("phone" === e) Object.keys(t).forEach(e => {
                e === r && (o.value = o.value.replace(/[^0-9+]/g, ""))
            });
            else Object.keys(t).forEach(e => {
                if (e === r) {
                    const t = i.querySelector(e);
                    if ("number" === t.type) t.value = t.value.replace(/[^0-9]/g, "")
                }
            })
        })
    },
    Li = (t, i) => {
        if (!t) return {};
        if (i && "sm" === i && t.sm) {
            const {
                sm: i
            } = t, n = e(t, ["sm"]);
            return Object.assign(Object.assign({}, n), i)
        }
        return e(t, ["sm"])
    };
var Pi = e => {
        var {
            activation_rule: t
        } = e;
        return !t || new $e(t).processUrlActivationRule()
    },
    ki = (e, t) => ae() ? void 0 !== (null == e ? void 0 : e.mobile) ? e.mobile : t : void 0 !== (null == e ? void 0 : e.default) ? e.default : t,
    Di = e => {
        e > 0 && (x.optinDeferredUntil = Date.now() + 86400 * parseInt(e, 10) * 1e3)
    },
    Ri = {
        showNativePrompt(e) {
            var {
                hintScreenConfig: t,
                subscribeCallback: i,
                source: n,
                nodeId: o,
                trackWebPushDenied: r,
                trackWebPushSubmission: s
            } = e;

            function a() {
                return window.poSubscriptionSource = y, i(t, n, o, r, s)
            }
            var {
                isSafari: c,
                isFirefox: l,
                isiOS: u
            } = pe();
            if (!c && !l && !u) return a();
            var d = document.querySelector("body");
            return ye("This is Safari/Firefox browser. The prompt will only show after the website is clicked somewhere"), new Promise(e => {
                d.addEventListener("click", () => {
                    a().then(e)
                })
            })
        },
        oldRender(e) {
            var t, {
                    config: i,
                    subscribeCallback: o
                } = e,
                r = new V;
            if (!r.isPermissionNotGranted && window.Notification && window.Notification.permission === d.NOTIFICATION_PERMISSION.DEFAULT) {
                if (i.optin.type !== n.OFF) {
                    var s = i.optin.config,
                        a = s.timeout,
                        c = a.default,
                        l = i.optin.type,
                        u = s.overlay;
                    ae() && (c = a.mobile);
                    var p = r.optinSeenCount; - 1 === c ? ye('🟠 Optin prompt was not shown. Reason: timeout set to "never"') : p >= s.maxCountPerSession ? ye("🟠 Optin prompt was not shown. Reason: maximum count per session limit reached (".concat(p, " / ").concat(s.maxCountPerSession, ")")) : Date.now() < x.optinDeferredUntil ? ye("🟠 Optin prompt was not shown. Reason: deferred till ".concat(new Date(x.optinDeferredUntil))) : setTimeout(() => {
                        Notification.permission !== d.NOTIFICATION_PERMISSION.DEFAULT || x.isPermissionGranted ? ye("🟠 Optin prompt was not shown. Reason: permission not default") : l === n.TWO_STEP ? Promise.all([
                            import ("./OptinPrompt.js"),
                            import ("./NewCustomPrompt.js")
                        ]).then(e => {
                            var [{
                                OptinPromptWidget: t
                            }, {
                                NewCustomPromptWidget: n
                            }] = e, {
                                position: a
                            } = s, c = t, l = new c;
                            if (c === n) l.setState(Ye(Ye({}, s), {}, {
                                logo: i.logo
                            })), setTimeout(() => {
                                o(null), l.changeState(ae() ? "mobile-fade" : "down"), setTimeout(ae() ? l.destroy.bind(l) : () => {
                                    l.changeState("fade-top"), setTimeout(l.destroy.bind(l), 300)
                                }, 5e3)
                            }, 5e3);
                            else {
                                var d = document.querySelector(".pushowl-optin");
                                d && (H.logToServer({
                                    message: "duplicate custom prompt",
                                    subdomain: H.subdomain,
                                    data: {
                                        breadcrumbs: ve
                                    }
                                }), d.remove()), l.setState({
                                    multilingual_title: s.multilingual_title,
                                    multilingual_description: s.multilingual_description,
                                    yesButton: s.yesButton,
                                    noButton: s.noButton,
                                    theme: s.theme,
                                    logo: i.logo,
                                    branding: i.branding,
                                    position: a,
                                    autoFocus: i.flags.custom_prompt_screenreader_support,
                                    yesButtonListener: () => {
                                        o(u), setTimeout(() => {
                                            l.destroy()
                                        }, 100), window.poSubscriptionSource = E, i.optin_report_enabled && window.poAnalytics.track("PNOptinAllowClicked", {
                                            optinSeenCount: r.optinSeenCount
                                        })
                                    },
                                    noButtonListener: () => {
                                        setTimeout(() => {
                                            l.destroy()
                                        }, 100), r.isPermissionNotGranted = !0, i.optin_report_enabled && window.poAnalytics.track("PNOptinLaterClicked", {
                                            optinSeenCount: r.optinSeenCount
                                        })
                                    }
                                })
                            }
                            r.optinSeenCount += 1, i.optin_report_enabled && window.poAnalytics.track("PNOptinShown", {
                                optinSeenCount: r.optinSeenCount
                            }), ye("Custom Prompt shown. Config: ", i.optin), Di(s.deferForDays)
                        }).catch(e => {
                            ye("Error encountered in loading Optin prompt: ".concat(e.message))
                        }) : (this.showNativePrompt({
                            hintScreenConfig: u,
                            subscribeCallback: o
                        }), r.optinSeenCount += 1, ye("Browser Prompt shown. Config: ", i.optin), Di(s.deferForDays))
                    }, 1e3 * c)
                }
            } else r.isPermissionNotGranted ? t = "prompt was dismissed in this session" : window.Notification && window.Notification.permission !== d.NOTIFICATION_PERMISSION.DEFAULT && (t = "permission already ".concat(window.Notification.permission)), ye("🟠 Optin prompt was not shown. Reason: ".concat(t))
        },
        renderPopup: e => Ue(function*() {
            var {
                showNextForm: t,
                deferForDays: i,
                node: n,
                shouldIncrementFrequency: o,
                waitTime: r,
                flowId: s,
                openShadowDOM: a,
                customOptinStep: c,
                isMerchantOnFreePlan: l
            } = e;
            try {
                var {
                    OptinForm: u
                } = yield
                import ("./index.js"), d = new V, p = new u(n, t, s, Ei({
                    nodeId: n.id,
                    flowId: s,
                    channelType: n.channels,
                    optinType: "popup"
                }), a, d.config.subscription_confirmation, c, l);
                setTimeout(() => p.render(), 1e3 * r), Di(i), o && (d.optinSeenCount += 1)
            } catch (e) {
                ye("Error encountered in loading New Optin: ".concat(e.message))
            }
        })(),
        renderEmbeddedFormOnDOM: e => Ue(function*() {
            var {
                showNextForm: t,
                node: i,
                flowId: n,
                DOMContainer: o
            } = e;
            try {
                var {
                    EmbeddedForm: r
                } = yield
                import ("./embedded-form.js"), s = new V;
                new r(i, t, n, Ei({
                    nodeId: i.id,
                    flowId: n,
                    channelType: i.channels,
                    optinType: "embedded"
                }), !0, s.config.subscription_confirmation, o).render()
            } catch (e) {
                ye("Error encountered in loading New Optin: ".concat(e.message))
            }
        })(),
        renderBISFormOnDOM: e => Ue(function*() {
            var {
                showNextForm: t,
                node: i,
                flowId: n,
                DOMContainer: o,
                currentVariant: r
            } = e;
            try {
                var {
                    BISForm: s
                } = yield
                import ("./bis_form.js");
                new s(i, t, n, Ei({
                    nodeId: i.id,
                    flowId: n,
                    channelType: i.channels,
                    optinType: "embedded"
                }), !0, o, r.id).render()
            } catch (e) {
                ye("Error encountered in loading New Optin: ".concat(e.message))
            }
        })(),
        showBrowserPrompt(e) {
            var {
                subscribeCallback: t,
                hintScreenConfig: i,
                shouldIncrementFrequency: n,
                deferForDays: o,
                waitTime: r,
                flowId: s,
                nodeId: a,
                formId: c,
                onDismiss: l
            } = e;
            if (dt()) {
                Ii({
                    event: "optin_viewed",
                    optinType: "browser_webpush",
                    flowId: s,
                    nodeId: a,
                    formId: c
                });
                var u = () => Ii({
                        event: "optin_submitted",
                        optinType: "browser_webpush",
                        flowId: s,
                        nodeId: a,
                        formId: c
                    }),
                    d = () => {
                        l && l(), Ii({
                            event: "optin_denied",
                            optinType: "browser_webpush",
                            flowId: s,
                            nodeId: a,
                            formId: c
                        })
                    };
                if (setTimeout(() => {
                        this.showNativePrompt({
                            hintScreenConfig: i,
                            subscribeCallback: t,
                            source: "optin_flows",
                            nodeId: a,
                            trackWebPushDenied: d,
                            trackWebPushSubmission: u
                        })
                    }, 1e3 * r), n)(new V).optinSeenCount += 1;
                Di(o)
            }
        },
        showCustomPrompt: e => Ue(function*() {
            var {
                waitTime: t,
                shouldIncrementFrequency: i,
                flowId: n,
                deferForDays: o,
                config: r,
                subscribeCallback: s,
                custom_prompt_screenreader_support: a,
                nodeId: c,
                formId: l,
                logo: u,
                onDismiss: d
            } = e;
            try {
                if (!dt()) return;
                var {
                    OptinPromptWidget: p
                } = yield
                import ("./OptinPrompt.js"), h = () => Ii({
                    event: "optin_submitted",
                    optinType: "custom_webpush",
                    flowId: n,
                    nodeId: c,
                    formId: l
                }), g = () => {
                    d && d(), Ii({
                        event: "optin_denied",
                        optinType: "custom_webpush",
                        flowId: n,
                        nodeId: c,
                        formId: l
                    })
                }, m = new p, f = new V;
                if (setTimeout(() => m.setState(Ye(Ye({}, r), {}, {
                        autoFocus: a,
                        yesButtonListener: () => {
                            s(r.overlay, "optin_flows", c, g, h), setTimeout(() => {
                                m.destroy()
                            }, 100), window.poSubscriptionSource = E
                        },
                        noButtonListener: () => {
                            g(), setTimeout(() => {
                                m.destroy()
                            }, 100), f.isPermissionNotGranted = !0, d && d()
                        },
                        logo: u
                    })), 1e3 * t), Ii({
                        event: "optin_viewed",
                        optinType: "custom_webpush",
                        flowId: n,
                        nodeId: c,
                        formId: l
                    }), Di(o), i)(new V).optinSeenCount += 1
            } catch (e) {
                ye("Error encountered in loading Custom prompt: ".concat(e.message))
            }
        })(),
        processNewConfig(e) {
            var t, i = e.find(e => "active" === e.status);
            if (!i) return [];
            for (var n = [], o = i.flow_nodes || [], r = 0; r < o.length; r += 1) {
                var s = o[r - 1];
                if (r % 2 != 0) {
                    var a = s.wait_times ? ki(s.wait_times, s.wait_time) : s.wait_time;
                    o[r].wait_time = a, o[r].underlay_color = i.underlay_color, o[r].underlay_opacity = i.underlay_opacity, o[r].underlay_enabled = i.underlay_enabled, n.push(o[r])
                }
            }
            var c = new V;
            if (null != c && null !== (t = c.config) && void 0 !== t && t.subscription_confirmation) {
                var l = n.find(e => e.channels.includes("email")),
                    u = n.find(e => e.channels.includes("sms"));
                if (l && u && n.indexOf(l) > n.indexOf(u)) {
                    var d = n.indexOf(l),
                        p = n.indexOf(u),
                        h = n[d];
                    n[d] = n[p], n[p] = h
                }
            }
            return [Ye(Ye({}, i), {}, {
                flow_nodes: n
            })]
        },
        newRenderBISForm(e) {
            for (var {
                    config: t,
                    bisForm: i,
                    DOMContainer: n,
                    currentVariant: o
                } = e, r = () => {
                    this.newRenderEmbeddedForm({
                        config: t,
                        bisForm: i,
                        DOMContainer: n
                    })
                }, {
                    flow_nodes: s
                } = i, a = 0; a < s.length; a += 1) {
                var c = s[a];
                if (c.underlay_color = i.underlay_color, c.underlay_opacity = i.underlay_opacity, c.underlay_enabled = i.underlay_enabled, "embedded" === c.optin_type) return void this.renderBISFormOnDOM({
                    node: c,
                    DOMContainer: n,
                    showNextForm: r,
                    flowId: i.id,
                    currentVariant: o
                })
            }
        },
        newRenderEmbeddedForm(e) {
            var {
                config: t,
                embeddedForm: i,
                DOMContainer: n
            } = e;
            if ("active" === i.status) {
                var {
                    activation_rule: o
                } = t;
                if (Pi({
                        activation_rule: o
                    }))
                    for (var r = () => {
                            this.newRenderEmbeddedForm({
                                config: t,
                                embeddedForm: i,
                                DOMContainer: n
                            })
                        }, {
                            flow_nodes: s
                        } = i, a = 0; a < s.length; a += 1) {
                        var c = s[a];
                        if ("embedded" === c.optin_type) return void this.renderEmbeddedFormOnDOM({
                            node: c,
                            DOMContainer: n,
                            showNextForm: r,
                            flowId: i.id
                        })
                    }
            }
        },
        newRender(e) {
            var t = this,
                {
                    config: i,
                    optinFlows: n,
                    shouldIncrementFrequency: o,
                    subscribeCallback: r,
                    skippedNodes: s = [],
                    customOptinStep: a = 0
                } = e,
                c = this.processNewConfig(n || []).find(e => "active" === e.status) || {};
            if (c.flow_nodes) {
                var {
                    flow_nodes: l
                } = c, {
                    activation_rule: u
                } = i, p = new V, {
                    optinSeenCount: h
                } = p, {
                    consent: g
                } = x, m = c && l && Pi({
                    activation_rule: u
                }) && (e => {
                    var {
                        deferForDays: t,
                        shouldIncrementFrequency: i
                    } = e;
                    return !(i && t > 0 && Date.now() < x.optinDeferredUntil && (ye("🟠 Optin prompt was not shown. Reason: deferred till ".concat(new Date(x.optinDeferredUntil))), 1))
                })({
                    deferForDays: c.defer_for_days,
                    shouldIncrementFrequency: o
                }) && (e => {
                    var {
                        frequency: t,
                        optinSeenCount: i,
                        shouldIncrementFrequency: n
                    } = e;
                    return !n || i < t || (ye("🟠 Optin prompt was not shown. Reason: Optin seen count exceeded"), !1)
                })({
                    frequency: c.frequency,
                    optinSeenCount: h,
                    shouldIncrementFrequency: o
                });
                ye("Can Optin Render", m);
                for (var f, w = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0,
                            o = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        t.newRender({
                            config: i,
                            optinFlows: n,
                            shouldIncrementFrequency: !1,
                            subscribeCallback: r,
                            skippedNodes: e ? [...s, e] : s,
                            customOptinStep: o || a >= 1 ? 0 : a + 1
                        })
                    }, b = function() {
                        var e = l[_],
                            n = s.includes(e.id),
                            u = e.forms[0] && Ni(e.forms[0].config),
                            p = (e => {
                                var {
                                    channels: t,
                                    consent: i
                                } = e;
                                return t.every(e => i.includes(e))
                            })({
                                consent: g,
                                channels: e.channels
                            });
                        if (m && !n && (u || !p)) {
                            if (-1 === e.wait_time) return 0;
                            if ("popup" === e.optin_type) return ye("Can render popup"), t.renderPopup({
                                node: e,
                                shouldIncrementFrequency: o,
                                showNextForm: w,
                                deferForDays: c.defer_for_days,
                                waitTime: e.wait_time,
                                flowId: c.id,
                                openShadowDOM: "enabled" === i.flags.open_shadow_dom,
                                customOptinStep: a,
                                isMerchantOnFreePlan: i.is_free_plan && "enabled" !== i.flags.disable_pushowl_branding
                            }), {
                                v: void 0
                            };
                            if ("browser_webpush" === e.optin_type) return t.showBrowserPrompt({
                                subscribeCallback: r,
                                waitTime: e.wait_time,
                                hintScreenConfig: e.forms[0].config.oneStep.overlay,
                                shouldIncrementFrequency: o,
                                deferForDays: c.defer_for_days,
                                flowId: c.id,
                                nodeId: e.id,
                                formId: e.forms[0].id,
                                onDismiss: () => {
                                    w(e.id)
                                }
                            }), {
                                v: void 0
                            };
                            if ("custom_webpush" === e.optin_type && window.Notification && window.Notification.permission === d.NOTIFICATION_PERMISSION.DEFAULT && !x.isPermissionGranted) {
                                var h = e.forms[0];
                                return t.showCustomPrompt({
                                    config: Ye(Ye({}, h.config.twoStep), {}, {
                                        position: {
                                            default: h.desktop_position,
                                            mobile: h.mobile_position
                                        }
                                    }),
                                    waitTime: e.wait_time,
                                    flowId: c.id,
                                    shouldIncrementFrequency: o,
                                    deferForDays: c.defer_for_days,
                                    subscribeCallback: r,
                                    custom_prompt_screenreader_support: i.flags.custom_prompt_screenreader_support,
                                    nodeId: e.id,
                                    formId: e.forms[0].id,
                                    logo: i.logo,
                                    onDismiss: () => {
                                        w(e.id)
                                    }
                                }), {
                                    v: void 0
                                }
                            }
                        }
                    }, _ = 0; _ < l.length; _ += 1)
                    if (0 !== (f = b()) && f) return f.v
            } else ye("Optin is set to OFF")
        }
    };
class ji {
    constructor(e) {
        var {
            wid: t,
            websitePushId: i
        } = e;
        this.wid = t, this.subdomain = H.subdomain, this.webPushId = i || H.webPushId, this.getSubscription = this.getSubscription.bind(this)
    }
    webServiceUrl() {
        return "".concat(H.apiEndpoint, "/safari/v2/").concat(this.wid)
    }
    getSubscription() {
        return new Promise((e, t) => {
            var i = n => {
                    ye("PermissionData:", n.permission), "default" === n.permission ? setTimeout(() => window.safari.pushNotification.requestPermission(this.webServiceUrl(), this.webPushId, {
                        domain: window.location.origin
                    }, i), 0) : "denied" === n.permission ? t(d.NOTIFICATION_PERMISSION.DENIED) : "granted" === n.permission && e(n.deviceToken)
                },
                n = window.safari.pushNotification.permission(this.webPushId);
            i(n)
        })
    }
}
class xi {
    constructor(e) {
        var {
            vapidPublicKey: t,
            integrations: i,
            serviceWorkerConfig: n
        } = e;
        this.getSubscription = this.getSubscription.bind(this), this.vapid_public_key = t, this.integrations = i, this.serviceWorkerConfig = n
    }
    getServiceWorkerParams(e) {
        return this.serviceWorkerConfig ? {
            url: this.serviceWorkerConfig.url,
            options: {
                scope: this.serviceWorkerConfig.scope
            }
        } : {
            url: H.getServiceWorkerUrlWithIntergrations(H.serviceWorkerUrl(e), this.integrations),
            options: {}
        }
    }
    getSubscription(e) {
        return new Promise((t, i) => {
            ("granted" === Notification.permission ? Promise.resolve("granted") : Notification.requestPermission()).then(n => {
                if (n === d.NOTIFICATION_PERMISSION.GRANTED) {
                    var o = this.getServiceWorkerParams(e),
                        r = o.options;
                    0 !== o.url.indexOf("http") && (o.url = "".concat(location.protocol, "//").concat(location.host).concat(o.url)), navigator.serviceWorker.register(o.url, o.options).then(e => {
                        var n;
                        "shopify" === H.platform && ("/" === r.scope ? navigator.serviceWorker.getRegistrations().then(function(e) {
                            e.forEach(function(e) {
                                e.scope.match(/pushowl\/sdks\//) && (e.unregister(), ye("Found stale service worker on subpath scope", e))
                            })
                        }) : navigator.serviceWorker.getRegistrations().then(function(e) {
                            e.forEach(function(e) {
                                e.active && e.active.scriptURL.match(/pushowl/) && !e.scope.match(/pushowl\//) && (e.unregister(), ye("Found stale service worker on root scope", e))
                            })
                        })), e.installing ? n = e.installing : e.waiting ? n = e.waiting : e.active && (n = e.active), n && ("activated" === n.state ? this._serviceWorkerSubscriber(e, t, i) : n.addEventListener("statechange", n => {
                            "activated" === n.target.state && this._serviceWorkerSubscriber(e, t, i)
                        }))
                    }).catch(e => {
                        Te(e), i(e)
                    })
                } else n !== d.NOTIFICATION_PERMISSION.DENIED && n !== d.NOTIFICATION_PERMISSION.DEFAULT || i(n)
            })
        })
    }
    _serviceWorkerSubscriber(e, t, i) {
        var n = {
            userVisibleOnly: !0,
            applicationServerKey: he(this.vapid_public_key)
        };
        e.pushManager.subscribe(n).then(e => {
            t(e)
        }).catch(n => {
            n.toString().indexOf("InvalidStateError") >= 0 ? e.pushManager.getSubscription().then(n => {
                n.unsubscribe().then(n => {
                    e.pushManager.subscribe({
                        userVisibleOnly: !0,
                        applicationServerKey: he(this.vapid_public_key)
                    }).then(e => {
                        t(e)
                    }).catch(e => {
                        i(e)
                    })
                }).catch(e => {
                    i(e)
                })
            }) : (Te(n), i(n))
        })
    }
}
class Ui {
    constructor(e) {
        var {
            flags: t,
            vapidPublicKey: i,
            integrations: n,
            websitePushId: o,
            wid: r,
            serviceWorkerConfig: s
        } = e;
        if (this.getSubscription = null, pe().isApnsSafari) {
            var a = new ji({
                websitePushId: o,
                wid: r
            });
            this.getSubscription = a.getSubscription.bind(this, t)
        } else {
            var c = new xi({
                vapidPublicKey: i,
                integrations: n,
                serviceWorkerConfig: s
            });
            this.getSubscription = c.getSubscription.bind(this, t)
        }
    }
    get isPermissionGranted() {
        return window.Notification && window.Notification.permission === d.NOTIFICATION_PERMISSION.GRANTED || x.isPermissionGranted
    }
    get isPermissionDefault() {
        return H.isWorkerAvailable.then(e => "default" === window.Notification.permission).catch(() => !1)
    }
}
class Bi {
    constructor() {
        var e;
        this.subdomain = H.subdomain, this.environment = H.environment, this.apiEndpoint = H.apiEndpoint, this.apiClient = new Ke, this.webPushId = H.webPushId, this.config = null, this.storageManager = new x, this.sessionManager = new V, this.storeLib = new(this.getStoreLibClass()), this.subscriberTokenExists = !!x.subscriberToken, this.tokenType = this.subscriberTokenExists ? "subscriber" : "visitor", this.tokenValue = this.subscriberTokenExists ? x.subscriberToken : x.visitorToken, this.customLog = console, window.sessionStorage && navigator.serviceWorker && (e = this.getConfig()).then(e => {
            this.config = e, e.flags && "enabled" === e.flags.remove_old_brevo_script && this.removeOldBrevoIntegration(), (({
                subdomain: e,
                flags: t
            }) => {
                if (!e) return !1;
                if (t && "disabled" === t.pwa_manifest) return !0;
                const i = Et(null == t ? void 0 : t.skip_manifest_for_subdomains),
                    n = "undefined" != typeof window ? Et(window.PUSHOWL_MANIFEST_BLOCKLIST) : [];
                return new Set([...i, ...n]).has(e)
            })({
                subdomain: this.subdomain,
                flags: e.flags
            }) ? It() : (({
                logoURL: e,
                storeTheme: t
            }) => {
                try {
                    const i = Object.assign(Object.assign({}, yt), {
                            name: document.title,
                            short_name: document.title
                        }),
                        n = document.querySelector('meta[name="theme-color"]');
                    n && (i.theme_color = n.getAttribute("content") || yt.theme_color), t && (i.theme_color = t);
                    const o = document.querySelector('meta[property="og:site_name"]');
                    if (o) {
                        const e = o.getAttribute("content") || document.title;
                        i.name = e, i.short_name = e
                    }
                    const r = document.querySelector('meta[property="og:description"]');
                    r && (i.description = r.getAttribute("content") || "");
                    const s = JSON.stringify(i),
                        a = new Blob([s], {
                            type: "application/json"
                        }),
                        c = URL.createObjectURL(a),
                        l = document.createElement("link");
                    l.rel = "manifest", l.href = c, l.dataset.pushowlManifest = "true";
                    const u = document.getElementsByTagName("head")[0];
                    document.querySelector("link[rel=manifest]") || u.insertBefore(l, u.firstChild);
                    const d = document.querySelector("link[rel=apple-touch-icon]");
                    if (e && !d) {
                        const t = document.createElement("link");
                        t.rel = "apple-touch-icon", t.href = e, t.dataset.pushowlManifest = "true", u.insertBefore(t, u.firstChild)
                    }
                } catch (e) {
                    ye("Unable to create manifest")
                }
            })({
                logoURL: e.logo,
                storeTheme: e.flags.store_theme
            }), Ee("Status", {
                ACR: e.abandoned_cart_enabled ? "🟢" : "🔴",
                "Browse abandonment": e.browse_abandonment_enabled ? "🟢" : "🔴",
                "Price drop": e.price_drop.enabled ? "🟢" : "🔴",
                "Back in stock": e.back_in_stock.enabled ? "🟢" : "🔴",
                "optin type": {
                    off: "🔴",
                    oneStep: "Browser prompt",
                    twoStep: "Custom prompt"
                }[e.optin.type],
                "Notification permission": window.Notification ? Notification.permission : null,
                "Store section": this.getStoreLibClass().section,
                "Notification Preferences": e.privacy.notification_preference.enabled ? "🟢" : "🔴"
            }), this.handleIOS(), this.load3PIntegrations()
        }), this.ready = new Promise(t => {
            this.init(e).then(() => {
                if ((!this.config.flags || "disabled" !== this.config.flags.status) && ((this.environment !== d.ENVIRONMENT.production || !this.config.flags || !1 !== this.config.flags.console_message && "disabled" !== this.config.flags.console_message) && this.customLog.log("[PushOwl Web Push Notifications] starting up"), this.browserHandler = new Ui({
                        flags: this.config.flags,
                        vapidPublicKey: this.config.vapid_public_key,
                        integrations: this.config.integrations,
                        websitePushId: this.config.website_push_id,
                        wid: this.config.wid,
                        serviceWorkerConfig: this.config.service_worker
                    }), this.isAllowed())) {
                    var e = {
                        subdomain: this.subdomain,
                        browserHandler: this.browserHandler,
                        config: this.config,
                        storeLib: this.storeLib,
                        storageManager: this.storageManager,
                        sessionManager: this.sessionManager
                    };
                    this.context = e, this.browserHandler.isPermissionGranted || !x.subscriberToken || x.hasRaisedUnsubscriptionEvent || (this.config.optin_report_enabled && window.poAnalytics.track("Unsubscribed"), x.hasRaisedUnsubscriptionEvent = !0), this.browserHandler.isPermissionGranted ? ht.verifySubscriber({
                        browserHandler: this.browserHandler
                    }).then(() => {
                        this.syncCustomerId(), this.onSubscriberVerifiedOnPageLoad()
                    }).catch((e, t) => {
                        ye(e), e === s.NO_SUBSCRIBER_TOKEN || e === s.INVALID_SUBSCRIBER_TOKEN ? ht.subscribe({
                            browserHandler: this.browserHandler,
                            websitePushId: this.config.website_push_id
                        }).catch(e => {
                            Te(e)
                        }) : e === s.INVALID_STATE_ERROR && ht.validateOrSyncSubscription({
                            subscription: t,
                            websitePushId: this.config.website_push_id
                        })
                    }) : this.isBrevoEnabled() && this.onSubscriberVerifiedOnPageLoad(), this.browserHandler.isPermissionDefault.then(e => {
                        e && this.handlePushNotificationUnsubscription()
                    }), this.customTasks(), mt.subscribeButtons({
                        context: e
                    }), this.checkPushowlSession(), this.onCanRun(), t()
                }
            }).catch(e => {
                Te(e)
            })
        }), this.debugCustomTask(), this.onScriptLoad(), Y.run()
    }
    removeOldBrevoIntegration() {
        ye("🧹 Redirecting old Brevo integration");
        var e = (e, t) => {
            var i;
            Object.defineProperty(window, e, {
                get: () => i,
                set: n => {
                    var o;
                    (o = n) && "object" == typeof o && ["sib_automation_host", "plugin_end_point", "user_connection_id", "isShopifyScopeUpdated", "isNewTrackingAllowed"].some(e => Object.prototype.hasOwnProperty.call(o, e)) ? (window[t] = n, ye("🔀 Redirected old Brevo ".concat(e, " to ").concat(t))) : (i = n, ye("✅ Allowed current integration to set ".concat(e)))
                },
                configurable: !1,
                enumerable: !0
            })
        };
        e("sib", "sib_old"), e("sendinblue", "sendinblue_old"), Object.defineProperty(window, "sibShopify", {
            get: () => window.sibShopify_old,
            set: e => {
                window.sibShopify_old = e, ye("🔀 Redirected sibShopify to sibShopify_old (old integration only)")
            },
            configurable: !1
        }), Object.defineProperty(window, "sib_email_id", {
            get: () => window.sib_email_id_old,
            set: e => {
                window.sib_email_id_old = e, ye("🔀 Redirected sib_email_id to sib_email_id_old")
            },
            configurable: !1
        }), ye("✅ Old Brevo variable redirection active")
    }
    handlePushNotificationUnsubscription() {
        var {
            consent: e
        } = x;
        1 === e.length && "webpush" === e[0] && (x.subscriberToken = null, G.del("pushowl_sw_subscriber_token")), x.isPermissionGranted = !1, x.consent = x.consent.filter(e => "webpush" !== e)
    }
    isBrevoEnabled() {
        return "enabled" === this.config.flags.brevo_email && !!this.config.brevo_ma_key
    }
    handleIOS() {
        var e;
        pe().isiOS && navigator.standalone && !x.subscriberToken && !x.hasLoggediOSStandaloneMode && (x.hasLoggediOSStandaloneMode = !0), this.isAllowed() && pe().isiOS && !navigator.standalone && V.installPromptSeenCount < 3 && !x.installPromptDismissed && null !== (e = this.config.ios_prompt) && void 0 !== e && e.enabled && (
            import ("./IOSInstallWidget.js").then(e => {
                var t, i, n, {
                        IOSInstallWidget: o
                    } = e,
                    r = new o({
                        title: null === (t = this.config.ios_prompt) || void 0 === t ? void 0 : t.title,
                        description: null === (i = this.config.ios_prompt) || void 0 === i ? void 0 : i.description,
                        btnText: null === (n = this.config.ios_prompt) || void 0 === n ? void 0 : n.btn_text
                    });
                setTimeout(() => {
                    r.init()
                }, 2e3)
            }), V.installPromptSeenCount += 1)
    }
    get flyoutHandler() {
        return new Promise(e => {
            import ("./FlyoutWidgetHandler.js").then(t => {
                var {
                    FlyoutWidgetHandler: i
                } = t;
                e(new i(this.config.flyout_config))
            }).catch(e => {
                ye("Error encountered in loading Flyout widget: ".concat(e.message))
            })
        })
    }
    onScriptLoad() {}
    onConfigLoaded() {}
    onCanRun() {}
    onSubscriberVerifiedOnPageLoad() {}
    onSuccessfullSubscription() {}
    getStoreLibClass() {}
    getStoreCartClass() {}
    getCurrentProduct() {}
    isAllowed() {
        var {
            activation_rule: e
        } = this.config;
        return !e || e.processUrlActivationRule()
    }
    isAutomationAllowed() {
        var {
            automation_rule: e
        } = this.config;
        return !e || e.processUrlActivationRule()
    }
    filterSKU(e) {
        var {
            automation_rule: t
        } = this.config;
        return t ? Ye(Ye({}, e), {}, {
            items: ((e || {}).items || []).filter(e => !t.processSKU(e.sku))
        }) : e
    }
    init(e) {
        return new Promise(t => {
            this.isEnabled().then(() => {
                (e || this.getConfig()).then(e => {
                    this.config = e, "enabled" === e.flags.subscriber_tracking && x.subscriberToken && (window.poAnalytics.setVisitorProperties({
                        wid: this.config.wid,
                        pagePath: window.location.href,
                        pageURL: window.location.origin + window.location.pathname,
                        subscriberToken: x.subscriberToken,
                        browserNotificationPermission: window.Notification ? window.Notification.permission : null
                    }), window.poAnalytics.track("subscriber_page_visited")), window.poAnalytics.setVisitorProperties({
                        wid: this.config.wid,
                        optinConfig: this.config.optin
                    }), ye("Analytics visitor props set: ", {
                        wid: this.config.wid,
                        optinConfig: this.config.optin
                    }), window.poAnalytics.meta.isNewVisitor && this.config.optin_report_enabled && window.poAnalytics.track("SessionCreated"), t(e)
                })
            }).catch(e => {
                Te(e), ye("🔴 Shutting down. Reason: ".concat(e))
            })
        })
    }
    getConfig() {
        return lt.get()
    }
    isEnabled() {
        return ut({
            subdomain: this.subdomain
        })
    }
    debugCustomTask() {
        var e = ue("poTaskType");
        e === S && (ye("Task type", e), this.isEnabled().then(e => {
            ! function(e) {
                var {
                    subdomain: t,
                    StoreLibClass: i,
                    isEnabled: n
                } = e, o = d.STORAGE_KEYS, r = new V, s = new x, a = new Ke, c = {
                    notification_permission: window.Notification && window.Notification.permission
                };
                c.localStorage = {
                    [o.VISITOR_TOKEN]: x.visitorToken,
                    [o.SESSION_TOKEN]: x.sessionToken,
                    [o.SUBSCRIBER_TOKEN]: x.subscriberToken,
                    [o.SUBSCRIPTION]: x.subscription,
                    [o.BACK_IN_STOCK_SUBSCRIPTIONS]: s.back_in_stock.subscriptions,
                    [o.PRICE_DROP_SUBSCRIPTIONS]: s.price_drop.subscriptions,
                    [o.SYNCED_CART_JSON]: x.synced_cart_json,
                    [o.SYNCED_CUSTOMER_ID]: x.syncedCustomerId,
                    [o.SYNCED_AC_EVENTS]: x.ac_events,
                    [o.OPTIN_DEFERRED_UNTIL]: x.optinDeferredUntil
                }, c.sessionStorage = {
                    [r.subscriptionVerifiedKey]: r.subscriptionVerified,
                    [r.permissionKey]: r.isPermissionNotGranted,
                    [r.optinSeenCountKey]: r.optinSeenCount
                }, c.subdomain = t, c.debug_url = window.location.href, c.user_agent = navigator.userAgent, c.logs = ve, Promise.all([new Promise(e => {
                    navigator.serviceWorker.getRegistrations().then(function(t) {
                        e(t.map(function(e) {
                            return {
                                scope: e.scope,
                                active: e.active
                            }
                        }))
                    })
                }), n, i ? i.getCart() : Promise.resolve()]).then(e => {
                    var [t, i, n] = e;
                    n && (c.current_cart_json = n), t && t.length && (c.serviceWorkers = t), "string" == typeof i && (c.pushowl_not_enabled_reason = i), a.debugLog(c), window.prompt("Send this to PushOwl Support", JSON.stringify(c, !1, 2))
                })
            }({
                subdomain: this.subdomain,
                StoreLibClass: this.getStoreLibClass(),
                isEnabled: e
            })
        }))
    }
    customTasks() {
        var e = ue("poTaskType");
        e && (ye("Task type", e), e === b ? ht.subscribeIfNotAlready({
            enableHintScreen: !0,
            websitePushId: this.config.website_push_id,
            browserHandler: this.browserHandler
        }) : e === _ && ht.unsubscribe(this.browserHandler))
    }
    checkPushowlSession() {
        "pushowl" === ue("utm_source") && function(e) {
            var {
                privacy: t
            } = e.config;
            if (t.notification_preference.enabled) {
                var i = document.querySelector("body"),
                    n = {
                        subdomain: e.subdomain,
                        subscriberToken: x.subscriberToken
                    };
                Promise.all([
                    import ("./NotificationPreference.js"),
                    import ("./NotificationPreferenceToggle.js")
                ]).then(e => {
                    var [{
                        NotificationPreference: o
                    }, {
                        NotificationPreferenceToggle: r
                    }] = e, s = new o(i, n, t.notification_preference);
                    new r(i, t.notification_preference, s).render(), ye("Notification Preference shown.")
                }).catch(e => {
                    ye("Error encountered in loading Notif preferences: ".concat(e.message))
                })
            }
        }(this.context)
    }
    syncCustomerId() {
        var e = this.getStoreLibClass();
        if (e.customerId && e.customerId !== x.syncedCustomerId && this.config.privacy.customer_id) {
            if (window.Shopify && !x.subscriberToken) {
                var t = be(d.STORAGE_KEYS.SUBSCRIBER_TOKEN);
                t && (x.subscriberToken = t)
            }
            this.apiClient.syncSubscriber().then(() => {
                x.syncedCustomerId = e.customerId
            }).catch(() => {
                Te("Subscriber not synced")
            })
        }
    }
    initiateDefaultPrompt(e, t, i, n, o) {
        var r = !(!e || ae()) && e.enabled;
        return H.isWorkerAvailable.then(s => {
            if (s) return ht.subscribe({
                enableHintScreen: r,
                hintScreenData: e,
                websitePushId: this.config.website_push_id,
                browserHandler: this.browserHandler,
                source: t,
                source_id: i
            }).then(e => {
                if (e && e.subscriberToken) {
                    var {
                        consent: t
                    } = x;
                    return x.consent = [...t, "webpush"], o && o(), this.onSuccessfullSubscription(), e
                }
                return n && n(), e
            }).catch(e => {}).finally(() => {
                var e = document.querySelector(".js-custom-prompt-2");
                e && e.remove()
            });
            var a = this.subdomain.replace(/\./g, "-");
            return H.scriptUrl.includes("pushowl-shopify.js") ? Promise.resolve({
                subscriberToken: x.subscriberToken
            }) : ("sendinblue" !== H.platform && window.open("https://".concat(a, ".powl.co/subscribe?po_url=").concat(encodeURIComponent(window.location.href), "&env=").concat(this.environment, "&subdomain=").concat(this.subdomain, "&platform=").concat(H.platform), "", "width=700,height=500"), new Promise(e => {
                window.addEventListener("message", t => {
                    var i = t.data;
                    if (i && "subscriptionFinish" === i.type) {
                        var n = i.data;
                        n && "granted" === n.status && (x.subscriberToken = n.subscriberToken, x.isPermissionGranted = !0, e({
                            subscriberToken: n.subscriberToken
                        }))
                    }
                })
            }))
        })
    }
    render() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
            t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
            i = this.getStoreLibClass();
        if (!this.config) throw "Pushowl Config not initialised";
        i.section === f.HOME ? this.defaultRender(t) : i.section === f.PRODUCT ? this.storeLib.getProductDetails(e).then(e => {
            this.productSectionRender(e), this.BISFormRender(e)
        }) : i.section === f.CHECKOUT ? ye("🟠 Optin prompt was not shown. Reason: Checkout page") : this.defaultRender(t), this.renderEmbeddedForms()
    }
    optinFlows(e) {
        var t = new Nt(this.config);
        Object.values(this.config.optin_flows || []).forEach(i => {
            var n, o = Ri.processNewConfig([i] || []).find(e => "active" === e.status) || {};
            if (o && "active" !== !o.status) {
                t.addOptinFlow({
                    id: o.id,
                    scrollDepth: o.scroll_depth,
                    exitIntent: o.exit_intent,
                    exclusionUrls: o.exclusion_urls || [],
                    inclusionUrls: o.inclusion_urls || [],
                    exclusionUrlsEnabled: o.exclusion_urls_enabled,
                    inclusionUrlsEnabled: o.inclusion_urls_enabled,
                    scrollDepthEnabled: o.scroll_depth_enabled,
                    timeSpent: ki(o.time_spent || {}, 0),
                    timeSpentEnabled: o.time_spent_enabled,
                    deviceType: o.device_type || [],
                    requireAllConditions: null !== (n = "all" === o.trigger_mode) && void 0 !== n && n,
                    exclusion_countries: o.exclusion_countries || [],
                    exclusion_countries_enabled: o.exclusion_countries_enabled || !1,
                    inclusion_countries: o.inclusion_countries || [],
                    inclusion_countries_enabled: o.inclusion_countries_enabled || !1
                }, () => {
                    Ri.newRender({
                        config: this.config,
                        optinFlows: [i],
                        shouldIncrementFrequency: e,
                        subscribeCallback: this.initiateDefaultPrompt.bind(this)
                    })
                })
            }
        }), t.initialize()
    }
    renderEmbeddedForms() {
        var e = this.config.embedded_forms;
        e && e.length && (null == e || e.forEach(e => {
            document.querySelectorAll('div[data-pushowl-form-id="'.concat(e.id, '"]')).forEach(t => {
                t && Ri.newRenderEmbeddedForm({
                    config: this.config,
                    embeddedForm: e,
                    DOMContainer: t
                })
            })
        }))
    }
    defaultRender() {
        var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            t = {
                isOptinRendered: !1,
                isFlyoutRendered: !1
            };
        "sendinblue" === H.platform ? Ri.oldRender({
            config: this.config,
            subscribeCallback: this.initiateDefaultPrompt.bind(this)
        }) : this.optinFlows(e), t.isOptinRendered = !0;
        var i = this.config.home.flyout;
        return dt() && i.enabled && window.Notification.permission !== d.NOTIFICATION_PERMISSION.GRANTED ? (this.flyoutHandler.then(e => {
            vt.renderOptin({
                rootContext: {
                    config: this.config,
                    browserHandler: this.browserHandler
                },
                flyoutHandler: e
            })
        }), t.isFlyoutRendered = !0) : ye("Flyout was not shown. Reason: ".concat(i.enabled ? "permission already granted" : "flyout is disabled"), "Config: ", this.config.home.flyout), t
    }
    productSectionRender(e) {
        if (dt()) {
            var t = e.currentVariant();
            if (!t) return void ye("Current variant not found");
            Ee("Current product", {
                id: t.id,
                name: t.name,
                "Is in stock?": t.available ? "✅" : "❌",
                price: t.price
            });
            var {
                back_in_stock: i,
                price_drop: n
            } = this.config, o = {
                config: this.config,
                browserHandler: this.browserHandler
            };
            this.flyoutHandler.then(r => {
                var s = {
                    rootContext: o,
                    flyoutHandler: r,
                    product: e,
                    variant: t
                };
                if (!t.available && i.enabled && this.isAutomationAllowed()) vt.renderBackInStock(s);
                else if (t.available && n.enabled && this.isAutomationAllowed()) vt.renderPriceDrop(s);
                else {
                    var {
                        isFlyoutRendered: a
                    } = this.defaultRender();
                    a || r.remove()
                }
            })
        }
    }
    BISFormRender(e) {
        var t = e.currentVariant();
        if (t)
            if (t.available) {
                var i = document.querySelector("div.pushowl-brevo-bis-form");
                i && (i.style.display = "none")
            } else {
                var n = this.config.bis_embedded_forms;
                if (n && n.length) {
                    var o = document.querySelector("div.pushowl-brevo-bis-form"),
                        r = n[0],
                        s = r ? Ye(Ye({}, r), {}, {
                            flow_nodes: r.flow_nodes.map(e => "form_collection" === e.type ? Ye(Ye({}, e), {}, {
                                forms: e.forms.filter(e => "step_1_b" !== e.step_type)
                            }) : e)
                        }) : null;
                    o && s && (o.style.display = "block", Ri.newRenderBISForm({
                        config: this.config,
                        bisForm: s,
                        DOMContainer: o,
                        currentVariant: t
                    }))
                }
            }
        else ye("Current variant not found")
    }
    showBrowserPrompt() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            overlay: {
                enabled: !1
            }
        };
        return Ri.showNativePrompt({
            hintScreenConfig: e,
            subscribeCallback: e => this.initiateDefaultPrompt(e)
        })
    }
    showCustomPrompt() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            t = arguments.length > 1 ? arguments[1] : void 0;
        import ("./OptinPrompt.js").then(i => {
            var {
                OptinPromptWidget: n
            } = i, o = this.config.optin.config, r = new n, s = {
                multilingual_title: e.title ? {
                    default: e.title
                } : o.multilingual_title,
                multilingual_description: e.description ? {
                    default: e.description
                } : o.multilingual_description,
                yesButton: e.yesButton && e.yesButton.label ? {
                    multilingual_label: {
                        default: e.yesButton.label
                    }
                } : o.yesButton,
                noButton: e.noButton && e.noButton.label ? {
                    multilingual_label: {
                        default: e.noButton.label
                    }
                } : o.noButton
            };
            r.setState(Ye(Ye({}, s), {}, {
                theme: e.theme || o.theme,
                logo: e.logo || o.logo,
                position: e.position || o.position,
                autoFocus: this.config.flags.custom_prompt_screenreader_support,
                yesButtonListener: () => {
                    t && (window.poSubscriptionSource = E, this.config.optin_report_enabled && window.poAnalytics.track("PNOptinAllowClicked", {
                        optinSeenCount: this.sessionManager.optinSeenCount
                    })), this.initiateDefaultPrompt(void 0 === e.overlay ? o.overlay : e.overlay).then(() => {
                        "function" == typeof e.yesButtonListener && e.yesButtonListener()
                    }), setTimeout(() => {
                        r.destroy()
                    }, 100)
                },
                noButtonListener: () => {
                    setTimeout(() => {
                        r.destroy()
                    }, 100), this.sessionManager.isPermissionNotGranted = !0, t && this.config.optin_report_enabled && window.poAnalytics.track("PNOptinLaterClicked", {
                        optinSeenCount: this.sessionManager.optinSeenCount
                    }), "function" == typeof e.noButtonListener && o.noButtonListener()
                }
            })), t && this.config.optin_report_enabled && window.poAnalytics.track("PNOptinShown", {
                optinSeenCount: this.sessionManager.optinSeenCount
            })
        }).catch(e => {
            ye("Error encountered in loading Optin Prompt widget (API): ".concat(e.message))
        })
    }
    load3PIntegrations() {}
    klaviyoIntegration() {
        var e = function() {
            var e = Ue(function*(e) {
                var t = e && e.detail && e.detail.metaData && (e.detail.metaData.$email || e.detail.metaData.email),
                    i = e && e.detail && e.detail.metaData && (e.detail.metaData.$phone_number || e.detail.metaData.phone_number);
                "stepSubmit" === e.detail.type && (yield Ve.identify({
                    email: t,
                    phone: i
                }))
            });
            return function(t) {
                return e.apply(this, arguments)
            }
        }();
        window.addEventListener("klaviyoForms", e)
    }
    trackPage(e) {
        ne.viewPage(e)
    }
    loadBrevoTracker() {
        var e;
        if ("enabled" === this.config.flags.brevo_email && this.config.brevo_ma_key && z() && (null === (e = window) || void 0 === e || null === (e = e.Shopify) || void 0 === e || !e.designMode)) {
            var t = "enabled" !== this.config.flags.old_tracker;
            return ne.loadTracker({
                isNewTracker: t,
                maKey: this.config.brevo_ma_key
            }), x.email && "undefined" !== x.email && (ne.emailId = x.email), t || this.trackPage(), !0
        }
        return !1
    }
    syncAbandonedCart(e, t) {
        this.isAutomationAllowed() && (e ? Promise.resolve(e) : this.getStoreLibClass().getCart()).then(e => {
            ! function(e) {
                var {
                    cartJson: t,
                    CartClass: i,
                    options: n = {
                        pushowl: !0,
                        brevo: !1
                    }
                } = e;
                if (t) {
                    var o = new i(t),
                        r = new Ke,
                        s = o.token ? "token" : "checkout_token",
                        a = ["Cart Token:", o[s], "Cart Items", o.item_count, "Last synced Cart:", x.synced_cart_json, "AC Events:", x.ac_events],
                        c = x.synced_cart_json,
                        l = c ? new i(c) : null;
                    t.updated_at = t.updated_at || (new Date).toISOString(), o.item_count > 0 && (!l || o.cartId !== l.cartId) || 0 === o.item_count && l && l[s] === o[s] && l.cartId !== o.cartId ? (n.pushowl ? r.syncCart(o).then(e => {
                        x.synced_cart_json = t, x.ac_events = e.result;
                        var {
                            token: i
                        } = e.result;
                        i && (x.subscriberToken = i), ye("Cart synced successfully. Response: ", e)
                    }).catch(e => {
                        Te(e), ye("🔴 Cart sync failed. Error: request failed. ", e, ...a)
                    }) : x.synced_cart_json = t, n.brevo && Ne(t)) : ye("Cart was not synced. Reason: No change since last sync.", ...a)
                }
            }({
                cartJson: this.filterSKU(e),
                CartClass: this.getStoreCartClass(),
                options: t
            })
        }).catch(e => {
            Te(e), ye("🔴 Cart sync failed. Error: cart could not be synced.  ", e)
        })
    }
    syncCart(e) {
        this.config.abandoned_cart_enabled && this.isAutomationAllowed() && (x.subscriberToken ? ht.verifySubscriber({
            browserHandler: this.browserHandler
        }).then(() => {
            this.syncAbandonedCart(e, {
                pushowl: !0,
                brevo: this.isBrevoEnabled()
            })
        }).catch(e => {
            Te(e), ye("🔴 Cart sync failed. Error: cart could not be synced.  ", e)
        }) : this.syncAbandonedCart(e, {
            pushowl: !1,
            brevo: this.isBrevoEnabled()
        }))
    }
    syncProductView() {
        var e = this.getStoreLibClass(),
            t = this.config.browse_abandonment_enabled,
            i = this.config.price_drop,
            n = this.config.price_drop.is_viewed;
        e.section === f.PRODUCT && this.isAutomationAllowed() && this.getCurrentProduct().then(e => {
            this.isBrevoEnabled() && this.storeLib.getProductDetails().then(t => {
                var i = t.currentVariant() || {};
                ne.track({
                    eventName: l.PRODUCT_VIEWED,
                    eventData: {
                        id: "".concat(e.id),
                        data: Ye(Ye({}, e), {}, {
                            title: t.title,
                            featured_image: i.featured_image || t.featured_image,
                            price: i.price || t.price,
                            currency: window.Shopify ? window.Shopify.currency.active : "",
                            url: Ce(window.location.href),
                            current_variant: i
                        })
                    }
                }), i ? ne.viewProduct(String(i.id)) : ne.viewProduct(String(e.id))
            }), x.subscriberToken && (t || i && n) && this.apiClient.syncProductView(e).then(e => {
                var {
                    token: t
                } = e.result;
                t && (x.subscriberToken = t), ye("Product synced", e)
            }).catch(e => {
                Te(e)
            })
        }).catch(e => {
            Te(e)
        })
    }
    subscriberLog(e) {
        var t = Object.entries(e).map(e => {
            var [t, i] = e;
            return "".concat(encodeURIComponent(t), "=").concat(encodeURIComponent(i))
        }).join("&");
        return Y.get({
            path: "/log/?".concat(t)
        })
    }
    setCustomerId(e) {
        window.pushowl.customerId = e, this.browserHandler.isPermissionGranted && ht.verifySubscriber({
            browserHandler: this.browserHandler
        }).then(() => {
            this.syncCustomerId()
        })
    }
    setCheckoutId(e) {
        this.browserHandler.isPermissionGranted && ht.verifySubscriber({
            browserHandler: this.browserHandler
        }).then(() => {
            this.apiClient.syncSubscriberTokenAndCheckoutId(e)
        })
    }
    showBackInStock(e, t) {
        this.flyoutHandler.then(i => {
            vt.renderBackInStock({
                rootContext: this.context,
                flyoutHandler: i,
                product: e,
                variant: t
            })
        })
    }
    showPriceDrop(e, t) {
        this.flyoutHandler.then(i => {
            vt.renderPriceDrop({
                rootContext: this.context,
                flyoutHandler: i,
                product: e,
                variant: t
            })
        })
    }
    identify() {
        return arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}
    }
}
if (!window.poAnalytics) {
    var Fi = {
        storeConfigGUID: H.guid,
        subdomain: H.subdomain,
        visitorToken: x.visitorToken,
        sessionToken: x.sessionToken
    };
    window.poAnalytics = new _t({
        endpoint: "".concat(H.apiEndpoint, "/event/v1/events")
    }), window.poAnalytics.setVisitorProperties(Fi), ye("Analytics initialized with data: ", Fi)
}
class Yi {
    constructor() {}
    get cartId() {
        return ""
    }
}
class Hi extends Yi {
    constructor(e) {
        super(), this.token = e.token, this.checkout_token = e.checkout_token, this.item_count = e.item_count, this.items = e.items
    }
    get cartId() {
        const e = [this.token || this.checkout_token || ""];
        let t = [];
        const i = {};
        for (const e of this.items) t.push(e.variant_id), i[e.variant_id] = e.quantity;
        t = t.sort((e, t) => e - t);
        for (const n of t) {
            const t = i[n];
            e.push(`${n}:${t}`)
        }
        return e.concat(e).join("-")
    }
}
var zi, Ki, Gi = ["/cart/add.js", "/cart/update.js", "/cart/change.js", "/cart/add", "/cart/update", "/cart/change"],
    Vi = {
        decodeBase64Id(e) {
            if (e && "string" == typeof e) {
                var t = e.split("::").shift();
                return window.atob(t).replace(/\?.*/, "").split("/").pop()
            }
            return e
        },
        detectAjaxCartUpdate(e) {
            var t = window.XMLHttpRequest.prototype.open;
            window.XMLHttpRequest.prototype.open = function(i, n) {
                this.addEventListener("readystatechange", function() {
                    var t = i.toUpperCase();
                    ("GET" === t && "/cart/add.js" === n || "POST" === t && ("/cart/add.js" === n || "/cart/update.js" === n || "/cart/change.js" === n)) && 4 === this.readyState && "function" == typeof e && e()
                }), t.apply(this, arguments)
            }
        },
        detectAjaxCartUpdate2: e => {
            var t = window.fetch;
            window.fetch = function() {
                var i = arguments.length <= 0 ? void 0 : arguments[0],
                    n = t(...arguments);
                return i.match(/api\/.*\/graphql/) ? (n.then(e => e.clone()).then(t => {
                    try {
                        t.json().then(t => {
                            var i;
                            if (t && t.data && (t.data.checkoutLineItemsUpdate && t.data.checkoutLineItemsUpdate.checkout ? i = t.data.checkoutLineItemsUpdate.checkout : t.data.checkoutLineItemsAdd && t.data.checkoutLineItemsAdd.checkout && (i = t.data.checkoutLineItemsAdd.checkout), i)) {
                                var n = i.lineItems.edges.map(e => ({
                                    variant_id: parseInt(Vi.decodeBase64Id(e.node.variant.id), 10),
                                    product_id: parseInt(Vi.decodeBase64Id(e.node.variant.product.id), 10),
                                    quantity: e.node.quantity
                                }));
                                "function" == typeof e && e({
                                    checkout_token: Vi.decodeBase64Id(i.id),
                                    item_count: n.length,
                                    items: n,
                                    updated_at: (new Date).toISOString()
                                })
                            }
                        })
                    } catch (e) {}
                }), n) : n
            }
        },
        detectAjaxCartUpdate3: e => {
            var t = window.fetch;
            window.fetch = function() {
                var i = arguments.length <= 0 ? void 0 : arguments[0],
                    n = "string" == typeof i ? i : i instanceof URL ? i.pathname : i instanceof Request ? i.url : "",
                    o = ((arguments.length <= 1 ? void 0 : arguments[1]) || {}).method || "GET",
                    r = t(...arguments);
                return ("GET" === o && n.includes("/cart/add") || "POST" === o && (n.includes("/cart/add") || n.includes("/cart/update") || n.includes("/cart/change"))) && r.then(() => {
                    e()
                }), r
            }
        },
        detectBigCAjaxCartUpdate: e => {
            var t = window.fetch;
            window.fetch = function() {
                var i = (arguments.length <= 0 ? void 0 : arguments[0]) || "",
                    n = ((arguments.length <= 1 ? void 0 : arguments[1]) || {}).method || "GET",
                    o = t(...arguments);
                return "POST" === n && (i.includes("/cart/add") || i.includes("/cart/update")) && o.then(() => {
                    e()
                }), o
            }
        },
        detectBigCAjaxCartUpdate2: e => {
            var t = window.XMLHttpRequest.prototype.open;
            window.XMLHttpRequest.prototype.open = function(i, n) {
                this.addEventListener("readystatechange", function() {
                    "POST" === i.toUpperCase() && (n.includes("/cart/add") || n.includes("/cart/update")) && 4 === this.readyState && "function" == typeof e && e()
                }), t.apply(this, arguments)
            }
        },
        detectShoplineAjaxCartUpdate: e => {
            if (window.fetch) {
                var t = window.fetch;
                window.fetch = function() {
                    try {
                        var i = (arguments.length <= 0 ? void 0 : arguments[0]) || "",
                            n = ((arguments.length <= 1 ? void 0 : arguments[1]) || {}).method || "GET",
                            o = t(...arguments),
                            r = Gi.some(e => i.includes(e));
                        return "POST" === n && r && o.then(() => {
                            "function" == typeof e && e()
                        }), o
                    } catch (e) {
                        return t(...arguments)
                    }
                }
            }
        },
        detectShoplineAjaxCartUpdate2: e => {
            if (window.XMLHttpRequest && window.XMLHttpRequest.prototype) {
                var t = window.XMLHttpRequest.prototype.open;
                window.XMLHttpRequest.prototype.open = function(i, n) {
                    try {
                        var o = Gi.some(e => n.includes(e));
                        this.addEventListener("readystatechange", function() {
                            try {
                                "POST" === i.toUpperCase() && o && 4 === this.readyState && "function" == typeof e && e()
                            } catch (e) {}
                        }), t.apply(this, arguments)
                    } catch (e) {
                        t.apply(this, arguments)
                    }
                }
            }
        }
    };
class qi extends Bi {
    onCanRun() {
        this.processBrevoEmailParam();
        var {
            context: e
        } = this;
        this.render(), mt.backInStockButtons({
            context: e,
            onSuccess: e => {
                this.productSectionRender(e)
            }
        }), mt.priceDropButtons({
            context: e,
            onSuccess: e => {
                this.productSectionRender(e)
            }
        }), this.initAjaxCartDetection(), this.handleVariantChange(), this.watchForAnyPageChange()
    }
    watchForAnyPageChange() {
        var {
            pageName: e
        } = te;
        return "/" === window.location.pathname ? this.trackPage("Homepage") : te.section === f.THANK_YOU ? this.trackPage("Thank you") : e ? this.trackPage(e) : this.trackPage()
    }
    watchForViewCategoryPage() {
        var {
            collectionName: e,
            collectionId: t
        } = te;
        e && "all" !== e && void 0 !== t && ne.viewCategory(t)
    }
    watchForViewSearchPage() {
        try {
            if ("/search" !== window.location.path) return;
            var e = decodeURIComponent(window.location.search.replace(/\?q=/, "").replace(/\+/g, " "));
            "" !== e && ne.search(e, Ce(window.location.href))
        } catch (e) {
            Te(e)
        }
    }
    processBrevoEmailParam() {
        try {
            var e = new URLSearchParams(window.location.search).get("_se"),
                t = e ? window.atob(e) : null,
                i = document.querySelector('meta[name="customer-email"]'),
                n = i ? i.getAttribute("content") : null;
            t && t !== x.email ? (x.email = t, x.consent = [...x.consent, "email"]) : n && (x.email = n, x.consent = [...x.consent, "email"])
        } catch (e) {
            ye("Error in processing brevo email param", e)
        }
    }
    onSubscriberVerifiedOnPageLoad() {
        this.syncAbandonedCart(null, {
            pushowl: this.config.abandoned_cart_enabled,
            brevo: "enabled" === this.config.flags.brevo_email && this.config.brevo_ma_key
        }), this.syncProductView()
    }
    onScriptLoad() {
        this.recoveredCartManager()
    }
    onSuccessfullSubscription() {
        this.render(!1, !1)
    }
    getStoreLibClass() {
        return te
    }
    getStoreCartClass() {
        return Hi
    }
    getCurrentProduct() {
        return this.storeLib.getRawCurrentProductDetails()
    }
    isEnabled() {
        return ut({
            subdomain: this.subdomain
        }).then(() => "undefined" == typeof __st && void 0 === window.Shopify ? Promise.reject(r.NOT_SHOPIFY) : Promise.resolve())
    }
    initAjaxCartDetection() {
        if (this.config.abandoned_cart_enabled || "enabled" === this.config.flags.brevo_email) {
            var e = e => {
                this.browserHandler.isPermissionGranted ? ht.verifySubscriber({
                    browserHandler: this.browserHandler
                }).then(() => {
                    ye("[AJAX CART] Detected Add to Cart"), this.syncAbandonedCart(e, {
                        brevo: this.isBrevoEnabled(),
                        pushowl: this.config.abandoned_cart_enabled
                    })
                }) : this.isBrevoEnabled() && this.syncAbandonedCart(e, {
                    brevo: !0,
                    pushowl: !1
                })
            };
            Vi.detectAjaxCartUpdate(e), this.config.flags && this.config.flags.enable_cart_detection_2 && Vi.detectAjaxCartUpdate2(e), Vi.detectAjaxCartUpdate3(e)
        }
    }
    handleVariantChange() {
        if (te.section === f.PRODUCT && (this.config.back_in_stock.enabled || this.config.price_drop.enabled || (this.config.bis_embedded_forms || []).length > 0)) {
            var e = document.querySelector('form[action$="cart/add"]'),
                t = document.querySelector('select[name="id"]');
            if (!e && t && (e = t.closest("form")), !e) return;
            var i = !1,
                n = () => {
                    i || (i = !0, setTimeout(() => {
                        ye("In-page variant change detected"), this.render(), i = !1
                    }, 500))
                };
            e.addEventListener("change", n), e.onchange || (e.onchange = n)
        }
    }
    load3PIntegrations() {
        z() && this.loadBrevoTracker(), this.watchForViewCategoryPage(), this.watchForViewSearchPage(), this.klaviyoIntegration();
        var e = [];
        e.length ? window.Notification && window.Notification.permission === d.NOTIFICATION_PERMISSION.GRANTED || navigator.serviceWorker.register("".concat(H.serviceWorkerUrl(), "&integrations=").concat(e.join(","))) : window.Notification && window.Notification.permission === d.NOTIFICATION_PERMISSION.GRANTED || navigator.serviceWorker.getRegistrations().then(function(e) {
            e.forEach(e => {
                e.active && e.active.scriptURL.match(/pushowl/) && e.unregister()
            })
        })
    }
    recoveredCartManager() {
        var e = ue("poCartData");
        if (e) try {
            var t = JSON.parse(window.atob(e));
            te.getCart().then(e => {
                if (0 === new Hi(e).item_count) {
                    var {
                        cart: i
                    } = t;
                    ge({
                        method: "POST",
                        url: "/cart/update.js",
                        payload: {
                            updates: i
                        }
                    }).then(() => {
                        ye("Cart Update Done"), window.location.href = window.location.origin + window.location.pathname
                    })
                }
            })
        } catch (e) {
            Te(e)
        }
    }
    identify() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            {
                email: t,
                properties: i
            } = e;
        return t && Ve.identify({
            email: t
        }, i || {}), e
    }
}
if (window.Shopify && !window.Shopify.customerPrivacy && window.Shopify.loadFeatures && window.Shopify.loadFeatures([{
        name: "consent-tracking-api",
        version: "0.1"
    }], e => {}), H.isDisabled()) ye("Pushowl is disabled in your store");
else {
    var $i = new qi,
        Wi = (zi = $i, Ki = {
            LOG_LEVELS: c,
            setLogLevel: e => {
                x.logLevel = e, ye("Log level set to: ".concat(e))
            },
            push(e) {
                zi.ready.then(() => {
                    e()
                })
            },
            getSubdomain: () => zi.subdomain,
            isEnabled: () => zi.isEnabled(),
            subscriberLog: e => zi.subscriberLog(e),
            subscribe() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                return ht.subscribeIfNotAlready({
                    enableHintScreen: e,
                    websitePushId: zi.config.website_push_id,
                    browserHandler: zi.browserHandler
                })
            },
            registerForEvent(e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                return new Promise((n, r) => {
                    ht.subscribeIfNotAlready({
                        enableHintScreen: t,
                        websitePushId: zi.config.website_push_id,
                        browserHandler: zi.browserHandler
                    }).then(() => {
                        zi.storeLib.getProductDetails(!1, i.productAlias).then(t => {
                            var c = i.productVariantId ? t.getVariant(i.productVariantId) : t.currentVariant(),
                                l = null,
                                u = null;
                            if (e === a.BACK_IN_STOCK) l = d.EVENT_API_PATH.BACK_IN_STOCK, u = zi.storageManager.back_in_stock;
                            else {
                                if (e !== a.PRICE_DROP) return void r(s.UNKNOWN_EVENT);
                                l = d.EVENT_API_PATH.PRICE_DROP, u = zi.storageManager.price_drop
                            }
                            ht.update(l, {
                                product_id: t.id,
                                product: t,
                                variant: c,
                                source: o.PARTNER_JS_API,
                                permission: window.Notification && window.Notification.permission
                            }).then(() => {
                                zi.productSectionRender(t), u.subscribe(c);
                                var e = {};
                                e[d.STORAGE_KEYS.SUBSCRIBER_TOKEN] = x.subscriberToken, n(e)
                            }).catch(e => {
                                Te(e)
                            })
                        })
                    }).catch(() => {
                        r({
                            error_code: s.PERMISSION_NOT_GRANTED
                        })
                    })
                })
            },
            isProductVariantSubscribed: (e, t) => "price_drop" === e ? zi.storageManager.price_drop.isSubscribed({
                id: t
            }) : "back_in_stock" === e && zi.storageManager.back_in_stock.isSubscribed({
                id: t
            }),
            showBrowserPrompt() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                    overlay: {
                        enabled: !1
                    }
                };
                return zi.showBrowserPrompt(e)
            },
            showCustomPrompt() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return e.overlay = null, zi.showCustomPrompt(e)
            },
            showWidget(e) {
                var {
                    type: t
                } = e, i = function(e, t) {
                    if (null == e) return {};
                    var i, n, o = function(e, t) {
                        if (null == e) return {};
                        var i = {};
                        for (var n in e)
                            if ({}.hasOwnProperty.call(e, n)) {
                                if (-1 !== t.indexOf(n)) continue;
                                i[n] = e[n]
                            }
                        return i
                    }(e, t);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        for (n = 0; n < r.length; n++) i = r[n], -1 === t.indexOf(i) && {}.propertyIsEnumerable.call(e, i) && (o[i] = e[i])
                    }
                    return o
                }(e, gt);
                switch (t) {
                    case "browserPrompt":
                        return zi.showBrowserPrompt(i);
                    case "customPrompt":
                        return zi.showCustomPrompt(i, !0);
                    case "priceDrop":
                        return i.variant.name = i.variant.title, delete i.variant.title, zi.showPriceDrop(i.product, i.variant);
                    case "backInStock":
                        return i.variant.name = i.variant.title, delete i.variant.title, zi.showBackInStock(i.product, i.variant);
                    case "optinFlows":
                        return zi.optinFlows(!0)
                }
            },
            showEmbeddedForms: () => zi.renderEmbeddedForms(),
            syncCart: e => (e.item_count = e.items.length, e.items.forEach(e => {
                e.variantId && (e.variant_id = e.variantId, delete e.variantId), e.productId && (e.product_id = e.productId, delete e.productId)
            }), e.checkoutToken && (e.checkout_token = e.checkoutToken, delete e.checkoutToken), zi.syncCart(e)),
            syncPageName: e => zi.syncPageName(e),
            syncProductView: e => (e.productId && (e.product_id = e.productId, delete e.productId), zi.syncProductView(e)),
            setCustomerId: e => zi.setCustomerId(e),
            setCheckoutId: e => zi.setCheckoutId(e),
            getCurrentPermission: () => x.isPermissionGranted ? Promise.resolve(d.NOTIFICATION_PERMISSION.GRANTED) : window && window.Notification ? Promise.resolve(Notification.permission) : void 0,
            identify: e => zi.identify(e),
            trackCategoryPage: e => zi.trackCategoryPage(e),
            track: e => ne.track(e)
        }, new Proxy(Ki, {
            get(e, t) {
                if (!e[t] && zi[t]) {
                    ye("🟠 Internal property accessed: ".concat(t));
                    var i = zi[t];
                    return "function" == typeof i ? i.bind(zi) : i
                }
                return Reflect.get(...arguments)
            }
        })),
        Qi = [];
    window.pushowl && (Array.isArray(window.pushowl) ? ye("Existing PushOwl found in queue mode with following tasks queued: ", Qi = window.pushowl) : ye("Existing PushOwl found and will be reused. Pushowl seems to be loading twice on this page. Please check page source.")), window.pushowl && !Array.isArray(window.pushowl) || (window.poSubscriptionSource = "", window.pushowl = Wi, ye("PushOwl instance created"), V.windowVariablesForOwly = window.pushowlSubdomain, $i.ready.then(() => {
        try {
            var e;
            "enabled" === (null === (e = $i.config) || void 0 === e || null === (e = e.flags) || void 0 === e ? void 0 : e.allow_form_tracking) ? (wt || (wt = new ft, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", () => {
                wt.init()
            }) : wt.init(), window.pushowlFormTracker = wt), ye("[PushOwl] Form tracker initialized automatically")) : ye("[PushOwl] Form tracker not initialized - flag not enabled")
        } catch (e) {
            Te("[PushOwl] Form tracker initialization failed:", e)
        }
    })), Qi.length && $i.ready.then(() => {
        ye("PushOwl ready to execute API functions."), Qi.forEach(e => e()), ye("Tasks from PushOwl queue executed. No. of tasks: ".concat(Qi.length))
    })
}
export {
    pi as A, hi as B, Vt as C, Xt as D, qt as E, ni as F, Ci as G, $t as H, Le as I, Ae as J, Mi as K, Oi as L, Ai as M, vi as N, Zt as O, p as P, fi as Q, Ti as R, x as S, ii as T, _i as U, Ve as V, Wt as W, Ke as X, t as _, V as a, ae as b, Ie as c, ye as d, pe as e, d as f, re as g, Ni as h, Se as i, ui as j, ci as k, ai as l, bi as m, ri as n, wi as o, se as p, mi as q, Gt as r, gi as s, oi as t, Qt as u, di as v, ti as w, ei as x, yi as y, Li as z
};
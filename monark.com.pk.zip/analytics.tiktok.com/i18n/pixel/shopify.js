(() => {
    var r = {},
        e = {};

    function n(o) {
        var t = e[o];
        if (void 0 !== t) return t.exports;
        var i = e[o] = {
            exports: {}
        };
        return r[o](i, i.exports, n), i.exports
    }
    n.rv = function() {
        return "1.0.0-rc.0"
    }, n.ruid = "bundler=rspack@1.0.0-rc.0", ("undefined" == typeof window || !self.window) && (self.window = self)
})();
window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'traffic_1::default';
window[window["TiktokAnalyticsObject"]]._vids = '74172070,74539884,74813232';
window[window["TiktokAnalyticsObject"]]._cc = 'PK';
window[window.TiktokAnalyticsObject]._li || (window[window.TiktokAnalyticsObject]._li = {}), window[window.TiktokAnalyticsObject]._li["D5549URC77UB50R0Q8R0"] = "e7810287-e817-11f0-9f7d-b83fd2f5010e";
window[window["TiktokAnalyticsObject"]]._cde = 390;;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = 'e78138f2-e817-11f0-9f7d-b83fd2f5010e';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": false,
    "AutoClick": false,
    "AutoConfig": false,
    "Callback": true,
    "DiagnosticsConsole": true,
    "EnableLPV": false,
    "EnrichIpv6": true,
    "EnrichIpv6V2": true,
    "EventBuilder": false,
    "EventBuilderRuleEngine": false,
    "HistoryObserver": false,
    "Identify": true,
    "JSBridge": false,
    "Metadata": false,
    "Monitor": false,
    "PageData": false,
    "PerformanceInteraction": false,
    "RuntimeMeasurement": false,
    "Shopify": false,
    "WebFL": false
};
window[window["TiktokAnalyticsObject"]]._csid_config = {
    "enable": true
};
window[window["TiktokAnalyticsObject"]]._ttls_config = {
    "key": "ttoclid"
};
! function(t, n, i, e, o, l) {
    var r = [{
            id: "ZjFmMTI5Mi4wLjAuNDk1",
            map: {
                Monitor: !1
            }
        }, {
            id: "ZjFmMTI5Mi4wLjAuNDk1",
            map: {
                Monitor: !0
            }
        }],
        c = {
            "info": {
                "pixelCode": "D5549URC77UB50R0Q8R0",
                "name": "TikTok Pixel for Shopify 1766475003",
                "status": 0,
                "setupMode": 1,
                "partner": "Shopify",
                "advertiserID": "7584494267427717128",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": true,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true,
                    "first_name": true,
                    "last_name": true,
                    "city": true,
                    "state": true,
                    "country": true,
                    "zip_code": true
                },
                "AutoAdvancedMatching": null,
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": {
                    "form_rules": null,
                    "vc_rules": {}
                },
                "PageData": {
                    "performance": false,
                    "interaction": true
                },
                "DiagnosticsConsole": true,
                "CompetitorInsight": true,
                "EventBuilder": true,
                "EnrichIpv6": true,
                "HistoryObserver": {
                    "dynamic_web_pageview": true
                },
                "RuntimeMeasurement": true,
                "JSBridge": true,
                "EventBuilderRuleEngine": true,
                "RemoveUnusedCode": true,
                "EnableLPV": true,
                "AutoConfigV2": true
            },
            "rules": []
        },
        a = "https://analytics.tiktok.com/i18n/pixel/static/",
        t = null == (t = c) || null == (n = t.info) ? void 0 : n.pixelCode;

    function s() {
        return self && self.TiktokAnalyticsObject || "ttq"
    }

    function d() {
        return self && self[s()]
    }

    function u(t, n) {
        n = d()[n];
        return n && n[t] || {}
    }
    var f, p, n = d();
    n || (n = [], self && (self[s()] = n)), Object.assign(c, {
            options: u(t, "_o")
        }), f = c, n._i || (n._i = {}), (p = f.info.pixelCode) && (n._i[p] || (n._i[p] = []), Object.assign(n._i[p], f), n._i[p]._load = +new Date), Object.assign(c.info, {
            loadStart: u(t, "_t"),
            loadEnd: u(t, "_i")._load,
            loadId: n._li && n._li[t] || ""
        }), null != (i = (e = n).instance) && null != (o = i.call(e, t)) && null != (l = o.setPixelInfo) && l.call(o, c.info),
        function n(i, e, o) {
            if (!(o && 2 < o)) try {
                var t, l;
                (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(i): ((t = document.createElement("script")).type = "text/javascript", t.async = !0, t.src = i, t.setAttribute("data-id", e), (l = document.getElementsByTagName("script")[0]) && l.parentNode && l.parentNode.insertBefore(t, l))
            } catch (t) {
                n(i, e, o ? o + 1 : 2)
            }
        }(function(t, n, i) {
            var l = 0 < arguments.length && void 0 !== t ? t : {},
                c = 1 < arguments.length ? n : void 0,
                t = 2 < arguments.length ? i : void 0,
                n = function(t, n) {
                    for (var i = 0; i < t.length; i++)
                        if (n.call(null, t[i], i)) return t[i]
                }(r, function(t) {
                    for (var n = t.map, i = Object.keys(n), e = function(t) {
                            return !(!l[t] || !c[t]) === n[t]
                        }, o = 0; o < i.length; o++)
                        if (!e.call(null, i[o], o)) return !1;
                    return !0
                });
            return n ? "".concat(t, "shopify.").concat(n.id, ".js") : "".concat(t, "shopify.").concat(r[0].id, ".js")
        }(n._plugins, c.plugins, a), t)
}();
(function() {
    "use strict";
    var ef = document.createElement("style");
    ef.textContent = `.chat-window{width:400px;height:600px;background:#fff;box-shadow:0 4px 10px #0000004d;border-radius:20px;position:fixed;bottom:20px;display:flex;flex-direction:column;z-index:999;overflow:hidden;animation:scaleUp .4s cubic-bezier(.34,1.56,.64,1);opacity:1;transform:scale(1);transition:all .4s cubic-bezier(.34,1.56,.64,1);pointer-events:auto;direction:ltr}.chat-header{color:#fff;padding:15px;display:flex;justify-content:space-between;align-items:center;border-radius:20px 20px 0 0}.d-widget-close-btn{background:none;border:none;color:#fff;font-size:18px;cursor:pointer;display:flex;justify-content:center;padding:1px 0;width:24px;height:24px;margin-bottom:0}.chat-messages{flex:1;padding:10px;overflow-y:auto;background-color:#fff;display:flex!important;flex-direction:column;gap:5px}.message{padding:8px 12px;border-radius:8px;position:relative;margin:4px 0;max-width:80%;word-wrap:break-word;width:fit-content}.message.user{margin-left:40px;align-self:flex-end;border-bottom-right-radius:0;color:#fff}.message.reply{padding-left:12px;background-color:#f0f0f0;margin-right:50px;margin-left:40px;align-self:flex-start;border-bottom-left-radius:0}.chat-input{display:flex;padding:10px 20px;border-top:1px solid #ddd;background-color:#fff}.chat-input input{flex:1;padding:8px 12px;border:1px solid #999999;border-radius:10px;outline:none;font-size:14px!important;color:#000!important;line-height:normal!important;letter-spacing:normal!important;font-family:Arial,Helvetica,sans-serif!important}.chat-input button{color:#fff;border:none;border-radius:50%;width:40px;height:40px;min-width:40px!important;min-height:40px!important;margin-left:10px;cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center}.chat-input button img{width:24px!important;height:24px!important;min-width:24px!important;min-height:24px!important;object-fit:contain}@keyframes scaleUp{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}.chat-fade-wrapper{position:fixed;bottom:20px;transition:all .4s cubic-bezier(.34,1.56,.64,1);pointer-events:none}.chat-fade-wrapper.open{opacity:1;transform:scale(1)}.chat-fade-wrapper.closing{opacity:0;transform:scale(.8);pointer-events:none}.typing-indicator{display:flex;gap:4px;height:20px;align-items:center}.typing-indicator span{width:6px;height:6px;background-color:#999;border-radius:50%;animation:blink 1.4s infinite both}.typing-indicator span:nth-child(2){animation-delay:.2s}.typing-indicator span:nth-child(3){animation-delay:.4s}@keyframes blink{0%{opacity:.2;transform:translateY(0)}20%{opacity:1;transform:translateY(-4px)}to{opacity:.2;transform:translateY(0)}}.bot-avatar{width:23px;height:23px;position:absolute;left:5px;bottom:0;border-radius:50%;margin-left:-35px;background-color:#fff;padding:0;box-shadow:0 1px 3px #0000001a}.powered-by{text-align:center;padding:15px;font-size:16px;color:#666;border-top:1px solid #eee;display:flex!important;justify-content:center;align-items:center;height:50px}.powered-by img{vertical-align:middle;margin-left:10px;margin-right:10px}.chat-window.closing{opacity:0;transform:scale(.8);pointer-events:none}.chat-window[style*="left:"],.chat-fade-wrapper[style*="left:"]{left:20px;transform-origin:bottom left}.chat-window[style*="right:"],.chat-fade-wrapper[style*="right:"]{right:20px;transform-origin:bottom right}@media screen and (max-width: 480px){.chat-window{width:43vh;transform:translate(-50%)!important}.chat-window[style*="left:"]{left:184px!important}.chat-window[style*="right:"]{right:auto!important;left:-184px!important}.message{max-width:85%}.chat-input{padding:10px;width:100%;box-sizing:border-box;position:absolute;bottom:48px}.powered-by{position:absolute;bottom:0;width:100%;padding:10px;box-sizing:border-box;background:#fff}.powered-by img{margin-top:3px}}@media screen and (max-width: 480px){.chat-window.closing{opacity:0;transform:translate(-50%) scale(.8)!important}}.chat-window.whatsapp-theme{background-color:#e4ddd6}.chat-window.whatsapp-theme .chat-header{background-color:#075e54!important}.chat-window.whatsapp-theme .chat-messages{background-image:url(https://cdn.shopify.com/s/files/1/0726/1339/6765/files/Dondy_production_wp_bg_img_dont_delete.jpg?v=1746507841);background-size:contain;background-repeat:repeat}.chat-window.whatsapp-theme .message{position:relative;margin:2px 0}.chat-window.whatsapp-theme .message:before{content:"";position:absolute;top:0;width:12px;height:12px}.chat-window.whatsapp-theme .message.user{margin-left:10px;margin-right:10px;background-color:#dcf8c6!important;color:#000;box-shadow:0 1px .5px #00000021;border-radius:8px 0 8px 8px}.chat-window.whatsapp-theme .message.user:before{right:-8px;background:linear-gradient(to bottom right,#dcf8c6 50%,transparent 50%)}.chat-window.whatsapp-theme .message.reply{margin-left:10px;margin-right:10px;background-color:#fff;box-shadow:0 1px .5px #00000021;border-radius:0 8px 8px}.chat-window.whatsapp-theme .message.reply:before{left:-8px;background:linear-gradient(to bottom left,#ffffff 50%,transparent 50%)}.chat-window.whatsapp-theme .chat-input{background-image:url(https://cdn.shopify.com/s/files/1/0726/1339/6765/files/Dondy_production_wp_bg_img_dont_delete.jpg?v=1746507841);background-size:contain;background-repeat:repeat;background-color:transparent;padding:10px}.chat-window.whatsapp-theme .chat-input input{border-radius:20px;background-color:#fff;border:none;padding:12px 15px}.chat-window.whatsapp-theme .chat-input button{background-color:#075e54!important}.chat-window.whatsapp-theme .powered-by{background-color:#fff}.chat-window.whatsapp-theme .bot-avatar{display:none}.whatsapp-widget{position:fixed;bottom:10px;z-index:2147483648;display:none}.whatsapp-widget-visible{display:block!important}.whatsapp-widget-left{left:10px}.whatsapp-widget-right{right:10px}.whatsapp-widget-upper-left{left:10px;bottom:90px}.whatsapp-widget-upper-right{right:10px;bottom:90px}.whatsapp-widget-mid-upper-right{right:10px;bottom:47px}.whatsapp-widget-mid-upper-left{left:10px;bottom:47px}.whatsapp-text{font-family:Helvetica;font-weight:610;font-size:12.5px;color:#000;background-color:#ffffffda;border-radius:11px;margin:0 5.5px;padding:2px 10px}.whatsapp-flex-container{display:flex;align-items:center}#whatsapp-link{text-decoration:none}#whatsapp-link svg{stroke:none;width:var(--whatsapp-link-width);height:var(--whatsapp-link-height);display:block!important}#whatsapp-link svg path{display:block!important}#whatsapp-link svg g{display:block!important;transform-origin:revert!important}
/*$vite$:1*/`, document.head.appendChild(ef);
    var qn = {
            exports: {}
        },
        be = {};
    /**
     * @license React
     * react-jsx-runtime.production.js
     *
     * Copyright (c) Meta Platforms, Inc. and affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var uf;

    function r1() {
        if (uf) return be;
        uf = 1;
        var p = Symbol.for("react.transitional.element"),
            F = Symbol.for("react.fragment");

        function B(m, W, P) {
            var el = null;
            if (P !== void 0 && (el = "" + P), W.key !== void 0 && (el = "" + W.key), "key" in W) {
                P = {};
                for (var nl in W) nl !== "key" && (P[nl] = W[nl])
            } else P = W;
            return W = P.ref, {
                $$typeof: p,
                type: m,
                key: el,
                ref: W !== void 0 ? W : null,
                props: P
            }
        }
        return be.Fragment = F, be.jsx = B, be.jsxs = B, be
    }
    var nf;

    function h1() {
        return nf || (nf = 1, qn.exports = r1()), qn.exports
    }
    var $ = h1(),
        Yn = {
            exports: {}
        },
        Se = {},
        Cn = {
            exports: {}
        },
        Bn = {};
    /**
     * @license React
     * scheduler.production.js
     *
     * Copyright (c) Meta Platforms, Inc. and affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var cf;

    function v1() {
        return cf || (cf = 1, function(p) {
            function F(b, _) {
                var q = b.length;
                b.push(_);
                l: for (; 0 < q;) {
                    var rl = q - 1 >>> 1,
                        s = b[rl];
                    if (0 < W(s, _)) b[rl] = _, b[q] = s, q = rl;
                    else break l
                }
            }

            function B(b) {
                return b.length === 0 ? null : b[0]
            }

            function m(b) {
                if (b.length === 0) return null;
                var _ = b[0],
                    q = b.pop();
                if (q !== _) {
                    b[0] = q;
                    l: for (var rl = 0, s = b.length, A = s >>> 1; rl < A;) {
                        var O = 2 * (rl + 1) - 1,
                            M = b[O],
                            R = O + 1,
                            ll = b[R];
                        if (0 > W(M, q)) R < s && 0 > W(ll, M) ? (b[rl] = ll, b[R] = q, rl = R) : (b[rl] = M, b[O] = q, rl = O);
                        else if (R < s && 0 > W(ll, q)) b[rl] = ll, b[R] = q, rl = R;
                        else break l
                    }
                }
                return _
            }

            function W(b, _) {
                var q = b.sortIndex - _.sortIndex;
                return q !== 0 ? q : b.id - _.id
            }
            if (p.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
                var P = performance;
                p.unstable_now = function() {
                    return P.now()
                }
            } else {
                var el = Date,
                    nl = el.now();
                p.unstable_now = function() {
                    return el.now() - nl
                }
            }
            var x = [],
                T = [],
                z = 1,
                Q = null,
                X = 3,
                ul = !1,
                ml = !1,
                _l = !1,
                Z = !1,
                vl = typeof setTimeout == "function" ? setTimeout : null,
                il = typeof clearTimeout == "function" ? clearTimeout : null,
                K = typeof setImmediate < "u" ? setImmediate : null;

            function gl(b) {
                for (var _ = B(T); _ !== null;) {
                    if (_.callback === null) m(T);
                    else if (_.startTime <= b) m(T), _.sortIndex = _.expirationTime, F(x, _);
                    else break;
                    _ = B(T)
                }
            }

            function L(b) {
                if (_l = !1, gl(b), !ml)
                    if (B(x) !== null) ml = !0, Nl || (Nl = !0, Xl());
                    else {
                        var _ = B(T);
                        _ !== null && Zl(L, _.startTime - b)
                    }
            }
            var Nl = !1,
                w = -1,
                Sl = 5,
                Ql = -1;

            function _t() {
                return Z ? !0 : !(p.unstable_now() - Ql < Sl)
            }

            function xt() {
                if (Z = !1, Nl) {
                    var b = p.unstable_now();
                    Ql = b;
                    var _ = !0;
                    try {
                        l: {
                            ml = !1,
                            _l && (_l = !1, il(w), w = -1),
                            ul = !0;
                            var q = X;
                            try {
                                t: {
                                    for (gl(b), Q = B(x); Q !== null && !(Q.expirationTime > b && _t());) {
                                        var rl = Q.callback;
                                        if (typeof rl == "function") {
                                            Q.callback = null, X = Q.priorityLevel;
                                            var s = rl(Q.expirationTime <= b);
                                            if (b = p.unstable_now(), typeof s == "function") {
                                                Q.callback = s, gl(b), _ = !0;
                                                break t
                                            }
                                            Q === B(x) && m(x), gl(b)
                                        } else m(x);
                                        Q = B(x)
                                    }
                                    if (Q !== null) _ = !0;
                                    else {
                                        var A = B(T);
                                        A !== null && Zl(L, A.startTime - b), _ = !1
                                    }
                                }
                                break l
                            }
                            finally {
                                Q = null, X = q, ul = !1
                            }
                            _ = void 0
                        }
                    }
                    finally {
                        _ ? Xl() : Nl = !1
                    }
                }
            }
            var Xl;
            if (typeof K == "function") Xl = function() {
                K(xt)
            };
            else if (typeof MessageChannel < "u") {
                var va = new MessageChannel,
                    ya = va.port2;
                va.port1.onmessage = xt, Xl = function() {
                    ya.postMessage(null)
                }
            } else Xl = function() {
                vl(xt, 0)
            };

            function Zl(b, _) {
                w = vl(function() {
                    b(p.unstable_now())
                }, _)
            }
            p.unstable_IdlePriority = 5, p.unstable_ImmediatePriority = 1, p.unstable_LowPriority = 4, p.unstable_NormalPriority = 3, p.unstable_Profiling = null, p.unstable_UserBlockingPriority = 2, p.unstable_cancelCallback = function(b) {
                b.callback = null
            }, p.unstable_forceFrameRate = function(b) {
                0 > b || 125 < b ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : Sl = 0 < b ? Math.floor(1e3 / b) : 5
            }, p.unstable_getCurrentPriorityLevel = function() {
                return X
            }, p.unstable_next = function(b) {
                switch (X) {
                    case 1:
                    case 2:
                    case 3:
                        var _ = 3;
                        break;
                    default:
                        _ = X
                }
                var q = X;
                X = _;
                try {
                    return b()
                } finally {
                    X = q
                }
            }, p.unstable_requestPaint = function() {
                Z = !0
            }, p.unstable_runWithPriority = function(b, _) {
                switch (b) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        break;
                    default:
                        b = 3
                }
                var q = X;
                X = b;
                try {
                    return _()
                } finally {
                    X = q
                }
            }, p.unstable_scheduleCallback = function(b, _, q) {
                var rl = p.unstable_now();
                switch (typeof q == "object" && q !== null ? (q = q.delay, q = typeof q == "number" && 0 < q ? rl + q : rl) : q = rl, b) {
                    case 1:
                        var s = -1;
                        break;
                    case 2:
                        s = 250;
                        break;
                    case 5:
                        s = 1073741823;
                        break;
                    case 4:
                        s = 1e4;
                        break;
                    default:
                        s = 5e3
                }
                return s = q + s, b = {
                    id: z++,
                    callback: _,
                    priorityLevel: b,
                    startTime: q,
                    expirationTime: s,
                    sortIndex: -1
                }, q > rl ? (b.sortIndex = q, F(T, b), B(x) === null && b === B(T) && (_l ? (il(w), w = -1) : _l = !0, Zl(L, q - rl))) : (b.sortIndex = s, F(x, b), ml || ul || (ml = !0, Nl || (Nl = !0, Xl()))), b
            }, p.unstable_shouldYield = _t, p.unstable_wrapCallback = function(b) {
                var _ = X;
                return function() {
                    var q = X;
                    X = _;
                    try {
                        return b.apply(this, arguments)
                    } finally {
                        X = q
                    }
                }
            }
        }(Bn)), Bn
    }
    var ff;

    function y1() {
        return ff || (ff = 1, Cn.exports = v1()), Cn.exports
    }
    var jn = {
            exports: {}
        },
        j = {};
    /**
     * @license React
     * react.production.js
     *
     * Copyright (c) Meta Platforms, Inc. and affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var sf;

    function m1() {
        if (sf) return j;
        sf = 1;
        var p = Symbol.for("react.transitional.element"),
            F = Symbol.for("react.portal"),
            B = Symbol.for("react.fragment"),
            m = Symbol.for("react.strict_mode"),
            W = Symbol.for("react.profiler"),
            P = Symbol.for("react.consumer"),
            el = Symbol.for("react.context"),
            nl = Symbol.for("react.forward_ref"),
            x = Symbol.for("react.suspense"),
            T = Symbol.for("react.memo"),
            z = Symbol.for("react.lazy"),
            Q = Symbol.iterator;

        function X(s) {
            return s === null || typeof s != "object" ? null : (s = Q && s[Q] || s["@@iterator"], typeof s == "function" ? s : null)
        }
        var ul = {
                isMounted: function() {
                    return !1
                },
                enqueueForceUpdate: function() {},
                enqueueReplaceState: function() {},
                enqueueSetState: function() {}
            },
            ml = Object.assign,
            _l = {};

        function Z(s, A, O) {
            this.props = s, this.context = A, this.refs = _l, this.updater = O || ul
        }
        Z.prototype.isReactComponent = {}, Z.prototype.setState = function(s, A) {
            if (typeof s != "object" && typeof s != "function" && s != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
            this.updater.enqueueSetState(this, s, A, "setState")
        }, Z.prototype.forceUpdate = function(s) {
            this.updater.enqueueForceUpdate(this, s, "forceUpdate")
        };

        function vl() {}
        vl.prototype = Z.prototype;

        function il(s, A, O) {
            this.props = s, this.context = A, this.refs = _l, this.updater = O || ul
        }
        var K = il.prototype = new vl;
        K.constructor = il, ml(K, Z.prototype), K.isPureReactComponent = !0;
        var gl = Array.isArray,
            L = {
                H: null,
                A: null,
                T: null,
                S: null,
                V: null
            },
            Nl = Object.prototype.hasOwnProperty;

        function w(s, A, O, M, R, ll) {
            return O = ll.ref, {
                $$typeof: p,
                type: s,
                key: A,
                ref: O !== void 0 ? O : null,
                props: ll
            }
        }

        function Sl(s, A) {
            return w(s.type, A, void 0, void 0, void 0, s.props)
        }

        function Ql(s) {
            return typeof s == "object" && s !== null && s.$$typeof === p
        }

        function _t(s) {
            var A = {
                "=": "=0",
                ":": "=2"
            };
            return "$" + s.replace(/[=:]/g, function(O) {
                return A[O]
            })
        }
        var xt = /\/+/g;

        function Xl(s, A) {
            return typeof s == "object" && s !== null && s.key != null ? _t("" + s.key) : A.toString(36)
        }

        function va() {}

        function ya(s) {
            switch (s.status) {
                case "fulfilled":
                    return s.value;
                case "rejected":
                    throw s.reason;
                default:
                    switch (typeof s.status == "string" ? s.then(va, va) : (s.status = "pending", s.then(function(A) {
                        s.status === "pending" && (s.status = "fulfilled", s.value = A)
                    }, function(A) {
                        s.status === "pending" && (s.status = "rejected", s.reason = A)
                    })), s.status) {
                        case "fulfilled":
                            return s.value;
                        case "rejected":
                            throw s.reason
                    }
            }
            throw s
        }

        function Zl(s, A, O, M, R) {
            var ll = typeof s;
            (ll === "undefined" || ll === "boolean") && (s = null);
            var C = !1;
            if (s === null) C = !0;
            else switch (ll) {
                case "bigint":
                case "string":
                case "number":
                    C = !0;
                    break;
                case "object":
                    switch (s.$$typeof) {
                        case p:
                        case F:
                            C = !0;
                            break;
                        case z:
                            return C = s._init, Zl(C(s._payload), A, O, M, R)
                    }
            }
            if (C) return R = R(s), C = M === "" ? "." + Xl(s, 0) : M, gl(R) ? (O = "", C != null && (O = C.replace(xt, "$&/") + "/"), Zl(R, A, O, "", function(Zt) {
                return Zt
            })) : R != null && (Ql(R) && (R = Sl(R, O + (R.key == null || s && s.key === R.key ? "" : ("" + R.key).replace(xt, "$&/") + "/") + C)), A.push(R)), 1;
            C = 0;
            var Il = M === "" ? "." : M + ":";
            if (gl(s))
                for (var pl = 0; pl < s.length; pl++) M = s[pl], ll = Il + Xl(M, pl), C += Zl(M, A, O, ll, R);
            else if (pl = X(s), typeof pl == "function")
                for (s = pl.call(s), pl = 0; !(M = s.next()).done;) M = M.value, ll = Il + Xl(M, pl++), C += Zl(M, A, O, ll, R);
            else if (ll === "object") {
                if (typeof s.then == "function") return Zl(ya(s), A, O, M, R);
                throw A = String(s), Error("Objects are not valid as a React child (found: " + (A === "[object Object]" ? "object with keys {" + Object.keys(s).join(", ") + "}" : A) + "). If you meant to render a collection of children, use an array instead.")
            }
            return C
        }

        function b(s, A, O) {
            if (s == null) return s;
            var M = [],
                R = 0;
            return Zl(s, M, "", "", function(ll) {
                return A.call(O, ll, R++)
            }), M
        }

        function _(s) {
            if (s._status === -1) {
                var A = s._result;
                A = A(), A.then(function(O) {
                    (s._status === 0 || s._status === -1) && (s._status = 1, s._result = O)
                }, function(O) {
                    (s._status === 0 || s._status === -1) && (s._status = 2, s._result = O)
                }), s._status === -1 && (s._status = 0, s._result = A)
            }
            if (s._status === 1) return s._result.default;
            throw s._result
        }
        var q = typeof reportError == "function" ? reportError : function(s) {
            if (typeof window == "object" && typeof window.ErrorEvent == "function") {
                var A = new window.ErrorEvent("error", {
                    bubbles: !0,
                    cancelable: !0,
                    message: typeof s == "object" && s !== null && typeof s.message == "string" ? String(s.message) : String(s),
                    error: s
                });
                if (!window.dispatchEvent(A)) return
            } else if (typeof process == "object" && typeof process.emit == "function") {
                process.emit("uncaughtException", s);
                return
            }
            console.error(s)
        };

        function rl() {}
        return j.Children = {
            map: b,
            forEach: function(s, A, O) {
                b(s, function() {
                    A.apply(this, arguments)
                }, O)
            },
            count: function(s) {
                var A = 0;
                return b(s, function() {
                    A++
                }), A
            },
            toArray: function(s) {
                return b(s, function(A) {
                    return A
                }) || []
            },
            only: function(s) {
                if (!Ql(s)) throw Error("React.Children.only expected to receive a single React element child.");
                return s
            }
        }, j.Component = Z, j.Fragment = B, j.Profiler = W, j.PureComponent = il, j.StrictMode = m, j.Suspense = x, j.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = L, j.__COMPILER_RUNTIME = {
            __proto__: null,
            c: function(s) {
                return L.H.useMemoCache(s)
            }
        }, j.cache = function(s) {
            return function() {
                return s.apply(null, arguments)
            }
        }, j.cloneElement = function(s, A, O) {
            if (s == null) throw Error("The argument must be a React element, but you passed " + s + ".");
            var M = ml({}, s.props),
                R = s.key,
                ll = void 0;
            if (A != null)
                for (C in A.ref !== void 0 && (ll = void 0), A.key !== void 0 && (R = "" + A.key), A) !Nl.call(A, C) || C === "key" || C === "__self" || C === "__source" || C === "ref" && A.ref === void 0 || (M[C] = A[C]);
            var C = arguments.length - 2;
            if (C === 1) M.children = O;
            else if (1 < C) {
                for (var Il = Array(C), pl = 0; pl < C; pl++) Il[pl] = arguments[pl + 2];
                M.children = Il
            }
            return w(s.type, R, void 0, void 0, ll, M)
        }, j.createContext = function(s) {
            return s = {
                $$typeof: el,
                _currentValue: s,
                _currentValue2: s,
                _threadCount: 0,
                Provider: null,
                Consumer: null
            }, s.Provider = s, s.Consumer = {
                $$typeof: P,
                _context: s
            }, s
        }, j.createElement = function(s, A, O) {
            var M, R = {},
                ll = null;
            if (A != null)
                for (M in A.key !== void 0 && (ll = "" + A.key), A) Nl.call(A, M) && M !== "key" && M !== "__self" && M !== "__source" && (R[M] = A[M]);
            var C = arguments.length - 2;
            if (C === 1) R.children = O;
            else if (1 < C) {
                for (var Il = Array(C), pl = 0; pl < C; pl++) Il[pl] = arguments[pl + 2];
                R.children = Il
            }
            if (s && s.defaultProps)
                for (M in C = s.defaultProps, C) R[M] === void 0 && (R[M] = C[M]);
            return w(s, ll, void 0, void 0, null, R)
        }, j.createRef = function() {
            return {
                current: null
            }
        }, j.forwardRef = function(s) {
            return {
                $$typeof: nl,
                render: s
            }
        }, j.isValidElement = Ql, j.lazy = function(s) {
            return {
                $$typeof: z,
                _payload: {
                    _status: -1,
                    _result: s
                },
                _init: _
            }
        }, j.memo = function(s, A) {
            return {
                $$typeof: T,
                type: s,
                compare: A === void 0 ? null : A
            }
        }, j.startTransition = function(s) {
            var A = L.T,
                O = {};
            L.T = O;
            try {
                var M = s(),
                    R = L.S;
                R !== null && R(O, M), typeof M == "object" && M !== null && typeof M.then == "function" && M.then(rl, q)
            } catch (ll) {
                q(ll)
            } finally {
                L.T = A
            }
        }, j.unstable_useCacheRefresh = function() {
            return L.H.useCacheRefresh()
        }, j.use = function(s) {
            return L.H.use(s)
        }, j.useActionState = function(s, A, O) {
            return L.H.useActionState(s, A, O)
        }, j.useCallback = function(s, A) {
            return L.H.useCallback(s, A)
        }, j.useContext = function(s) {
            return L.H.useContext(s)
        }, j.useDebugValue = function() {}, j.useDeferredValue = function(s, A) {
            return L.H.useDeferredValue(s, A)
        }, j.useEffect = function(s, A, O) {
            var M = L.H;
            if (typeof O == "function") throw Error("useEffect CRUD overload is not enabled in this build of React.");
            return M.useEffect(s, A)
        }, j.useId = function() {
            return L.H.useId()
        }, j.useImperativeHandle = function(s, A, O) {
            return L.H.useImperativeHandle(s, A, O)
        }, j.useInsertionEffect = function(s, A) {
            return L.H.useInsertionEffect(s, A)
        }, j.useLayoutEffect = function(s, A) {
            return L.H.useLayoutEffect(s, A)
        }, j.useMemo = function(s, A) {
            return L.H.useMemo(s, A)
        }, j.useOptimistic = function(s, A) {
            return L.H.useOptimistic(s, A)
        }, j.useReducer = function(s, A, O) {
            return L.H.useReducer(s, A, O)
        }, j.useRef = function(s) {
            return L.H.useRef(s)
        }, j.useState = function(s) {
            return L.H.useState(s)
        }, j.useSyncExternalStore = function(s, A, O) {
            return L.H.useSyncExternalStore(s, A, O)
        }, j.useTransition = function() {
            return L.H.useTransition()
        }, j.version = "19.1.0", j
    }
    var of ;

    function wn() {
        return of || ( of = 1, jn.exports = m1()), jn.exports
    }
    var Gn = {
            exports: {}
        },
        Gl = {};
    /**
     * @license React
     * react-dom.production.js
     *
     * Copyright (c) Meta Platforms, Inc. and affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var df;

    function g1() {
        if (df) return Gl;
        df = 1;
        var p = wn();

        function F(x) {
            var T = "https://react.dev/errors/" + x;
            if (1 < arguments.length) {
                T += "?args[]=" + encodeURIComponent(arguments[1]);
                for (var z = 2; z < arguments.length; z++) T += "&args[]=" + encodeURIComponent(arguments[z])
            }
            return "Minified React error #" + x + "; visit " + T + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
        }

        function B() {}
        var m = {
                d: {
                    f: B,
                    r: function() {
                        throw Error(F(522))
                    },
                    D: B,
                    C: B,
                    L: B,
                    m: B,
                    X: B,
                    S: B,
                    M: B
                },
                p: 0,
                findDOMNode: null
            },
            W = Symbol.for("react.portal");

        function P(x, T, z) {
            var Q = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
            return {
                $$typeof: W,
                key: Q == null ? null : "" + Q,
                children: x,
                containerInfo: T,
                implementation: z
            }
        }
        var el = p.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

        function nl(x, T) {
            if (x === "font") return "";
            if (typeof T == "string") return T === "use-credentials" ? T : ""
        }
        return Gl.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = m, Gl.createPortal = function(x, T) {
            var z = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
            if (!T || T.nodeType !== 1 && T.nodeType !== 9 && T.nodeType !== 11) throw Error(F(299));
            return P(x, T, null, z)
        }, Gl.flushSync = function(x) {
            var T = el.T,
                z = m.p;
            try {
                if (el.T = null, m.p = 2, x) return x()
            } finally {
                el.T = T, m.p = z, m.d.f()
            }
        }, Gl.preconnect = function(x, T) {
            typeof x == "string" && (T ? (T = T.crossOrigin, T = typeof T == "string" ? T === "use-credentials" ? T : "" : void 0) : T = null, m.d.C(x, T))
        }, Gl.prefetchDNS = function(x) {
            typeof x == "string" && m.d.D(x)
        }, Gl.preinit = function(x, T) {
            if (typeof x == "string" && T && typeof T.as == "string") {
                var z = T.as,
                    Q = nl(z, T.crossOrigin),
                    X = typeof T.integrity == "string" ? T.integrity : void 0,
                    ul = typeof T.fetchPriority == "string" ? T.fetchPriority : void 0;
                z === "style" ? m.d.S(x, typeof T.precedence == "string" ? T.precedence : void 0, {
                    crossOrigin: Q,
                    integrity: X,
                    fetchPriority: ul
                }) : z === "script" && m.d.X(x, {
                    crossOrigin: Q,
                    integrity: X,
                    fetchPriority: ul,
                    nonce: typeof T.nonce == "string" ? T.nonce : void 0
                })
            }
        }, Gl.preinitModule = function(x, T) {
            if (typeof x == "string")
                if (typeof T == "object" && T !== null) {
                    if (T.as == null || T.as === "script") {
                        var z = nl(T.as, T.crossOrigin);
                        m.d.M(x, {
                            crossOrigin: z,
                            integrity: typeof T.integrity == "string" ? T.integrity : void 0,
                            nonce: typeof T.nonce == "string" ? T.nonce : void 0
                        })
                    }
                } else T == null && m.d.M(x)
        }, Gl.preload = function(x, T) {
            if (typeof x == "string" && typeof T == "object" && T !== null && typeof T.as == "string") {
                var z = T.as,
                    Q = nl(z, T.crossOrigin);
                m.d.L(x, z, {
                    crossOrigin: Q,
                    integrity: typeof T.integrity == "string" ? T.integrity : void 0,
                    nonce: typeof T.nonce == "string" ? T.nonce : void 0,
                    type: typeof T.type == "string" ? T.type : void 0,
                    fetchPriority: typeof T.fetchPriority == "string" ? T.fetchPriority : void 0,
                    referrerPolicy: typeof T.referrerPolicy == "string" ? T.referrerPolicy : void 0,
                    imageSrcSet: typeof T.imageSrcSet == "string" ? T.imageSrcSet : void 0,
                    imageSizes: typeof T.imageSizes == "string" ? T.imageSizes : void 0,
                    media: typeof T.media == "string" ? T.media : void 0
                })
            }
        }, Gl.preloadModule = function(x, T) {
            if (typeof x == "string")
                if (T) {
                    var z = nl(T.as, T.crossOrigin);
                    m.d.m(x, {
                        as: typeof T.as == "string" && T.as !== "script" ? T.as : void 0,
                        crossOrigin: z,
                        integrity: typeof T.integrity == "string" ? T.integrity : void 0
                    })
                } else m.d.m(x)
        }, Gl.requestFormReset = function(x) {
            m.d.r(x)
        }, Gl.unstable_batchedUpdates = function(x, T) {
            return x(T)
        }, Gl.useFormState = function(x, T, z) {
            return el.H.useFormState(x, T, z)
        }, Gl.useFormStatus = function() {
            return el.H.useHostTransitionStatus()
        }, Gl.version = "19.1.0", Gl
    }
    var rf;

    function p1() {
        if (rf) return Gn.exports;
        rf = 1;

        function p() {
            if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
                __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(p)
            } catch (F) {
                console.error(F)
            }
        }
        return p(), Gn.exports = g1(), Gn.exports
    }
    /**
     * @license React
     * react-dom-client.production.js
     *
     * Copyright (c) Meta Platforms, Inc. and affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var hf;

    function b1() {
        if (hf) return Se;
        hf = 1;
        var p = y1(),
            F = wn(),
            B = p1();

        function m(l) {
            var t = "https://react.dev/errors/" + l;
            if (1 < arguments.length) {
                t += "?args[]=" + encodeURIComponent(arguments[1]);
                for (var a = 2; a < arguments.length; a++) t += "&args[]=" + encodeURIComponent(arguments[a])
            }
            return "Minified React error #" + l + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
        }

        function W(l) {
            return !(!l || l.nodeType !== 1 && l.nodeType !== 9 && l.nodeType !== 11)
        }

        function P(l) {
            var t = l,
                a = l;
            if (l.alternate)
                for (; t.return;) t = t.return;
            else {
                l = t;
                do t = l, (t.flags & 4098) !== 0 && (a = t.return), l = t.return; while (l)
            }
            return t.tag === 3 ? a : null
        }

        function el(l) {
            if (l.tag === 13) {
                var t = l.memoizedState;
                if (t === null && (l = l.alternate, l !== null && (t = l.memoizedState)), t !== null) return t.dehydrated
            }
            return null
        }

        function nl(l) {
            if (P(l) !== l) throw Error(m(188))
        }

        function x(l) {
            var t = l.alternate;
            if (!t) {
                if (t = P(l), t === null) throw Error(m(188));
                return t !== l ? null : l
            }
            for (var a = l, e = t;;) {
                var u = a.return;
                if (u === null) break;
                var n = u.alternate;
                if (n === null) {
                    if (e = u.return, e !== null) {
                        a = e;
                        continue
                    }
                    break
                }
                if (u.child === n.child) {
                    for (n = u.child; n;) {
                        if (n === a) return nl(u), l;
                        if (n === e) return nl(u), t;
                        n = n.sibling
                    }
                    throw Error(m(188))
                }
                if (a.return !== e.return) a = u, e = n;
                else {
                    for (var i = !1, c = u.child; c;) {
                        if (c === a) {
                            i = !0, a = u, e = n;
                            break
                        }
                        if (c === e) {
                            i = !0, e = u, a = n;
                            break
                        }
                        c = c.sibling
                    }
                    if (!i) {
                        for (c = n.child; c;) {
                            if (c === a) {
                                i = !0, a = n, e = u;
                                break
                            }
                            if (c === e) {
                                i = !0, e = n, a = u;
                                break
                            }
                            c = c.sibling
                        }
                        if (!i) throw Error(m(189))
                    }
                }
                if (a.alternate !== e) throw Error(m(190))
            }
            if (a.tag !== 3) throw Error(m(188));
            return a.stateNode.current === a ? l : t
        }

        function T(l) {
            var t = l.tag;
            if (t === 5 || t === 26 || t === 27 || t === 6) return l;
            for (l = l.child; l !== null;) {
                if (t = T(l), t !== null) return t;
                l = l.sibling
            }
            return null
        }
        var z = Object.assign,
            Q = Symbol.for("react.element"),
            X = Symbol.for("react.transitional.element"),
            ul = Symbol.for("react.portal"),
            ml = Symbol.for("react.fragment"),
            _l = Symbol.for("react.strict_mode"),
            Z = Symbol.for("react.profiler"),
            vl = Symbol.for("react.provider"),
            il = Symbol.for("react.consumer"),
            K = Symbol.for("react.context"),
            gl = Symbol.for("react.forward_ref"),
            L = Symbol.for("react.suspense"),
            Nl = Symbol.for("react.suspense_list"),
            w = Symbol.for("react.memo"),
            Sl = Symbol.for("react.lazy"),
            Ql = Symbol.for("react.activity"),
            _t = Symbol.for("react.memo_cache_sentinel"),
            xt = Symbol.iterator;

        function Xl(l) {
            return l === null || typeof l != "object" ? null : (l = xt && l[xt] || l["@@iterator"], typeof l == "function" ? l : null)
        }
        var va = Symbol.for("react.client.reference");

        function ya(l) {
            if (l == null) return null;
            if (typeof l == "function") return l.$$typeof === va ? null : l.displayName || l.name || null;
            if (typeof l == "string") return l;
            switch (l) {
                case ml:
                    return "Fragment";
                case Z:
                    return "Profiler";
                case _l:
                    return "StrictMode";
                case L:
                    return "Suspense";
                case Nl:
                    return "SuspenseList";
                case Ql:
                    return "Activity"
            }
            if (typeof l == "object") switch (l.$$typeof) {
                case ul:
                    return "Portal";
                case K:
                    return (l.displayName || "Context") + ".Provider";
                case il:
                    return (l._context.displayName || "Context") + ".Consumer";
                case gl:
                    var t = l.render;
                    return l = l.displayName, l || (l = t.displayName || t.name || "", l = l !== "" ? "ForwardRef(" + l + ")" : "ForwardRef"), l;
                case w:
                    return t = l.displayName || null, t !== null ? t : ya(l.type) || "Memo";
                case Sl:
                    t = l._payload, l = l._init;
                    try {
                        return ya(l(t))
                    } catch {}
            }
            return null
        }
        var Zl = Array.isArray,
            b = F.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
            _ = B.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
            q = {
                pending: !1,
                data: null,
                method: null,
                action: null
            },
            rl = [],
            s = -1;

        function A(l) {
            return {
                current: l
            }
        }

        function O(l) {
            0 > s || (l.current = rl[s], rl[s] = null, s--)
        }

        function M(l, t) {
            s++, rl[s] = l.current, l.current = t
        }
        var R = A(null),
            ll = A(null),
            C = A(null),
            Il = A(null);

        function pl(l, t) {
            switch (M(C, t), M(ll, l), M(R, null), t.nodeType) {
                case 9:
                case 11:
                    l = (l = t.documentElement) && (l = l.namespaceURI) ? Go(l) : 0;
                    break;
                default:
                    if (l = t.tagName, t = t.namespaceURI) t = Go(t), l = Qo(t, l);
                    else switch (l) {
                        case "svg":
                            l = 1;
                            break;
                        case "math":
                            l = 2;
                            break;
                        default:
                            l = 0
                    }
            }
            O(R), M(R, l)
        }

        function Zt() {
            O(R), O(ll), O(C)
        }

        function Xn(l) {
            l.memoizedState !== null && M(Il, l);
            var t = R.current,
                a = Qo(t, l.type);
            t !== a && (M(ll, l), M(R, a))
        }

        function pu(l) {
            ll.current === l && (O(R), O(ll)), Il.current === l && (O(Il), hu._currentValue = q)
        }
        var Zn = Object.prototype.hasOwnProperty,
            Ln = p.unstable_scheduleCallback,
            Vn = p.unstable_cancelCallback,
            C1 = p.unstable_shouldYield,
            B1 = p.unstable_requestPaint,
            St = p.unstable_now,
            j1 = p.unstable_getCurrentPriorityLevel,
            bf = p.unstable_ImmediatePriority,
            Sf = p.unstable_UserBlockingPriority,
            bu = p.unstable_NormalPriority,
            w1 = p.unstable_LowPriority,
            Tf = p.unstable_IdlePriority,
            G1 = p.log,
            Q1 = p.unstable_setDisableYieldValue,
            Te = null,
            Pl = null;

        function Lt(l) {
            if (typeof G1 == "function" && Q1(l), Pl && typeof Pl.setStrictMode == "function") try {
                Pl.setStrictMode(Te, l)
            } catch {}
        }
        var lt = Math.clz32 ? Math.clz32 : L1,
            X1 = Math.log,
            Z1 = Math.LN2;

        function L1(l) {
            return l >>>= 0, l === 0 ? 32 : 31 - (X1(l) / Z1 | 0) | 0
        }
        var Su = 256,
            Tu = 4194304;

        function ma(l) {
            var t = l & 42;
            if (t !== 0) return t;
            switch (l & -l) {
                case 1:
                    return 1;
                case 2:
                    return 2;
                case 4:
                    return 4;
                case 8:
                    return 8;
                case 16:
                    return 16;
                case 32:
                    return 32;
                case 64:
                    return 64;
                case 128:
                    return 128;
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                    return l & 4194048;
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    return l & 62914560;
                case 67108864:
                    return 67108864;
                case 134217728:
                    return 134217728;
                case 268435456:
                    return 268435456;
                case 536870912:
                    return 536870912;
                case 1073741824:
                    return 0;
                default:
                    return l
            }
        }

        function Eu(l, t, a) {
            var e = l.pendingLanes;
            if (e === 0) return 0;
            var u = 0,
                n = l.suspendedLanes,
                i = l.pingedLanes;
            l = l.warmLanes;
            var c = e & 134217727;
            return c !== 0 ? (e = c & ~n, e !== 0 ? u = ma(e) : (i &= c, i !== 0 ? u = ma(i) : a || (a = c & ~l, a !== 0 && (u = ma(a))))) : (c = e & ~n, c !== 0 ? u = ma(c) : i !== 0 ? u = ma(i) : a || (a = e & ~l, a !== 0 && (u = ma(a)))), u === 0 ? 0 : t !== 0 && t !== u && (t & n) === 0 && (n = u & -u, a = t & -t, n >= a || n === 32 && (a & 4194048) !== 0) ? t : u
        }

        function Ee(l, t) {
            return (l.pendingLanes & ~(l.suspendedLanes & ~l.pingedLanes) & t) === 0
        }

        function V1(l, t) {
            switch (l) {
                case 1:
                case 2:
                case 4:
                case 8:
                case 64:
                    return t + 250;
                case 16:
                case 32:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                    return t + 5e3;
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    return -1;
                case 67108864:
                case 134217728:
                case 268435456:
                case 536870912:
                case 1073741824:
                    return -1;
                default:
                    return -1
            }
        }

        function Ef() {
            var l = Su;
            return Su <<= 1, (Su & 4194048) === 0 && (Su = 256), l
        }

        function Af() {
            var l = Tu;
            return Tu <<= 1, (Tu & 62914560) === 0 && (Tu = 4194304), l
        }

        function Kn(l) {
            for (var t = [], a = 0; 31 > a; a++) t.push(l);
            return t
        }

        function Ae(l, t) {
            l.pendingLanes |= t, t !== 268435456 && (l.suspendedLanes = 0, l.pingedLanes = 0, l.warmLanes = 0)
        }

        function K1(l, t, a, e, u, n) {
            var i = l.pendingLanes;
            l.pendingLanes = a, l.suspendedLanes = 0, l.pingedLanes = 0, l.warmLanes = 0, l.expiredLanes &= a, l.entangledLanes &= a, l.errorRecoveryDisabledLanes &= a, l.shellSuspendCounter = 0;
            var c = l.entanglements,
                f = l.expirationTimes,
                h = l.hiddenUpdates;
            for (a = i & ~a; 0 < a;) {
                var g = 31 - lt(a),
                    E = 1 << g;
                c[g] = 0, f[g] = -1;
                var v = h[g];
                if (v !== null)
                    for (h[g] = null, g = 0; g < v.length; g++) {
                        var y = v[g];
                        y !== null && (y.lane &= -536870913)
                    }
                a &= ~E
            }
            e !== 0 && zf(l, e, 0), n !== 0 && u === 0 && l.tag !== 0 && (l.suspendedLanes |= n & ~(i & ~t))
        }

        function zf(l, t, a) {
            l.pendingLanes |= t, l.suspendedLanes &= ~t;
            var e = 31 - lt(t);
            l.entangledLanes |= t, l.entanglements[e] = l.entanglements[e] | 1073741824 | a & 4194090
        }

        function Mf(l, t) {
            var a = l.entangledLanes |= t;
            for (l = l.entanglements; a;) {
                var e = 31 - lt(a),
                    u = 1 << e;
                u & t | l[e] & t && (l[e] |= t), a &= ~u
            }
        }

        function Jn(l) {
            switch (l) {
                case 2:
                    l = 1;
                    break;
                case 8:
                    l = 4;
                    break;
                case 32:
                    l = 16;
                    break;
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    l = 128;
                    break;
                case 268435456:
                    l = 134217728;
                    break;
                default:
                    l = 0
            }
            return l
        }

        function kn(l) {
            return l &= -l, 2 < l ? 8 < l ? (l & 134217727) !== 0 ? 32 : 268435456 : 8 : 2
        }

        function _f() {
            var l = _.p;
            return l !== 0 ? l : (l = window.event, l === void 0 ? 32 : i1(l.type))
        }

        function J1(l, t) {
            var a = _.p;
            try {
                return _.p = l, t()
            } finally {
                _.p = a
            }
        }
        var Vt = Math.random().toString(36).slice(2),
            Ll = "__reactFiber$" + Vt,
            Jl = "__reactProps$" + Vt,
            qa = "__reactContainer$" + Vt,
            Wn = "__reactEvents$" + Vt,
            k1 = "__reactListeners$" + Vt,
            W1 = "__reactHandles$" + Vt,
            xf = "__reactResources$" + Vt,
            ze = "__reactMarker$" + Vt;

        function $n(l) {
            delete l[Ll], delete l[Jl], delete l[Wn], delete l[k1], delete l[W1]
        }

        function Ya(l) {
            var t = l[Ll];
            if (t) return t;
            for (var a = l.parentNode; a;) {
                if (t = a[qa] || a[Ll]) {
                    if (a = t.alternate, t.child !== null || a !== null && a.child !== null)
                        for (l = Vo(l); l !== null;) {
                            if (a = l[Ll]) return a;
                            l = Vo(l)
                        }
                    return t
                }
                l = a, a = l.parentNode
            }
            return null
        }

        function Ca(l) {
            if (l = l[Ll] || l[qa]) {
                var t = l.tag;
                if (t === 5 || t === 6 || t === 13 || t === 26 || t === 27 || t === 3) return l
            }
            return null
        }

        function Me(l) {
            var t = l.tag;
            if (t === 5 || t === 26 || t === 27 || t === 6) return l.stateNode;
            throw Error(m(33))
        }

        function Ba(l) {
            var t = l[xf];
            return t || (t = l[xf] = {
                hoistableStyles: new Map,
                hoistableScripts: new Map
            }), t
        }

        function Hl(l) {
            l[ze] = !0
        }
        var Of = new Set,
            Df = {};

        function ga(l, t) {
            ja(l, t), ja(l + "Capture", t)
        }

        function ja(l, t) {
            for (Df[l] = t, l = 0; l < t.length; l++) Of.add(t[l])
        }
        var $1 = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),
            Uf = {},
            Rf = {};

        function F1(l) {
            return Zn.call(Rf, l) ? !0 : Zn.call(Uf, l) ? !1 : $1.test(l) ? Rf[l] = !0 : (Uf[l] = !0, !1)
        }

        function Au(l, t, a) {
            if (F1(t))
                if (a === null) l.removeAttribute(t);
                else {
                    switch (typeof a) {
                        case "undefined":
                        case "function":
                        case "symbol":
                            l.removeAttribute(t);
                            return;
                        case "boolean":
                            var e = t.toLowerCase().slice(0, 5);
                            if (e !== "data-" && e !== "aria-") {
                                l.removeAttribute(t);
                                return
                            }
                    }
                    l.setAttribute(t, "" + a)
                }
        }

        function zu(l, t, a) {
            if (a === null) l.removeAttribute(t);
            else {
                switch (typeof a) {
                    case "undefined":
                    case "function":
                    case "symbol":
                    case "boolean":
                        l.removeAttribute(t);
                        return
                }
                l.setAttribute(t, "" + a)
            }
        }

        function Ot(l, t, a, e) {
            if (e === null) l.removeAttribute(a);
            else {
                switch (typeof e) {
                    case "undefined":
                    case "function":
                    case "symbol":
                    case "boolean":
                        l.removeAttribute(a);
                        return
                }
                l.setAttributeNS(t, a, "" + e)
            }
        }
        var Fn, Nf;

        function wa(l) {
            if (Fn === void 0) try {
                throw Error()
            } catch (a) {
                var t = a.stack.trim().match(/\n( *(at )?)/);
                Fn = t && t[1] || "", Nf = -1 < a.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < a.stack.indexOf("@") ? "@unknown:0:0" : ""
            }
            return `
` + Fn + l + Nf
        }
        var In = !1;

        function Pn(l, t) {
            if (!l || In) return "";
            In = !0;
            var a = Error.prepareStackTrace;
            Error.prepareStackTrace = void 0;
            try {
                var e = {
                    DetermineComponentFrameRoot: function() {
                        try {
                            if (t) {
                                var E = function() {
                                    throw Error()
                                };
                                if (Object.defineProperty(E.prototype, "props", {
                                        set: function() {
                                            throw Error()
                                        }
                                    }), typeof Reflect == "object" && Reflect.construct) {
                                    try {
                                        Reflect.construct(E, [])
                                    } catch (y) {
                                        var v = y
                                    }
                                    Reflect.construct(l, [], E)
                                } else {
                                    try {
                                        E.call()
                                    } catch (y) {
                                        v = y
                                    }
                                    l.call(E.prototype)
                                }
                            } else {
                                try {
                                    throw Error()
                                } catch (y) {
                                    v = y
                                }(E = l()) && typeof E.catch == "function" && E.catch(function() {})
                            }
                        } catch (y) {
                            if (y && v && typeof y.stack == "string") return [y.stack, v.stack]
                        }
                        return [null, null]
                    }
                };
                e.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
                var u = Object.getOwnPropertyDescriptor(e.DetermineComponentFrameRoot, "name");
                u && u.configurable && Object.defineProperty(e.DetermineComponentFrameRoot, "name", {
                    value: "DetermineComponentFrameRoot"
                });
                var n = e.DetermineComponentFrameRoot(),
                    i = n[0],
                    c = n[1];
                if (i && c) {
                    var f = i.split(`
`),
                        h = c.split(`
`);
                    for (u = e = 0; e < f.length && !f[e].includes("DetermineComponentFrameRoot");) e++;
                    for (; u < h.length && !h[u].includes("DetermineComponentFrameRoot");) u++;
                    if (e === f.length || u === h.length)
                        for (e = f.length - 1, u = h.length - 1; 1 <= e && 0 <= u && f[e] !== h[u];) u--;
                    for (; 1 <= e && 0 <= u; e--, u--)
                        if (f[e] !== h[u]) {
                            if (e !== 1 || u !== 1)
                                do
                                    if (e--, u--, 0 > u || f[e] !== h[u]) {
                                        var g = `
` + f[e].replace(" at new ", " at ");
                                        return l.displayName && g.includes("<anonymous>") && (g = g.replace("<anonymous>", l.displayName)), g
                                    }
                            while (1 <= e && 0 <= u);
                            break
                        }
                }
            } finally {
                In = !1, Error.prepareStackTrace = a
            }
            return (a = l ? l.displayName || l.name : "") ? wa(a) : ""
        }

        function I1(l) {
            switch (l.tag) {
                case 26:
                case 27:
                case 5:
                    return wa(l.type);
                case 16:
                    return wa("Lazy");
                case 13:
                    return wa("Suspense");
                case 19:
                    return wa("SuspenseList");
                case 0:
                case 15:
                    return Pn(l.type, !1);
                case 11:
                    return Pn(l.type.render, !1);
                case 1:
                    return Pn(l.type, !0);
                case 31:
                    return wa("Activity");
                default:
                    return ""
            }
        }

        function Hf(l) {
            try {
                var t = "";
                do t += I1(l), l = l.return; while (l);
                return t
            } catch (a) {
                return `
Error generating stack: ` + a.message + `
` + a.stack
            }
        }

        function ft(l) {
            switch (typeof l) {
                case "bigint":
                case "boolean":
                case "number":
                case "string":
                case "undefined":
                    return l;
                case "object":
                    return l;
                default:
                    return ""
            }
        }

        function qf(l) {
            var t = l.type;
            return (l = l.nodeName) && l.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
        }

        function P1(l) {
            var t = qf(l) ? "checked" : "value",
                a = Object.getOwnPropertyDescriptor(l.constructor.prototype, t),
                e = "" + l[t];
            if (!l.hasOwnProperty(t) && typeof a < "u" && typeof a.get == "function" && typeof a.set == "function") {
                var u = a.get,
                    n = a.set;
                return Object.defineProperty(l, t, {
                    configurable: !0,
                    get: function() {
                        return u.call(this)
                    },
                    set: function(i) {
                        e = "" + i, n.call(this, i)
                    }
                }), Object.defineProperty(l, t, {
                    enumerable: a.enumerable
                }), {
                    getValue: function() {
                        return e
                    },
                    setValue: function(i) {
                        e = "" + i
                    },
                    stopTracking: function() {
                        l._valueTracker = null, delete l[t]
                    }
                }
            }
        }

        function Mu(l) {
            l._valueTracker || (l._valueTracker = P1(l))
        }

        function Yf(l) {
            if (!l) return !1;
            var t = l._valueTracker;
            if (!t) return !0;
            var a = t.getValue(),
                e = "";
            return l && (e = qf(l) ? l.checked ? "true" : "false" : l.value), l = e, l !== a ? (t.setValue(l), !0) : !1
        }

        function _u(l) {
            if (l = l || (typeof document < "u" ? document : void 0), typeof l > "u") return null;
            try {
                return l.activeElement || l.body
            } catch {
                return l.body
            }
        }
        var ld = /[\n"\\]/g;

        function st(l) {
            return l.replace(ld, function(t) {
                return "\\" + t.charCodeAt(0).toString(16) + " "
            })
        }

        function li(l, t, a, e, u, n, i, c) {
            l.name = "", i != null && typeof i != "function" && typeof i != "symbol" && typeof i != "boolean" ? l.type = i : l.removeAttribute("type"), t != null ? i === "number" ? (t === 0 && l.value === "" || l.value != t) && (l.value = "" + ft(t)) : l.value !== "" + ft(t) && (l.value = "" + ft(t)) : i !== "submit" && i !== "reset" || l.removeAttribute("value"), t != null ? ti(l, i, ft(t)) : a != null ? ti(l, i, ft(a)) : e != null && l.removeAttribute("value"), u == null && n != null && (l.defaultChecked = !!n), u != null && (l.checked = u && typeof u != "function" && typeof u != "symbol"), c != null && typeof c != "function" && typeof c != "symbol" && typeof c != "boolean" ? l.name = "" + ft(c) : l.removeAttribute("name")
        }

        function Cf(l, t, a, e, u, n, i, c) {
            if (n != null && typeof n != "function" && typeof n != "symbol" && typeof n != "boolean" && (l.type = n), t != null || a != null) {
                if (!(n !== "submit" && n !== "reset" || t != null)) return;
                a = a != null ? "" + ft(a) : "", t = t != null ? "" + ft(t) : a, c || t === l.value || (l.value = t), l.defaultValue = t
            }
            e = e ? ? u, e = typeof e != "function" && typeof e != "symbol" && !!e, l.checked = c ? l.checked : !!e, l.defaultChecked = !!e, i != null && typeof i != "function" && typeof i != "symbol" && typeof i != "boolean" && (l.name = i)
        }

        function ti(l, t, a) {
            t === "number" && _u(l.ownerDocument) === l || l.defaultValue === "" + a || (l.defaultValue = "" + a)
        }

        function Ga(l, t, a, e) {
            if (l = l.options, t) {
                t = {};
                for (var u = 0; u < a.length; u++) t["$" + a[u]] = !0;
                for (a = 0; a < l.length; a++) u = t.hasOwnProperty("$" + l[a].value), l[a].selected !== u && (l[a].selected = u), u && e && (l[a].defaultSelected = !0)
            } else {
                for (a = "" + ft(a), t = null, u = 0; u < l.length; u++) {
                    if (l[u].value === a) {
                        l[u].selected = !0, e && (l[u].defaultSelected = !0);
                        return
                    }
                    t !== null || l[u].disabled || (t = l[u])
                }
                t !== null && (t.selected = !0)
            }
        }

        function Bf(l, t, a) {
            if (t != null && (t = "" + ft(t), t !== l.value && (l.value = t), a == null)) {
                l.defaultValue !== t && (l.defaultValue = t);
                return
            }
            l.defaultValue = a != null ? "" + ft(a) : ""
        }

        function jf(l, t, a, e) {
            if (t == null) {
                if (e != null) {
                    if (a != null) throw Error(m(92));
                    if (Zl(e)) {
                        if (1 < e.length) throw Error(m(93));
                        e = e[0]
                    }
                    a = e
                }
                a == null && (a = ""), t = a
            }
            a = ft(t), l.defaultValue = a, e = l.textContent, e === a && e !== "" && e !== null && (l.value = e)
        }

        function Qa(l, t) {
            if (t) {
                var a = l.firstChild;
                if (a && a === l.lastChild && a.nodeType === 3) {
                    a.nodeValue = t;
                    return
                }
            }
            l.textContent = t
        }
        var td = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));

        function wf(l, t, a) {
            var e = t.indexOf("--") === 0;
            a == null || typeof a == "boolean" || a === "" ? e ? l.setProperty(t, "") : t === "float" ? l.cssFloat = "" : l[t] = "" : e ? l.setProperty(t, a) : typeof a != "number" || a === 0 || td.has(t) ? t === "float" ? l.cssFloat = a : l[t] = ("" + a).trim() : l[t] = a + "px"
        }

        function Gf(l, t, a) {
            if (t != null && typeof t != "object") throw Error(m(62));
            if (l = l.style, a != null) {
                for (var e in a) !a.hasOwnProperty(e) || t != null && t.hasOwnProperty(e) || (e.indexOf("--") === 0 ? l.setProperty(e, "") : e === "float" ? l.cssFloat = "" : l[e] = "");
                for (var u in t) e = t[u], t.hasOwnProperty(u) && a[u] !== e && wf(l, u, e)
            } else
                for (var n in t) t.hasOwnProperty(n) && wf(l, n, t[n])
        }

        function ai(l) {
            if (l.indexOf("-") === -1) return !1;
            switch (l) {
                case "annotation-xml":
                case "color-profile":
                case "font-face":
                case "font-face-src":
                case "font-face-uri":
                case "font-face-format":
                case "font-face-name":
                case "missing-glyph":
                    return !1;
                default:
                    return !0
            }
        }
        var ad = new Map([
                ["acceptCharset", "accept-charset"],
                ["htmlFor", "for"],
                ["httpEquiv", "http-equiv"],
                ["crossOrigin", "crossorigin"],
                ["accentHeight", "accent-height"],
                ["alignmentBaseline", "alignment-baseline"],
                ["arabicForm", "arabic-form"],
                ["baselineShift", "baseline-shift"],
                ["capHeight", "cap-height"],
                ["clipPath", "clip-path"],
                ["clipRule", "clip-rule"],
                ["colorInterpolation", "color-interpolation"],
                ["colorInterpolationFilters", "color-interpolation-filters"],
                ["colorProfile", "color-profile"],
                ["colorRendering", "color-rendering"],
                ["dominantBaseline", "dominant-baseline"],
                ["enableBackground", "enable-background"],
                ["fillOpacity", "fill-opacity"],
                ["fillRule", "fill-rule"],
                ["floodColor", "flood-color"],
                ["floodOpacity", "flood-opacity"],
                ["fontFamily", "font-family"],
                ["fontSize", "font-size"],
                ["fontSizeAdjust", "font-size-adjust"],
                ["fontStretch", "font-stretch"],
                ["fontStyle", "font-style"],
                ["fontVariant", "font-variant"],
                ["fontWeight", "font-weight"],
                ["glyphName", "glyph-name"],
                ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
                ["glyphOrientationVertical", "glyph-orientation-vertical"],
                ["horizAdvX", "horiz-adv-x"],
                ["horizOriginX", "horiz-origin-x"],
                ["imageRendering", "image-rendering"],
                ["letterSpacing", "letter-spacing"],
                ["lightingColor", "lighting-color"],
                ["markerEnd", "marker-end"],
                ["markerMid", "marker-mid"],
                ["markerStart", "marker-start"],
                ["overlinePosition", "overline-position"],
                ["overlineThickness", "overline-thickness"],
                ["paintOrder", "paint-order"],
                ["panose-1", "panose-1"],
                ["pointerEvents", "pointer-events"],
                ["renderingIntent", "rendering-intent"],
                ["shapeRendering", "shape-rendering"],
                ["stopColor", "stop-color"],
                ["stopOpacity", "stop-opacity"],
                ["strikethroughPosition", "strikethrough-position"],
                ["strikethroughThickness", "strikethrough-thickness"],
                ["strokeDasharray", "stroke-dasharray"],
                ["strokeDashoffset", "stroke-dashoffset"],
                ["strokeLinecap", "stroke-linecap"],
                ["strokeLinejoin", "stroke-linejoin"],
                ["strokeMiterlimit", "stroke-miterlimit"],
                ["strokeOpacity", "stroke-opacity"],
                ["strokeWidth", "stroke-width"],
                ["textAnchor", "text-anchor"],
                ["textDecoration", "text-decoration"],
                ["textRendering", "text-rendering"],
                ["transformOrigin", "transform-origin"],
                ["underlinePosition", "underline-position"],
                ["underlineThickness", "underline-thickness"],
                ["unicodeBidi", "unicode-bidi"],
                ["unicodeRange", "unicode-range"],
                ["unitsPerEm", "units-per-em"],
                ["vAlphabetic", "v-alphabetic"],
                ["vHanging", "v-hanging"],
                ["vIdeographic", "v-ideographic"],
                ["vMathematical", "v-mathematical"],
                ["vectorEffect", "vector-effect"],
                ["vertAdvY", "vert-adv-y"],
                ["vertOriginX", "vert-origin-x"],
                ["vertOriginY", "vert-origin-y"],
                ["wordSpacing", "word-spacing"],
                ["writingMode", "writing-mode"],
                ["xmlnsXlink", "xmlns:xlink"],
                ["xHeight", "x-height"]
            ]),
            ed = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;

        function xu(l) {
            return ed.test("" + l) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : l
        }
        var ei = null;

        function ui(l) {
            return l = l.target || l.srcElement || window, l.correspondingUseElement && (l = l.correspondingUseElement), l.nodeType === 3 ? l.parentNode : l
        }
        var Xa = null,
            Za = null;

        function Qf(l) {
            var t = Ca(l);
            if (t && (l = t.stateNode)) {
                var a = l[Jl] || null;
                l: switch (l = t.stateNode, t.type) {
                    case "input":
                        if (li(l, a.value, a.defaultValue, a.defaultValue, a.checked, a.defaultChecked, a.type, a.name), t = a.name, a.type === "radio" && t != null) {
                            for (a = l; a.parentNode;) a = a.parentNode;
                            for (a = a.querySelectorAll('input[name="' + st("" + t) + '"][type="radio"]'), t = 0; t < a.length; t++) {
                                var e = a[t];
                                if (e !== l && e.form === l.form) {
                                    var u = e[Jl] || null;
                                    if (!u) throw Error(m(90));
                                    li(e, u.value, u.defaultValue, u.defaultValue, u.checked, u.defaultChecked, u.type, u.name)
                                }
                            }
                            for (t = 0; t < a.length; t++) e = a[t], e.form === l.form && Yf(e)
                        }
                        break l;
                    case "textarea":
                        Bf(l, a.value, a.defaultValue);
                        break l;
                    case "select":
                        t = a.value, t != null && Ga(l, !!a.multiple, t, !1)
                }
            }
        }
        var ni = !1;

        function Xf(l, t, a) {
            if (ni) return l(t, a);
            ni = !0;
            try {
                var e = l(t);
                return e
            } finally {
                if (ni = !1, (Xa !== null || Za !== null) && (hn(), Xa && (t = Xa, l = Za, Za = Xa = null, Qf(t), l)))
                    for (t = 0; t < l.length; t++) Qf(l[t])
            }
        }

        function _e(l, t) {
            var a = l.stateNode;
            if (a === null) return null;
            var e = a[Jl] || null;
            if (e === null) return null;
            a = e[t];
            l: switch (t) {
                case "onClick":
                case "onClickCapture":
                case "onDoubleClick":
                case "onDoubleClickCapture":
                case "onMouseDown":
                case "onMouseDownCapture":
                case "onMouseMove":
                case "onMouseMoveCapture":
                case "onMouseUp":
                case "onMouseUpCapture":
                case "onMouseEnter":
                    (e = !e.disabled) || (l = l.type, e = !(l === "button" || l === "input" || l === "select" || l === "textarea")), l = !e;
                    break l;
                default:
                    l = !1
            }
            if (l) return null;
            if (a && typeof a != "function") throw Error(m(231, t, typeof a));
            return a
        }
        var Dt = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
            ii = !1;
        if (Dt) try {
            var xe = {};
            Object.defineProperty(xe, "passive", {
                get: function() {
                    ii = !0
                }
            }), window.addEventListener("test", xe, xe), window.removeEventListener("test", xe, xe)
        } catch {
            ii = !1
        }
        var Kt = null,
            ci = null,
            Ou = null;

        function Zf() {
            if (Ou) return Ou;
            var l, t = ci,
                a = t.length,
                e, u = "value" in Kt ? Kt.value : Kt.textContent,
                n = u.length;
            for (l = 0; l < a && t[l] === u[l]; l++);
            var i = a - l;
            for (e = 1; e <= i && t[a - e] === u[n - e]; e++);
            return Ou = u.slice(l, 1 < e ? 1 - e : void 0)
        }

        function Du(l) {
            var t = l.keyCode;
            return "charCode" in l ? (l = l.charCode, l === 0 && t === 13 && (l = 13)) : l = t, l === 10 && (l = 13), 32 <= l || l === 13 ? l : 0
        }

        function Uu() {
            return !0
        }

        function Lf() {
            return !1
        }

        function kl(l) {
            function t(a, e, u, n, i) {
                this._reactName = a, this._targetInst = u, this.type = e, this.nativeEvent = n, this.target = i, this.currentTarget = null;
                for (var c in l) l.hasOwnProperty(c) && (a = l[c], this[c] = a ? a(n) : n[c]);
                return this.isDefaultPrevented = (n.defaultPrevented != null ? n.defaultPrevented : n.returnValue === !1) ? Uu : Lf, this.isPropagationStopped = Lf, this
            }
            return z(t.prototype, {
                preventDefault: function() {
                    this.defaultPrevented = !0;
                    var a = this.nativeEvent;
                    a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue != "unknown" && (a.returnValue = !1), this.isDefaultPrevented = Uu)
                },
                stopPropagation: function() {
                    var a = this.nativeEvent;
                    a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble != "unknown" && (a.cancelBubble = !0), this.isPropagationStopped = Uu)
                },
                persist: function() {},
                isPersistent: Uu
            }), t
        }
        var pa = {
                eventPhase: 0,
                bubbles: 0,
                cancelable: 0,
                timeStamp: function(l) {
                    return l.timeStamp || Date.now()
                },
                defaultPrevented: 0,
                isTrusted: 0
            },
            Ru = kl(pa),
            Oe = z({}, pa, {
                view: 0,
                detail: 0
            }),
            ud = kl(Oe),
            fi, si, De, Nu = z({}, Oe, {
                screenX: 0,
                screenY: 0,
                clientX: 0,
                clientY: 0,
                pageX: 0,
                pageY: 0,
                ctrlKey: 0,
                shiftKey: 0,
                altKey: 0,
                metaKey: 0,
                getModifierState: di,
                button: 0,
                buttons: 0,
                relatedTarget: function(l) {
                    return l.relatedTarget === void 0 ? l.fromElement === l.srcElement ? l.toElement : l.fromElement : l.relatedTarget
                },
                movementX: function(l) {
                    return "movementX" in l ? l.movementX : (l !== De && (De && l.type === "mousemove" ? (fi = l.screenX - De.screenX, si = l.screenY - De.screenY) : si = fi = 0, De = l), fi)
                },
                movementY: function(l) {
                    return "movementY" in l ? l.movementY : si
                }
            }),
            Vf = kl(Nu),
            nd = z({}, Nu, {
                dataTransfer: 0
            }),
            id = kl(nd),
            cd = z({}, Oe, {
                relatedTarget: 0
            }),
            oi = kl(cd),
            fd = z({}, pa, {
                animationName: 0,
                elapsedTime: 0,
                pseudoElement: 0
            }),
            sd = kl(fd),
            od = z({}, pa, {
                clipboardData: function(l) {
                    return "clipboardData" in l ? l.clipboardData : window.clipboardData
                }
            }),
            dd = kl(od),
            rd = z({}, pa, {
                data: 0
            }),
            Kf = kl(rd),
            hd = {
                Esc: "Escape",
                Spacebar: " ",
                Left: "ArrowLeft",
                Up: "ArrowUp",
                Right: "ArrowRight",
                Down: "ArrowDown",
                Del: "Delete",
                Win: "OS",
                Menu: "ContextMenu",
                Apps: "ContextMenu",
                Scroll: "ScrollLock",
                MozPrintableKey: "Unidentified"
            },
            vd = {
                8: "Backspace",
                9: "Tab",
                12: "Clear",
                13: "Enter",
                16: "Shift",
                17: "Control",
                18: "Alt",
                19: "Pause",
                20: "CapsLock",
                27: "Escape",
                32: " ",
                33: "PageUp",
                34: "PageDown",
                35: "End",
                36: "Home",
                37: "ArrowLeft",
                38: "ArrowUp",
                39: "ArrowRight",
                40: "ArrowDown",
                45: "Insert",
                46: "Delete",
                112: "F1",
                113: "F2",
                114: "F3",
                115: "F4",
                116: "F5",
                117: "F6",
                118: "F7",
                119: "F8",
                120: "F9",
                121: "F10",
                122: "F11",
                123: "F12",
                144: "NumLock",
                145: "ScrollLock",
                224: "Meta"
            },
            yd = {
                Alt: "altKey",
                Control: "ctrlKey",
                Meta: "metaKey",
                Shift: "shiftKey"
            };

        function md(l) {
            var t = this.nativeEvent;
            return t.getModifierState ? t.getModifierState(l) : (l = yd[l]) ? !!t[l] : !1
        }

        function di() {
            return md
        }
        var gd = z({}, Oe, {
                key: function(l) {
                    if (l.key) {
                        var t = hd[l.key] || l.key;
                        if (t !== "Unidentified") return t
                    }
                    return l.type === "keypress" ? (l = Du(l), l === 13 ? "Enter" : String.fromCharCode(l)) : l.type === "keydown" || l.type === "keyup" ? vd[l.keyCode] || "Unidentified" : ""
                },
                code: 0,
                location: 0,
                ctrlKey: 0,
                shiftKey: 0,
                altKey: 0,
                metaKey: 0,
                repeat: 0,
                locale: 0,
                getModifierState: di,
                charCode: function(l) {
                    return l.type === "keypress" ? Du(l) : 0
                },
                keyCode: function(l) {
                    return l.type === "keydown" || l.type === "keyup" ? l.keyCode : 0
                },
                which: function(l) {
                    return l.type === "keypress" ? Du(l) : l.type === "keydown" || l.type === "keyup" ? l.keyCode : 0
                }
            }),
            pd = kl(gd),
            bd = z({}, Nu, {
                pointerId: 0,
                width: 0,
                height: 0,
                pressure: 0,
                tangentialPressure: 0,
                tiltX: 0,
                tiltY: 0,
                twist: 0,
                pointerType: 0,
                isPrimary: 0
            }),
            Jf = kl(bd),
            Sd = z({}, Oe, {
                touches: 0,
                targetTouches: 0,
                changedTouches: 0,
                altKey: 0,
                metaKey: 0,
                ctrlKey: 0,
                shiftKey: 0,
                getModifierState: di
            }),
            Td = kl(Sd),
            Ed = z({}, pa, {
                propertyName: 0,
                elapsedTime: 0,
                pseudoElement: 0
            }),
            Ad = kl(Ed),
            zd = z({}, Nu, {
                deltaX: function(l) {
                    return "deltaX" in l ? l.deltaX : "wheelDeltaX" in l ? -l.wheelDeltaX : 0
                },
                deltaY: function(l) {
                    return "deltaY" in l ? l.deltaY : "wheelDeltaY" in l ? -l.wheelDeltaY : "wheelDelta" in l ? -l.wheelDelta : 0
                },
                deltaZ: 0,
                deltaMode: 0
            }),
            Md = kl(zd),
            _d = z({}, pa, {
                newState: 0,
                oldState: 0
            }),
            xd = kl(_d),
            Od = [9, 13, 27, 32],
            ri = Dt && "CompositionEvent" in window,
            Ue = null;
        Dt && "documentMode" in document && (Ue = document.documentMode);
        var Dd = Dt && "TextEvent" in window && !Ue,
            kf = Dt && (!ri || Ue && 8 < Ue && 11 >= Ue),
            Wf = " ",
            $f = !1;

        function Ff(l, t) {
            switch (l) {
                case "keyup":
                    return Od.indexOf(t.keyCode) !== -1;
                case "keydown":
                    return t.keyCode !== 229;
                case "keypress":
                case "mousedown":
                case "focusout":
                    return !0;
                default:
                    return !1
            }
        }

        function If(l) {
            return l = l.detail, typeof l == "object" && "data" in l ? l.data : null
        }
        var La = !1;

        function Ud(l, t) {
            switch (l) {
                case "compositionend":
                    return If(t);
                case "keypress":
                    return t.which !== 32 ? null : ($f = !0, Wf);
                case "textInput":
                    return l = t.data, l === Wf && $f ? null : l;
                default:
                    return null
            }
        }

        function Rd(l, t) {
            if (La) return l === "compositionend" || !ri && Ff(l, t) ? (l = Zf(), Ou = ci = Kt = null, La = !1, l) : null;
            switch (l) {
                case "paste":
                    return null;
                case "keypress":
                    if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                        if (t.char && 1 < t.char.length) return t.char;
                        if (t.which) return String.fromCharCode(t.which)
                    }
                    return null;
                case "compositionend":
                    return kf && t.locale !== "ko" ? null : t.data;
                default:
                    return null
            }
        }
        var Nd = {
            color: !0,
            date: !0,
            datetime: !0,
            "datetime-local": !0,
            email: !0,
            month: !0,
            number: !0,
            password: !0,
            range: !0,
            search: !0,
            tel: !0,
            text: !0,
            time: !0,
            url: !0,
            week: !0
        };

        function Pf(l) {
            var t = l && l.nodeName && l.nodeName.toLowerCase();
            return t === "input" ? !!Nd[l.type] : t === "textarea"
        }

        function ls(l, t, a, e) {
            Xa ? Za ? Za.push(e) : Za = [e] : Xa = e, t = bn(t, "onChange"), 0 < t.length && (a = new Ru("onChange", "change", null, a, e), l.push({
                event: a,
                listeners: t
            }))
        }
        var Re = null,
            Ne = null;

        function Hd(l) {
            Yo(l, 0)
        }

        function Hu(l) {
            var t = Me(l);
            if (Yf(t)) return l
        }

        function ts(l, t) {
            if (l === "change") return t
        }
        var as = !1;
        if (Dt) {
            var hi;
            if (Dt) {
                var vi = "oninput" in document;
                if (!vi) {
                    var es = document.createElement("div");
                    es.setAttribute("oninput", "return;"), vi = typeof es.oninput == "function"
                }
                hi = vi
            } else hi = !1;
            as = hi && (!document.documentMode || 9 < document.documentMode)
        }

        function us() {
            Re && (Re.detachEvent("onpropertychange", ns), Ne = Re = null)
        }

        function ns(l) {
            if (l.propertyName === "value" && Hu(Ne)) {
                var t = [];
                ls(t, Ne, l, ui(l)), Xf(Hd, t)
            }
        }

        function qd(l, t, a) {
            l === "focusin" ? (us(), Re = t, Ne = a, Re.attachEvent("onpropertychange", ns)) : l === "focusout" && us()
        }

        function Yd(l) {
            if (l === "selectionchange" || l === "keyup" || l === "keydown") return Hu(Ne)
        }

        function Cd(l, t) {
            if (l === "click") return Hu(t)
        }

        function Bd(l, t) {
            if (l === "input" || l === "change") return Hu(t)
        }

        function jd(l, t) {
            return l === t && (l !== 0 || 1 / l === 1 / t) || l !== l && t !== t
        }
        var tt = typeof Object.is == "function" ? Object.is : jd;

        function He(l, t) {
            if (tt(l, t)) return !0;
            if (typeof l != "object" || l === null || typeof t != "object" || t === null) return !1;
            var a = Object.keys(l),
                e = Object.keys(t);
            if (a.length !== e.length) return !1;
            for (e = 0; e < a.length; e++) {
                var u = a[e];
                if (!Zn.call(t, u) || !tt(l[u], t[u])) return !1
            }
            return !0
        }

        function is(l) {
            for (; l && l.firstChild;) l = l.firstChild;
            return l
        }

        function cs(l, t) {
            var a = is(l);
            l = 0;
            for (var e; a;) {
                if (a.nodeType === 3) {
                    if (e = l + a.textContent.length, l <= t && e >= t) return {
                        node: a,
                        offset: t - l
                    };
                    l = e
                }
                l: {
                    for (; a;) {
                        if (a.nextSibling) {
                            a = a.nextSibling;
                            break l
                        }
                        a = a.parentNode
                    }
                    a = void 0
                }
                a = is(a)
            }
        }

        function fs(l, t) {
            return l && t ? l === t ? !0 : l && l.nodeType === 3 ? !1 : t && t.nodeType === 3 ? fs(l, t.parentNode) : "contains" in l ? l.contains(t) : l.compareDocumentPosition ? !!(l.compareDocumentPosition(t) & 16) : !1 : !1
        }

        function ss(l) {
            l = l != null && l.ownerDocument != null && l.ownerDocument.defaultView != null ? l.ownerDocument.defaultView : window;
            for (var t = _u(l.document); t instanceof l.HTMLIFrameElement;) {
                try {
                    var a = typeof t.contentWindow.location.href == "string"
                } catch {
                    a = !1
                }
                if (a) l = t.contentWindow;
                else break;
                t = _u(l.document)
            }
            return t
        }

        function yi(l) {
            var t = l && l.nodeName && l.nodeName.toLowerCase();
            return t && (t === "input" && (l.type === "text" || l.type === "search" || l.type === "tel" || l.type === "url" || l.type === "password") || t === "textarea" || l.contentEditable === "true")
        }
        var wd = Dt && "documentMode" in document && 11 >= document.documentMode,
            Va = null,
            mi = null,
            qe = null,
            gi = !1;

        function os(l, t, a) {
            var e = a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
            gi || Va == null || Va !== _u(e) || (e = Va, "selectionStart" in e && yi(e) ? e = {
                start: e.selectionStart,
                end: e.selectionEnd
            } : (e = (e.ownerDocument && e.ownerDocument.defaultView || window).getSelection(), e = {
                anchorNode: e.anchorNode,
                anchorOffset: e.anchorOffset,
                focusNode: e.focusNode,
                focusOffset: e.focusOffset
            }), qe && He(qe, e) || (qe = e, e = bn(mi, "onSelect"), 0 < e.length && (t = new Ru("onSelect", "select", null, t, a), l.push({
                event: t,
                listeners: e
            }), t.target = Va)))
        }

        function ba(l, t) {
            var a = {};
            return a[l.toLowerCase()] = t.toLowerCase(), a["Webkit" + l] = "webkit" + t, a["Moz" + l] = "moz" + t, a
        }
        var Ka = {
                animationend: ba("Animation", "AnimationEnd"),
                animationiteration: ba("Animation", "AnimationIteration"),
                animationstart: ba("Animation", "AnimationStart"),
                transitionrun: ba("Transition", "TransitionRun"),
                transitionstart: ba("Transition", "TransitionStart"),
                transitioncancel: ba("Transition", "TransitionCancel"),
                transitionend: ba("Transition", "TransitionEnd")
            },
            pi = {},
            ds = {};
        Dt && (ds = document.createElement("div").style, "AnimationEvent" in window || (delete Ka.animationend.animation, delete Ka.animationiteration.animation, delete Ka.animationstart.animation), "TransitionEvent" in window || delete Ka.transitionend.transition);

        function Sa(l) {
            if (pi[l]) return pi[l];
            if (!Ka[l]) return l;
            var t = Ka[l],
                a;
            for (a in t)
                if (t.hasOwnProperty(a) && a in ds) return pi[l] = t[a];
            return l
        }
        var rs = Sa("animationend"),
            hs = Sa("animationiteration"),
            vs = Sa("animationstart"),
            Gd = Sa("transitionrun"),
            Qd = Sa("transitionstart"),
            Xd = Sa("transitioncancel"),
            ys = Sa("transitionend"),
            ms = new Map,
            bi = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
        bi.push("scrollEnd");

        function gt(l, t) {
            ms.set(l, t), ga(t, [l])
        }
        var gs = new WeakMap;

        function ot(l, t) {
            if (typeof l == "object" && l !== null) {
                var a = gs.get(l);
                return a !== void 0 ? a : (t = {
                    value: l,
                    source: t,
                    stack: Hf(t)
                }, gs.set(l, t), t)
            }
            return {
                value: l,
                source: t,
                stack: Hf(t)
            }
        }
        var dt = [],
            Ja = 0,
            Si = 0;

        function qu() {
            for (var l = Ja, t = Si = Ja = 0; t < l;) {
                var a = dt[t];
                dt[t++] = null;
                var e = dt[t];
                dt[t++] = null;
                var u = dt[t];
                dt[t++] = null;
                var n = dt[t];
                if (dt[t++] = null, e !== null && u !== null) {
                    var i = e.pending;
                    i === null ? u.next = u : (u.next = i.next, i.next = u), e.pending = u
                }
                n !== 0 && ps(a, u, n)
            }
        }

        function Yu(l, t, a, e) {
            dt[Ja++] = l, dt[Ja++] = t, dt[Ja++] = a, dt[Ja++] = e, Si |= e, l.lanes |= e, l = l.alternate, l !== null && (l.lanes |= e)
        }

        function Ti(l, t, a, e) {
            return Yu(l, t, a, e), Cu(l)
        }

        function ka(l, t) {
            return Yu(l, null, null, t), Cu(l)
        }

        function ps(l, t, a) {
            l.lanes |= a;
            var e = l.alternate;
            e !== null && (e.lanes |= a);
            for (var u = !1, n = l.return; n !== null;) n.childLanes |= a, e = n.alternate, e !== null && (e.childLanes |= a), n.tag === 22 && (l = n.stateNode, l === null || l._visibility & 1 || (u = !0)), l = n, n = n.return;
            return l.tag === 3 ? (n = l.stateNode, u && t !== null && (u = 31 - lt(a), l = n.hiddenUpdates, e = l[u], e === null ? l[u] = [t] : e.push(t), t.lane = a | 536870912), n) : null
        }

        function Cu(l) {
            if (50 < nu) throw nu = 0, xc = null, Error(m(185));
            for (var t = l.return; t !== null;) l = t, t = l.return;
            return l.tag === 3 ? l.stateNode : null
        }
        var Wa = {};

        function Zd(l, t, a, e) {
            this.tag = l, this.key = a, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = e, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
        }

        function at(l, t, a, e) {
            return new Zd(l, t, a, e)
        }

        function Ei(l) {
            return l = l.prototype, !(!l || !l.isReactComponent)
        }

        function Ut(l, t) {
            var a = l.alternate;
            return a === null ? (a = at(l.tag, t, l.key, l.mode), a.elementType = l.elementType, a.type = l.type, a.stateNode = l.stateNode, a.alternate = l, l.alternate = a) : (a.pendingProps = t, a.type = l.type, a.flags = 0, a.subtreeFlags = 0, a.deletions = null), a.flags = l.flags & 65011712, a.childLanes = l.childLanes, a.lanes = l.lanes, a.child = l.child, a.memoizedProps = l.memoizedProps, a.memoizedState = l.memoizedState, a.updateQueue = l.updateQueue, t = l.dependencies, a.dependencies = t === null ? null : {
                lanes: t.lanes,
                firstContext: t.firstContext
            }, a.sibling = l.sibling, a.index = l.index, a.ref = l.ref, a.refCleanup = l.refCleanup, a
        }

        function bs(l, t) {
            l.flags &= 65011714;
            var a = l.alternate;
            return a === null ? (l.childLanes = 0, l.lanes = t, l.child = null, l.subtreeFlags = 0, l.memoizedProps = null, l.memoizedState = null, l.updateQueue = null, l.dependencies = null, l.stateNode = null) : (l.childLanes = a.childLanes, l.lanes = a.lanes, l.child = a.child, l.subtreeFlags = 0, l.deletions = null, l.memoizedProps = a.memoizedProps, l.memoizedState = a.memoizedState, l.updateQueue = a.updateQueue, l.type = a.type, t = a.dependencies, l.dependencies = t === null ? null : {
                lanes: t.lanes,
                firstContext: t.firstContext
            }), l
        }

        function Bu(l, t, a, e, u, n) {
            var i = 0;
            if (e = l, typeof l == "function") Ei(l) && (i = 1);
            else if (typeof l == "string") i = Vr(l, a, R.current) ? 26 : l === "html" || l === "head" || l === "body" ? 27 : 5;
            else l: switch (l) {
                case Ql:
                    return l = at(31, a, t, u), l.elementType = Ql, l.lanes = n, l;
                case ml:
                    return Ta(a.children, u, n, t);
                case _l:
                    i = 8, u |= 24;
                    break;
                case Z:
                    return l = at(12, a, t, u | 2), l.elementType = Z, l.lanes = n, l;
                case L:
                    return l = at(13, a, t, u), l.elementType = L, l.lanes = n, l;
                case Nl:
                    return l = at(19, a, t, u), l.elementType = Nl, l.lanes = n, l;
                default:
                    if (typeof l == "object" && l !== null) switch (l.$$typeof) {
                        case vl:
                        case K:
                            i = 10;
                            break l;
                        case il:
                            i = 9;
                            break l;
                        case gl:
                            i = 11;
                            break l;
                        case w:
                            i = 14;
                            break l;
                        case Sl:
                            i = 16, e = null;
                            break l
                    }
                    i = 29, a = Error(m(130, l === null ? "null" : typeof l, "")), e = null
            }
            return t = at(i, a, t, u), t.elementType = l, t.type = e, t.lanes = n, t
        }

        function Ta(l, t, a, e) {
            return l = at(7, l, e, t), l.lanes = a, l
        }

        function Ai(l, t, a) {
            return l = at(6, l, null, t), l.lanes = a, l
        }

        function zi(l, t, a) {
            return t = at(4, l.children !== null ? l.children : [], l.key, t), t.lanes = a, t.stateNode = {
                containerInfo: l.containerInfo,
                pendingChildren: null,
                implementation: l.implementation
            }, t
        }
        var $a = [],
            Fa = 0,
            ju = null,
            wu = 0,
            rt = [],
            ht = 0,
            Ea = null,
            Rt = 1,
            Nt = "";

        function Aa(l, t) {
            $a[Fa++] = wu, $a[Fa++] = ju, ju = l, wu = t
        }

        function Ss(l, t, a) {
            rt[ht++] = Rt, rt[ht++] = Nt, rt[ht++] = Ea, Ea = l;
            var e = Rt;
            l = Nt;
            var u = 32 - lt(e) - 1;
            e &= ~(1 << u), a += 1;
            var n = 32 - lt(t) + u;
            if (30 < n) {
                var i = u - u % 5;
                n = (e & (1 << i) - 1).toString(32), e >>= i, u -= i, Rt = 1 << 32 - lt(t) + u | a << u | e, Nt = n + l
            } else Rt = 1 << n | a << u | e, Nt = l
        }

        function Mi(l) {
            l.return !== null && (Aa(l, 1), Ss(l, 1, 0))
        }

        function _i(l) {
            for (; l === ju;) ju = $a[--Fa], $a[Fa] = null, wu = $a[--Fa], $a[Fa] = null;
            for (; l === Ea;) Ea = rt[--ht], rt[ht] = null, Nt = rt[--ht], rt[ht] = null, Rt = rt[--ht], rt[ht] = null
        }
        var Kl = null,
            El = null,
            al = !1,
            za = null,
            Tt = !1,
            xi = Error(m(519));

        function Ma(l) {
            var t = Error(m(418, ""));
            throw Be(ot(t, l)), xi
        }

        function Ts(l) {
            var t = l.stateNode,
                a = l.type,
                e = l.memoizedProps;
            switch (t[Ll] = l, t[Jl] = e, a) {
                case "dialog":
                    k("cancel", t), k("close", t);
                    break;
                case "iframe":
                case "object":
                case "embed":
                    k("load", t);
                    break;
                case "video":
                case "audio":
                    for (a = 0; a < cu.length; a++) k(cu[a], t);
                    break;
                case "source":
                    k("error", t);
                    break;
                case "img":
                case "image":
                case "link":
                    k("error", t), k("load", t);
                    break;
                case "details":
                    k("toggle", t);
                    break;
                case "input":
                    k("invalid", t), Cf(t, e.value, e.defaultValue, e.checked, e.defaultChecked, e.type, e.name, !0), Mu(t);
                    break;
                case "select":
                    k("invalid", t);
                    break;
                case "textarea":
                    k("invalid", t), jf(t, e.value, e.defaultValue, e.children), Mu(t)
            }
            a = e.children, typeof a != "string" && typeof a != "number" && typeof a != "bigint" || t.textContent === "" + a || e.suppressHydrationWarning === !0 || wo(t.textContent, a) ? (e.popover != null && (k("beforetoggle", t), k("toggle", t)), e.onScroll != null && k("scroll", t), e.onScrollEnd != null && k("scrollend", t), e.onClick != null && (t.onclick = Sn), t = !0) : t = !1, t || Ma(l)
        }

        function Es(l) {
            for (Kl = l.return; Kl;) switch (Kl.tag) {
                case 5:
                case 13:
                    Tt = !1;
                    return;
                case 27:
                case 3:
                    Tt = !0;
                    return;
                default:
                    Kl = Kl.return
            }
        }

        function Ye(l) {
            if (l !== Kl) return !1;
            if (!al) return Es(l), al = !0, !1;
            var t = l.tag,
                a;
            if ((a = t !== 3 && t !== 27) && ((a = t === 5) && (a = l.type, a = !(a !== "form" && a !== "button") || Zc(l.type, l.memoizedProps)), a = !a), a && El && Ma(l), Es(l), t === 13) {
                if (l = l.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(m(317));
                l: {
                    for (l = l.nextSibling, t = 0; l;) {
                        if (l.nodeType === 8)
                            if (a = l.data, a === "/$") {
                                if (t === 0) {
                                    El = bt(l.nextSibling);
                                    break l
                                }
                                t--
                            } else a !== "$" && a !== "$!" && a !== "$?" || t++;
                        l = l.nextSibling
                    }
                    El = null
                }
            } else t === 27 ? (t = El, fa(l.type) ? (l = Jc, Jc = null, El = l) : El = t) : El = Kl ? bt(l.stateNode.nextSibling) : null;
            return !0
        }

        function Ce() {
            El = Kl = null, al = !1
        }

        function As() {
            var l = za;
            return l !== null && (Fl === null ? Fl = l : Fl.push.apply(Fl, l), za = null), l
        }

        function Be(l) {
            za === null ? za = [l] : za.push(l)
        }
        var Oi = A(null),
            _a = null,
            Ht = null;

        function Jt(l, t, a) {
            M(Oi, t._currentValue), t._currentValue = a
        }

        function qt(l) {
            l._currentValue = Oi.current, O(Oi)
        }

        function Di(l, t, a) {
            for (; l !== null;) {
                var e = l.alternate;
                if ((l.childLanes & t) !== t ? (l.childLanes |= t, e !== null && (e.childLanes |= t)) : e !== null && (e.childLanes & t) !== t && (e.childLanes |= t), l === a) break;
                l = l.return
            }
        }

        function Ui(l, t, a, e) {
            var u = l.child;
            for (u !== null && (u.return = l); u !== null;) {
                var n = u.dependencies;
                if (n !== null) {
                    var i = u.child;
                    n = n.firstContext;
                    l: for (; n !== null;) {
                        var c = n;
                        n = u;
                        for (var f = 0; f < t.length; f++)
                            if (c.context === t[f]) {
                                n.lanes |= a, c = n.alternate, c !== null && (c.lanes |= a), Di(n.return, a, l), e || (i = null);
                                break l
                            }
                        n = c.next
                    }
                } else if (u.tag === 18) {
                    if (i = u.return, i === null) throw Error(m(341));
                    i.lanes |= a, n = i.alternate, n !== null && (n.lanes |= a), Di(i, a, l), i = null
                } else i = u.child;
                if (i !== null) i.return = u;
                else
                    for (i = u; i !== null;) {
                        if (i === l) {
                            i = null;
                            break
                        }
                        if (u = i.sibling, u !== null) {
                            u.return = i.return, i = u;
                            break
                        }
                        i = i.return
                    }
                u = i
            }
        }

        function je(l, t, a, e) {
            l = null;
            for (var u = t, n = !1; u !== null;) {
                if (!n) {
                    if ((u.flags & 524288) !== 0) n = !0;
                    else if ((u.flags & 262144) !== 0) break
                }
                if (u.tag === 10) {
                    var i = u.alternate;
                    if (i === null) throw Error(m(387));
                    if (i = i.memoizedProps, i !== null) {
                        var c = u.type;
                        tt(u.pendingProps.value, i.value) || (l !== null ? l.push(c) : l = [c])
                    }
                } else if (u === Il.current) {
                    if (i = u.alternate, i === null) throw Error(m(387));
                    i.memoizedState.memoizedState !== u.memoizedState.memoizedState && (l !== null ? l.push(hu) : l = [hu])
                }
                u = u.return
            }
            l !== null && Ui(t, l, a, e), t.flags |= 262144
        }

        function Gu(l) {
            for (l = l.firstContext; l !== null;) {
                if (!tt(l.context._currentValue, l.memoizedValue)) return !0;
                l = l.next
            }
            return !1
        }

        function xa(l) {
            _a = l, Ht = null, l = l.dependencies, l !== null && (l.firstContext = null)
        }

        function Vl(l) {
            return zs(_a, l)
        }

        function Qu(l, t) {
            return _a === null && xa(l), zs(l, t)
        }

        function zs(l, t) {
            var a = t._currentValue;
            if (t = {
                    context: t,
                    memoizedValue: a,
                    next: null
                }, Ht === null) {
                if (l === null) throw Error(m(308));
                Ht = t, l.dependencies = {
                    lanes: 0,
                    firstContext: t
                }, l.flags |= 524288
            } else Ht = Ht.next = t;
            return a
        }
        var Ld = typeof AbortController < "u" ? AbortController : function() {
                var l = [],
                    t = this.signal = {
                        aborted: !1,
                        addEventListener: function(a, e) {
                            l.push(e)
                        }
                    };
                this.abort = function() {
                    t.aborted = !0, l.forEach(function(a) {
                        return a()
                    })
                }
            },
            Vd = p.unstable_scheduleCallback,
            Kd = p.unstable_NormalPriority,
            Dl = {
                $$typeof: K,
                Consumer: null,
                Provider: null,
                _currentValue: null,
                _currentValue2: null,
                _threadCount: 0
            };

        function Ri() {
            return {
                controller: new Ld,
                data: new Map,
                refCount: 0
            }
        }

        function we(l) {
            l.refCount--, l.refCount === 0 && Vd(Kd, function() {
                l.controller.abort()
            })
        }
        var Ge = null,
            Ni = 0,
            Ia = 0,
            Pa = null;

        function Jd(l, t) {
            if (Ge === null) {
                var a = Ge = [];
                Ni = 0, Ia = qc(), Pa = {
                    status: "pending",
                    value: void 0,
                    then: function(e) {
                        a.push(e)
                    }
                }
            }
            return Ni++, t.then(Ms, Ms), t
        }

        function Ms() {
            if (--Ni === 0 && Ge !== null) {
                Pa !== null && (Pa.status = "fulfilled");
                var l = Ge;
                Ge = null, Ia = 0, Pa = null;
                for (var t = 0; t < l.length; t++)(0, l[t])()
            }
        }

        function kd(l, t) {
            var a = [],
                e = {
                    status: "pending",
                    value: null,
                    reason: null,
                    then: function(u) {
                        a.push(u)
                    }
                };
            return l.then(function() {
                e.status = "fulfilled", e.value = t;
                for (var u = 0; u < a.length; u++)(0, a[u])(t)
            }, function(u) {
                for (e.status = "rejected", e.reason = u, u = 0; u < a.length; u++)(0, a[u])(void 0)
            }), e
        }
        var _s = b.S;
        b.S = function(l, t) {
            typeof t == "object" && t !== null && typeof t.then == "function" && Jd(l, t), _s !== null && _s(l, t)
        };
        var Oa = A(null);

        function Hi() {
            var l = Oa.current;
            return l !== null ? l : yl.pooledCache
        }

        function Xu(l, t) {
            t === null ? M(Oa, Oa.current) : M(Oa, t.pool)
        }

        function xs() {
            var l = Hi();
            return l === null ? null : {
                parent: Dl._currentValue,
                pool: l
            }
        }
        var Qe = Error(m(460)),
            Os = Error(m(474)),
            Zu = Error(m(542)),
            qi = {
                then: function() {}
            };

        function Ds(l) {
            return l = l.status, l === "fulfilled" || l === "rejected"
        }

        function Lu() {}

        function Us(l, t, a) {
            switch (a = l[a], a === void 0 ? l.push(t) : a !== t && (t.then(Lu, Lu), t = a), t.status) {
                case "fulfilled":
                    return t.value;
                case "rejected":
                    throw l = t.reason, Ns(l), l;
                default:
                    if (typeof t.status == "string") t.then(Lu, Lu);
                    else {
                        if (l = yl, l !== null && 100 < l.shellSuspendCounter) throw Error(m(482));
                        l = t, l.status = "pending", l.then(function(e) {
                            if (t.status === "pending") {
                                var u = t;
                                u.status = "fulfilled", u.value = e
                            }
                        }, function(e) {
                            if (t.status === "pending") {
                                var u = t;
                                u.status = "rejected", u.reason = e
                            }
                        })
                    }
                    switch (t.status) {
                        case "fulfilled":
                            return t.value;
                        case "rejected":
                            throw l = t.reason, Ns(l), l
                    }
                    throw Xe = t, Qe
            }
        }
        var Xe = null;

        function Rs() {
            if (Xe === null) throw Error(m(459));
            var l = Xe;
            return Xe = null, l
        }

        function Ns(l) {
            if (l === Qe || l === Zu) throw Error(m(483))
        }
        var kt = !1;

        function Yi(l) {
            l.updateQueue = {
                baseState: l.memoizedState,
                firstBaseUpdate: null,
                lastBaseUpdate: null,
                shared: {
                    pending: null,
                    lanes: 0,
                    hiddenCallbacks: null
                },
                callbacks: null
            }
        }

        function Ci(l, t) {
            l = l.updateQueue, t.updateQueue === l && (t.updateQueue = {
                baseState: l.baseState,
                firstBaseUpdate: l.firstBaseUpdate,
                lastBaseUpdate: l.lastBaseUpdate,
                shared: l.shared,
                callbacks: null
            })
        }

        function Wt(l) {
            return {
                lane: l,
                tag: 0,
                payload: null,
                callback: null,
                next: null
            }
        }

        function $t(l, t, a) {
            var e = l.updateQueue;
            if (e === null) return null;
            if (e = e.shared, (cl & 2) !== 0) {
                var u = e.pending;
                return u === null ? t.next = t : (t.next = u.next, u.next = t), e.pending = t, t = Cu(l), ps(l, null, a), t
            }
            return Yu(l, e, t, a), Cu(l)
        }

        function Ze(l, t, a) {
            if (t = t.updateQueue, t !== null && (t = t.shared, (a & 4194048) !== 0)) {
                var e = t.lanes;
                e &= l.pendingLanes, a |= e, t.lanes = a, Mf(l, a)
            }
        }

        function Bi(l, t) {
            var a = l.updateQueue,
                e = l.alternate;
            if (e !== null && (e = e.updateQueue, a === e)) {
                var u = null,
                    n = null;
                if (a = a.firstBaseUpdate, a !== null) {
                    do {
                        var i = {
                            lane: a.lane,
                            tag: a.tag,
                            payload: a.payload,
                            callback: null,
                            next: null
                        };
                        n === null ? u = n = i : n = n.next = i, a = a.next
                    } while (a !== null);
                    n === null ? u = n = t : n = n.next = t
                } else u = n = t;
                a = {
                    baseState: e.baseState,
                    firstBaseUpdate: u,
                    lastBaseUpdate: n,
                    shared: e.shared,
                    callbacks: e.callbacks
                }, l.updateQueue = a;
                return
            }
            l = a.lastBaseUpdate, l === null ? a.firstBaseUpdate = t : l.next = t, a.lastBaseUpdate = t
        }
        var ji = !1;

        function Le() {
            if (ji) {
                var l = Pa;
                if (l !== null) throw l
            }
        }

        function Ve(l, t, a, e) {
            ji = !1;
            var u = l.updateQueue;
            kt = !1;
            var n = u.firstBaseUpdate,
                i = u.lastBaseUpdate,
                c = u.shared.pending;
            if (c !== null) {
                u.shared.pending = null;
                var f = c,
                    h = f.next;
                f.next = null, i === null ? n = h : i.next = h, i = f;
                var g = l.alternate;
                g !== null && (g = g.updateQueue, c = g.lastBaseUpdate, c !== i && (c === null ? g.firstBaseUpdate = h : c.next = h, g.lastBaseUpdate = f))
            }
            if (n !== null) {
                var E = u.baseState;
                i = 0, g = h = f = null, c = n;
                do {
                    var v = c.lane & -536870913,
                        y = v !== c.lane;
                    if (y ? (I & v) === v : (e & v) === v) {
                        v !== 0 && v === Ia && (ji = !0), g !== null && (g = g.next = {
                            lane: 0,
                            tag: c.tag,
                            payload: c.payload,
                            callback: null,
                            next: null
                        });
                        l: {
                            var Y = l,
                                N = c;v = t;
                            var dl = a;
                            switch (N.tag) {
                                case 1:
                                    if (Y = N.payload, typeof Y == "function") {
                                        E = Y.call(dl, E, v);
                                        break l
                                    }
                                    E = Y;
                                    break l;
                                case 3:
                                    Y.flags = Y.flags & -65537 | 128;
                                case 0:
                                    if (Y = N.payload, v = typeof Y == "function" ? Y.call(dl, E, v) : Y, v == null) break l;
                                    E = z({}, E, v);
                                    break l;
                                case 2:
                                    kt = !0
                            }
                        }
                        v = c.callback, v !== null && (l.flags |= 64, y && (l.flags |= 8192), y = u.callbacks, y === null ? u.callbacks = [v] : y.push(v))
                    } else y = {
                        lane: v,
                        tag: c.tag,
                        payload: c.payload,
                        callback: c.callback,
                        next: null
                    }, g === null ? (h = g = y, f = E) : g = g.next = y, i |= v;
                    if (c = c.next, c === null) {
                        if (c = u.shared.pending, c === null) break;
                        y = c, c = y.next, y.next = null, u.lastBaseUpdate = y, u.shared.pending = null
                    }
                } while (!0);
                g === null && (f = E), u.baseState = f, u.firstBaseUpdate = h, u.lastBaseUpdate = g, n === null && (u.shared.lanes = 0), ua |= i, l.lanes = i, l.memoizedState = E
            }
        }

        function Hs(l, t) {
            if (typeof l != "function") throw Error(m(191, l));
            l.call(t)
        }

        function qs(l, t) {
            var a = l.callbacks;
            if (a !== null)
                for (l.callbacks = null, l = 0; l < a.length; l++) Hs(a[l], t)
        }
        var le = A(null),
            Vu = A(0);

        function Ys(l, t) {
            l = Qt, M(Vu, l), M(le, t), Qt = l | t.baseLanes
        }

        function wi() {
            M(Vu, Qt), M(le, le.current)
        }

        function Gi() {
            Qt = Vu.current, O(le), O(Vu)
        }
        var Ft = 0,
            G = null,
            sl = null,
            xl = null,
            Ku = !1,
            te = !1,
            Da = !1,
            Ju = 0,
            Ke = 0,
            ae = null,
            Wd = 0;

        function zl() {
            throw Error(m(321))
        }

        function Qi(l, t) {
            if (t === null) return !1;
            for (var a = 0; a < t.length && a < l.length; a++)
                if (!tt(l[a], t[a])) return !1;
            return !0
        }

        function Xi(l, t, a, e, u, n) {
            return Ft = n, G = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, b.H = l === null || l.memoizedState === null ? p0 : b0, Da = !1, n = a(e, u), Da = !1, te && (n = Bs(t, a, e, u)), Cs(l), n
        }

        function Cs(l) {
            b.H = Pu;
            var t = sl !== null && sl.next !== null;
            if (Ft = 0, xl = sl = G = null, Ku = !1, Ke = 0, ae = null, t) throw Error(m(300));
            l === null || ql || (l = l.dependencies, l !== null && Gu(l) && (ql = !0))
        }

        function Bs(l, t, a, e) {
            G = l;
            var u = 0;
            do {
                if (te && (ae = null), Ke = 0, te = !1, 25 <= u) throw Error(m(301));
                if (u += 1, xl = sl = null, l.updateQueue != null) {
                    var n = l.updateQueue;
                    n.lastEffect = null, n.events = null, n.stores = null, n.memoCache != null && (n.memoCache.index = 0)
                }
                b.H = ar, n = t(a, e)
            } while (te);
            return n
        }

        function $d() {
            var l = b.H,
                t = l.useState()[0];
            return t = typeof t.then == "function" ? Je(t) : t, l = l.useState()[0], (sl !== null ? sl.memoizedState : null) !== l && (G.flags |= 1024), t
        }

        function Zi() {
            var l = Ju !== 0;
            return Ju = 0, l
        }

        function Li(l, t, a) {
            t.updateQueue = l.updateQueue, t.flags &= -2053, l.lanes &= ~a
        }

        function Vi(l) {
            if (Ku) {
                for (l = l.memoizedState; l !== null;) {
                    var t = l.queue;
                    t !== null && (t.pending = null), l = l.next
                }
                Ku = !1
            }
            Ft = 0, xl = sl = G = null, te = !1, Ke = Ju = 0, ae = null
        }

        function Wl() {
            var l = {
                memoizedState: null,
                baseState: null,
                baseQueue: null,
                queue: null,
                next: null
            };
            return xl === null ? G.memoizedState = xl = l : xl = xl.next = l, xl
        }

        function Ol() {
            if (sl === null) {
                var l = G.alternate;
                l = l !== null ? l.memoizedState : null
            } else l = sl.next;
            var t = xl === null ? G.memoizedState : xl.next;
            if (t !== null) xl = t, sl = l;
            else {
                if (l === null) throw G.alternate === null ? Error(m(467)) : Error(m(310));
                sl = l, l = {
                    memoizedState: sl.memoizedState,
                    baseState: sl.baseState,
                    baseQueue: sl.baseQueue,
                    queue: sl.queue,
                    next: null
                }, xl === null ? G.memoizedState = xl = l : xl = xl.next = l
            }
            return xl
        }

        function Ki() {
            return {
                lastEffect: null,
                events: null,
                stores: null,
                memoCache: null
            }
        }

        function Je(l) {
            var t = Ke;
            return Ke += 1, ae === null && (ae = []), l = Us(ae, l, t), t = G, (xl === null ? t.memoizedState : xl.next) === null && (t = t.alternate, b.H = t === null || t.memoizedState === null ? p0 : b0), l
        }

        function ku(l) {
            if (l !== null && typeof l == "object") {
                if (typeof l.then == "function") return Je(l);
                if (l.$$typeof === K) return Vl(l)
            }
            throw Error(m(438, String(l)))
        }

        function Ji(l) {
            var t = null,
                a = G.updateQueue;
            if (a !== null && (t = a.memoCache), t == null) {
                var e = G.alternate;
                e !== null && (e = e.updateQueue, e !== null && (e = e.memoCache, e != null && (t = {
                    data: e.data.map(function(u) {
                        return u.slice()
                    }),
                    index: 0
                })))
            }
            if (t == null && (t = {
                    data: [],
                    index: 0
                }), a === null && (a = Ki(), G.updateQueue = a), a.memoCache = t, a = t.data[t.index], a === void 0)
                for (a = t.data[t.index] = Array(l), e = 0; e < l; e++) a[e] = _t;
            return t.index++, a
        }

        function Yt(l, t) {
            return typeof t == "function" ? t(l) : t
        }

        function Wu(l) {
            var t = Ol();
            return ki(t, sl, l)
        }

        function ki(l, t, a) {
            var e = l.queue;
            if (e === null) throw Error(m(311));
            e.lastRenderedReducer = a;
            var u = l.baseQueue,
                n = e.pending;
            if (n !== null) {
                if (u !== null) {
                    var i = u.next;
                    u.next = n.next, n.next = i
                }
                t.baseQueue = u = n, e.pending = null
            }
            if (n = l.baseState, u === null) l.memoizedState = n;
            else {
                t = u.next;
                var c = i = null,
                    f = null,
                    h = t,
                    g = !1;
                do {
                    var E = h.lane & -536870913;
                    if (E !== h.lane ? (I & E) === E : (Ft & E) === E) {
                        var v = h.revertLane;
                        if (v === 0) f !== null && (f = f.next = {
                            lane: 0,
                            revertLane: 0,
                            action: h.action,
                            hasEagerState: h.hasEagerState,
                            eagerState: h.eagerState,
                            next: null
                        }), E === Ia && (g = !0);
                        else if ((Ft & v) === v) {
                            h = h.next, v === Ia && (g = !0);
                            continue
                        } else E = {
                            lane: 0,
                            revertLane: h.revertLane,
                            action: h.action,
                            hasEagerState: h.hasEagerState,
                            eagerState: h.eagerState,
                            next: null
                        }, f === null ? (c = f = E, i = n) : f = f.next = E, G.lanes |= v, ua |= v;
                        E = h.action, Da && a(n, E), n = h.hasEagerState ? h.eagerState : a(n, E)
                    } else v = {
                        lane: E,
                        revertLane: h.revertLane,
                        action: h.action,
                        hasEagerState: h.hasEagerState,
                        eagerState: h.eagerState,
                        next: null
                    }, f === null ? (c = f = v, i = n) : f = f.next = v, G.lanes |= E, ua |= E;
                    h = h.next
                } while (h !== null && h !== t);
                if (f === null ? i = n : f.next = c, !tt(n, l.memoizedState) && (ql = !0, g && (a = Pa, a !== null))) throw a;
                l.memoizedState = n, l.baseState = i, l.baseQueue = f, e.lastRenderedState = n
            }
            return u === null && (e.lanes = 0), [l.memoizedState, e.dispatch]
        }

        function Wi(l) {
            var t = Ol(),
                a = t.queue;
            if (a === null) throw Error(m(311));
            a.lastRenderedReducer = l;
            var e = a.dispatch,
                u = a.pending,
                n = t.memoizedState;
            if (u !== null) {
                a.pending = null;
                var i = u = u.next;
                do n = l(n, i.action), i = i.next; while (i !== u);
                tt(n, t.memoizedState) || (ql = !0), t.memoizedState = n, t.baseQueue === null && (t.baseState = n), a.lastRenderedState = n
            }
            return [n, e]
        }

        function js(l, t, a) {
            var e = G,
                u = Ol(),
                n = al;
            if (n) {
                if (a === void 0) throw Error(m(407));
                a = a()
            } else a = t();
            var i = !tt((sl || u).memoizedState, a);
            i && (u.memoizedState = a, ql = !0), u = u.queue;
            var c = Qs.bind(null, e, u, l);
            if (ke(2048, 8, c, [l]), u.getSnapshot !== t || i || xl !== null && xl.memoizedState.tag & 1) {
                if (e.flags |= 2048, ee(9, $u(), Gs.bind(null, e, u, a, t), null), yl === null) throw Error(m(349));
                n || (Ft & 124) !== 0 || ws(e, t, a)
            }
            return a
        }

        function ws(l, t, a) {
            l.flags |= 16384, l = {
                getSnapshot: t,
                value: a
            }, t = G.updateQueue, t === null ? (t = Ki(), G.updateQueue = t, t.stores = [l]) : (a = t.stores, a === null ? t.stores = [l] : a.push(l))
        }

        function Gs(l, t, a, e) {
            t.value = a, t.getSnapshot = e, Xs(t) && Zs(l)
        }

        function Qs(l, t, a) {
            return a(function() {
                Xs(t) && Zs(l)
            })
        }

        function Xs(l) {
            var t = l.getSnapshot;
            l = l.value;
            try {
                var a = t();
                return !tt(l, a)
            } catch {
                return !0
            }
        }

        function Zs(l) {
            var t = ka(l, 2);
            t !== null && ct(t, l, 2)
        }

        function $i(l) {
            var t = Wl();
            if (typeof l == "function") {
                var a = l;
                if (l = a(), Da) {
                    Lt(!0);
                    try {
                        a()
                    } finally {
                        Lt(!1)
                    }
                }
            }
            return t.memoizedState = t.baseState = l, t.queue = {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: Yt,
                lastRenderedState: l
            }, t
        }

        function Ls(l, t, a, e) {
            return l.baseState = a, ki(l, sl, typeof e == "function" ? e : Yt)
        }

        function Fd(l, t, a, e, u) {
            if (Iu(l)) throw Error(m(485));
            if (l = t.action, l !== null) {
                var n = {
                    payload: u,
                    action: l,
                    next: null,
                    isTransition: !0,
                    status: "pending",
                    value: null,
                    reason: null,
                    listeners: [],
                    then: function(i) {
                        n.listeners.push(i)
                    }
                };
                b.T !== null ? a(!0) : n.isTransition = !1, e(n), a = t.pending, a === null ? (n.next = t.pending = n, Vs(t, n)) : (n.next = a.next, t.pending = a.next = n)
            }
        }

        function Vs(l, t) {
            var a = t.action,
                e = t.payload,
                u = l.state;
            if (t.isTransition) {
                var n = b.T,
                    i = {};
                b.T = i;
                try {
                    var c = a(u, e),
                        f = b.S;
                    f !== null && f(i, c), Ks(l, t, c)
                } catch (h) {
                    Fi(l, t, h)
                } finally {
                    b.T = n
                }
            } else try {
                n = a(u, e), Ks(l, t, n)
            } catch (h) {
                Fi(l, t, h)
            }
        }

        function Ks(l, t, a) {
            a !== null && typeof a == "object" && typeof a.then == "function" ? a.then(function(e) {
                Js(l, t, e)
            }, function(e) {
                return Fi(l, t, e)
            }) : Js(l, t, a)
        }

        function Js(l, t, a) {
            t.status = "fulfilled", t.value = a, ks(t), l.state = a, t = l.pending, t !== null && (a = t.next, a === t ? l.pending = null : (a = a.next, t.next = a, Vs(l, a)))
        }

        function Fi(l, t, a) {
            var e = l.pending;
            if (l.pending = null, e !== null) {
                e = e.next;
                do t.status = "rejected", t.reason = a, ks(t), t = t.next; while (t !== e)
            }
            l.action = null
        }

        function ks(l) {
            l = l.listeners;
            for (var t = 0; t < l.length; t++)(0, l[t])()
        }

        function Ws(l, t) {
            return t
        }

        function $s(l, t) {
            if (al) {
                var a = yl.formState;
                if (a !== null) {
                    l: {
                        var e = G;
                        if (al) {
                            if (El) {
                                t: {
                                    for (var u = El, n = Tt; u.nodeType !== 8;) {
                                        if (!n) {
                                            u = null;
                                            break t
                                        }
                                        if (u = bt(u.nextSibling), u === null) {
                                            u = null;
                                            break t
                                        }
                                    }
                                    n = u.data,
                                    u = n === "F!" || n === "F" ? u : null
                                }
                                if (u) {
                                    El = bt(u.nextSibling), e = u.data === "F!";
                                    break l
                                }
                            }
                            Ma(e)
                        }
                        e = !1
                    }
                    e && (t = a[0])
                }
            }
            return a = Wl(), a.memoizedState = a.baseState = t, e = {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: Ws,
                lastRenderedState: t
            }, a.queue = e, a = y0.bind(null, G, e), e.dispatch = a, e = $i(!1), n = ac.bind(null, G, !1, e.queue), e = Wl(), u = {
                state: t,
                dispatch: null,
                action: l,
                pending: null
            }, e.queue = u, a = Fd.bind(null, G, u, n, a), u.dispatch = a, e.memoizedState = l, [t, a, !1]
        }

        function Fs(l) {
            var t = Ol();
            return Is(t, sl, l)
        }

        function Is(l, t, a) {
            if (t = ki(l, t, Ws)[0], l = Wu(Yt)[0], typeof t == "object" && t !== null && typeof t.then == "function") try {
                var e = Je(t)
            } catch (i) {
                throw i === Qe ? Zu : i
            } else e = t;
            t = Ol();
            var u = t.queue,
                n = u.dispatch;
            return a !== t.memoizedState && (G.flags |= 2048, ee(9, $u(), Id.bind(null, u, a), null)), [e, n, l]
        }

        function Id(l, t) {
            l.action = t
        }

        function Ps(l) {
            var t = Ol(),
                a = sl;
            if (a !== null) return Is(t, a, l);
            Ol(), t = t.memoizedState, a = Ol();
            var e = a.queue.dispatch;
            return a.memoizedState = l, [t, e, !1]
        }

        function ee(l, t, a, e) {
            return l = {
                tag: l,
                create: a,
                deps: e,
                inst: t,
                next: null
            }, t = G.updateQueue, t === null && (t = Ki(), G.updateQueue = t), a = t.lastEffect, a === null ? t.lastEffect = l.next = l : (e = a.next, a.next = l, l.next = e, t.lastEffect = l), l
        }

        function $u() {
            return {
                destroy: void 0,
                resource: void 0
            }
        }

        function l0() {
            return Ol().memoizedState
        }

        function Fu(l, t, a, e) {
            var u = Wl();
            e = e === void 0 ? null : e, G.flags |= l, u.memoizedState = ee(1 | t, $u(), a, e)
        }

        function ke(l, t, a, e) {
            var u = Ol();
            e = e === void 0 ? null : e;
            var n = u.memoizedState.inst;
            sl !== null && e !== null && Qi(e, sl.memoizedState.deps) ? u.memoizedState = ee(t, n, a, e) : (G.flags |= l, u.memoizedState = ee(1 | t, n, a, e))
        }

        function t0(l, t) {
            Fu(8390656, 8, l, t)
        }

        function a0(l, t) {
            ke(2048, 8, l, t)
        }

        function e0(l, t) {
            return ke(4, 2, l, t)
        }

        function u0(l, t) {
            return ke(4, 4, l, t)
        }

        function n0(l, t) {
            if (typeof t == "function") {
                l = l();
                var a = t(l);
                return function() {
                    typeof a == "function" ? a() : t(null)
                }
            }
            if (t != null) return l = l(), t.current = l,
                function() {
                    t.current = null
                }
        }

        function i0(l, t, a) {
            a = a != null ? a.concat([l]) : null, ke(4, 4, n0.bind(null, t, l), a)
        }

        function Ii() {}

        function c0(l, t) {
            var a = Ol();
            t = t === void 0 ? null : t;
            var e = a.memoizedState;
            return t !== null && Qi(t, e[1]) ? e[0] : (a.memoizedState = [l, t], l)
        }

        function f0(l, t) {
            var a = Ol();
            t = t === void 0 ? null : t;
            var e = a.memoizedState;
            if (t !== null && Qi(t, e[1])) return e[0];
            if (e = l(), Da) {
                Lt(!0);
                try {
                    l()
                } finally {
                    Lt(!1)
                }
            }
            return a.memoizedState = [e, t], e
        }

        function Pi(l, t, a) {
            return a === void 0 || (Ft & 1073741824) !== 0 ? l.memoizedState = t : (l.memoizedState = a, l = ro(), G.lanes |= l, ua |= l, a)
        }

        function s0(l, t, a, e) {
            return tt(a, t) ? a : le.current !== null ? (l = Pi(l, a, e), tt(l, t) || (ql = !0), l) : (Ft & 42) === 0 ? (ql = !0, l.memoizedState = a) : (l = ro(), G.lanes |= l, ua |= l, t)
        }

        function o0(l, t, a, e, u) {
            var n = _.p;
            _.p = n !== 0 && 8 > n ? n : 8;
            var i = b.T,
                c = {};
            b.T = c, ac(l, !1, t, a);
            try {
                var f = u(),
                    h = b.S;
                if (h !== null && h(c, f), f !== null && typeof f == "object" && typeof f.then == "function") {
                    var g = kd(f, e);
                    We(l, t, g, it(l))
                } else We(l, t, e, it(l))
            } catch (E) {
                We(l, t, {
                    then: function() {},
                    status: "rejected",
                    reason: E
                }, it())
            } finally {
                _.p = n, b.T = i
            }
        }

        function Pd() {}

        function lc(l, t, a, e) {
            if (l.tag !== 5) throw Error(m(476));
            var u = d0(l).queue;
            o0(l, u, t, q, a === null ? Pd : function() {
                return r0(l), a(e)
            })
        }

        function d0(l) {
            var t = l.memoizedState;
            if (t !== null) return t;
            t = {
                memoizedState: q,
                baseState: q,
                baseQueue: null,
                queue: {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: Yt,
                    lastRenderedState: q
                },
                next: null
            };
            var a = {};
            return t.next = {
                memoizedState: a,
                baseState: a,
                baseQueue: null,
                queue: {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: Yt,
                    lastRenderedState: a
                },
                next: null
            }, l.memoizedState = t, l = l.alternate, l !== null && (l.memoizedState = t), t
        }

        function r0(l) {
            var t = d0(l).next.queue;
            We(l, t, {}, it())
        }

        function tc() {
            return Vl(hu)
        }

        function h0() {
            return Ol().memoizedState
        }

        function v0() {
            return Ol().memoizedState
        }

        function lr(l) {
            for (var t = l.return; t !== null;) {
                switch (t.tag) {
                    case 24:
                    case 3:
                        var a = it();
                        l = Wt(a);
                        var e = $t(t, l, a);
                        e !== null && (ct(e, t, a), Ze(e, t, a)), t = {
                            cache: Ri()
                        }, l.payload = t;
                        return
                }
                t = t.return
            }
        }

        function tr(l, t, a) {
            var e = it();
            a = {
                lane: e,
                revertLane: 0,
                action: a,
                hasEagerState: !1,
                eagerState: null,
                next: null
            }, Iu(l) ? m0(t, a) : (a = Ti(l, t, a, e), a !== null && (ct(a, l, e), g0(a, t, e)))
        }

        function y0(l, t, a) {
            var e = it();
            We(l, t, a, e)
        }

        function We(l, t, a, e) {
            var u = {
                lane: e,
                revertLane: 0,
                action: a,
                hasEagerState: !1,
                eagerState: null,
                next: null
            };
            if (Iu(l)) m0(t, u);
            else {
                var n = l.alternate;
                if (l.lanes === 0 && (n === null || n.lanes === 0) && (n = t.lastRenderedReducer, n !== null)) try {
                    var i = t.lastRenderedState,
                        c = n(i, a);
                    if (u.hasEagerState = !0, u.eagerState = c, tt(c, i)) return Yu(l, t, u, 0), yl === null && qu(), !1
                } catch {} finally {}
                if (a = Ti(l, t, u, e), a !== null) return ct(a, l, e), g0(a, t, e), !0
            }
            return !1
        }

        function ac(l, t, a, e) {
            if (e = {
                    lane: 2,
                    revertLane: qc(),
                    action: e,
                    hasEagerState: !1,
                    eagerState: null,
                    next: null
                }, Iu(l)) {
                if (t) throw Error(m(479))
            } else t = Ti(l, a, e, 2), t !== null && ct(t, l, 2)
        }

        function Iu(l) {
            var t = l.alternate;
            return l === G || t !== null && t === G
        }

        function m0(l, t) {
            te = Ku = !0;
            var a = l.pending;
            a === null ? t.next = t : (t.next = a.next, a.next = t), l.pending = t
        }

        function g0(l, t, a) {
            if ((a & 4194048) !== 0) {
                var e = t.lanes;
                e &= l.pendingLanes, a |= e, t.lanes = a, Mf(l, a)
            }
        }
        var Pu = {
                readContext: Vl,
                use: ku,
                useCallback: zl,
                useContext: zl,
                useEffect: zl,
                useImperativeHandle: zl,
                useLayoutEffect: zl,
                useInsertionEffect: zl,
                useMemo: zl,
                useReducer: zl,
                useRef: zl,
                useState: zl,
                useDebugValue: zl,
                useDeferredValue: zl,
                useTransition: zl,
                useSyncExternalStore: zl,
                useId: zl,
                useHostTransitionStatus: zl,
                useFormState: zl,
                useActionState: zl,
                useOptimistic: zl,
                useMemoCache: zl,
                useCacheRefresh: zl
            },
            p0 = {
                readContext: Vl,
                use: ku,
                useCallback: function(l, t) {
                    return Wl().memoizedState = [l, t === void 0 ? null : t], l
                },
                useContext: Vl,
                useEffect: t0,
                useImperativeHandle: function(l, t, a) {
                    a = a != null ? a.concat([l]) : null, Fu(4194308, 4, n0.bind(null, t, l), a)
                },
                useLayoutEffect: function(l, t) {
                    return Fu(4194308, 4, l, t)
                },
                useInsertionEffect: function(l, t) {
                    Fu(4, 2, l, t)
                },
                useMemo: function(l, t) {
                    var a = Wl();
                    t = t === void 0 ? null : t;
                    var e = l();
                    if (Da) {
                        Lt(!0);
                        try {
                            l()
                        } finally {
                            Lt(!1)
                        }
                    }
                    return a.memoizedState = [e, t], e
                },
                useReducer: function(l, t, a) {
                    var e = Wl();
                    if (a !== void 0) {
                        var u = a(t);
                        if (Da) {
                            Lt(!0);
                            try {
                                a(t)
                            } finally {
                                Lt(!1)
                            }
                        }
                    } else u = t;
                    return e.memoizedState = e.baseState = u, l = {
                        pending: null,
                        lanes: 0,
                        dispatch: null,
                        lastRenderedReducer: l,
                        lastRenderedState: u
                    }, e.queue = l, l = l.dispatch = tr.bind(null, G, l), [e.memoizedState, l]
                },
                useRef: function(l) {
                    var t = Wl();
                    return l = {
                        current: l
                    }, t.memoizedState = l
                },
                useState: function(l) {
                    l = $i(l);
                    var t = l.queue,
                        a = y0.bind(null, G, t);
                    return t.dispatch = a, [l.memoizedState, a]
                },
                useDebugValue: Ii,
                useDeferredValue: function(l, t) {
                    var a = Wl();
                    return Pi(a, l, t)
                },
                useTransition: function() {
                    var l = $i(!1);
                    return l = o0.bind(null, G, l.queue, !0, !1), Wl().memoizedState = l, [!1, l]
                },
                useSyncExternalStore: function(l, t, a) {
                    var e = G,
                        u = Wl();
                    if (al) {
                        if (a === void 0) throw Error(m(407));
                        a = a()
                    } else {
                        if (a = t(), yl === null) throw Error(m(349));
                        (I & 124) !== 0 || ws(e, t, a)
                    }
                    u.memoizedState = a;
                    var n = {
                        value: a,
                        getSnapshot: t
                    };
                    return u.queue = n, t0(Qs.bind(null, e, n, l), [l]), e.flags |= 2048, ee(9, $u(), Gs.bind(null, e, n, a, t), null), a
                },
                useId: function() {
                    var l = Wl(),
                        t = yl.identifierPrefix;
                    if (al) {
                        var a = Nt,
                            e = Rt;
                        a = (e & ~(1 << 32 - lt(e) - 1)).toString(32) + a, t = "«" + t + "R" + a, a = Ju++, 0 < a && (t += "H" + a.toString(32)), t += "»"
                    } else a = Wd++, t = "«" + t + "r" + a.toString(32) + "»";
                    return l.memoizedState = t
                },
                useHostTransitionStatus: tc,
                useFormState: $s,
                useActionState: $s,
                useOptimistic: function(l) {
                    var t = Wl();
                    t.memoizedState = t.baseState = l;
                    var a = {
                        pending: null,
                        lanes: 0,
                        dispatch: null,
                        lastRenderedReducer: null,
                        lastRenderedState: null
                    };
                    return t.queue = a, t = ac.bind(null, G, !0, a), a.dispatch = t, [l, t]
                },
                useMemoCache: Ji,
                useCacheRefresh: function() {
                    return Wl().memoizedState = lr.bind(null, G)
                }
            },
            b0 = {
                readContext: Vl,
                use: ku,
                useCallback: c0,
                useContext: Vl,
                useEffect: a0,
                useImperativeHandle: i0,
                useInsertionEffect: e0,
                useLayoutEffect: u0,
                useMemo: f0,
                useReducer: Wu,
                useRef: l0,
                useState: function() {
                    return Wu(Yt)
                },
                useDebugValue: Ii,
                useDeferredValue: function(l, t) {
                    var a = Ol();
                    return s0(a, sl.memoizedState, l, t)
                },
                useTransition: function() {
                    var l = Wu(Yt)[0],
                        t = Ol().memoizedState;
                    return [typeof l == "boolean" ? l : Je(l), t]
                },
                useSyncExternalStore: js,
                useId: h0,
                useHostTransitionStatus: tc,
                useFormState: Fs,
                useActionState: Fs,
                useOptimistic: function(l, t) {
                    var a = Ol();
                    return Ls(a, sl, l, t)
                },
                useMemoCache: Ji,
                useCacheRefresh: v0
            },
            ar = {
                readContext: Vl,
                use: ku,
                useCallback: c0,
                useContext: Vl,
                useEffect: a0,
                useImperativeHandle: i0,
                useInsertionEffect: e0,
                useLayoutEffect: u0,
                useMemo: f0,
                useReducer: Wi,
                useRef: l0,
                useState: function() {
                    return Wi(Yt)
                },
                useDebugValue: Ii,
                useDeferredValue: function(l, t) {
                    var a = Ol();
                    return sl === null ? Pi(a, l, t) : s0(a, sl.memoizedState, l, t)
                },
                useTransition: function() {
                    var l = Wi(Yt)[0],
                        t = Ol().memoizedState;
                    return [typeof l == "boolean" ? l : Je(l), t]
                },
                useSyncExternalStore: js,
                useId: h0,
                useHostTransitionStatus: tc,
                useFormState: Ps,
                useActionState: Ps,
                useOptimistic: function(l, t) {
                    var a = Ol();
                    return sl !== null ? Ls(a, sl, l, t) : (a.baseState = l, [l, a.queue.dispatch])
                },
                useMemoCache: Ji,
                useCacheRefresh: v0
            },
            ue = null,
            $e = 0;

        function ln(l) {
            var t = $e;
            return $e += 1, ue === null && (ue = []), Us(ue, l, t)
        }

        function Fe(l, t) {
            t = t.props.ref, l.ref = t !== void 0 ? t : null
        }

        function tn(l, t) {
            throw t.$$typeof === Q ? Error(m(525)) : (l = Object.prototype.toString.call(t), Error(m(31, l === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : l)))
        }

        function S0(l) {
            var t = l._init;
            return t(l._payload)
        }

        function T0(l) {
            function t(d, o) {
                if (l) {
                    var r = d.deletions;
                    r === null ? (d.deletions = [o], d.flags |= 16) : r.push(o)
                }
            }

            function a(d, o) {
                if (!l) return null;
                for (; o !== null;) t(d, o), o = o.sibling;
                return null
            }

            function e(d) {
                for (var o = new Map; d !== null;) d.key !== null ? o.set(d.key, d) : o.set(d.index, d), d = d.sibling;
                return o
            }

            function u(d, o) {
                return d = Ut(d, o), d.index = 0, d.sibling = null, d
            }

            function n(d, o, r) {
                return d.index = r, l ? (r = d.alternate, r !== null ? (r = r.index, r < o ? (d.flags |= 67108866, o) : r) : (d.flags |= 67108866, o)) : (d.flags |= 1048576, o)
            }

            function i(d) {
                return l && d.alternate === null && (d.flags |= 67108866), d
            }

            function c(d, o, r, S) {
                return o === null || o.tag !== 6 ? (o = Ai(r, d.mode, S), o.return = d, o) : (o = u(o, r), o.return = d, o)
            }

            function f(d, o, r, S) {
                var D = r.type;
                return D === ml ? g(d, o, r.props.children, S, r.key) : o !== null && (o.elementType === D || typeof D == "object" && D !== null && D.$$typeof === Sl && S0(D) === o.type) ? (o = u(o, r.props), Fe(o, r), o.return = d, o) : (o = Bu(r.type, r.key, r.props, null, d.mode, S), Fe(o, r), o.return = d, o)
            }

            function h(d, o, r, S) {
                return o === null || o.tag !== 4 || o.stateNode.containerInfo !== r.containerInfo || o.stateNode.implementation !== r.implementation ? (o = zi(r, d.mode, S), o.return = d, o) : (o = u(o, r.children || []), o.return = d, o)
            }

            function g(d, o, r, S, D) {
                return o === null || o.tag !== 7 ? (o = Ta(r, d.mode, S, D), o.return = d, o) : (o = u(o, r), o.return = d, o)
            }

            function E(d, o, r) {
                if (typeof o == "string" && o !== "" || typeof o == "number" || typeof o == "bigint") return o = Ai("" + o, d.mode, r), o.return = d, o;
                if (typeof o == "object" && o !== null) {
                    switch (o.$$typeof) {
                        case X:
                            return r = Bu(o.type, o.key, o.props, null, d.mode, r), Fe(r, o), r.return = d, r;
                        case ul:
                            return o = zi(o, d.mode, r), o.return = d, o;
                        case Sl:
                            var S = o._init;
                            return o = S(o._payload), E(d, o, r)
                    }
                    if (Zl(o) || Xl(o)) return o = Ta(o, d.mode, r, null), o.return = d, o;
                    if (typeof o.then == "function") return E(d, ln(o), r);
                    if (o.$$typeof === K) return E(d, Qu(d, o), r);
                    tn(d, o)
                }
                return null
            }

            function v(d, o, r, S) {
                var D = o !== null ? o.key : null;
                if (typeof r == "string" && r !== "" || typeof r == "number" || typeof r == "bigint") return D !== null ? null : c(d, o, "" + r, S);
                if (typeof r == "object" && r !== null) {
                    switch (r.$$typeof) {
                        case X:
                            return r.key === D ? f(d, o, r, S) : null;
                        case ul:
                            return r.key === D ? h(d, o, r, S) : null;
                        case Sl:
                            return D = r._init, r = D(r._payload), v(d, o, r, S)
                    }
                    if (Zl(r) || Xl(r)) return D !== null ? null : g(d, o, r, S, null);
                    if (typeof r.then == "function") return v(d, o, ln(r), S);
                    if (r.$$typeof === K) return v(d, o, Qu(d, r), S);
                    tn(d, r)
                }
                return null
            }

            function y(d, o, r, S, D) {
                if (typeof S == "string" && S !== "" || typeof S == "number" || typeof S == "bigint") return d = d.get(r) || null, c(o, d, "" + S, D);
                if (typeof S == "object" && S !== null) {
                    switch (S.$$typeof) {
                        case X:
                            return d = d.get(S.key === null ? r : S.key) || null, f(o, d, S, D);
                        case ul:
                            return d = d.get(S.key === null ? r : S.key) || null, h(o, d, S, D);
                        case Sl:
                            var V = S._init;
                            return S = V(S._payload), y(d, o, r, S, D)
                    }
                    if (Zl(S) || Xl(S)) return d = d.get(r) || null, g(o, d, S, D, null);
                    if (typeof S.then == "function") return y(d, o, r, ln(S), D);
                    if (S.$$typeof === K) return y(d, o, r, Qu(o, S), D);
                    tn(o, S)
                }
                return null
            }

            function Y(d, o, r, S) {
                for (var D = null, V = null, U = o, H = o = 0, Cl = null; U !== null && H < r.length; H++) {
                    U.index > H ? (Cl = U, U = null) : Cl = U.sibling;
                    var tl = v(d, U, r[H], S);
                    if (tl === null) {
                        U === null && (U = Cl);
                        break
                    }
                    l && U && tl.alternate === null && t(d, U), o = n(tl, o, H), V === null ? D = tl : V.sibling = tl, V = tl, U = Cl
                }
                if (H === r.length) return a(d, U), al && Aa(d, H), D;
                if (U === null) {
                    for (; H < r.length; H++) U = E(d, r[H], S), U !== null && (o = n(U, o, H), V === null ? D = U : V.sibling = U, V = U);
                    return al && Aa(d, H), D
                }
                for (U = e(U); H < r.length; H++) Cl = y(U, d, H, r[H], S), Cl !== null && (l && Cl.alternate !== null && U.delete(Cl.key === null ? H : Cl.key), o = n(Cl, o, H), V === null ? D = Cl : V.sibling = Cl, V = Cl);
                return l && U.forEach(function(ha) {
                    return t(d, ha)
                }), al && Aa(d, H), D
            }

            function N(d, o, r, S) {
                if (r == null) throw Error(m(151));
                for (var D = null, V = null, U = o, H = o = 0, Cl = null, tl = r.next(); U !== null && !tl.done; H++, tl = r.next()) {
                    U.index > H ? (Cl = U, U = null) : Cl = U.sibling;
                    var ha = v(d, U, tl.value, S);
                    if (ha === null) {
                        U === null && (U = Cl);
                        break
                    }
                    l && U && ha.alternate === null && t(d, U), o = n(ha, o, H), V === null ? D = ha : V.sibling = ha, V = ha, U = Cl
                }
                if (tl.done) return a(d, U), al && Aa(d, H), D;
                if (U === null) {
                    for (; !tl.done; H++, tl = r.next()) tl = E(d, tl.value, S), tl !== null && (o = n(tl, o, H), V === null ? D = tl : V.sibling = tl, V = tl);
                    return al && Aa(d, H), D
                }
                for (U = e(U); !tl.done; H++, tl = r.next()) tl = y(U, d, H, tl.value, S), tl !== null && (l && tl.alternate !== null && U.delete(tl.key === null ? H : tl.key), o = n(tl, o, H), V === null ? D = tl : V.sibling = tl, V = tl);
                return l && U.forEach(function(eh) {
                    return t(d, eh)
                }), al && Aa(d, H), D
            }

            function dl(d, o, r, S) {
                if (typeof r == "object" && r !== null && r.type === ml && r.key === null && (r = r.props.children), typeof r == "object" && r !== null) {
                    switch (r.$$typeof) {
                        case X:
                            l: {
                                for (var D = r.key; o !== null;) {
                                    if (o.key === D) {
                                        if (D = r.type, D === ml) {
                                            if (o.tag === 7) {
                                                a(d, o.sibling), S = u(o, r.props.children), S.return = d, d = S;
                                                break l
                                            }
                                        } else if (o.elementType === D || typeof D == "object" && D !== null && D.$$typeof === Sl && S0(D) === o.type) {
                                            a(d, o.sibling), S = u(o, r.props), Fe(S, r), S.return = d, d = S;
                                            break l
                                        }
                                        a(d, o);
                                        break
                                    } else t(d, o);
                                    o = o.sibling
                                }
                                r.type === ml ? (S = Ta(r.props.children, d.mode, S, r.key), S.return = d, d = S) : (S = Bu(r.type, r.key, r.props, null, d.mode, S), Fe(S, r), S.return = d, d = S)
                            }
                            return i(d);
                        case ul:
                            l: {
                                for (D = r.key; o !== null;) {
                                    if (o.key === D)
                                        if (o.tag === 4 && o.stateNode.containerInfo === r.containerInfo && o.stateNode.implementation === r.implementation) {
                                            a(d, o.sibling), S = u(o, r.children || []), S.return = d, d = S;
                                            break l
                                        } else {
                                            a(d, o);
                                            break
                                        }
                                    else t(d, o);
                                    o = o.sibling
                                }
                                S = zi(r, d.mode, S),
                                S.return = d,
                                d = S
                            }
                            return i(d);
                        case Sl:
                            return D = r._init, r = D(r._payload), dl(d, o, r, S)
                    }
                    if (Zl(r)) return Y(d, o, r, S);
                    if (Xl(r)) {
                        if (D = Xl(r), typeof D != "function") throw Error(m(150));
                        return r = D.call(r), N(d, o, r, S)
                    }
                    if (typeof r.then == "function") return dl(d, o, ln(r), S);
                    if (r.$$typeof === K) return dl(d, o, Qu(d, r), S);
                    tn(d, r)
                }
                return typeof r == "string" && r !== "" || typeof r == "number" || typeof r == "bigint" ? (r = "" + r, o !== null && o.tag === 6 ? (a(d, o.sibling), S = u(o, r), S.return = d, d = S) : (a(d, o), S = Ai(r, d.mode, S), S.return = d, d = S), i(d)) : a(d, o)
            }
            return function(d, o, r, S) {
                try {
                    $e = 0;
                    var D = dl(d, o, r, S);
                    return ue = null, D
                } catch (U) {
                    if (U === Qe || U === Zu) throw U;
                    var V = at(29, U, null, d.mode);
                    return V.lanes = S, V.return = d, V
                } finally {}
            }
        }
        var ne = T0(!0),
            E0 = T0(!1),
            vt = A(null),
            Et = null;

        function It(l) {
            var t = l.alternate;
            M(Ul, Ul.current & 1), M(vt, l), Et === null && (t === null || le.current !== null || t.memoizedState !== null) && (Et = l)
        }

        function A0(l) {
            if (l.tag === 22) {
                if (M(Ul, Ul.current), M(vt, l), Et === null) {
                    var t = l.alternate;
                    t !== null && t.memoizedState !== null && (Et = l)
                }
            } else Pt()
        }

        function Pt() {
            M(Ul, Ul.current), M(vt, vt.current)
        }

        function Ct(l) {
            O(vt), Et === l && (Et = null), O(Ul)
        }
        var Ul = A(0);

        function an(l) {
            for (var t = l; t !== null;) {
                if (t.tag === 13) {
                    var a = t.memoizedState;
                    if (a !== null && (a = a.dehydrated, a === null || a.data === "$?" || Kc(a))) return t
                } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
                    if ((t.flags & 128) !== 0) return t
                } else if (t.child !== null) {
                    t.child.return = t, t = t.child;
                    continue
                }
                if (t === l) break;
                for (; t.sibling === null;) {
                    if (t.return === null || t.return === l) return null;
                    t = t.return
                }
                t.sibling.return = t.return, t = t.sibling
            }
            return null
        }

        function ec(l, t, a, e) {
            t = l.memoizedState, a = a(e, t), a = a == null ? t : z({}, t, a), l.memoizedState = a, l.lanes === 0 && (l.updateQueue.baseState = a)
        }
        var uc = {
            enqueueSetState: function(l, t, a) {
                l = l._reactInternals;
                var e = it(),
                    u = Wt(e);
                u.payload = t, a != null && (u.callback = a), t = $t(l, u, e), t !== null && (ct(t, l, e), Ze(t, l, e))
            },
            enqueueReplaceState: function(l, t, a) {
                l = l._reactInternals;
                var e = it(),
                    u = Wt(e);
                u.tag = 1, u.payload = t, a != null && (u.callback = a), t = $t(l, u, e), t !== null && (ct(t, l, e), Ze(t, l, e))
            },
            enqueueForceUpdate: function(l, t) {
                l = l._reactInternals;
                var a = it(),
                    e = Wt(a);
                e.tag = 2, t != null && (e.callback = t), t = $t(l, e, a), t !== null && (ct(t, l, a), Ze(t, l, a))
            }
        };

        function z0(l, t, a, e, u, n, i) {
            return l = l.stateNode, typeof l.shouldComponentUpdate == "function" ? l.shouldComponentUpdate(e, n, i) : t.prototype && t.prototype.isPureReactComponent ? !He(a, e) || !He(u, n) : !0
        }

        function M0(l, t, a, e) {
            l = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(a, e), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(a, e), t.state !== l && uc.enqueueReplaceState(t, t.state, null)
        }

        function Ua(l, t) {
            var a = t;
            if ("ref" in t) {
                a = {};
                for (var e in t) e !== "ref" && (a[e] = t[e])
            }
            if (l = l.defaultProps) {
                a === t && (a = z({}, a));
                for (var u in l) a[u] === void 0 && (a[u] = l[u])
            }
            return a
        }
        var en = typeof reportError == "function" ? reportError : function(l) {
            if (typeof window == "object" && typeof window.ErrorEvent == "function") {
                var t = new window.ErrorEvent("error", {
                    bubbles: !0,
                    cancelable: !0,
                    message: typeof l == "object" && l !== null && typeof l.message == "string" ? String(l.message) : String(l),
                    error: l
                });
                if (!window.dispatchEvent(t)) return
            } else if (typeof process == "object" && typeof process.emit == "function") {
                process.emit("uncaughtException", l);
                return
            }
            console.error(l)
        };

        function _0(l) {
            en(l)
        }

        function x0(l) {
            console.error(l)
        }

        function O0(l) {
            en(l)
        }

        function un(l, t) {
            try {
                var a = l.onUncaughtError;
                a(t.value, {
                    componentStack: t.stack
                })
            } catch (e) {
                setTimeout(function() {
                    throw e
                })
            }
        }

        function D0(l, t, a) {
            try {
                var e = l.onCaughtError;
                e(a.value, {
                    componentStack: a.stack,
                    errorBoundary: t.tag === 1 ? t.stateNode : null
                })
            } catch (u) {
                setTimeout(function() {
                    throw u
                })
            }
        }

        function nc(l, t, a) {
            return a = Wt(a), a.tag = 3, a.payload = {
                element: null
            }, a.callback = function() {
                un(l, t)
            }, a
        }

        function U0(l) {
            return l = Wt(l), l.tag = 3, l
        }

        function R0(l, t, a, e) {
            var u = a.type.getDerivedStateFromError;
            if (typeof u == "function") {
                var n = e.value;
                l.payload = function() {
                    return u(n)
                }, l.callback = function() {
                    D0(t, a, e)
                }
            }
            var i = a.stateNode;
            i !== null && typeof i.componentDidCatch == "function" && (l.callback = function() {
                D0(t, a, e), typeof u != "function" && (na === null ? na = new Set([this]) : na.add(this));
                var c = e.stack;
                this.componentDidCatch(e.value, {
                    componentStack: c !== null ? c : ""
                })
            })
        }

        function er(l, t, a, e, u) {
            if (a.flags |= 32768, e !== null && typeof e == "object" && typeof e.then == "function") {
                if (t = a.alternate, t !== null && je(t, a, u, !0), a = vt.current, a !== null) {
                    switch (a.tag) {
                        case 13:
                            return Et === null ? Dc() : a.alternate === null && Al === 0 && (Al = 3), a.flags &= -257, a.flags |= 65536, a.lanes = u, e === qi ? a.flags |= 16384 : (t = a.updateQueue, t === null ? a.updateQueue = new Set([e]) : t.add(e), Rc(l, e, u)), !1;
                        case 22:
                            return a.flags |= 65536, e === qi ? a.flags |= 16384 : (t = a.updateQueue, t === null ? (t = {
                                transitions: null,
                                markerInstances: null,
                                retryQueue: new Set([e])
                            }, a.updateQueue = t) : (a = t.retryQueue, a === null ? t.retryQueue = new Set([e]) : a.add(e)), Rc(l, e, u)), !1
                    }
                    throw Error(m(435, a.tag))
                }
                return Rc(l, e, u), Dc(), !1
            }
            if (al) return t = vt.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = u, e !== xi && (l = Error(m(422), {
                cause: e
            }), Be(ot(l, a)))) : (e !== xi && (t = Error(m(423), {
                cause: e
            }), Be(ot(t, a))), l = l.current.alternate, l.flags |= 65536, u &= -u, l.lanes |= u, e = ot(e, a), u = nc(l.stateNode, e, u), Bi(l, u), Al !== 4 && (Al = 2)), !1;
            var n = Error(m(520), {
                cause: e
            });
            if (n = ot(n, a), uu === null ? uu = [n] : uu.push(n), Al !== 4 && (Al = 2), t === null) return !0;
            e = ot(e, a), a = t;
            do {
                switch (a.tag) {
                    case 3:
                        return a.flags |= 65536, l = u & -u, a.lanes |= l, l = nc(a.stateNode, e, l), Bi(a, l), !1;
                    case 1:
                        if (t = a.type, n = a.stateNode, (a.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || n !== null && typeof n.componentDidCatch == "function" && (na === null || !na.has(n)))) return a.flags |= 65536, u &= -u, a.lanes |= u, u = U0(u), R0(u, l, a, e), Bi(a, u), !1
                }
                a = a.return
            } while (a !== null);
            return !1
        }
        var N0 = Error(m(461)),
            ql = !1;

        function Bl(l, t, a, e) {
            t.child = l === null ? E0(t, null, a, e) : ne(t, l.child, a, e)
        }

        function H0(l, t, a, e, u) {
            a = a.render;
            var n = t.ref;
            if ("ref" in e) {
                var i = {};
                for (var c in e) c !== "ref" && (i[c] = e[c])
            } else i = e;
            return xa(t), e = Xi(l, t, a, i, n, u), c = Zi(), l !== null && !ql ? (Li(l, t, u), Bt(l, t, u)) : (al && c && Mi(t), t.flags |= 1, Bl(l, t, e, u), t.child)
        }

        function q0(l, t, a, e, u) {
            if (l === null) {
                var n = a.type;
                return typeof n == "function" && !Ei(n) && n.defaultProps === void 0 && a.compare === null ? (t.tag = 15, t.type = n, Y0(l, t, n, e, u)) : (l = Bu(a.type, null, e, t, t.mode, u), l.ref = t.ref, l.return = t, t.child = l)
            }
            if (n = l.child, !hc(l, u)) {
                var i = n.memoizedProps;
                if (a = a.compare, a = a !== null ? a : He, a(i, e) && l.ref === t.ref) return Bt(l, t, u)
            }
            return t.flags |= 1, l = Ut(n, e), l.ref = t.ref, l.return = t, t.child = l
        }

        function Y0(l, t, a, e, u) {
            if (l !== null) {
                var n = l.memoizedProps;
                if (He(n, e) && l.ref === t.ref)
                    if (ql = !1, t.pendingProps = e = n, hc(l, u))(l.flags & 131072) !== 0 && (ql = !0);
                    else return t.lanes = l.lanes, Bt(l, t, u)
            }
            return ic(l, t, a, e, u)
        }

        function C0(l, t, a) {
            var e = t.pendingProps,
                u = e.children,
                n = l !== null ? l.memoizedState : null;
            if (e.mode === "hidden") {
                if ((t.flags & 128) !== 0) {
                    if (e = n !== null ? n.baseLanes | a : a, l !== null) {
                        for (u = t.child = l.child, n = 0; u !== null;) n = n | u.lanes | u.childLanes, u = u.sibling;
                        t.childLanes = n & ~e
                    } else t.childLanes = 0, t.child = null;
                    return B0(l, t, e, a)
                }
                if ((a & 536870912) !== 0) t.memoizedState = {
                    baseLanes: 0,
                    cachePool: null
                }, l !== null && Xu(t, n !== null ? n.cachePool : null), n !== null ? Ys(t, n) : wi(), A0(t);
                else return t.lanes = t.childLanes = 536870912, B0(l, t, n !== null ? n.baseLanes | a : a, a)
            } else n !== null ? (Xu(t, n.cachePool), Ys(t, n), Pt(), t.memoizedState = null) : (l !== null && Xu(t, null), wi(), Pt());
            return Bl(l, t, u, a), t.child
        }

        function B0(l, t, a, e) {
            var u = Hi();
            return u = u === null ? null : {
                parent: Dl._currentValue,
                pool: u
            }, t.memoizedState = {
                baseLanes: a,
                cachePool: u
            }, l !== null && Xu(t, null), wi(), A0(t), l !== null && je(l, t, e, !0), null
        }

        function nn(l, t) {
            var a = t.ref;
            if (a === null) l !== null && l.ref !== null && (t.flags |= 4194816);
            else {
                if (typeof a != "function" && typeof a != "object") throw Error(m(284));
                (l === null || l.ref !== a) && (t.flags |= 4194816)
            }
        }

        function ic(l, t, a, e, u) {
            return xa(t), a = Xi(l, t, a, e, void 0, u), e = Zi(), l !== null && !ql ? (Li(l, t, u), Bt(l, t, u)) : (al && e && Mi(t), t.flags |= 1, Bl(l, t, a, u), t.child)
        }

        function j0(l, t, a, e, u, n) {
            return xa(t), t.updateQueue = null, a = Bs(t, e, a, u), Cs(l), e = Zi(), l !== null && !ql ? (Li(l, t, n), Bt(l, t, n)) : (al && e && Mi(t), t.flags |= 1, Bl(l, t, a, n), t.child)
        }

        function w0(l, t, a, e, u) {
            if (xa(t), t.stateNode === null) {
                var n = Wa,
                    i = a.contextType;
                typeof i == "object" && i !== null && (n = Vl(i)), n = new a(e, n), t.memoizedState = n.state !== null && n.state !== void 0 ? n.state : null, n.updater = uc, t.stateNode = n, n._reactInternals = t, n = t.stateNode, n.props = e, n.state = t.memoizedState, n.refs = {}, Yi(t), i = a.contextType, n.context = typeof i == "object" && i !== null ? Vl(i) : Wa, n.state = t.memoizedState, i = a.getDerivedStateFromProps, typeof i == "function" && (ec(t, a, i, e), n.state = t.memoizedState), typeof a.getDerivedStateFromProps == "function" || typeof n.getSnapshotBeforeUpdate == "function" || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (i = n.state, typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount(), i !== n.state && uc.enqueueReplaceState(n, n.state, null), Ve(t, e, n, u), Le(), n.state = t.memoizedState), typeof n.componentDidMount == "function" && (t.flags |= 4194308), e = !0
            } else if (l === null) {
                n = t.stateNode;
                var c = t.memoizedProps,
                    f = Ua(a, c);
                n.props = f;
                var h = n.context,
                    g = a.contextType;
                i = Wa, typeof g == "object" && g !== null && (i = Vl(g));
                var E = a.getDerivedStateFromProps;
                g = typeof E == "function" || typeof n.getSnapshotBeforeUpdate == "function", c = t.pendingProps !== c, g || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (c || h !== i) && M0(t, n, e, i), kt = !1;
                var v = t.memoizedState;
                n.state = v, Ve(t, e, n, u), Le(), h = t.memoizedState, c || v !== h || kt ? (typeof E == "function" && (ec(t, a, E, e), h = t.memoizedState), (f = kt || z0(t, a, f, e, v, h, i)) ? (g || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount()), typeof n.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof n.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = e, t.memoizedState = h), n.props = e, n.state = h, n.context = i, e = f) : (typeof n.componentDidMount == "function" && (t.flags |= 4194308), e = !1)
            } else {
                n = t.stateNode, Ci(l, t), i = t.memoizedProps, g = Ua(a, i), n.props = g, E = t.pendingProps, v = n.context, h = a.contextType, f = Wa, typeof h == "object" && h !== null && (f = Vl(h)), c = a.getDerivedStateFromProps, (h = typeof c == "function" || typeof n.getSnapshotBeforeUpdate == "function") || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (i !== E || v !== f) && M0(t, n, e, f), kt = !1, v = t.memoizedState, n.state = v, Ve(t, e, n, u), Le();
                var y = t.memoizedState;
                i !== E || v !== y || kt || l !== null && l.dependencies !== null && Gu(l.dependencies) ? (typeof c == "function" && (ec(t, a, c, e), y = t.memoizedState), (g = kt || z0(t, a, g, e, v, y, f) || l !== null && l.dependencies !== null && Gu(l.dependencies)) ? (h || typeof n.UNSAFE_componentWillUpdate != "function" && typeof n.componentWillUpdate != "function" || (typeof n.componentWillUpdate == "function" && n.componentWillUpdate(e, y, f), typeof n.UNSAFE_componentWillUpdate == "function" && n.UNSAFE_componentWillUpdate(e, y, f)), typeof n.componentDidUpdate == "function" && (t.flags |= 4), typeof n.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof n.componentDidUpdate != "function" || i === l.memoizedProps && v === l.memoizedState || (t.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || i === l.memoizedProps && v === l.memoizedState || (t.flags |= 1024), t.memoizedProps = e, t.memoizedState = y), n.props = e, n.state = y, n.context = f, e = g) : (typeof n.componentDidUpdate != "function" || i === l.memoizedProps && v === l.memoizedState || (t.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || i === l.memoizedProps && v === l.memoizedState || (t.flags |= 1024), e = !1)
            }
            return n = e, nn(l, t), e = (t.flags & 128) !== 0, n || e ? (n = t.stateNode, a = e && typeof a.getDerivedStateFromError != "function" ? null : n.render(), t.flags |= 1, l !== null && e ? (t.child = ne(t, l.child, null, u), t.child = ne(t, null, a, u)) : Bl(l, t, a, u), t.memoizedState = n.state, l = t.child) : l = Bt(l, t, u), l
        }

        function G0(l, t, a, e) {
            return Ce(), t.flags |= 256, Bl(l, t, a, e), t.child
        }
        var cc = {
            dehydrated: null,
            treeContext: null,
            retryLane: 0,
            hydrationErrors: null
        };

        function fc(l) {
            return {
                baseLanes: l,
                cachePool: xs()
            }
        }

        function sc(l, t, a) {
            return l = l !== null ? l.childLanes & ~a : 0, t && (l |= yt), l
        }

        function Q0(l, t, a) {
            var e = t.pendingProps,
                u = !1,
                n = (t.flags & 128) !== 0,
                i;
            if ((i = n) || (i = l !== null && l.memoizedState === null ? !1 : (Ul.current & 2) !== 0), i && (u = !0, t.flags &= -129), i = (t.flags & 32) !== 0, t.flags &= -33, l === null) {
                if (al) {
                    if (u ? It(t) : Pt(), al) {
                        var c = El,
                            f;
                        if (f = c) {
                            l: {
                                for (f = c, c = Tt; f.nodeType !== 8;) {
                                    if (!c) {
                                        c = null;
                                        break l
                                    }
                                    if (f = bt(f.nextSibling), f === null) {
                                        c = null;
                                        break l
                                    }
                                }
                                c = f
                            }
                            c !== null ? (t.memoizedState = {
                                dehydrated: c,
                                treeContext: Ea !== null ? {
                                    id: Rt,
                                    overflow: Nt
                                } : null,
                                retryLane: 536870912,
                                hydrationErrors: null
                            }, f = at(18, null, null, 0), f.stateNode = c, f.return = t, t.child = f, Kl = t, El = null, f = !0) : f = !1
                        }
                        f || Ma(t)
                    }
                    if (c = t.memoizedState, c !== null && (c = c.dehydrated, c !== null)) return Kc(c) ? t.lanes = 32 : t.lanes = 536870912, null;
                    Ct(t)
                }
                return c = e.children, e = e.fallback, u ? (Pt(), u = t.mode, c = cn({
                    mode: "hidden",
                    children: c
                }, u), e = Ta(e, u, a, null), c.return = t, e.return = t, c.sibling = e, t.child = c, u = t.child, u.memoizedState = fc(a), u.childLanes = sc(l, i, a), t.memoizedState = cc, e) : (It(t), oc(t, c))
            }
            if (f = l.memoizedState, f !== null && (c = f.dehydrated, c !== null)) {
                if (n) t.flags & 256 ? (It(t), t.flags &= -257, t = dc(l, t, a)) : t.memoizedState !== null ? (Pt(), t.child = l.child, t.flags |= 128, t = null) : (Pt(), u = e.fallback, c = t.mode, e = cn({
                    mode: "visible",
                    children: e.children
                }, c), u = Ta(u, c, a, null), u.flags |= 2, e.return = t, u.return = t, e.sibling = u, t.child = e, ne(t, l.child, null, a), e = t.child, e.memoizedState = fc(a), e.childLanes = sc(l, i, a), t.memoizedState = cc, t = u);
                else if (It(t), Kc(c)) {
                    if (i = c.nextSibling && c.nextSibling.dataset, i) var h = i.dgst;
                    i = h, e = Error(m(419)), e.stack = "", e.digest = i, Be({
                        value: e,
                        source: null,
                        stack: null
                    }), t = dc(l, t, a)
                } else if (ql || je(l, t, a, !1), i = (a & l.childLanes) !== 0, ql || i) {
                    if (i = yl, i !== null && (e = a & -a, e = (e & 42) !== 0 ? 1 : Jn(e), e = (e & (i.suspendedLanes | a)) !== 0 ? 0 : e, e !== 0 && e !== f.retryLane)) throw f.retryLane = e, ka(l, e), ct(i, l, e), N0;
                    c.data === "$?" || Dc(), t = dc(l, t, a)
                } else c.data === "$?" ? (t.flags |= 192, t.child = l.child, t = null) : (l = f.treeContext, El = bt(c.nextSibling), Kl = t, al = !0, za = null, Tt = !1, l !== null && (rt[ht++] = Rt, rt[ht++] = Nt, rt[ht++] = Ea, Rt = l.id, Nt = l.overflow, Ea = t), t = oc(t, e.children), t.flags |= 4096);
                return t
            }
            return u ? (Pt(), u = e.fallback, c = t.mode, f = l.child, h = f.sibling, e = Ut(f, {
                mode: "hidden",
                children: e.children
            }), e.subtreeFlags = f.subtreeFlags & 65011712, h !== null ? u = Ut(h, u) : (u = Ta(u, c, a, null), u.flags |= 2), u.return = t, e.return = t, e.sibling = u, t.child = e, e = u, u = t.child, c = l.child.memoizedState, c === null ? c = fc(a) : (f = c.cachePool, f !== null ? (h = Dl._currentValue, f = f.parent !== h ? {
                parent: h,
                pool: h
            } : f) : f = xs(), c = {
                baseLanes: c.baseLanes | a,
                cachePool: f
            }), u.memoizedState = c, u.childLanes = sc(l, i, a), t.memoizedState = cc, e) : (It(t), a = l.child, l = a.sibling, a = Ut(a, {
                mode: "visible",
                children: e.children
            }), a.return = t, a.sibling = null, l !== null && (i = t.deletions, i === null ? (t.deletions = [l], t.flags |= 16) : i.push(l)), t.child = a, t.memoizedState = null, a)
        }

        function oc(l, t) {
            return t = cn({
                mode: "visible",
                children: t
            }, l.mode), t.return = l, l.child = t
        }

        function cn(l, t) {
            return l = at(22, l, null, t), l.lanes = 0, l.stateNode = {
                _visibility: 1,
                _pendingMarkers: null,
                _retryCache: null,
                _transitions: null
            }, l
        }

        function dc(l, t, a) {
            return ne(t, l.child, null, a), l = oc(t, t.pendingProps.children), l.flags |= 2, t.memoizedState = null, l
        }

        function X0(l, t, a) {
            l.lanes |= t;
            var e = l.alternate;
            e !== null && (e.lanes |= t), Di(l.return, t, a)
        }

        function rc(l, t, a, e, u) {
            var n = l.memoizedState;
            n === null ? l.memoizedState = {
                isBackwards: t,
                rendering: null,
                renderingStartTime: 0,
                last: e,
                tail: a,
                tailMode: u
            } : (n.isBackwards = t, n.rendering = null, n.renderingStartTime = 0, n.last = e, n.tail = a, n.tailMode = u)
        }

        function Z0(l, t, a) {
            var e = t.pendingProps,
                u = e.revealOrder,
                n = e.tail;
            if (Bl(l, t, e.children, a), e = Ul.current, (e & 2) !== 0) e = e & 1 | 2, t.flags |= 128;
            else {
                if (l !== null && (l.flags & 128) !== 0) l: for (l = t.child; l !== null;) {
                    if (l.tag === 13) l.memoizedState !== null && X0(l, a, t);
                    else if (l.tag === 19) X0(l, a, t);
                    else if (l.child !== null) {
                        l.child.return = l, l = l.child;
                        continue
                    }
                    if (l === t) break l;
                    for (; l.sibling === null;) {
                        if (l.return === null || l.return === t) break l;
                        l = l.return
                    }
                    l.sibling.return = l.return, l = l.sibling
                }
                e &= 1
            }
            switch (M(Ul, e), u) {
                case "forwards":
                    for (a = t.child, u = null; a !== null;) l = a.alternate, l !== null && an(l) === null && (u = a), a = a.sibling;
                    a = u, a === null ? (u = t.child, t.child = null) : (u = a.sibling, a.sibling = null), rc(t, !1, u, a, n);
                    break;
                case "backwards":
                    for (a = null, u = t.child, t.child = null; u !== null;) {
                        if (l = u.alternate, l !== null && an(l) === null) {
                            t.child = u;
                            break
                        }
                        l = u.sibling, u.sibling = a, a = u, u = l
                    }
                    rc(t, !0, a, null, n);
                    break;
                case "together":
                    rc(t, !1, null, null, void 0);
                    break;
                default:
                    t.memoizedState = null
            }
            return t.child
        }

        function Bt(l, t, a) {
            if (l !== null && (t.dependencies = l.dependencies), ua |= t.lanes, (a & t.childLanes) === 0)
                if (l !== null) {
                    if (je(l, t, a, !1), (a & t.childLanes) === 0) return null
                } else return null;
            if (l !== null && t.child !== l.child) throw Error(m(153));
            if (t.child !== null) {
                for (l = t.child, a = Ut(l, l.pendingProps), t.child = a, a.return = t; l.sibling !== null;) l = l.sibling, a = a.sibling = Ut(l, l.pendingProps), a.return = t;
                a.sibling = null
            }
            return t.child
        }

        function hc(l, t) {
            return (l.lanes & t) !== 0 ? !0 : (l = l.dependencies, !!(l !== null && Gu(l)))
        }

        function ur(l, t, a) {
            switch (t.tag) {
                case 3:
                    pl(t, t.stateNode.containerInfo), Jt(t, Dl, l.memoizedState.cache), Ce();
                    break;
                case 27:
                case 5:
                    Xn(t);
                    break;
                case 4:
                    pl(t, t.stateNode.containerInfo);
                    break;
                case 10:
                    Jt(t, t.type, t.memoizedProps.value);
                    break;
                case 13:
                    var e = t.memoizedState;
                    if (e !== null) return e.dehydrated !== null ? (It(t), t.flags |= 128, null) : (a & t.child.childLanes) !== 0 ? Q0(l, t, a) : (It(t), l = Bt(l, t, a), l !== null ? l.sibling : null);
                    It(t);
                    break;
                case 19:
                    var u = (l.flags & 128) !== 0;
                    if (e = (a & t.childLanes) !== 0, e || (je(l, t, a, !1), e = (a & t.childLanes) !== 0), u) {
                        if (e) return Z0(l, t, a);
                        t.flags |= 128
                    }
                    if (u = t.memoizedState, u !== null && (u.rendering = null, u.tail = null, u.lastEffect = null), M(Ul, Ul.current), e) break;
                    return null;
                case 22:
                case 23:
                    return t.lanes = 0, C0(l, t, a);
                case 24:
                    Jt(t, Dl, l.memoizedState.cache)
            }
            return Bt(l, t, a)
        }

        function L0(l, t, a) {
            if (l !== null)
                if (l.memoizedProps !== t.pendingProps) ql = !0;
                else {
                    if (!hc(l, a) && (t.flags & 128) === 0) return ql = !1, ur(l, t, a);
                    ql = (l.flags & 131072) !== 0
                }
            else ql = !1, al && (t.flags & 1048576) !== 0 && Ss(t, wu, t.index);
            switch (t.lanes = 0, t.tag) {
                case 16:
                    l: {
                        l = t.pendingProps;
                        var e = t.elementType,
                            u = e._init;
                        if (e = u(e._payload), t.type = e, typeof e == "function") Ei(e) ? (l = Ua(e, l), t.tag = 1, t = w0(null, t, e, l, a)) : (t.tag = 0, t = ic(null, t, e, l, a));
                        else {
                            if (e != null) {
                                if (u = e.$$typeof, u === gl) {
                                    t.tag = 11, t = H0(null, t, e, l, a);
                                    break l
                                } else if (u === w) {
                                    t.tag = 14, t = q0(null, t, e, l, a);
                                    break l
                                }
                            }
                            throw t = ya(e) || e, Error(m(306, t, ""))
                        }
                    }
                    return t;
                case 0:
                    return ic(l, t, t.type, t.pendingProps, a);
                case 1:
                    return e = t.type, u = Ua(e, t.pendingProps), w0(l, t, e, u, a);
                case 3:
                    l: {
                        if (pl(t, t.stateNode.containerInfo), l === null) throw Error(m(387));e = t.pendingProps;
                        var n = t.memoizedState;u = n.element,
                        Ci(l, t),
                        Ve(t, e, null, a);
                        var i = t.memoizedState;
                        if (e = i.cache, Jt(t, Dl, e), e !== n.cache && Ui(t, [Dl], a, !0), Le(), e = i.element, n.isDehydrated)
                            if (n = {
                                    element: e,
                                    isDehydrated: !1,
                                    cache: i.cache
                                }, t.updateQueue.baseState = n, t.memoizedState = n, t.flags & 256) {
                                t = G0(l, t, e, a);
                                break l
                            } else if (e !== u) {
                            u = ot(Error(m(424)), t), Be(u), t = G0(l, t, e, a);
                            break l
                        } else {
                            switch (l = t.stateNode.containerInfo, l.nodeType) {
                                case 9:
                                    l = l.body;
                                    break;
                                default:
                                    l = l.nodeName === "HTML" ? l.ownerDocument.body : l
                            }
                            for (El = bt(l.firstChild), Kl = t, al = !0, za = null, Tt = !0, a = E0(t, null, e, a), t.child = a; a;) a.flags = a.flags & -3 | 4096, a = a.sibling
                        } else {
                            if (Ce(), e === u) {
                                t = Bt(l, t, a);
                                break l
                            }
                            Bl(l, t, e, a)
                        }
                        t = t.child
                    }
                    return t;
                case 26:
                    return nn(l, t), l === null ? (a = Wo(t.type, null, t.pendingProps, null)) ? t.memoizedState = a : al || (a = t.type, l = t.pendingProps, e = Tn(C.current).createElement(a), e[Ll] = t, e[Jl] = l, wl(e, a, l), Hl(e), t.stateNode = e) : t.memoizedState = Wo(t.type, l.memoizedProps, t.pendingProps, l.memoizedState), null;
                case 27:
                    return Xn(t), l === null && al && (e = t.stateNode = Ko(t.type, t.pendingProps, C.current), Kl = t, Tt = !0, u = El, fa(t.type) ? (Jc = u, El = bt(e.firstChild)) : El = u), Bl(l, t, t.pendingProps.children, a), nn(l, t), l === null && (t.flags |= 4194304), t.child;
                case 5:
                    return l === null && al && ((u = e = El) && (e = Nr(e, t.type, t.pendingProps, Tt), e !== null ? (t.stateNode = e, Kl = t, El = bt(e.firstChild), Tt = !1, u = !0) : u = !1), u || Ma(t)), Xn(t), u = t.type, n = t.pendingProps, i = l !== null ? l.memoizedProps : null, e = n.children, Zc(u, n) ? e = null : i !== null && Zc(u, i) && (t.flags |= 32), t.memoizedState !== null && (u = Xi(l, t, $d, null, null, a), hu._currentValue = u), nn(l, t), Bl(l, t, e, a), t.child;
                case 6:
                    return l === null && al && ((l = a = El) && (a = Hr(a, t.pendingProps, Tt), a !== null ? (t.stateNode = a, Kl = t, El = null, l = !0) : l = !1), l || Ma(t)), null;
                case 13:
                    return Q0(l, t, a);
                case 4:
                    return pl(t, t.stateNode.containerInfo), e = t.pendingProps, l === null ? t.child = ne(t, null, e, a) : Bl(l, t, e, a), t.child;
                case 11:
                    return H0(l, t, t.type, t.pendingProps, a);
                case 7:
                    return Bl(l, t, t.pendingProps, a), t.child;
                case 8:
                    return Bl(l, t, t.pendingProps.children, a), t.child;
                case 12:
                    return Bl(l, t, t.pendingProps.children, a), t.child;
                case 10:
                    return e = t.pendingProps, Jt(t, t.type, e.value), Bl(l, t, e.children, a), t.child;
                case 9:
                    return u = t.type._context, e = t.pendingProps.children, xa(t), u = Vl(u), e = e(u), t.flags |= 1, Bl(l, t, e, a), t.child;
                case 14:
                    return q0(l, t, t.type, t.pendingProps, a);
                case 15:
                    return Y0(l, t, t.type, t.pendingProps, a);
                case 19:
                    return Z0(l, t, a);
                case 31:
                    return e = t.pendingProps, a = t.mode, e = {
                        mode: e.mode,
                        children: e.children
                    }, l === null ? (a = cn(e, a), a.ref = t.ref, t.child = a, a.return = t, t = a) : (a = Ut(l.child, e), a.ref = t.ref, t.child = a, a.return = t, t = a), t;
                case 22:
                    return C0(l, t, a);
                case 24:
                    return xa(t), e = Vl(Dl), l === null ? (u = Hi(), u === null && (u = yl, n = Ri(), u.pooledCache = n, n.refCount++, n !== null && (u.pooledCacheLanes |= a), u = n), t.memoizedState = {
                        parent: e,
                        cache: u
                    }, Yi(t), Jt(t, Dl, u)) : ((l.lanes & a) !== 0 && (Ci(l, t), Ve(t, null, null, a), Le()), u = l.memoizedState, n = t.memoizedState, u.parent !== e ? (u = {
                        parent: e,
                        cache: e
                    }, t.memoizedState = u, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = u), Jt(t, Dl, e)) : (e = n.cache, Jt(t, Dl, e), e !== u.cache && Ui(t, [Dl], a, !0))), Bl(l, t, t.pendingProps.children, a), t.child;
                case 29:
                    throw t.pendingProps
            }
            throw Error(m(156, t.tag))
        }

        function jt(l) {
            l.flags |= 4
        }

        function V0(l, t) {
            if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0) l.flags &= -16777217;
            else if (l.flags |= 16777216, !l1(t)) {
                if (t = vt.current, t !== null && ((I & 4194048) === I ? Et !== null : (I & 62914560) !== I && (I & 536870912) === 0 || t !== Et)) throw Xe = qi, Os;
                l.flags |= 8192
            }
        }

        function fn(l, t) {
            t !== null && (l.flags |= 4), l.flags & 16384 && (t = l.tag !== 22 ? Af() : 536870912, l.lanes |= t, se |= t)
        }

        function Ie(l, t) {
            if (!al) switch (l.tailMode) {
                case "hidden":
                    t = l.tail;
                    for (var a = null; t !== null;) t.alternate !== null && (a = t), t = t.sibling;
                    a === null ? l.tail = null : a.sibling = null;
                    break;
                case "collapsed":
                    a = l.tail;
                    for (var e = null; a !== null;) a.alternate !== null && (e = a), a = a.sibling;
                    e === null ? t || l.tail === null ? l.tail = null : l.tail.sibling = null : e.sibling = null
            }
        }

        function Tl(l) {
            var t = l.alternate !== null && l.alternate.child === l.child,
                a = 0,
                e = 0;
            if (t)
                for (var u = l.child; u !== null;) a |= u.lanes | u.childLanes, e |= u.subtreeFlags & 65011712, e |= u.flags & 65011712, u.return = l, u = u.sibling;
            else
                for (u = l.child; u !== null;) a |= u.lanes | u.childLanes, e |= u.subtreeFlags, e |= u.flags, u.return = l, u = u.sibling;
            return l.subtreeFlags |= e, l.childLanes = a, t
        }

        function nr(l, t, a) {
            var e = t.pendingProps;
            switch (_i(t), t.tag) {
                case 31:
                case 16:
                case 15:
                case 0:
                case 11:
                case 7:
                case 8:
                case 12:
                case 9:
                case 14:
                    return Tl(t), null;
                case 1:
                    return Tl(t), null;
                case 3:
                    return a = t.stateNode, e = null, l !== null && (e = l.memoizedState.cache), t.memoizedState.cache !== e && (t.flags |= 2048), qt(Dl), Zt(), a.pendingContext && (a.context = a.pendingContext, a.pendingContext = null), (l === null || l.child === null) && (Ye(t) ? jt(t) : l === null || l.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, As())), Tl(t), null;
                case 26:
                    return a = t.memoizedState, l === null ? (jt(t), a !== null ? (Tl(t), V0(t, a)) : (Tl(t), t.flags &= -16777217)) : a ? a !== l.memoizedState ? (jt(t), Tl(t), V0(t, a)) : (Tl(t), t.flags &= -16777217) : (l.memoizedProps !== e && jt(t), Tl(t), t.flags &= -16777217), null;
                case 27:
                    pu(t), a = C.current;
                    var u = t.type;
                    if (l !== null && t.stateNode != null) l.memoizedProps !== e && jt(t);
                    else {
                        if (!e) {
                            if (t.stateNode === null) throw Error(m(166));
                            return Tl(t), null
                        }
                        l = R.current, Ye(t) ? Ts(t) : (l = Ko(u, e, a), t.stateNode = l, jt(t))
                    }
                    return Tl(t), null;
                case 5:
                    if (pu(t), a = t.type, l !== null && t.stateNode != null) l.memoizedProps !== e && jt(t);
                    else {
                        if (!e) {
                            if (t.stateNode === null) throw Error(m(166));
                            return Tl(t), null
                        }
                        if (l = R.current, Ye(t)) Ts(t);
                        else {
                            switch (u = Tn(C.current), l) {
                                case 1:
                                    l = u.createElementNS("http://www.w3.org/2000/svg", a);
                                    break;
                                case 2:
                                    l = u.createElementNS("http://www.w3.org/1998/Math/MathML", a);
                                    break;
                                default:
                                    switch (a) {
                                        case "svg":
                                            l = u.createElementNS("http://www.w3.org/2000/svg", a);
                                            break;
                                        case "math":
                                            l = u.createElementNS("http://www.w3.org/1998/Math/MathML", a);
                                            break;
                                        case "script":
                                            l = u.createElement("div"), l.innerHTML = "<script><\/script>", l = l.removeChild(l.firstChild);
                                            break;
                                        case "select":
                                            l = typeof e.is == "string" ? u.createElement("select", {
                                                is: e.is
                                            }) : u.createElement("select"), e.multiple ? l.multiple = !0 : e.size && (l.size = e.size);
                                            break;
                                        default:
                                            l = typeof e.is == "string" ? u.createElement(a, {
                                                is: e.is
                                            }) : u.createElement(a)
                                    }
                            }
                            l[Ll] = t, l[Jl] = e;
                            l: for (u = t.child; u !== null;) {
                                if (u.tag === 5 || u.tag === 6) l.appendChild(u.stateNode);
                                else if (u.tag !== 4 && u.tag !== 27 && u.child !== null) {
                                    u.child.return = u, u = u.child;
                                    continue
                                }
                                if (u === t) break l;
                                for (; u.sibling === null;) {
                                    if (u.return === null || u.return === t) break l;
                                    u = u.return
                                }
                                u.sibling.return = u.return, u = u.sibling
                            }
                            t.stateNode = l;
                            l: switch (wl(l, a, e), a) {
                                case "button":
                                case "input":
                                case "select":
                                case "textarea":
                                    l = !!e.autoFocus;
                                    break l;
                                case "img":
                                    l = !0;
                                    break l;
                                default:
                                    l = !1
                            }
                            l && jt(t)
                        }
                    }
                    return Tl(t), t.flags &= -16777217, null;
                case 6:
                    if (l && t.stateNode != null) l.memoizedProps !== e && jt(t);
                    else {
                        if (typeof e != "string" && t.stateNode === null) throw Error(m(166));
                        if (l = C.current, Ye(t)) {
                            if (l = t.stateNode, a = t.memoizedProps, e = null, u = Kl, u !== null) switch (u.tag) {
                                case 27:
                                case 5:
                                    e = u.memoizedProps
                            }
                            l[Ll] = t, l = !!(l.nodeValue === a || e !== null && e.suppressHydrationWarning === !0 || wo(l.nodeValue, a)), l || Ma(t)
                        } else l = Tn(l).createTextNode(e), l[Ll] = t, t.stateNode = l
                    }
                    return Tl(t), null;
                case 13:
                    if (e = t.memoizedState, l === null || l.memoizedState !== null && l.memoizedState.dehydrated !== null) {
                        if (u = Ye(t), e !== null && e.dehydrated !== null) {
                            if (l === null) {
                                if (!u) throw Error(m(318));
                                if (u = t.memoizedState, u = u !== null ? u.dehydrated : null, !u) throw Error(m(317));
                                u[Ll] = t
                            } else Ce(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
                            Tl(t), u = !1
                        } else u = As(), l !== null && l.memoizedState !== null && (l.memoizedState.hydrationErrors = u), u = !0;
                        if (!u) return t.flags & 256 ? (Ct(t), t) : (Ct(t), null)
                    }
                    if (Ct(t), (t.flags & 128) !== 0) return t.lanes = a, t;
                    if (a = e !== null, l = l !== null && l.memoizedState !== null, a) {
                        e = t.child, u = null, e.alternate !== null && e.alternate.memoizedState !== null && e.alternate.memoizedState.cachePool !== null && (u = e.alternate.memoizedState.cachePool.pool);
                        var n = null;
                        e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), n !== u && (e.flags |= 2048)
                    }
                    return a !== l && a && (t.child.flags |= 8192), fn(t, t.updateQueue), Tl(t), null;
                case 4:
                    return Zt(), l === null && jc(t.stateNode.containerInfo), Tl(t), null;
                case 10:
                    return qt(t.type), Tl(t), null;
                case 19:
                    if (O(Ul), u = t.memoizedState, u === null) return Tl(t), null;
                    if (e = (t.flags & 128) !== 0, n = u.rendering, n === null)
                        if (e) Ie(u, !1);
                        else {
                            if (Al !== 0 || l !== null && (l.flags & 128) !== 0)
                                for (l = t.child; l !== null;) {
                                    if (n = an(l), n !== null) {
                                        for (t.flags |= 128, Ie(u, !1), l = n.updateQueue, t.updateQueue = l, fn(t, l), t.subtreeFlags = 0, l = a, a = t.child; a !== null;) bs(a, l), a = a.sibling;
                                        return M(Ul, Ul.current & 1 | 2), t.child
                                    }
                                    l = l.sibling
                                }
                            u.tail !== null && St() > dn && (t.flags |= 128, e = !0, Ie(u, !1), t.lanes = 4194304)
                        }
                    else {
                        if (!e)
                            if (l = an(n), l !== null) {
                                if (t.flags |= 128, e = !0, l = l.updateQueue, t.updateQueue = l, fn(t, l), Ie(u, !0), u.tail === null && u.tailMode === "hidden" && !n.alternate && !al) return Tl(t), null
                            } else 2 * St() - u.renderingStartTime > dn && a !== 536870912 && (t.flags |= 128, e = !0, Ie(u, !1), t.lanes = 4194304);
                        u.isBackwards ? (n.sibling = t.child, t.child = n) : (l = u.last, l !== null ? l.sibling = n : t.child = n, u.last = n)
                    }
                    return u.tail !== null ? (t = u.tail, u.rendering = t, u.tail = t.sibling, u.renderingStartTime = St(), t.sibling = null, l = Ul.current, M(Ul, e ? l & 1 | 2 : l & 1), t) : (Tl(t), null);
                case 22:
                case 23:
                    return Ct(t), Gi(), e = t.memoizedState !== null, l !== null ? l.memoizedState !== null !== e && (t.flags |= 8192) : e && (t.flags |= 8192), e ? (a & 536870912) !== 0 && (t.flags & 128) === 0 && (Tl(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Tl(t), a = t.updateQueue, a !== null && fn(t, a.retryQueue), a = null, l !== null && l.memoizedState !== null && l.memoizedState.cachePool !== null && (a = l.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== a && (t.flags |= 2048), l !== null && O(Oa), null;
                case 24:
                    return a = null, l !== null && (a = l.memoizedState.cache), t.memoizedState.cache !== a && (t.flags |= 2048), qt(Dl), Tl(t), null;
                case 25:
                    return null;
                case 30:
                    return null
            }
            throw Error(m(156, t.tag))
        }

        function ir(l, t) {
            switch (_i(t), t.tag) {
                case 1:
                    return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
                case 3:
                    return qt(Dl), Zt(), l = t.flags, (l & 65536) !== 0 && (l & 128) === 0 ? (t.flags = l & -65537 | 128, t) : null;
                case 26:
                case 27:
                case 5:
                    return pu(t), null;
                case 13:
                    if (Ct(t), l = t.memoizedState, l !== null && l.dehydrated !== null) {
                        if (t.alternate === null) throw Error(m(340));
                        Ce()
                    }
                    return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
                case 19:
                    return O(Ul), null;
                case 4:
                    return Zt(), null;
                case 10:
                    return qt(t.type), null;
                case 22:
                case 23:
                    return Ct(t), Gi(), l !== null && O(Oa), l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
                case 24:
                    return qt(Dl), null;
                case 25:
                    return null;
                default:
                    return null
            }
        }

        function K0(l, t) {
            switch (_i(t), t.tag) {
                case 3:
                    qt(Dl), Zt();
                    break;
                case 26:
                case 27:
                case 5:
                    pu(t);
                    break;
                case 4:
                    Zt();
                    break;
                case 13:
                    Ct(t);
                    break;
                case 19:
                    O(Ul);
                    break;
                case 10:
                    qt(t.type);
                    break;
                case 22:
                case 23:
                    Ct(t), Gi(), l !== null && O(Oa);
                    break;
                case 24:
                    qt(Dl)
            }
        }

        function Pe(l, t) {
            try {
                var a = t.updateQueue,
                    e = a !== null ? a.lastEffect : null;
                if (e !== null) {
                    var u = e.next;
                    a = u;
                    do {
                        if ((a.tag & l) === l) {
                            e = void 0;
                            var n = a.create,
                                i = a.inst;
                            e = n(), i.destroy = e
                        }
                        a = a.next
                    } while (a !== u)
                }
            } catch (c) {
                hl(t, t.return, c)
            }
        }

        function la(l, t, a) {
            try {
                var e = t.updateQueue,
                    u = e !== null ? e.lastEffect : null;
                if (u !== null) {
                    var n = u.next;
                    e = n;
                    do {
                        if ((e.tag & l) === l) {
                            var i = e.inst,
                                c = i.destroy;
                            if (c !== void 0) {
                                i.destroy = void 0, u = t;
                                var f = a,
                                    h = c;
                                try {
                                    h()
                                } catch (g) {
                                    hl(u, f, g)
                                }
                            }
                        }
                        e = e.next
                    } while (e !== n)
                }
            } catch (g) {
                hl(t, t.return, g)
            }
        }

        function J0(l) {
            var t = l.updateQueue;
            if (t !== null) {
                var a = l.stateNode;
                try {
                    qs(t, a)
                } catch (e) {
                    hl(l, l.return, e)
                }
            }
        }

        function k0(l, t, a) {
            a.props = Ua(l.type, l.memoizedProps), a.state = l.memoizedState;
            try {
                a.componentWillUnmount()
            } catch (e) {
                hl(l, t, e)
            }
        }

        function lu(l, t) {
            try {
                var a = l.ref;
                if (a !== null) {
                    switch (l.tag) {
                        case 26:
                        case 27:
                        case 5:
                            var e = l.stateNode;
                            break;
                        case 30:
                            e = l.stateNode;
                            break;
                        default:
                            e = l.stateNode
                    }
                    typeof a == "function" ? l.refCleanup = a(e) : a.current = e
                }
            } catch (u) {
                hl(l, t, u)
            }
        }

        function At(l, t) {
            var a = l.ref,
                e = l.refCleanup;
            if (a !== null)
                if (typeof e == "function") try {
                    e()
                } catch (u) {
                    hl(l, t, u)
                } finally {
                    l.refCleanup = null, l = l.alternate, l != null && (l.refCleanup = null)
                } else if (typeof a == "function") try {
                    a(null)
                } catch (u) {
                    hl(l, t, u)
                } else a.current = null
        }

        function W0(l) {
            var t = l.type,
                a = l.memoizedProps,
                e = l.stateNode;
            try {
                l: switch (t) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                        a.autoFocus && e.focus();
                        break l;
                    case "img":
                        a.src ? e.src = a.src : a.srcSet && (e.srcset = a.srcSet)
                }
            }
            catch (u) {
                hl(l, l.return, u)
            }
        }

        function vc(l, t, a) {
            try {
                var e = l.stateNode;
                xr(e, l.type, a, t), e[Jl] = t
            } catch (u) {
                hl(l, l.return, u)
            }
        }

        function $0(l) {
            return l.tag === 5 || l.tag === 3 || l.tag === 26 || l.tag === 27 && fa(l.type) || l.tag === 4
        }

        function yc(l) {
            l: for (;;) {
                for (; l.sibling === null;) {
                    if (l.return === null || $0(l.return)) return null;
                    l = l.return
                }
                for (l.sibling.return = l.return, l = l.sibling; l.tag !== 5 && l.tag !== 6 && l.tag !== 18;) {
                    if (l.tag === 27 && fa(l.type) || l.flags & 2 || l.child === null || l.tag === 4) continue l;
                    l.child.return = l, l = l.child
                }
                if (!(l.flags & 2)) return l.stateNode
            }
        }

        function mc(l, t, a) {
            var e = l.tag;
            if (e === 5 || e === 6) l = l.stateNode, t ? (a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a).insertBefore(l, t) : (t = a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a, t.appendChild(l), a = a._reactRootContainer, a != null || t.onclick !== null || (t.onclick = Sn));
            else if (e !== 4 && (e === 27 && fa(l.type) && (a = l.stateNode, t = null), l = l.child, l !== null))
                for (mc(l, t, a), l = l.sibling; l !== null;) mc(l, t, a), l = l.sibling
        }

        function sn(l, t, a) {
            var e = l.tag;
            if (e === 5 || e === 6) l = l.stateNode, t ? a.insertBefore(l, t) : a.appendChild(l);
            else if (e !== 4 && (e === 27 && fa(l.type) && (a = l.stateNode), l = l.child, l !== null))
                for (sn(l, t, a), l = l.sibling; l !== null;) sn(l, t, a), l = l.sibling
        }

        function F0(l) {
            var t = l.stateNode,
                a = l.memoizedProps;
            try {
                for (var e = l.type, u = t.attributes; u.length;) t.removeAttributeNode(u[0]);
                wl(t, e, a), t[Ll] = l, t[Jl] = a
            } catch (n) {
                hl(l, l.return, n)
            }
        }
        var wt = !1,
            Ml = !1,
            gc = !1,
            I0 = typeof WeakSet == "function" ? WeakSet : Set,
            Yl = null;

        function cr(l, t) {
            if (l = l.containerInfo, Qc = xn, l = ss(l), yi(l)) {
                if ("selectionStart" in l) var a = {
                    start: l.selectionStart,
                    end: l.selectionEnd
                };
                else l: {
                    a = (a = l.ownerDocument) && a.defaultView || window;
                    var e = a.getSelection && a.getSelection();
                    if (e && e.rangeCount !== 0) {
                        a = e.anchorNode;
                        var u = e.anchorOffset,
                            n = e.focusNode;
                        e = e.focusOffset;
                        try {
                            a.nodeType, n.nodeType
                        } catch {
                            a = null;
                            break l
                        }
                        var i = 0,
                            c = -1,
                            f = -1,
                            h = 0,
                            g = 0,
                            E = l,
                            v = null;
                        t: for (;;) {
                            for (var y; E !== a || u !== 0 && E.nodeType !== 3 || (c = i + u), E !== n || e !== 0 && E.nodeType !== 3 || (f = i + e), E.nodeType === 3 && (i += E.nodeValue.length), (y = E.firstChild) !== null;) v = E, E = y;
                            for (;;) {
                                if (E === l) break t;
                                if (v === a && ++h === u && (c = i), v === n && ++g === e && (f = i), (y = E.nextSibling) !== null) break;
                                E = v, v = E.parentNode
                            }
                            E = y
                        }
                        a = c === -1 || f === -1 ? null : {
                            start: c,
                            end: f
                        }
                    } else a = null
                }
                a = a || {
                    start: 0,
                    end: 0
                }
            } else a = null;
            for (Xc = {
                    focusedElem: l,
                    selectionRange: a
                }, xn = !1, Yl = t; Yl !== null;)
                if (t = Yl, l = t.child, (t.subtreeFlags & 1024) !== 0 && l !== null) l.return = t, Yl = l;
                else
                    for (; Yl !== null;) {
                        switch (t = Yl, n = t.alternate, l = t.flags, t.tag) {
                            case 0:
                                break;
                            case 11:
                            case 15:
                                break;
                            case 1:
                                if ((l & 1024) !== 0 && n !== null) {
                                    l = void 0, a = t, u = n.memoizedProps, n = n.memoizedState, e = a.stateNode;
                                    try {
                                        var Y = Ua(a.type, u, a.elementType === a.type);
                                        l = e.getSnapshotBeforeUpdate(Y, n), e.__reactInternalSnapshotBeforeUpdate = l
                                    } catch (N) {
                                        hl(a, a.return, N)
                                    }
                                }
                                break;
                            case 3:
                                if ((l & 1024) !== 0) {
                                    if (l = t.stateNode.containerInfo, a = l.nodeType, a === 9) Vc(l);
                                    else if (a === 1) switch (l.nodeName) {
                                        case "HEAD":
                                        case "HTML":
                                        case "BODY":
                                            Vc(l);
                                            break;
                                        default:
                                            l.textContent = ""
                                    }
                                }
                                break;
                            case 5:
                            case 26:
                            case 27:
                            case 6:
                            case 4:
                            case 17:
                                break;
                            default:
                                if ((l & 1024) !== 0) throw Error(m(163))
                        }
                        if (l = t.sibling, l !== null) {
                            l.return = t.return, Yl = l;
                            break
                        }
                        Yl = t.return
                    }
        }

        function P0(l, t, a) {
            var e = a.flags;
            switch (a.tag) {
                case 0:
                case 11:
                case 15:
                    ta(l, a), e & 4 && Pe(5, a);
                    break;
                case 1:
                    if (ta(l, a), e & 4)
                        if (l = a.stateNode, t === null) try {
                            l.componentDidMount()
                        } catch (i) {
                            hl(a, a.return, i)
                        } else {
                            var u = Ua(a.type, t.memoizedProps);
                            t = t.memoizedState;
                            try {
                                l.componentDidUpdate(u, t, l.__reactInternalSnapshotBeforeUpdate)
                            } catch (i) {
                                hl(a, a.return, i)
                            }
                        }
                    e & 64 && J0(a), e & 512 && lu(a, a.return);
                    break;
                case 3:
                    if (ta(l, a), e & 64 && (l = a.updateQueue, l !== null)) {
                        if (t = null, a.child !== null) switch (a.child.tag) {
                            case 27:
                            case 5:
                                t = a.child.stateNode;
                                break;
                            case 1:
                                t = a.child.stateNode
                        }
                        try {
                            qs(l, t)
                        } catch (i) {
                            hl(a, a.return, i)
                        }
                    }
                    break;
                case 27:
                    t === null && e & 4 && F0(a);
                case 26:
                case 5:
                    ta(l, a), t === null && e & 4 && W0(a), e & 512 && lu(a, a.return);
                    break;
                case 12:
                    ta(l, a);
                    break;
                case 13:
                    ta(l, a), e & 4 && ao(l, a), e & 64 && (l = a.memoizedState, l !== null && (l = l.dehydrated, l !== null && (a = mr.bind(null, a), qr(l, a))));
                    break;
                case 22:
                    if (e = a.memoizedState !== null || wt, !e) {
                        t = t !== null && t.memoizedState !== null || Ml, u = wt;
                        var n = Ml;
                        wt = e, (Ml = t) && !n ? aa(l, a, (a.subtreeFlags & 8772) !== 0) : ta(l, a), wt = u, Ml = n
                    }
                    break;
                case 30:
                    break;
                default:
                    ta(l, a)
            }
        }

        function lo(l) {
            var t = l.alternate;
            t !== null && (l.alternate = null, lo(t)), l.child = null, l.deletions = null, l.sibling = null, l.tag === 5 && (t = l.stateNode, t !== null && $n(t)), l.stateNode = null, l.return = null, l.dependencies = null, l.memoizedProps = null, l.memoizedState = null, l.pendingProps = null, l.stateNode = null, l.updateQueue = null
        }
        var bl = null,
            $l = !1;

        function Gt(l, t, a) {
            for (a = a.child; a !== null;) to(l, t, a), a = a.sibling
        }

        function to(l, t, a) {
            if (Pl && typeof Pl.onCommitFiberUnmount == "function") try {
                Pl.onCommitFiberUnmount(Te, a)
            } catch {}
            switch (a.tag) {
                case 26:
                    Ml || At(a, t), Gt(l, t, a), a.memoizedState ? a.memoizedState.count-- : a.stateNode && (a = a.stateNode, a.parentNode.removeChild(a));
                    break;
                case 27:
                    Ml || At(a, t);
                    var e = bl,
                        u = $l;
                    fa(a.type) && (bl = a.stateNode, $l = !1), Gt(l, t, a), su(a.stateNode), bl = e, $l = u;
                    break;
                case 5:
                    Ml || At(a, t);
                case 6:
                    if (e = bl, u = $l, bl = null, Gt(l, t, a), bl = e, $l = u, bl !== null)
                        if ($l) try {
                            (bl.nodeType === 9 ? bl.body : bl.nodeName === "HTML" ? bl.ownerDocument.body : bl).removeChild(a.stateNode)
                        } catch (n) {
                            hl(a, t, n)
                        } else try {
                            bl.removeChild(a.stateNode)
                        } catch (n) {
                            hl(a, t, n)
                        }
                    break;
                case 18:
                    bl !== null && ($l ? (l = bl, Lo(l.nodeType === 9 ? l.body : l.nodeName === "HTML" ? l.ownerDocument.body : l, a.stateNode), gu(l)) : Lo(bl, a.stateNode));
                    break;
                case 4:
                    e = bl, u = $l, bl = a.stateNode.containerInfo, $l = !0, Gt(l, t, a), bl = e, $l = u;
                    break;
                case 0:
                case 11:
                case 14:
                case 15:
                    Ml || la(2, a, t), Ml || la(4, a, t), Gt(l, t, a);
                    break;
                case 1:
                    Ml || (At(a, t), e = a.stateNode, typeof e.componentWillUnmount == "function" && k0(a, t, e)), Gt(l, t, a);
                    break;
                case 21:
                    Gt(l, t, a);
                    break;
                case 22:
                    Ml = (e = Ml) || a.memoizedState !== null, Gt(l, t, a), Ml = e;
                    break;
                default:
                    Gt(l, t, a)
            }
        }

        function ao(l, t) {
            if (t.memoizedState === null && (l = t.alternate, l !== null && (l = l.memoizedState, l !== null && (l = l.dehydrated, l !== null)))) try {
                gu(l)
            } catch (a) {
                hl(t, t.return, a)
            }
        }

        function fr(l) {
            switch (l.tag) {
                case 13:
                case 19:
                    var t = l.stateNode;
                    return t === null && (t = l.stateNode = new I0), t;
                case 22:
                    return l = l.stateNode, t = l._retryCache, t === null && (t = l._retryCache = new I0), t;
                default:
                    throw Error(m(435, l.tag))
            }
        }

        function pc(l, t) {
            var a = fr(l);
            t.forEach(function(e) {
                var u = gr.bind(null, l, e);
                a.has(e) || (a.add(e), e.then(u, u))
            })
        }

        function et(l, t) {
            var a = t.deletions;
            if (a !== null)
                for (var e = 0; e < a.length; e++) {
                    var u = a[e],
                        n = l,
                        i = t,
                        c = i;
                    l: for (; c !== null;) {
                        switch (c.tag) {
                            case 27:
                                if (fa(c.type)) {
                                    bl = c.stateNode, $l = !1;
                                    break l
                                }
                                break;
                            case 5:
                                bl = c.stateNode, $l = !1;
                                break l;
                            case 3:
                            case 4:
                                bl = c.stateNode.containerInfo, $l = !0;
                                break l
                        }
                        c = c.return
                    }
                    if (bl === null) throw Error(m(160));
                    to(n, i, u), bl = null, $l = !1, n = u.alternate, n !== null && (n.return = null), u.return = null
                }
            if (t.subtreeFlags & 13878)
                for (t = t.child; t !== null;) eo(t, l), t = t.sibling
        }
        var pt = null;

        function eo(l, t) {
            var a = l.alternate,
                e = l.flags;
            switch (l.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    et(t, l), ut(l), e & 4 && (la(3, l, l.return), Pe(3, l), la(5, l, l.return));
                    break;
                case 1:
                    et(t, l), ut(l), e & 512 && (Ml || a === null || At(a, a.return)), e & 64 && wt && (l = l.updateQueue, l !== null && (e = l.callbacks, e !== null && (a = l.shared.hiddenCallbacks, l.shared.hiddenCallbacks = a === null ? e : a.concat(e))));
                    break;
                case 26:
                    var u = pt;
                    if (et(t, l), ut(l), e & 512 && (Ml || a === null || At(a, a.return)), e & 4) {
                        var n = a !== null ? a.memoizedState : null;
                        if (e = l.memoizedState, a === null)
                            if (e === null)
                                if (l.stateNode === null) {
                                    l: {
                                        e = l.type,
                                        a = l.memoizedProps,
                                        u = u.ownerDocument || u;t: switch (e) {
                                            case "title":
                                                n = u.getElementsByTagName("title")[0], (!n || n[ze] || n[Ll] || n.namespaceURI === "http://www.w3.org/2000/svg" || n.hasAttribute("itemprop")) && (n = u.createElement(e), u.head.insertBefore(n, u.querySelector("head > title"))), wl(n, e, a), n[Ll] = l, Hl(n), e = n;
                                                break l;
                                            case "link":
                                                var i = Io("link", "href", u).get(e + (a.href || ""));
                                                if (i) {
                                                    for (var c = 0; c < i.length; c++)
                                                        if (n = i[c], n.getAttribute("href") === (a.href == null || a.href === "" ? null : a.href) && n.getAttribute("rel") === (a.rel == null ? null : a.rel) && n.getAttribute("title") === (a.title == null ? null : a.title) && n.getAttribute("crossorigin") === (a.crossOrigin == null ? null : a.crossOrigin)) {
                                                            i.splice(c, 1);
                                                            break t
                                                        }
                                                }
                                                n = u.createElement(e), wl(n, e, a), u.head.appendChild(n);
                                                break;
                                            case "meta":
                                                if (i = Io("meta", "content", u).get(e + (a.content || ""))) {
                                                    for (c = 0; c < i.length; c++)
                                                        if (n = i[c], n.getAttribute("content") === (a.content == null ? null : "" + a.content) && n.getAttribute("name") === (a.name == null ? null : a.name) && n.getAttribute("property") === (a.property == null ? null : a.property) && n.getAttribute("http-equiv") === (a.httpEquiv == null ? null : a.httpEquiv) && n.getAttribute("charset") === (a.charSet == null ? null : a.charSet)) {
                                                            i.splice(c, 1);
                                                            break t
                                                        }
                                                }
                                                n = u.createElement(e), wl(n, e, a), u.head.appendChild(n);
                                                break;
                                            default:
                                                throw Error(m(468, e))
                                        }
                                        n[Ll] = l,
                                        Hl(n),
                                        e = n
                                    }
                                    l.stateNode = e
                                }
                        else Po(u, l.type, l.stateNode);
                        else l.stateNode = Fo(u, e, l.memoizedProps);
                        else n !== e ? (n === null ? a.stateNode !== null && (a = a.stateNode, a.parentNode.removeChild(a)) : n.count--, e === null ? Po(u, l.type, l.stateNode) : Fo(u, e, l.memoizedProps)) : e === null && l.stateNode !== null && vc(l, l.memoizedProps, a.memoizedProps)
                    }
                    break;
                case 27:
                    et(t, l), ut(l), e & 512 && (Ml || a === null || At(a, a.return)), a !== null && e & 4 && vc(l, l.memoizedProps, a.memoizedProps);
                    break;
                case 5:
                    if (et(t, l), ut(l), e & 512 && (Ml || a === null || At(a, a.return)), l.flags & 32) {
                        u = l.stateNode;
                        try {
                            Qa(u, "")
                        } catch (y) {
                            hl(l, l.return, y)
                        }
                    }
                    e & 4 && l.stateNode != null && (u = l.memoizedProps, vc(l, u, a !== null ? a.memoizedProps : u)), e & 1024 && (gc = !0);
                    break;
                case 6:
                    if (et(t, l), ut(l), e & 4) {
                        if (l.stateNode === null) throw Error(m(162));
                        e = l.memoizedProps, a = l.stateNode;
                        try {
                            a.nodeValue = e
                        } catch (y) {
                            hl(l, l.return, y)
                        }
                    }
                    break;
                case 3:
                    if (zn = null, u = pt, pt = En(t.containerInfo), et(t, l), pt = u, ut(l), e & 4 && a !== null && a.memoizedState.isDehydrated) try {
                        gu(t.containerInfo)
                    } catch (y) {
                        hl(l, l.return, y)
                    }
                    gc && (gc = !1, uo(l));
                    break;
                case 4:
                    e = pt, pt = En(l.stateNode.containerInfo), et(t, l), ut(l), pt = e;
                    break;
                case 12:
                    et(t, l), ut(l);
                    break;
                case 13:
                    et(t, l), ut(l), l.child.flags & 8192 && l.memoizedState !== null != (a !== null && a.memoizedState !== null) && (zc = St()), e & 4 && (e = l.updateQueue, e !== null && (l.updateQueue = null, pc(l, e)));
                    break;
                case 22:
                    u = l.memoizedState !== null;
                    var f = a !== null && a.memoizedState !== null,
                        h = wt,
                        g = Ml;
                    if (wt = h || u, Ml = g || f, et(t, l), Ml = g, wt = h, ut(l), e & 8192) l: for (t = l.stateNode, t._visibility = u ? t._visibility & -2 : t._visibility | 1, u && (a === null || f || wt || Ml || Ra(l)), a = null, t = l;;) {
                        if (t.tag === 5 || t.tag === 26) {
                            if (a === null) {
                                f = a = t;
                                try {
                                    if (n = f.stateNode, u) i = n.style, typeof i.setProperty == "function" ? i.setProperty("display", "none", "important") : i.display = "none";
                                    else {
                                        c = f.stateNode;
                                        var E = f.memoizedProps.style,
                                            v = E != null && E.hasOwnProperty("display") ? E.display : null;
                                        c.style.display = v == null || typeof v == "boolean" ? "" : ("" + v).trim()
                                    }
                                } catch (y) {
                                    hl(f, f.return, y)
                                }
                            }
                        } else if (t.tag === 6) {
                            if (a === null) {
                                f = t;
                                try {
                                    f.stateNode.nodeValue = u ? "" : f.memoizedProps
                                } catch (y) {
                                    hl(f, f.return, y)
                                }
                            }
                        } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === l) && t.child !== null) {
                            t.child.return = t, t = t.child;
                            continue
                        }
                        if (t === l) break l;
                        for (; t.sibling === null;) {
                            if (t.return === null || t.return === l) break l;
                            a === t && (a = null), t = t.return
                        }
                        a === t && (a = null), t.sibling.return = t.return, t = t.sibling
                    }
                    e & 4 && (e = l.updateQueue, e !== null && (a = e.retryQueue, a !== null && (e.retryQueue = null, pc(l, a))));
                    break;
                case 19:
                    et(t, l), ut(l), e & 4 && (e = l.updateQueue, e !== null && (l.updateQueue = null, pc(l, e)));
                    break;
                case 30:
                    break;
                case 21:
                    break;
                default:
                    et(t, l), ut(l)
            }
        }

        function ut(l) {
            var t = l.flags;
            if (t & 2) {
                try {
                    for (var a, e = l.return; e !== null;) {
                        if ($0(e)) {
                            a = e;
                            break
                        }
                        e = e.return
                    }
                    if (a == null) throw Error(m(160));
                    switch (a.tag) {
                        case 27:
                            var u = a.stateNode,
                                n = yc(l);
                            sn(l, n, u);
                            break;
                        case 5:
                            var i = a.stateNode;
                            a.flags & 32 && (Qa(i, ""), a.flags &= -33);
                            var c = yc(l);
                            sn(l, c, i);
                            break;
                        case 3:
                        case 4:
                            var f = a.stateNode.containerInfo,
                                h = yc(l);
                            mc(l, h, f);
                            break;
                        default:
                            throw Error(m(161))
                    }
                } catch (g) {
                    hl(l, l.return, g)
                }
                l.flags &= -3
            }
            t & 4096 && (l.flags &= -4097)
        }

        function uo(l) {
            if (l.subtreeFlags & 1024)
                for (l = l.child; l !== null;) {
                    var t = l;
                    uo(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), l = l.sibling
                }
        }

        function ta(l, t) {
            if (t.subtreeFlags & 8772)
                for (t = t.child; t !== null;) P0(l, t.alternate, t), t = t.sibling
        }

        function Ra(l) {
            for (l = l.child; l !== null;) {
                var t = l;
                switch (t.tag) {
                    case 0:
                    case 11:
                    case 14:
                    case 15:
                        la(4, t, t.return), Ra(t);
                        break;
                    case 1:
                        At(t, t.return);
                        var a = t.stateNode;
                        typeof a.componentWillUnmount == "function" && k0(t, t.return, a), Ra(t);
                        break;
                    case 27:
                        su(t.stateNode);
                    case 26:
                    case 5:
                        At(t, t.return), Ra(t);
                        break;
                    case 22:
                        t.memoizedState === null && Ra(t);
                        break;
                    case 30:
                        Ra(t);
                        break;
                    default:
                        Ra(t)
                }
                l = l.sibling
            }
        }

        function aa(l, t, a) {
            for (a = a && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null;) {
                var e = t.alternate,
                    u = l,
                    n = t,
                    i = n.flags;
                switch (n.tag) {
                    case 0:
                    case 11:
                    case 15:
                        aa(u, n, a), Pe(4, n);
                        break;
                    case 1:
                        if (aa(u, n, a), e = n, u = e.stateNode, typeof u.componentDidMount == "function") try {
                            u.componentDidMount()
                        } catch (h) {
                            hl(e, e.return, h)
                        }
                        if (e = n, u = e.updateQueue, u !== null) {
                            var c = e.stateNode;
                            try {
                                var f = u.shared.hiddenCallbacks;
                                if (f !== null)
                                    for (u.shared.hiddenCallbacks = null, u = 0; u < f.length; u++) Hs(f[u], c)
                            } catch (h) {
                                hl(e, e.return, h)
                            }
                        }
                        a && i & 64 && J0(n), lu(n, n.return);
                        break;
                    case 27:
                        F0(n);
                    case 26:
                    case 5:
                        aa(u, n, a), a && e === null && i & 4 && W0(n), lu(n, n.return);
                        break;
                    case 12:
                        aa(u, n, a);
                        break;
                    case 13:
                        aa(u, n, a), a && i & 4 && ao(u, n);
                        break;
                    case 22:
                        n.memoizedState === null && aa(u, n, a), lu(n, n.return);
                        break;
                    case 30:
                        break;
                    default:
                        aa(u, n, a)
                }
                t = t.sibling
            }
        }

        function bc(l, t) {
            var a = null;
            l !== null && l.memoizedState !== null && l.memoizedState.cachePool !== null && (a = l.memoizedState.cachePool.pool), l = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (l = t.memoizedState.cachePool.pool), l !== a && (l != null && l.refCount++, a != null && we(a))
        }

        function Sc(l, t) {
            l = null, t.alternate !== null && (l = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== l && (t.refCount++, l != null && we(l))
        }

        function zt(l, t, a, e) {
            if (t.subtreeFlags & 10256)
                for (t = t.child; t !== null;) no(l, t, a, e), t = t.sibling
        }

        function no(l, t, a, e) {
            var u = t.flags;
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    zt(l, t, a, e), u & 2048 && Pe(9, t);
                    break;
                case 1:
                    zt(l, t, a, e);
                    break;
                case 3:
                    zt(l, t, a, e), u & 2048 && (l = null, t.alternate !== null && (l = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== l && (t.refCount++, l != null && we(l)));
                    break;
                case 12:
                    if (u & 2048) {
                        zt(l, t, a, e), l = t.stateNode;
                        try {
                            var n = t.memoizedProps,
                                i = n.id,
                                c = n.onPostCommit;
                            typeof c == "function" && c(i, t.alternate === null ? "mount" : "update", l.passiveEffectDuration, -0)
                        } catch (f) {
                            hl(t, t.return, f)
                        }
                    } else zt(l, t, a, e);
                    break;
                case 13:
                    zt(l, t, a, e);
                    break;
                case 23:
                    break;
                case 22:
                    n = t.stateNode, i = t.alternate, t.memoizedState !== null ? n._visibility & 2 ? zt(l, t, a, e) : tu(l, t) : n._visibility & 2 ? zt(l, t, a, e) : (n._visibility |= 2, ie(l, t, a, e, (t.subtreeFlags & 10256) !== 0)), u & 2048 && bc(i, t);
                    break;
                case 24:
                    zt(l, t, a, e), u & 2048 && Sc(t.alternate, t);
                    break;
                default:
                    zt(l, t, a, e)
            }
        }

        function ie(l, t, a, e, u) {
            for (u = u && (t.subtreeFlags & 10256) !== 0, t = t.child; t !== null;) {
                var n = l,
                    i = t,
                    c = a,
                    f = e,
                    h = i.flags;
                switch (i.tag) {
                    case 0:
                    case 11:
                    case 15:
                        ie(n, i, c, f, u), Pe(8, i);
                        break;
                    case 23:
                        break;
                    case 22:
                        var g = i.stateNode;
                        i.memoizedState !== null ? g._visibility & 2 ? ie(n, i, c, f, u) : tu(n, i) : (g._visibility |= 2, ie(n, i, c, f, u)), u && h & 2048 && bc(i.alternate, i);
                        break;
                    case 24:
                        ie(n, i, c, f, u), u && h & 2048 && Sc(i.alternate, i);
                        break;
                    default:
                        ie(n, i, c, f, u)
                }
                t = t.sibling
            }
        }

        function tu(l, t) {
            if (t.subtreeFlags & 10256)
                for (t = t.child; t !== null;) {
                    var a = l,
                        e = t,
                        u = e.flags;
                    switch (e.tag) {
                        case 22:
                            tu(a, e), u & 2048 && bc(e.alternate, e);
                            break;
                        case 24:
                            tu(a, e), u & 2048 && Sc(e.alternate, e);
                            break;
                        default:
                            tu(a, e)
                    }
                    t = t.sibling
                }
        }
        var au = 8192;

        function ce(l) {
            if (l.subtreeFlags & au)
                for (l = l.child; l !== null;) io(l), l = l.sibling
        }

        function io(l) {
            switch (l.tag) {
                case 26:
                    ce(l), l.flags & au && l.memoizedState !== null && Jr(pt, l.memoizedState, l.memoizedProps);
                    break;
                case 5:
                    ce(l);
                    break;
                case 3:
                case 4:
                    var t = pt;
                    pt = En(l.stateNode.containerInfo), ce(l), pt = t;
                    break;
                case 22:
                    l.memoizedState === null && (t = l.alternate, t !== null && t.memoizedState !== null ? (t = au, au = 16777216, ce(l), au = t) : ce(l));
                    break;
                default:
                    ce(l)
            }
        }

        function co(l) {
            var t = l.alternate;
            if (t !== null && (l = t.child, l !== null)) {
                t.child = null;
                do t = l.sibling, l.sibling = null, l = t; while (l !== null)
            }
        }

        function eu(l) {
            var t = l.deletions;
            if ((l.flags & 16) !== 0) {
                if (t !== null)
                    for (var a = 0; a < t.length; a++) {
                        var e = t[a];
                        Yl = e, so(e, l)
                    }
                co(l)
            }
            if (l.subtreeFlags & 10256)
                for (l = l.child; l !== null;) fo(l), l = l.sibling
        }

        function fo(l) {
            switch (l.tag) {
                case 0:
                case 11:
                case 15:
                    eu(l), l.flags & 2048 && la(9, l, l.return);
                    break;
                case 3:
                    eu(l);
                    break;
                case 12:
                    eu(l);
                    break;
                case 22:
                    var t = l.stateNode;
                    l.memoizedState !== null && t._visibility & 2 && (l.return === null || l.return.tag !== 13) ? (t._visibility &= -3, on(l)) : eu(l);
                    break;
                default:
                    eu(l)
            }
        }

        function on(l) {
            var t = l.deletions;
            if ((l.flags & 16) !== 0) {
                if (t !== null)
                    for (var a = 0; a < t.length; a++) {
                        var e = t[a];
                        Yl = e, so(e, l)
                    }
                co(l)
            }
            for (l = l.child; l !== null;) {
                switch (t = l, t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        la(8, t, t.return), on(t);
                        break;
                    case 22:
                        a = t.stateNode, a._visibility & 2 && (a._visibility &= -3, on(t));
                        break;
                    default:
                        on(t)
                }
                l = l.sibling
            }
        }

        function so(l, t) {
            for (; Yl !== null;) {
                var a = Yl;
                switch (a.tag) {
                    case 0:
                    case 11:
                    case 15:
                        la(8, a, t);
                        break;
                    case 23:
                    case 22:
                        if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
                            var e = a.memoizedState.cachePool.pool;
                            e != null && e.refCount++
                        }
                        break;
                    case 24:
                        we(a.memoizedState.cache)
                }
                if (e = a.child, e !== null) e.return = a, Yl = e;
                else l: for (a = l; Yl !== null;) {
                    e = Yl;
                    var u = e.sibling,
                        n = e.return;
                    if (lo(e), e === a) {
                        Yl = null;
                        break l
                    }
                    if (u !== null) {
                        u.return = n, Yl = u;
                        break l
                    }
                    Yl = n
                }
            }
        }
        var sr = {
                getCacheForType: function(l) {
                    var t = Vl(Dl),
                        a = t.data.get(l);
                    return a === void 0 && (a = l(), t.data.set(l, a)), a
                }
            },
            or = typeof WeakMap == "function" ? WeakMap : Map,
            cl = 0,
            yl = null,
            J = null,
            I = 0,
            fl = 0,
            nt = null,
            ea = !1,
            fe = !1,
            Tc = !1,
            Qt = 0,
            Al = 0,
            ua = 0,
            Na = 0,
            Ec = 0,
            yt = 0,
            se = 0,
            uu = null,
            Fl = null,
            Ac = !1,
            zc = 0,
            dn = 1 / 0,
            rn = null,
            na = null,
            jl = 0,
            ia = null,
            oe = null,
            de = 0,
            Mc = 0,
            _c = null,
            oo = null,
            nu = 0,
            xc = null;

        function it() {
            if ((cl & 2) !== 0 && I !== 0) return I & -I;
            if (b.T !== null) {
                var l = Ia;
                return l !== 0 ? l : qc()
            }
            return _f()
        }

        function ro() {
            yt === 0 && (yt = (I & 536870912) === 0 || al ? Ef() : 536870912);
            var l = vt.current;
            return l !== null && (l.flags |= 32), yt
        }

        function ct(l, t, a) {
            (l === yl && (fl === 2 || fl === 9) || l.cancelPendingCommit !== null) && (re(l, 0), ca(l, I, yt, !1)), Ae(l, a), ((cl & 2) === 0 || l !== yl) && (l === yl && ((cl & 2) === 0 && (Na |= a), Al === 4 && ca(l, I, yt, !1)), Mt(l))
        }

        function ho(l, t, a) {
            if ((cl & 6) !== 0) throw Error(m(327));
            var e = !a && (t & 124) === 0 && (t & l.expiredLanes) === 0 || Ee(l, t),
                u = e ? hr(l, t) : Uc(l, t, !0),
                n = e;
            do {
                if (u === 0) {
                    fe && !e && ca(l, t, 0, !1);
                    break
                } else {
                    if (a = l.current.alternate, n && !dr(a)) {
                        u = Uc(l, t, !1), n = !1;
                        continue
                    }
                    if (u === 2) {
                        if (n = t, l.errorRecoveryDisabledLanes & n) var i = 0;
                        else i = l.pendingLanes & -536870913, i = i !== 0 ? i : i & 536870912 ? 536870912 : 0;
                        if (i !== 0) {
                            t = i;
                            l: {
                                var c = l;u = uu;
                                var f = c.current.memoizedState.isDehydrated;
                                if (f && (re(c, i).flags |= 256), i = Uc(c, i, !1), i !== 2) {
                                    if (Tc && !f) {
                                        c.errorRecoveryDisabledLanes |= n, Na |= n, u = 4;
                                        break l
                                    }
                                    n = Fl, Fl = u, n !== null && (Fl === null ? Fl = n : Fl.push.apply(Fl, n))
                                }
                                u = i
                            }
                            if (n = !1, u !== 2) continue
                        }
                    }
                    if (u === 1) {
                        re(l, 0), ca(l, t, 0, !0);
                        break
                    }
                    l: {
                        switch (e = l, n = u, n) {
                            case 0:
                            case 1:
                                throw Error(m(345));
                            case 4:
                                if ((t & 4194048) !== t) break;
                            case 6:
                                ca(e, t, yt, !ea);
                                break l;
                            case 2:
                                Fl = null;
                                break;
                            case 3:
                            case 5:
                                break;
                            default:
                                throw Error(m(329))
                        }
                        if ((t & 62914560) === t && (u = zc + 300 - St(), 10 < u)) {
                            if (ca(e, t, yt, !ea), Eu(e, 0, !0) !== 0) break l;
                            e.timeoutHandle = Xo(vo.bind(null, e, a, Fl, rn, Ac, t, yt, Na, se, ea, n, 2, -0, 0), u);
                            break l
                        }
                        vo(e, a, Fl, rn, Ac, t, yt, Na, se, ea, n, 0, -0, 0)
                    }
                }
                break
            } while (!0);
            Mt(l)
        }

        function vo(l, t, a, e, u, n, i, c, f, h, g, E, v, y) {
            if (l.timeoutHandle = -1, E = t.subtreeFlags, (E & 8192 || (E & 16785408) === 16785408) && (ru = {
                    stylesheets: null,
                    count: 0,
                    unsuspend: Kr
                }, io(t), E = kr(), E !== null)) {
                l.cancelPendingCommit = E(To.bind(null, l, t, n, a, e, u, i, c, f, g, 1, v, y)), ca(l, n, i, !h);
                return
            }
            To(l, t, n, a, e, u, i, c, f)
        }

        function dr(l) {
            for (var t = l;;) {
                var a = t.tag;
                if ((a === 0 || a === 11 || a === 15) && t.flags & 16384 && (a = t.updateQueue, a !== null && (a = a.stores, a !== null)))
                    for (var e = 0; e < a.length; e++) {
                        var u = a[e],
                            n = u.getSnapshot;
                        u = u.value;
                        try {
                            if (!tt(n(), u)) return !1
                        } catch {
                            return !1
                        }
                    }
                if (a = t.child, t.subtreeFlags & 16384 && a !== null) a.return = t, t = a;
                else {
                    if (t === l) break;
                    for (; t.sibling === null;) {
                        if (t.return === null || t.return === l) return !0;
                        t = t.return
                    }
                    t.sibling.return = t.return, t = t.sibling
                }
            }
            return !0
        }

        function ca(l, t, a, e) {
            t &= ~Ec, t &= ~Na, l.suspendedLanes |= t, l.pingedLanes &= ~t, e && (l.warmLanes |= t), e = l.expirationTimes;
            for (var u = t; 0 < u;) {
                var n = 31 - lt(u),
                    i = 1 << n;
                e[n] = -1, u &= ~i
            }
            a !== 0 && zf(l, a, t)
        }

        function hn() {
            return (cl & 6) === 0 ? (iu(0), !1) : !0
        }

        function Oc() {
            if (J !== null) {
                if (fl === 0) var l = J.return;
                else l = J, Ht = _a = null, Vi(l), ue = null, $e = 0, l = J;
                for (; l !== null;) K0(l.alternate, l), l = l.return;
                J = null
            }
        }

        function re(l, t) {
            var a = l.timeoutHandle;
            a !== -1 && (l.timeoutHandle = -1, Dr(a)), a = l.cancelPendingCommit, a !== null && (l.cancelPendingCommit = null, a()), Oc(), yl = l, J = a = Ut(l.current, null), I = t, fl = 0, nt = null, ea = !1, fe = Ee(l, t), Tc = !1, se = yt = Ec = Na = ua = Al = 0, Fl = uu = null, Ac = !1, (t & 8) !== 0 && (t |= t & 32);
            var e = l.entangledLanes;
            if (e !== 0)
                for (l = l.entanglements, e &= t; 0 < e;) {
                    var u = 31 - lt(e),
                        n = 1 << u;
                    t |= l[u], e &= ~n
                }
            return Qt = t, qu(), a
        }

        function yo(l, t) {
            G = null, b.H = Pu, t === Qe || t === Zu ? (t = Rs(), fl = 3) : t === Os ? (t = Rs(), fl = 4) : fl = t === N0 ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, nt = t, J === null && (Al = 1, un(l, ot(t, l.current)))
        }

        function mo() {
            var l = b.H;
            return b.H = Pu, l === null ? Pu : l
        }

        function go() {
            var l = b.A;
            return b.A = sr, l
        }

        function Dc() {
            Al = 4, ea || (I & 4194048) !== I && vt.current !== null || (fe = !0), (ua & 134217727) === 0 && (Na & 134217727) === 0 || yl === null || ca(yl, I, yt, !1)
        }

        function Uc(l, t, a) {
            var e = cl;
            cl |= 2;
            var u = mo(),
                n = go();
            (yl !== l || I !== t) && (rn = null, re(l, t)), t = !1;
            var i = Al;
            l: do try {
                    if (fl !== 0 && J !== null) {
                        var c = J,
                            f = nt;
                        switch (fl) {
                            case 8:
                                Oc(), i = 6;
                                break l;
                            case 3:
                            case 2:
                            case 9:
                            case 6:
                                vt.current === null && (t = !0);
                                var h = fl;
                                if (fl = 0, nt = null, he(l, c, f, h), a && fe) {
                                    i = 0;
                                    break l
                                }
                                break;
                            default:
                                h = fl, fl = 0, nt = null, he(l, c, f, h)
                        }
                    }
                    rr(), i = Al;
                    break
                } catch (g) {
                    yo(l, g)
                }
                while (!0);
                return t && l.shellSuspendCounter++, Ht = _a = null, cl = e, b.H = u, b.A = n, J === null && (yl = null, I = 0, qu()), i
        }

        function rr() {
            for (; J !== null;) po(J)
        }

        function hr(l, t) {
            var a = cl;
            cl |= 2;
            var e = mo(),
                u = go();
            yl !== l || I !== t ? (rn = null, dn = St() + 500, re(l, t)) : fe = Ee(l, t);
            l: do try {
                    if (fl !== 0 && J !== null) {
                        t = J;
                        var n = nt;
                        t: switch (fl) {
                            case 1:
                                fl = 0, nt = null, he(l, t, n, 1);
                                break;
                            case 2:
                            case 9:
                                if (Ds(n)) {
                                    fl = 0, nt = null, bo(t);
                                    break
                                }
                                t = function() {
                                    fl !== 2 && fl !== 9 || yl !== l || (fl = 7), Mt(l)
                                }, n.then(t, t);
                                break l;
                            case 3:
                                fl = 7;
                                break l;
                            case 4:
                                fl = 5;
                                break l;
                            case 7:
                                Ds(n) ? (fl = 0, nt = null, bo(t)) : (fl = 0, nt = null, he(l, t, n, 7));
                                break;
                            case 5:
                                var i = null;
                                switch (J.tag) {
                                    case 26:
                                        i = J.memoizedState;
                                    case 5:
                                    case 27:
                                        var c = J;
                                        if (!i || l1(i)) {
                                            fl = 0, nt = null;
                                            var f = c.sibling;
                                            if (f !== null) J = f;
                                            else {
                                                var h = c.return;
                                                h !== null ? (J = h, vn(h)) : J = null
                                            }
                                            break t
                                        }
                                }
                                fl = 0, nt = null, he(l, t, n, 5);
                                break;
                            case 6:
                                fl = 0, nt = null, he(l, t, n, 6);
                                break;
                            case 8:
                                Oc(), Al = 6;
                                break l;
                            default:
                                throw Error(m(462))
                        }
                    }
                    vr();
                    break
                } catch (g) {
                    yo(l, g)
                }
                while (!0);
                return Ht = _a = null, b.H = e, b.A = u, cl = a, J !== null ? 0 : (yl = null, I = 0, qu(), Al)
        }

        function vr() {
            for (; J !== null && !C1();) po(J)
        }

        function po(l) {
            var t = L0(l.alternate, l, Qt);
            l.memoizedProps = l.pendingProps, t === null ? vn(l) : J = t
        }

        function bo(l) {
            var t = l,
                a = t.alternate;
            switch (t.tag) {
                case 15:
                case 0:
                    t = j0(a, t, t.pendingProps, t.type, void 0, I);
                    break;
                case 11:
                    t = j0(a, t, t.pendingProps, t.type.render, t.ref, I);
                    break;
                case 5:
                    Vi(t);
                default:
                    K0(a, t), t = J = bs(t, Qt), t = L0(a, t, Qt)
            }
            l.memoizedProps = l.pendingProps, t === null ? vn(l) : J = t
        }

        function he(l, t, a, e) {
            Ht = _a = null, Vi(t), ue = null, $e = 0;
            var u = t.return;
            try {
                if (er(l, u, t, a, I)) {
                    Al = 1, un(l, ot(a, l.current)), J = null;
                    return
                }
            } catch (n) {
                if (u !== null) throw J = u, n;
                Al = 1, un(l, ot(a, l.current)), J = null;
                return
            }
            t.flags & 32768 ? (al || e === 1 ? l = !0 : fe || (I & 536870912) !== 0 ? l = !1 : (ea = l = !0, (e === 2 || e === 9 || e === 3 || e === 6) && (e = vt.current, e !== null && e.tag === 13 && (e.flags |= 16384))), So(t, l)) : vn(t)
        }

        function vn(l) {
            var t = l;
            do {
                if ((t.flags & 32768) !== 0) {
                    So(t, ea);
                    return
                }
                l = t.return;
                var a = nr(t.alternate, t, Qt);
                if (a !== null) {
                    J = a;
                    return
                }
                if (t = t.sibling, t !== null) {
                    J = t;
                    return
                }
                J = t = l
            } while (t !== null);
            Al === 0 && (Al = 5)
        }

        function So(l, t) {
            do {
                var a = ir(l.alternate, l);
                if (a !== null) {
                    a.flags &= 32767, J = a;
                    return
                }
                if (a = l.return, a !== null && (a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null), !t && (l = l.sibling, l !== null)) {
                    J = l;
                    return
                }
                J = l = a
            } while (l !== null);
            Al = 6, J = null
        }

        function To(l, t, a, e, u, n, i, c, f) {
            l.cancelPendingCommit = null;
            do yn(); while (jl !== 0);
            if ((cl & 6) !== 0) throw Error(m(327));
            if (t !== null) {
                if (t === l.current) throw Error(m(177));
                if (n = t.lanes | t.childLanes, n |= Si, K1(l, a, n, i, c, f), l === yl && (J = yl = null, I = 0), oe = t, ia = l, de = a, Mc = n, _c = u, oo = e, (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? (l.callbackNode = null, l.callbackPriority = 0, pr(bu, function() {
                        return _o(), null
                    })) : (l.callbackNode = null, l.callbackPriority = 0), e = (t.flags & 13878) !== 0, (t.subtreeFlags & 13878) !== 0 || e) {
                    e = b.T, b.T = null, u = _.p, _.p = 2, i = cl, cl |= 4;
                    try {
                        cr(l, t, a)
                    } finally {
                        cl = i, _.p = u, b.T = e
                    }
                }
                jl = 1, Eo(), Ao(), zo()
            }
        }

        function Eo() {
            if (jl === 1) {
                jl = 0;
                var l = ia,
                    t = oe,
                    a = (t.flags & 13878) !== 0;
                if ((t.subtreeFlags & 13878) !== 0 || a) {
                    a = b.T, b.T = null;
                    var e = _.p;
                    _.p = 2;
                    var u = cl;
                    cl |= 4;
                    try {
                        eo(t, l);
                        var n = Xc,
                            i = ss(l.containerInfo),
                            c = n.focusedElem,
                            f = n.selectionRange;
                        if (i !== c && c && c.ownerDocument && fs(c.ownerDocument.documentElement, c)) {
                            if (f !== null && yi(c)) {
                                var h = f.start,
                                    g = f.end;
                                if (g === void 0 && (g = h), "selectionStart" in c) c.selectionStart = h, c.selectionEnd = Math.min(g, c.value.length);
                                else {
                                    var E = c.ownerDocument || document,
                                        v = E && E.defaultView || window;
                                    if (v.getSelection) {
                                        var y = v.getSelection(),
                                            Y = c.textContent.length,
                                            N = Math.min(f.start, Y),
                                            dl = f.end === void 0 ? N : Math.min(f.end, Y);
                                        !y.extend && N > dl && (i = dl, dl = N, N = i);
                                        var d = cs(c, N),
                                            o = cs(c, dl);
                                        if (d && o && (y.rangeCount !== 1 || y.anchorNode !== d.node || y.anchorOffset !== d.offset || y.focusNode !== o.node || y.focusOffset !== o.offset)) {
                                            var r = E.createRange();
                                            r.setStart(d.node, d.offset), y.removeAllRanges(), N > dl ? (y.addRange(r), y.extend(o.node, o.offset)) : (r.setEnd(o.node, o.offset), y.addRange(r))
                                        }
                                    }
                                }
                            }
                            for (E = [], y = c; y = y.parentNode;) y.nodeType === 1 && E.push({
                                element: y,
                                left: y.scrollLeft,
                                top: y.scrollTop
                            });
                            for (typeof c.focus == "function" && c.focus(), c = 0; c < E.length; c++) {
                                var S = E[c];
                                S.element.scrollLeft = S.left, S.element.scrollTop = S.top
                            }
                        }
                        xn = !!Qc, Xc = Qc = null
                    } finally {
                        cl = u, _.p = e, b.T = a
                    }
                }
                l.current = t, jl = 2
            }
        }

        function Ao() {
            if (jl === 2) {
                jl = 0;
                var l = ia,
                    t = oe,
                    a = (t.flags & 8772) !== 0;
                if ((t.subtreeFlags & 8772) !== 0 || a) {
                    a = b.T, b.T = null;
                    var e = _.p;
                    _.p = 2;
                    var u = cl;
                    cl |= 4;
                    try {
                        P0(l, t.alternate, t)
                    } finally {
                        cl = u, _.p = e, b.T = a
                    }
                }
                jl = 3
            }
        }

        function zo() {
            if (jl === 4 || jl === 3) {
                jl = 0, B1();
                var l = ia,
                    t = oe,
                    a = de,
                    e = oo;
                (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? jl = 5 : (jl = 0, oe = ia = null, Mo(l, l.pendingLanes));
                var u = l.pendingLanes;
                if (u === 0 && (na = null), kn(a), t = t.stateNode, Pl && typeof Pl.onCommitFiberRoot == "function") try {
                    Pl.onCommitFiberRoot(Te, t, void 0, (t.current.flags & 128) === 128)
                } catch {}
                if (e !== null) {
                    t = b.T, u = _.p, _.p = 2, b.T = null;
                    try {
                        for (var n = l.onRecoverableError, i = 0; i < e.length; i++) {
                            var c = e[i];
                            n(c.value, {
                                componentStack: c.stack
                            })
                        }
                    } finally {
                        b.T = t, _.p = u
                    }
                }(de & 3) !== 0 && yn(), Mt(l), u = l.pendingLanes, (a & 4194090) !== 0 && (u & 42) !== 0 ? l === xc ? nu++ : (nu = 0, xc = l) : nu = 0, iu(0)
            }
        }

        function Mo(l, t) {
            (l.pooledCacheLanes &= t) === 0 && (t = l.pooledCache, t != null && (l.pooledCache = null, we(t)))
        }

        function yn(l) {
            return Eo(), Ao(), zo(), _o()
        }

        function _o() {
            if (jl !== 5) return !1;
            var l = ia,
                t = Mc;
            Mc = 0;
            var a = kn(de),
                e = b.T,
                u = _.p;
            try {
                _.p = 32 > a ? 32 : a, b.T = null, a = _c, _c = null;
                var n = ia,
                    i = de;
                if (jl = 0, oe = ia = null, de = 0, (cl & 6) !== 0) throw Error(m(331));
                var c = cl;
                if (cl |= 4, fo(n.current), no(n, n.current, i, a), cl = c, iu(0, !1), Pl && typeof Pl.onPostCommitFiberRoot == "function") try {
                    Pl.onPostCommitFiberRoot(Te, n)
                } catch {}
                return !0
            } finally {
                _.p = u, b.T = e, Mo(l, t)
            }
        }

        function xo(l, t, a) {
            t = ot(a, t), t = nc(l.stateNode, t, 2), l = $t(l, t, 2), l !== null && (Ae(l, 2), Mt(l))
        }

        function hl(l, t, a) {
            if (l.tag === 3) xo(l, l, a);
            else
                for (; t !== null;) {
                    if (t.tag === 3) {
                        xo(t, l, a);
                        break
                    } else if (t.tag === 1) {
                        var e = t.stateNode;
                        if (typeof t.type.getDerivedStateFromError == "function" || typeof e.componentDidCatch == "function" && (na === null || !na.has(e))) {
                            l = ot(a, l), a = U0(2), e = $t(t, a, 2), e !== null && (R0(a, e, t, l), Ae(e, 2), Mt(e));
                            break
                        }
                    }
                    t = t.return
                }
        }

        function Rc(l, t, a) {
            var e = l.pingCache;
            if (e === null) {
                e = l.pingCache = new or;
                var u = new Set;
                e.set(t, u)
            } else u = e.get(t), u === void 0 && (u = new Set, e.set(t, u));
            u.has(a) || (Tc = !0, u.add(a), l = yr.bind(null, l, t, a), t.then(l, l))
        }

        function yr(l, t, a) {
            var e = l.pingCache;
            e !== null && e.delete(t), l.pingedLanes |= l.suspendedLanes & a, l.warmLanes &= ~a, yl === l && (I & a) === a && (Al === 4 || Al === 3 && (I & 62914560) === I && 300 > St() - zc ? (cl & 2) === 0 && re(l, 0) : Ec |= a, se === I && (se = 0)), Mt(l)
        }

        function Oo(l, t) {
            t === 0 && (t = Af()), l = ka(l, t), l !== null && (Ae(l, t), Mt(l))
        }

        function mr(l) {
            var t = l.memoizedState,
                a = 0;
            t !== null && (a = t.retryLane), Oo(l, a)
        }

        function gr(l, t) {
            var a = 0;
            switch (l.tag) {
                case 13:
                    var e = l.stateNode,
                        u = l.memoizedState;
                    u !== null && (a = u.retryLane);
                    break;
                case 19:
                    e = l.stateNode;
                    break;
                case 22:
                    e = l.stateNode._retryCache;
                    break;
                default:
                    throw Error(m(314))
            }
            e !== null && e.delete(t), Oo(l, a)
        }

        function pr(l, t) {
            return Ln(l, t)
        }
        var mn = null,
            ve = null,
            Nc = !1,
            gn = !1,
            Hc = !1,
            Ha = 0;

        function Mt(l) {
            l !== ve && l.next === null && (ve === null ? mn = ve = l : ve = ve.next = l), gn = !0, Nc || (Nc = !0, Sr())
        }

        function iu(l, t) {
            if (!Hc && gn) {
                Hc = !0;
                do
                    for (var a = !1, e = mn; e !== null;) {
                        if (l !== 0) {
                            var u = e.pendingLanes;
                            if (u === 0) var n = 0;
                            else {
                                var i = e.suspendedLanes,
                                    c = e.pingedLanes;
                                n = (1 << 31 - lt(42 | l) + 1) - 1, n &= u & ~(i & ~c), n = n & 201326741 ? n & 201326741 | 1 : n ? n | 2 : 0
                            }
                            n !== 0 && (a = !0, No(e, n))
                        } else n = I, n = Eu(e, e === yl ? n : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), (n & 3) === 0 || Ee(e, n) || (a = !0, No(e, n));
                        e = e.next
                    }
                while (a);
                Hc = !1
            }
        }

        function br() {
            Do()
        }

        function Do() {
            gn = Nc = !1;
            var l = 0;
            Ha !== 0 && (Or() && (l = Ha), Ha = 0);
            for (var t = St(), a = null, e = mn; e !== null;) {
                var u = e.next,
                    n = Uo(e, t);
                n === 0 ? (e.next = null, a === null ? mn = u : a.next = u, u === null && (ve = a)) : (a = e, (l !== 0 || (n & 3) !== 0) && (gn = !0)), e = u
            }
            iu(l)
        }

        function Uo(l, t) {
            for (var a = l.suspendedLanes, e = l.pingedLanes, u = l.expirationTimes, n = l.pendingLanes & -62914561; 0 < n;) {
                var i = 31 - lt(n),
                    c = 1 << i,
                    f = u[i];
                f === -1 ? ((c & a) === 0 || (c & e) !== 0) && (u[i] = V1(c, t)) : f <= t && (l.expiredLanes |= c), n &= ~c
            }
            if (t = yl, a = I, a = Eu(l, l === t ? a : 0, l.cancelPendingCommit !== null || l.timeoutHandle !== -1), e = l.callbackNode, a === 0 || l === t && (fl === 2 || fl === 9) || l.cancelPendingCommit !== null) return e !== null && e !== null && Vn(e), l.callbackNode = null, l.callbackPriority = 0;
            if ((a & 3) === 0 || Ee(l, a)) {
                if (t = a & -a, t === l.callbackPriority) return t;
                switch (e !== null && Vn(e), kn(a)) {
                    case 2:
                    case 8:
                        a = Sf;
                        break;
                    case 32:
                        a = bu;
                        break;
                    case 268435456:
                        a = Tf;
                        break;
                    default:
                        a = bu
                }
                return e = Ro.bind(null, l), a = Ln(a, e), l.callbackPriority = t, l.callbackNode = a, t
            }
            return e !== null && e !== null && Vn(e), l.callbackPriority = 2, l.callbackNode = null, 2
        }

        function Ro(l, t) {
            if (jl !== 0 && jl !== 5) return l.callbackNode = null, l.callbackPriority = 0, null;
            var a = l.callbackNode;
            if (yn() && l.callbackNode !== a) return null;
            var e = I;
            return e = Eu(l, l === yl ? e : 0, l.cancelPendingCommit !== null || l.timeoutHandle !== -1), e === 0 ? null : (ho(l, e, t), Uo(l, St()), l.callbackNode != null && l.callbackNode === a ? Ro.bind(null, l) : null)
        }

        function No(l, t) {
            if (yn()) return null;
            ho(l, t, !0)
        }

        function Sr() {
            Ur(function() {
                (cl & 6) !== 0 ? Ln(bf, br) : Do()
            })
        }

        function qc() {
            return Ha === 0 && (Ha = Ef()), Ha
        }

        function Ho(l) {
            return l == null || typeof l == "symbol" || typeof l == "boolean" ? null : typeof l == "function" ? l : xu("" + l)
        }

        function qo(l, t) {
            var a = t.ownerDocument.createElement("input");
            return a.name = t.name, a.value = t.value, l.id && a.setAttribute("form", l.id), t.parentNode.insertBefore(a, t), l = new FormData(l), a.parentNode.removeChild(a), l
        }

        function Tr(l, t, a, e, u) {
            if (t === "submit" && a && a.stateNode === u) {
                var n = Ho((u[Jl] || null).action),
                    i = e.submitter;
                i && (t = (t = i[Jl] || null) ? Ho(t.formAction) : i.getAttribute("formAction"), t !== null && (n = t, i = null));
                var c = new Ru("action", "action", null, e, u);
                l.push({
                    event: c,
                    listeners: [{
                        instance: null,
                        listener: function() {
                            if (e.defaultPrevented) {
                                if (Ha !== 0) {
                                    var f = i ? qo(u, i) : new FormData(u);
                                    lc(a, {
                                        pending: !0,
                                        data: f,
                                        method: u.method,
                                        action: n
                                    }, null, f)
                                }
                            } else typeof n == "function" && (c.preventDefault(), f = i ? qo(u, i) : new FormData(u), lc(a, {
                                pending: !0,
                                data: f,
                                method: u.method,
                                action: n
                            }, n, f))
                        },
                        currentTarget: u
                    }]
                })
            }
        }
        for (var Yc = 0; Yc < bi.length; Yc++) {
            var Cc = bi[Yc],
                Er = Cc.toLowerCase(),
                Ar = Cc[0].toUpperCase() + Cc.slice(1);
            gt(Er, "on" + Ar)
        }
        gt(rs, "onAnimationEnd"), gt(hs, "onAnimationIteration"), gt(vs, "onAnimationStart"), gt("dblclick", "onDoubleClick"), gt("focusin", "onFocus"), gt("focusout", "onBlur"), gt(Gd, "onTransitionRun"), gt(Qd, "onTransitionStart"), gt(Xd, "onTransitionCancel"), gt(ys, "onTransitionEnd"), ja("onMouseEnter", ["mouseout", "mouseover"]), ja("onMouseLeave", ["mouseout", "mouseover"]), ja("onPointerEnter", ["pointerout", "pointerover"]), ja("onPointerLeave", ["pointerout", "pointerover"]), ga("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), ga("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), ga("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), ga("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), ga("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), ga("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
        var cu = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
            zr = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(cu));

        function Yo(l, t) {
            t = (t & 4) !== 0;
            for (var a = 0; a < l.length; a++) {
                var e = l[a],
                    u = e.event;
                e = e.listeners;
                l: {
                    var n = void 0;
                    if (t)
                        for (var i = e.length - 1; 0 <= i; i--) {
                            var c = e[i],
                                f = c.instance,
                                h = c.currentTarget;
                            if (c = c.listener, f !== n && u.isPropagationStopped()) break l;
                            n = c, u.currentTarget = h;
                            try {
                                n(u)
                            } catch (g) {
                                en(g)
                            }
                            u.currentTarget = null, n = f
                        } else
                            for (i = 0; i < e.length; i++) {
                                if (c = e[i], f = c.instance, h = c.currentTarget, c = c.listener, f !== n && u.isPropagationStopped()) break l;
                                n = c, u.currentTarget = h;
                                try {
                                    n(u)
                                } catch (g) {
                                    en(g)
                                }
                                u.currentTarget = null, n = f
                            }
                }
            }
        }

        function k(l, t) {
            var a = t[Wn];
            a === void 0 && (a = t[Wn] = new Set);
            var e = l + "__bubble";
            a.has(e) || (Co(t, l, 2, !1), a.add(e))
        }

        function Bc(l, t, a) {
            var e = 0;
            t && (e |= 4), Co(a, l, e, t)
        }
        var pn = "_reactListening" + Math.random().toString(36).slice(2);

        function jc(l) {
            if (!l[pn]) {
                l[pn] = !0, Of.forEach(function(a) {
                    a !== "selectionchange" && (zr.has(a) || Bc(a, !1, l), Bc(a, !0, l))
                });
                var t = l.nodeType === 9 ? l : l.ownerDocument;
                t === null || t[pn] || (t[pn] = !0, Bc("selectionchange", !1, t))
            }
        }

        function Co(l, t, a, e) {
            switch (i1(t)) {
                case 2:
                    var u = Fr;
                    break;
                case 8:
                    u = Ir;
                    break;
                default:
                    u = Ic
            }
            a = u.bind(null, t, a, l), u = void 0, !ii || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (u = !0), e ? u !== void 0 ? l.addEventListener(t, a, {
                capture: !0,
                passive: u
            }) : l.addEventListener(t, a, !0) : u !== void 0 ? l.addEventListener(t, a, {
                passive: u
            }) : l.addEventListener(t, a, !1)
        }

        function wc(l, t, a, e, u) {
            var n = e;
            if ((t & 1) === 0 && (t & 2) === 0 && e !== null) l: for (;;) {
                if (e === null) return;
                var i = e.tag;
                if (i === 3 || i === 4) {
                    var c = e.stateNode.containerInfo;
                    if (c === u) break;
                    if (i === 4)
                        for (i = e.return; i !== null;) {
                            var f = i.tag;
                            if ((f === 3 || f === 4) && i.stateNode.containerInfo === u) return;
                            i = i.return
                        }
                    for (; c !== null;) {
                        if (i = Ya(c), i === null) return;
                        if (f = i.tag, f === 5 || f === 6 || f === 26 || f === 27) {
                            e = n = i;
                            continue l
                        }
                        c = c.parentNode
                    }
                }
                e = e.return
            }
            Xf(function() {
                var h = n,
                    g = ui(a),
                    E = [];
                l: {
                    var v = ms.get(l);
                    if (v !== void 0) {
                        var y = Ru,
                            Y = l;
                        switch (l) {
                            case "keypress":
                                if (Du(a) === 0) break l;
                            case "keydown":
                            case "keyup":
                                y = pd;
                                break;
                            case "focusin":
                                Y = "focus", y = oi;
                                break;
                            case "focusout":
                                Y = "blur", y = oi;
                                break;
                            case "beforeblur":
                            case "afterblur":
                                y = oi;
                                break;
                            case "click":
                                if (a.button === 2) break l;
                            case "auxclick":
                            case "dblclick":
                            case "mousedown":
                            case "mousemove":
                            case "mouseup":
                            case "mouseout":
                            case "mouseover":
                            case "contextmenu":
                                y = Vf;
                                break;
                            case "drag":
                            case "dragend":
                            case "dragenter":
                            case "dragexit":
                            case "dragleave":
                            case "dragover":
                            case "dragstart":
                            case "drop":
                                y = id;
                                break;
                            case "touchcancel":
                            case "touchend":
                            case "touchmove":
                            case "touchstart":
                                y = Td;
                                break;
                            case rs:
                            case hs:
                            case vs:
                                y = sd;
                                break;
                            case ys:
                                y = Ad;
                                break;
                            case "scroll":
                            case "scrollend":
                                y = ud;
                                break;
                            case "wheel":
                                y = Md;
                                break;
                            case "copy":
                            case "cut":
                            case "paste":
                                y = dd;
                                break;
                            case "gotpointercapture":
                            case "lostpointercapture":
                            case "pointercancel":
                            case "pointerdown":
                            case "pointermove":
                            case "pointerout":
                            case "pointerover":
                            case "pointerup":
                                y = Jf;
                                break;
                            case "toggle":
                            case "beforetoggle":
                                y = xd
                        }
                        var N = (t & 4) !== 0,
                            dl = !N && (l === "scroll" || l === "scrollend"),
                            d = N ? v !== null ? v + "Capture" : null : v;
                        N = [];
                        for (var o = h, r; o !== null;) {
                            var S = o;
                            if (r = S.stateNode, S = S.tag, S !== 5 && S !== 26 && S !== 27 || r === null || d === null || (S = _e(o, d), S != null && N.push(fu(o, S, r))), dl) break;
                            o = o.return
                        }
                        0 < N.length && (v = new y(v, Y, null, a, g), E.push({
                            event: v,
                            listeners: N
                        }))
                    }
                }
                if ((t & 7) === 0) {
                    l: {
                        if (v = l === "mouseover" || l === "pointerover", y = l === "mouseout" || l === "pointerout", v && a !== ei && (Y = a.relatedTarget || a.fromElement) && (Ya(Y) || Y[qa])) break l;
                        if ((y || v) && (v = g.window === g ? g : (v = g.ownerDocument) ? v.defaultView || v.parentWindow : window, y ? (Y = a.relatedTarget || a.toElement, y = h, Y = Y ? Ya(Y) : null, Y !== null && (dl = P(Y), N = Y.tag, Y !== dl || N !== 5 && N !== 27 && N !== 6) && (Y = null)) : (y = null, Y = h), y !== Y)) {
                            if (N = Vf, S = "onMouseLeave", d = "onMouseEnter", o = "mouse", (l === "pointerout" || l === "pointerover") && (N = Jf, S = "onPointerLeave", d = "onPointerEnter", o = "pointer"), dl = y == null ? v : Me(y), r = Y == null ? v : Me(Y), v = new N(S, o + "leave", y, a, g), v.target = dl, v.relatedTarget = r, S = null, Ya(g) === h && (N = new N(d, o + "enter", Y, a, g), N.target = r, N.relatedTarget = dl, S = N), dl = S, y && Y) t: {
                                for (N = y, d = Y, o = 0, r = N; r; r = ye(r)) o++;
                                for (r = 0, S = d; S; S = ye(S)) r++;
                                for (; 0 < o - r;) N = ye(N),
                                o--;
                                for (; 0 < r - o;) d = ye(d),
                                r--;
                                for (; o--;) {
                                    if (N === d || d !== null && N === d.alternate) break t;
                                    N = ye(N), d = ye(d)
                                }
                                N = null
                            }
                            else N = null;
                            y !== null && Bo(E, v, y, N, !1), Y !== null && dl !== null && Bo(E, dl, Y, N, !0)
                        }
                    }
                    l: {
                        if (v = h ? Me(h) : window, y = v.nodeName && v.nodeName.toLowerCase(), y === "select" || y === "input" && v.type === "file") var D = ts;
                        else if (Pf(v))
                            if (as) D = Bd;
                            else {
                                D = Yd;
                                var V = qd
                            }
                        else y = v.nodeName,
                        !y || y.toLowerCase() !== "input" || v.type !== "checkbox" && v.type !== "radio" ? h && ai(h.elementType) && (D = ts) : D = Cd;
                        if (D && (D = D(l, h))) {
                            ls(E, D, a, g);
                            break l
                        }
                        V && V(l, v, h),
                        l === "focusout" && h && v.type === "number" && h.memoizedProps.value != null && ti(v, "number", v.value)
                    }
                    switch (V = h ? Me(h) : window, l) {
                        case "focusin":
                            (Pf(V) || V.contentEditable === "true") && (Va = V, mi = h, qe = null);
                            break;
                        case "focusout":
                            qe = mi = Va = null;
                            break;
                        case "mousedown":
                            gi = !0;
                            break;
                        case "contextmenu":
                        case "mouseup":
                        case "dragend":
                            gi = !1, os(E, a, g);
                            break;
                        case "selectionchange":
                            if (wd) break;
                        case "keydown":
                        case "keyup":
                            os(E, a, g)
                    }
                    var U;
                    if (ri) l: {
                        switch (l) {
                            case "compositionstart":
                                var H = "onCompositionStart";
                                break l;
                            case "compositionend":
                                H = "onCompositionEnd";
                                break l;
                            case "compositionupdate":
                                H = "onCompositionUpdate";
                                break l
                        }
                        H = void 0
                    }
                    else La ? Ff(l, a) && (H = "onCompositionEnd") : l === "keydown" && a.keyCode === 229 && (H = "onCompositionStart");H && (kf && a.locale !== "ko" && (La || H !== "onCompositionStart" ? H === "onCompositionEnd" && La && (U = Zf()) : (Kt = g, ci = "value" in Kt ? Kt.value : Kt.textContent, La = !0)), V = bn(h, H), 0 < V.length && (H = new Kf(H, l, null, a, g), E.push({
                        event: H,
                        listeners: V
                    }), U ? H.data = U : (U = If(a), U !== null && (H.data = U)))),
                    (U = Dd ? Ud(l, a) : Rd(l, a)) && (H = bn(h, "onBeforeInput"), 0 < H.length && (V = new Kf("onBeforeInput", "beforeinput", null, a, g), E.push({
                        event: V,
                        listeners: H
                    }), V.data = U)),
                    Tr(E, l, h, a, g)
                }
                Yo(E, t)
            })
        }

        function fu(l, t, a) {
            return {
                instance: l,
                listener: t,
                currentTarget: a
            }
        }

        function bn(l, t) {
            for (var a = t + "Capture", e = []; l !== null;) {
                var u = l,
                    n = u.stateNode;
                if (u = u.tag, u !== 5 && u !== 26 && u !== 27 || n === null || (u = _e(l, a), u != null && e.unshift(fu(l, u, n)), u = _e(l, t), u != null && e.push(fu(l, u, n))), l.tag === 3) return e;
                l = l.return
            }
            return []
        }

        function ye(l) {
            if (l === null) return null;
            do l = l.return; while (l && l.tag !== 5 && l.tag !== 27);
            return l || null
        }

        function Bo(l, t, a, e, u) {
            for (var n = t._reactName, i = []; a !== null && a !== e;) {
                var c = a,
                    f = c.alternate,
                    h = c.stateNode;
                if (c = c.tag, f !== null && f === e) break;
                c !== 5 && c !== 26 && c !== 27 || h === null || (f = h, u ? (h = _e(a, n), h != null && i.unshift(fu(a, h, f))) : u || (h = _e(a, n), h != null && i.push(fu(a, h, f)))), a = a.return
            }
            i.length !== 0 && l.push({
                event: t,
                listeners: i
            })
        }
        var Mr = /\r\n?/g,
            _r = /\u0000|\uFFFD/g;

        function jo(l) {
            return (typeof l == "string" ? l : "" + l).replace(Mr, `
`).replace(_r, "")
        }

        function wo(l, t) {
            return t = jo(t), jo(l) === t
        }

        function Sn() {}

        function ol(l, t, a, e, u, n) {
            switch (a) {
                case "children":
                    typeof e == "string" ? t === "body" || t === "textarea" && e === "" || Qa(l, e) : (typeof e == "number" || typeof e == "bigint") && t !== "body" && Qa(l, "" + e);
                    break;
                case "className":
                    zu(l, "class", e);
                    break;
                case "tabIndex":
                    zu(l, "tabindex", e);
                    break;
                case "dir":
                case "role":
                case "viewBox":
                case "width":
                case "height":
                    zu(l, a, e);
                    break;
                case "style":
                    Gf(l, e, n);
                    break;
                case "data":
                    if (t !== "object") {
                        zu(l, "data", e);
                        break
                    }
                case "src":
                case "href":
                    if (e === "" && (t !== "a" || a !== "href")) {
                        l.removeAttribute(a);
                        break
                    }
                    if (e == null || typeof e == "function" || typeof e == "symbol" || typeof e == "boolean") {
                        l.removeAttribute(a);
                        break
                    }
                    e = xu("" + e), l.setAttribute(a, e);
                    break;
                case "action":
                case "formAction":
                    if (typeof e == "function") {
                        l.setAttribute(a, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
                        break
                    } else typeof n == "function" && (a === "formAction" ? (t !== "input" && ol(l, t, "name", u.name, u, null), ol(l, t, "formEncType", u.formEncType, u, null), ol(l, t, "formMethod", u.formMethod, u, null), ol(l, t, "formTarget", u.formTarget, u, null)) : (ol(l, t, "encType", u.encType, u, null), ol(l, t, "method", u.method, u, null), ol(l, t, "target", u.target, u, null)));
                    if (e == null || typeof e == "symbol" || typeof e == "boolean") {
                        l.removeAttribute(a);
                        break
                    }
                    e = xu("" + e), l.setAttribute(a, e);
                    break;
                case "onClick":
                    e != null && (l.onclick = Sn);
                    break;
                case "onScroll":
                    e != null && k("scroll", l);
                    break;
                case "onScrollEnd":
                    e != null && k("scrollend", l);
                    break;
                case "dangerouslySetInnerHTML":
                    if (e != null) {
                        if (typeof e != "object" || !("__html" in e)) throw Error(m(61));
                        if (a = e.__html, a != null) {
                            if (u.children != null) throw Error(m(60));
                            l.innerHTML = a
                        }
                    }
                    break;
                case "multiple":
                    l.multiple = e && typeof e != "function" && typeof e != "symbol";
                    break;
                case "muted":
                    l.muted = e && typeof e != "function" && typeof e != "symbol";
                    break;
                case "suppressContentEditableWarning":
                case "suppressHydrationWarning":
                case "defaultValue":
                case "defaultChecked":
                case "innerHTML":
                case "ref":
                    break;
                case "autoFocus":
                    break;
                case "xlinkHref":
                    if (e == null || typeof e == "function" || typeof e == "boolean" || typeof e == "symbol") {
                        l.removeAttribute("xlink:href");
                        break
                    }
                    a = xu("" + e), l.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", a);
                    break;
                case "contentEditable":
                case "spellCheck":
                case "draggable":
                case "value":
                case "autoReverse":
                case "externalResourcesRequired":
                case "focusable":
                case "preserveAlpha":
                    e != null && typeof e != "function" && typeof e != "symbol" ? l.setAttribute(a, "" + e) : l.removeAttribute(a);
                    break;
                case "inert":
                case "allowFullScreen":
                case "async":
                case "autoPlay":
                case "controls":
                case "default":
                case "defer":
                case "disabled":
                case "disablePictureInPicture":
                case "disableRemotePlayback":
                case "formNoValidate":
                case "hidden":
                case "loop":
                case "noModule":
                case "noValidate":
                case "open":
                case "playsInline":
                case "readOnly":
                case "required":
                case "reversed":
                case "scoped":
                case "seamless":
                case "itemScope":
                    e && typeof e != "function" && typeof e != "symbol" ? l.setAttribute(a, "") : l.removeAttribute(a);
                    break;
                case "capture":
                case "download":
                    e === !0 ? l.setAttribute(a, "") : e !== !1 && e != null && typeof e != "function" && typeof e != "symbol" ? l.setAttribute(a, e) : l.removeAttribute(a);
                    break;
                case "cols":
                case "rows":
                case "size":
                case "span":
                    e != null && typeof e != "function" && typeof e != "symbol" && !isNaN(e) && 1 <= e ? l.setAttribute(a, e) : l.removeAttribute(a);
                    break;
                case "rowSpan":
                case "start":
                    e == null || typeof e == "function" || typeof e == "symbol" || isNaN(e) ? l.removeAttribute(a) : l.setAttribute(a, e);
                    break;
                case "popover":
                    k("beforetoggle", l), k("toggle", l), Au(l, "popover", e);
                    break;
                case "xlinkActuate":
                    Ot(l, "http://www.w3.org/1999/xlink", "xlink:actuate", e);
                    break;
                case "xlinkArcrole":
                    Ot(l, "http://www.w3.org/1999/xlink", "xlink:arcrole", e);
                    break;
                case "xlinkRole":
                    Ot(l, "http://www.w3.org/1999/xlink", "xlink:role", e);
                    break;
                case "xlinkShow":
                    Ot(l, "http://www.w3.org/1999/xlink", "xlink:show", e);
                    break;
                case "xlinkTitle":
                    Ot(l, "http://www.w3.org/1999/xlink", "xlink:title", e);
                    break;
                case "xlinkType":
                    Ot(l, "http://www.w3.org/1999/xlink", "xlink:type", e);
                    break;
                case "xmlBase":
                    Ot(l, "http://www.w3.org/XML/1998/namespace", "xml:base", e);
                    break;
                case "xmlLang":
                    Ot(l, "http://www.w3.org/XML/1998/namespace", "xml:lang", e);
                    break;
                case "xmlSpace":
                    Ot(l, "http://www.w3.org/XML/1998/namespace", "xml:space", e);
                    break;
                case "is":
                    Au(l, "is", e);
                    break;
                case "innerText":
                case "textContent":
                    break;
                default:
                    (!(2 < a.length) || a[0] !== "o" && a[0] !== "O" || a[1] !== "n" && a[1] !== "N") && (a = ad.get(a) || a, Au(l, a, e))
            }
        }

        function Gc(l, t, a, e, u, n) {
            switch (a) {
                case "style":
                    Gf(l, e, n);
                    break;
                case "dangerouslySetInnerHTML":
                    if (e != null) {
                        if (typeof e != "object" || !("__html" in e)) throw Error(m(61));
                        if (a = e.__html, a != null) {
                            if (u.children != null) throw Error(m(60));
                            l.innerHTML = a
                        }
                    }
                    break;
                case "children":
                    typeof e == "string" ? Qa(l, e) : (typeof e == "number" || typeof e == "bigint") && Qa(l, "" + e);
                    break;
                case "onScroll":
                    e != null && k("scroll", l);
                    break;
                case "onScrollEnd":
                    e != null && k("scrollend", l);
                    break;
                case "onClick":
                    e != null && (l.onclick = Sn);
                    break;
                case "suppressContentEditableWarning":
                case "suppressHydrationWarning":
                case "innerHTML":
                case "ref":
                    break;
                case "innerText":
                case "textContent":
                    break;
                default:
                    if (!Df.hasOwnProperty(a)) l: {
                        if (a[0] === "o" && a[1] === "n" && (u = a.endsWith("Capture"), t = a.slice(2, u ? a.length - 7 : void 0), n = l[Jl] || null, n = n != null ? n[a] : null, typeof n == "function" && l.removeEventListener(t, n, u), typeof e == "function")) {
                            typeof n != "function" && n !== null && (a in l ? l[a] = null : l.hasAttribute(a) && l.removeAttribute(a)), l.addEventListener(t, e, u);
                            break l
                        }
                        a in l ? l[a] = e : e === !0 ? l.setAttribute(a, "") : Au(l, a, e)
                    }
            }
        }

        function wl(l, t, a) {
            switch (t) {
                case "div":
                case "span":
                case "svg":
                case "path":
                case "a":
                case "g":
                case "p":
                case "li":
                    break;
                case "img":
                    k("error", l), k("load", l);
                    var e = !1,
                        u = !1,
                        n;
                    for (n in a)
                        if (a.hasOwnProperty(n)) {
                            var i = a[n];
                            if (i != null) switch (n) {
                                case "src":
                                    e = !0;
                                    break;
                                case "srcSet":
                                    u = !0;
                                    break;
                                case "children":
                                case "dangerouslySetInnerHTML":
                                    throw Error(m(137, t));
                                default:
                                    ol(l, t, n, i, a, null)
                            }
                        }
                    u && ol(l, t, "srcSet", a.srcSet, a, null), e && ol(l, t, "src", a.src, a, null);
                    return;
                case "input":
                    k("invalid", l);
                    var c = n = i = u = null,
                        f = null,
                        h = null;
                    for (e in a)
                        if (a.hasOwnProperty(e)) {
                            var g = a[e];
                            if (g != null) switch (e) {
                                case "name":
                                    u = g;
                                    break;
                                case "type":
                                    i = g;
                                    break;
                                case "checked":
                                    f = g;
                                    break;
                                case "defaultChecked":
                                    h = g;
                                    break;
                                case "value":
                                    n = g;
                                    break;
                                case "defaultValue":
                                    c = g;
                                    break;
                                case "children":
                                case "dangerouslySetInnerHTML":
                                    if (g != null) throw Error(m(137, t));
                                    break;
                                default:
                                    ol(l, t, e, g, a, null)
                            }
                        }
                    Cf(l, n, c, f, h, i, u, !1), Mu(l);
                    return;
                case "select":
                    k("invalid", l), e = i = n = null;
                    for (u in a)
                        if (a.hasOwnProperty(u) && (c = a[u], c != null)) switch (u) {
                            case "value":
                                n = c;
                                break;
                            case "defaultValue":
                                i = c;
                                break;
                            case "multiple":
                                e = c;
                            default:
                                ol(l, t, u, c, a, null)
                        }
                    t = n, a = i, l.multiple = !!e, t != null ? Ga(l, !!e, t, !1) : a != null && Ga(l, !!e, a, !0);
                    return;
                case "textarea":
                    k("invalid", l), n = u = e = null;
                    for (i in a)
                        if (a.hasOwnProperty(i) && (c = a[i], c != null)) switch (i) {
                            case "value":
                                e = c;
                                break;
                            case "defaultValue":
                                u = c;
                                break;
                            case "children":
                                n = c;
                                break;
                            case "dangerouslySetInnerHTML":
                                if (c != null) throw Error(m(91));
                                break;
                            default:
                                ol(l, t, i, c, a, null)
                        }
                    jf(l, e, u, n), Mu(l);
                    return;
                case "option":
                    for (f in a)
                        if (a.hasOwnProperty(f) && (e = a[f], e != null)) switch (f) {
                            case "selected":
                                l.selected = e && typeof e != "function" && typeof e != "symbol";
                                break;
                            default:
                                ol(l, t, f, e, a, null)
                        }
                    return;
                case "dialog":
                    k("beforetoggle", l), k("toggle", l), k("cancel", l), k("close", l);
                    break;
                case "iframe":
                case "object":
                    k("load", l);
                    break;
                case "video":
                case "audio":
                    for (e = 0; e < cu.length; e++) k(cu[e], l);
                    break;
                case "image":
                    k("error", l), k("load", l);
                    break;
                case "details":
                    k("toggle", l);
                    break;
                case "embed":
                case "source":
                case "link":
                    k("error", l), k("load", l);
                case "area":
                case "base":
                case "br":
                case "col":
                case "hr":
                case "keygen":
                case "meta":
                case "param":
                case "track":
                case "wbr":
                case "menuitem":
                    for (h in a)
                        if (a.hasOwnProperty(h) && (e = a[h], e != null)) switch (h) {
                            case "children":
                            case "dangerouslySetInnerHTML":
                                throw Error(m(137, t));
                            default:
                                ol(l, t, h, e, a, null)
                        }
                    return;
                default:
                    if (ai(t)) {
                        for (g in a) a.hasOwnProperty(g) && (e = a[g], e !== void 0 && Gc(l, t, g, e, a, void 0));
                        return
                    }
            }
            for (c in a) a.hasOwnProperty(c) && (e = a[c], e != null && ol(l, t, c, e, a, null))
        }

        function xr(l, t, a, e) {
            switch (t) {
                case "div":
                case "span":
                case "svg":
                case "path":
                case "a":
                case "g":
                case "p":
                case "li":
                    break;
                case "input":
                    var u = null,
                        n = null,
                        i = null,
                        c = null,
                        f = null,
                        h = null,
                        g = null;
                    for (y in a) {
                        var E = a[y];
                        if (a.hasOwnProperty(y) && E != null) switch (y) {
                            case "checked":
                                break;
                            case "value":
                                break;
                            case "defaultValue":
                                f = E;
                            default:
                                e.hasOwnProperty(y) || ol(l, t, y, null, e, E)
                        }
                    }
                    for (var v in e) {
                        var y = e[v];
                        if (E = a[v], e.hasOwnProperty(v) && (y != null || E != null)) switch (v) {
                            case "type":
                                n = y;
                                break;
                            case "name":
                                u = y;
                                break;
                            case "checked":
                                h = y;
                                break;
                            case "defaultChecked":
                                g = y;
                                break;
                            case "value":
                                i = y;
                                break;
                            case "defaultValue":
                                c = y;
                                break;
                            case "children":
                            case "dangerouslySetInnerHTML":
                                if (y != null) throw Error(m(137, t));
                                break;
                            default:
                                y !== E && ol(l, t, v, y, e, E)
                        }
                    }
                    li(l, i, c, f, h, g, n, u);
                    return;
                case "select":
                    y = i = c = v = null;
                    for (n in a)
                        if (f = a[n], a.hasOwnProperty(n) && f != null) switch (n) {
                            case "value":
                                break;
                            case "multiple":
                                y = f;
                            default:
                                e.hasOwnProperty(n) || ol(l, t, n, null, e, f)
                        }
                    for (u in e)
                        if (n = e[u], f = a[u], e.hasOwnProperty(u) && (n != null || f != null)) switch (u) {
                            case "value":
                                v = n;
                                break;
                            case "defaultValue":
                                c = n;
                                break;
                            case "multiple":
                                i = n;
                            default:
                                n !== f && ol(l, t, u, n, e, f)
                        }
                    t = c, a = i, e = y, v != null ? Ga(l, !!a, v, !1) : !!e != !!a && (t != null ? Ga(l, !!a, t, !0) : Ga(l, !!a, a ? [] : "", !1));
                    return;
                case "textarea":
                    y = v = null;
                    for (c in a)
                        if (u = a[c], a.hasOwnProperty(c) && u != null && !e.hasOwnProperty(c)) switch (c) {
                            case "value":
                                break;
                            case "children":
                                break;
                            default:
                                ol(l, t, c, null, e, u)
                        }
                    for (i in e)
                        if (u = e[i], n = a[i], e.hasOwnProperty(i) && (u != null || n != null)) switch (i) {
                            case "value":
                                v = u;
                                break;
                            case "defaultValue":
                                y = u;
                                break;
                            case "children":
                                break;
                            case "dangerouslySetInnerHTML":
                                if (u != null) throw Error(m(91));
                                break;
                            default:
                                u !== n && ol(l, t, i, u, e, n)
                        }
                    Bf(l, v, y);
                    return;
                case "option":
                    for (var Y in a)
                        if (v = a[Y], a.hasOwnProperty(Y) && v != null && !e.hasOwnProperty(Y)) switch (Y) {
                            case "selected":
                                l.selected = !1;
                                break;
                            default:
                                ol(l, t, Y, null, e, v)
                        }
                    for (f in e)
                        if (v = e[f], y = a[f], e.hasOwnProperty(f) && v !== y && (v != null || y != null)) switch (f) {
                            case "selected":
                                l.selected = v && typeof v != "function" && typeof v != "symbol";
                                break;
                            default:
                                ol(l, t, f, v, e, y)
                        }
                    return;
                case "img":
                case "link":
                case "area":
                case "base":
                case "br":
                case "col":
                case "embed":
                case "hr":
                case "keygen":
                case "meta":
                case "param":
                case "source":
                case "track":
                case "wbr":
                case "menuitem":
                    for (var N in a) v = a[N], a.hasOwnProperty(N) && v != null && !e.hasOwnProperty(N) && ol(l, t, N, null, e, v);
                    for (h in e)
                        if (v = e[h], y = a[h], e.hasOwnProperty(h) && v !== y && (v != null || y != null)) switch (h) {
                            case "children":
                            case "dangerouslySetInnerHTML":
                                if (v != null) throw Error(m(137, t));
                                break;
                            default:
                                ol(l, t, h, v, e, y)
                        }
                    return;
                default:
                    if (ai(t)) {
                        for (var dl in a) v = a[dl], a.hasOwnProperty(dl) && v !== void 0 && !e.hasOwnProperty(dl) && Gc(l, t, dl, void 0, e, v);
                        for (g in e) v = e[g], y = a[g], !e.hasOwnProperty(g) || v === y || v === void 0 && y === void 0 || Gc(l, t, g, v, e, y);
                        return
                    }
            }
            for (var d in a) v = a[d], a.hasOwnProperty(d) && v != null && !e.hasOwnProperty(d) && ol(l, t, d, null, e, v);
            for (E in e) v = e[E], y = a[E], !e.hasOwnProperty(E) || v === y || v == null && y == null || ol(l, t, E, v, e, y)
        }
        var Qc = null,
            Xc = null;

        function Tn(l) {
            return l.nodeType === 9 ? l : l.ownerDocument
        }

        function Go(l) {
            switch (l) {
                case "http://www.w3.org/2000/svg":
                    return 1;
                case "http://www.w3.org/1998/Math/MathML":
                    return 2;
                default:
                    return 0
            }
        }

        function Qo(l, t) {
            if (l === 0) switch (t) {
                case "svg":
                    return 1;
                case "math":
                    return 2;
                default:
                    return 0
            }
            return l === 1 && t === "foreignObject" ? 0 : l
        }

        function Zc(l, t) {
            return l === "textarea" || l === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
        }
        var Lc = null;

        function Or() {
            var l = window.event;
            return l && l.type === "popstate" ? l === Lc ? !1 : (Lc = l, !0) : (Lc = null, !1)
        }
        var Xo = typeof setTimeout == "function" ? setTimeout : void 0,
            Dr = typeof clearTimeout == "function" ? clearTimeout : void 0,
            Zo = typeof Promise == "function" ? Promise : void 0,
            Ur = typeof queueMicrotask == "function" ? queueMicrotask : typeof Zo < "u" ? function(l) {
                return Zo.resolve(null).then(l).catch(Rr)
            } : Xo;

        function Rr(l) {
            setTimeout(function() {
                throw l
            })
        }

        function fa(l) {
            return l === "head"
        }

        function Lo(l, t) {
            var a = t,
                e = 0,
                u = 0;
            do {
                var n = a.nextSibling;
                if (l.removeChild(a), n && n.nodeType === 8)
                    if (a = n.data, a === "/$") {
                        if (0 < e && 8 > e) {
                            a = e;
                            var i = l.ownerDocument;
                            if (a & 1 && su(i.documentElement), a & 2 && su(i.body), a & 4)
                                for (a = i.head, su(a), i = a.firstChild; i;) {
                                    var c = i.nextSibling,
                                        f = i.nodeName;
                                    i[ze] || f === "SCRIPT" || f === "STYLE" || f === "LINK" && i.rel.toLowerCase() === "stylesheet" || a.removeChild(i), i = c
                                }
                        }
                        if (u === 0) {
                            l.removeChild(n), gu(t);
                            return
                        }
                        u--
                    } else a === "$" || a === "$?" || a === "$!" ? u++ : e = a.charCodeAt(0) - 48;
                else e = 0;
                a = n
            } while (a);
            gu(t)
        }

        function Vc(l) {
            var t = l.firstChild;
            for (t && t.nodeType === 10 && (t = t.nextSibling); t;) {
                var a = t;
                switch (t = t.nextSibling, a.nodeName) {
                    case "HTML":
                    case "HEAD":
                    case "BODY":
                        Vc(a), $n(a);
                        continue;
                    case "SCRIPT":
                    case "STYLE":
                        continue;
                    case "LINK":
                        if (a.rel.toLowerCase() === "stylesheet") continue
                }
                l.removeChild(a)
            }
        }

        function Nr(l, t, a, e) {
            for (; l.nodeType === 1;) {
                var u = a;
                if (l.nodeName.toLowerCase() !== t.toLowerCase()) {
                    if (!e && (l.nodeName !== "INPUT" || l.type !== "hidden")) break
                } else if (e) {
                    if (!l[ze]) switch (t) {
                        case "meta":
                            if (!l.hasAttribute("itemprop")) break;
                            return l;
                        case "link":
                            if (n = l.getAttribute("rel"), n === "stylesheet" && l.hasAttribute("data-precedence")) break;
                            if (n !== u.rel || l.getAttribute("href") !== (u.href == null || u.href === "" ? null : u.href) || l.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin) || l.getAttribute("title") !== (u.title == null ? null : u.title)) break;
                            return l;
                        case "style":
                            if (l.hasAttribute("data-precedence")) break;
                            return l;
                        case "script":
                            if (n = l.getAttribute("src"), (n !== (u.src == null ? null : u.src) || l.getAttribute("type") !== (u.type == null ? null : u.type) || l.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin)) && n && l.hasAttribute("async") && !l.hasAttribute("itemprop")) break;
                            return l;
                        default:
                            return l
                    }
                } else if (t === "input" && l.type === "hidden") {
                    var n = u.name == null ? null : "" + u.name;
                    if (u.type === "hidden" && l.getAttribute("name") === n) return l
                } else return l;
                if (l = bt(l.nextSibling), l === null) break
            }
            return null
        }

        function Hr(l, t, a) {
            if (t === "") return null;
            for (; l.nodeType !== 3;)
                if ((l.nodeType !== 1 || l.nodeName !== "INPUT" || l.type !== "hidden") && !a || (l = bt(l.nextSibling), l === null)) return null;
            return l
        }

        function Kc(l) {
            return l.data === "$!" || l.data === "$?" && l.ownerDocument.readyState === "complete"
        }

        function qr(l, t) {
            var a = l.ownerDocument;
            if (l.data !== "$?" || a.readyState === "complete") t();
            else {
                var e = function() {
                    t(), a.removeEventListener("DOMContentLoaded", e)
                };
                a.addEventListener("DOMContentLoaded", e), l._reactRetry = e
            }
        }

        function bt(l) {
            for (; l != null; l = l.nextSibling) {
                var t = l.nodeType;
                if (t === 1 || t === 3) break;
                if (t === 8) {
                    if (t = l.data, t === "$" || t === "$!" || t === "$?" || t === "F!" || t === "F") break;
                    if (t === "/$") return null
                }
            }
            return l
        }
        var Jc = null;

        function Vo(l) {
            l = l.previousSibling;
            for (var t = 0; l;) {
                if (l.nodeType === 8) {
                    var a = l.data;
                    if (a === "$" || a === "$!" || a === "$?") {
                        if (t === 0) return l;
                        t--
                    } else a === "/$" && t++
                }
                l = l.previousSibling
            }
            return null
        }

        function Ko(l, t, a) {
            switch (t = Tn(a), l) {
                case "html":
                    if (l = t.documentElement, !l) throw Error(m(452));
                    return l;
                case "head":
                    if (l = t.head, !l) throw Error(m(453));
                    return l;
                case "body":
                    if (l = t.body, !l) throw Error(m(454));
                    return l;
                default:
                    throw Error(m(451))
            }
        }

        function su(l) {
            for (var t = l.attributes; t.length;) l.removeAttributeNode(t[0]);
            $n(l)
        }
        var mt = new Map,
            Jo = new Set;

        function En(l) {
            return typeof l.getRootNode == "function" ? l.getRootNode() : l.nodeType === 9 ? l : l.ownerDocument
        }
        var Xt = _.d;
        _.d = {
            f: Yr,
            r: Cr,
            D: Br,
            C: jr,
            L: wr,
            m: Gr,
            X: Xr,
            S: Qr,
            M: Zr
        };

        function Yr() {
            var l = Xt.f(),
                t = hn();
            return l || t
        }

        function Cr(l) {
            var t = Ca(l);
            t !== null && t.tag === 5 && t.type === "form" ? r0(t) : Xt.r(l)
        }
        var me = typeof document > "u" ? null : document;

        function ko(l, t, a) {
            var e = me;
            if (e && typeof t == "string" && t) {
                var u = st(t);
                u = 'link[rel="' + l + '"][href="' + u + '"]', typeof a == "string" && (u += '[crossorigin="' + a + '"]'), Jo.has(u) || (Jo.add(u), l = {
                    rel: l,
                    crossOrigin: a,
                    href: t
                }, e.querySelector(u) === null && (t = e.createElement("link"), wl(t, "link", l), Hl(t), e.head.appendChild(t)))
            }
        }

        function Br(l) {
            Xt.D(l), ko("dns-prefetch", l, null)
        }

        function jr(l, t) {
            Xt.C(l, t), ko("preconnect", l, t)
        }

        function wr(l, t, a) {
            Xt.L(l, t, a);
            var e = me;
            if (e && l && t) {
                var u = 'link[rel="preload"][as="' + st(t) + '"]';
                t === "image" && a && a.imageSrcSet ? (u += '[imagesrcset="' + st(a.imageSrcSet) + '"]', typeof a.imageSizes == "string" && (u += '[imagesizes="' + st(a.imageSizes) + '"]')) : u += '[href="' + st(l) + '"]';
                var n = u;
                switch (t) {
                    case "style":
                        n = ge(l);
                        break;
                    case "script":
                        n = pe(l)
                }
                mt.has(n) || (l = z({
                    rel: "preload",
                    href: t === "image" && a && a.imageSrcSet ? void 0 : l,
                    as: t
                }, a), mt.set(n, l), e.querySelector(u) !== null || t === "style" && e.querySelector(ou(n)) || t === "script" && e.querySelector(du(n)) || (t = e.createElement("link"), wl(t, "link", l), Hl(t), e.head.appendChild(t)))
            }
        }

        function Gr(l, t) {
            Xt.m(l, t);
            var a = me;
            if (a && l) {
                var e = t && typeof t.as == "string" ? t.as : "script",
                    u = 'link[rel="modulepreload"][as="' + st(e) + '"][href="' + st(l) + '"]',
                    n = u;
                switch (e) {
                    case "audioworklet":
                    case "paintworklet":
                    case "serviceworker":
                    case "sharedworker":
                    case "worker":
                    case "script":
                        n = pe(l)
                }
                if (!mt.has(n) && (l = z({
                        rel: "modulepreload",
                        href: l
                    }, t), mt.set(n, l), a.querySelector(u) === null)) {
                    switch (e) {
                        case "audioworklet":
                        case "paintworklet":
                        case "serviceworker":
                        case "sharedworker":
                        case "worker":
                        case "script":
                            if (a.querySelector(du(n))) return
                    }
                    e = a.createElement("link"), wl(e, "link", l), Hl(e), a.head.appendChild(e)
                }
            }
        }

        function Qr(l, t, a) {
            Xt.S(l, t, a);
            var e = me;
            if (e && l) {
                var u = Ba(e).hoistableStyles,
                    n = ge(l);
                t = t || "default";
                var i = u.get(n);
                if (!i) {
                    var c = {
                        loading: 0,
                        preload: null
                    };
                    if (i = e.querySelector(ou(n))) c.loading = 5;
                    else {
                        l = z({
                            rel: "stylesheet",
                            href: l,
                            "data-precedence": t
                        }, a), (a = mt.get(n)) && kc(l, a);
                        var f = i = e.createElement("link");
                        Hl(f), wl(f, "link", l), f._p = new Promise(function(h, g) {
                            f.onload = h, f.onerror = g
                        }), f.addEventListener("load", function() {
                            c.loading |= 1
                        }), f.addEventListener("error", function() {
                            c.loading |= 2
                        }), c.loading |= 4, An(i, t, e)
                    }
                    i = {
                        type: "stylesheet",
                        instance: i,
                        count: 1,
                        state: c
                    }, u.set(n, i)
                }
            }
        }

        function Xr(l, t) {
            Xt.X(l, t);
            var a = me;
            if (a && l) {
                var e = Ba(a).hoistableScripts,
                    u = pe(l),
                    n = e.get(u);
                n || (n = a.querySelector(du(u)), n || (l = z({
                    src: l,
                    async: !0
                }, t), (t = mt.get(u)) && Wc(l, t), n = a.createElement("script"), Hl(n), wl(n, "link", l), a.head.appendChild(n)), n = {
                    type: "script",
                    instance: n,
                    count: 1,
                    state: null
                }, e.set(u, n))
            }
        }

        function Zr(l, t) {
            Xt.M(l, t);
            var a = me;
            if (a && l) {
                var e = Ba(a).hoistableScripts,
                    u = pe(l),
                    n = e.get(u);
                n || (n = a.querySelector(du(u)), n || (l = z({
                    src: l,
                    async: !0,
                    type: "module"
                }, t), (t = mt.get(u)) && Wc(l, t), n = a.createElement("script"), Hl(n), wl(n, "link", l), a.head.appendChild(n)), n = {
                    type: "script",
                    instance: n,
                    count: 1,
                    state: null
                }, e.set(u, n))
            }
        }

        function Wo(l, t, a, e) {
            var u = (u = C.current) ? En(u) : null;
            if (!u) throw Error(m(446));
            switch (l) {
                case "meta":
                case "title":
                    return null;
                case "style":
                    return typeof a.precedence == "string" && typeof a.href == "string" ? (t = ge(a.href), a = Ba(u).hoistableStyles, e = a.get(t), e || (e = {
                        type: "style",
                        instance: null,
                        count: 0,
                        state: null
                    }, a.set(t, e)), e) : {
                        type: "void",
                        instance: null,
                        count: 0,
                        state: null
                    };
                case "link":
                    if (a.rel === "stylesheet" && typeof a.href == "string" && typeof a.precedence == "string") {
                        l = ge(a.href);
                        var n = Ba(u).hoistableStyles,
                            i = n.get(l);
                        if (i || (u = u.ownerDocument || u, i = {
                                type: "stylesheet",
                                instance: null,
                                count: 0,
                                state: {
                                    loading: 0,
                                    preload: null
                                }
                            }, n.set(l, i), (n = u.querySelector(ou(l))) && !n._p && (i.instance = n, i.state.loading = 5), mt.has(l) || (a = {
                                rel: "preload",
                                as: "style",
                                href: a.href,
                                crossOrigin: a.crossOrigin,
                                integrity: a.integrity,
                                media: a.media,
                                hrefLang: a.hrefLang,
                                referrerPolicy: a.referrerPolicy
                            }, mt.set(l, a), n || Lr(u, l, a, i.state))), t && e === null) throw Error(m(528, ""));
                        return i
                    }
                    if (t && e !== null) throw Error(m(529, ""));
                    return null;
                case "script":
                    return t = a.async, a = a.src, typeof a == "string" && t && typeof t != "function" && typeof t != "symbol" ? (t = pe(a), a = Ba(u).hoistableScripts, e = a.get(t), e || (e = {
                        type: "script",
                        instance: null,
                        count: 0,
                        state: null
                    }, a.set(t, e)), e) : {
                        type: "void",
                        instance: null,
                        count: 0,
                        state: null
                    };
                default:
                    throw Error(m(444, l))
            }
        }

        function ge(l) {
            return 'href="' + st(l) + '"'
        }

        function ou(l) {
            return 'link[rel="stylesheet"][' + l + "]"
        }

        function $o(l) {
            return z({}, l, {
                "data-precedence": l.precedence,
                precedence: null
            })
        }

        function Lr(l, t, a, e) {
            l.querySelector('link[rel="preload"][as="style"][' + t + "]") ? e.loading = 1 : (t = l.createElement("link"), e.preload = t, t.addEventListener("load", function() {
                return e.loading |= 1
            }), t.addEventListener("error", function() {
                return e.loading |= 2
            }), wl(t, "link", a), Hl(t), l.head.appendChild(t))
        }

        function pe(l) {
            return '[src="' + st(l) + '"]'
        }

        function du(l) {
            return "script[async]" + l
        }

        function Fo(l, t, a) {
            if (t.count++, t.instance === null) switch (t.type) {
                case "style":
                    var e = l.querySelector('style[data-href~="' + st(a.href) + '"]');
                    if (e) return t.instance = e, Hl(e), e;
                    var u = z({}, a, {
                        "data-href": a.href,
                        "data-precedence": a.precedence,
                        href: null,
                        precedence: null
                    });
                    return e = (l.ownerDocument || l).createElement("style"), Hl(e), wl(e, "style", u), An(e, a.precedence, l), t.instance = e;
                case "stylesheet":
                    u = ge(a.href);
                    var n = l.querySelector(ou(u));
                    if (n) return t.state.loading |= 4, t.instance = n, Hl(n), n;
                    e = $o(a), (u = mt.get(u)) && kc(e, u), n = (l.ownerDocument || l).createElement("link"), Hl(n);
                    var i = n;
                    return i._p = new Promise(function(c, f) {
                        i.onload = c, i.onerror = f
                    }), wl(n, "link", e), t.state.loading |= 4, An(n, a.precedence, l), t.instance = n;
                case "script":
                    return n = pe(a.src), (u = l.querySelector(du(n))) ? (t.instance = u, Hl(u), u) : (e = a, (u = mt.get(n)) && (e = z({}, a), Wc(e, u)), l = l.ownerDocument || l, u = l.createElement("script"), Hl(u), wl(u, "link", e), l.head.appendChild(u), t.instance = u);
                case "void":
                    return null;
                default:
                    throw Error(m(443, t.type))
            } else t.type === "stylesheet" && (t.state.loading & 4) === 0 && (e = t.instance, t.state.loading |= 4, An(e, a.precedence, l));
            return t.instance
        }

        function An(l, t, a) {
            for (var e = a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), u = e.length ? e[e.length - 1] : null, n = u, i = 0; i < e.length; i++) {
                var c = e[i];
                if (c.dataset.precedence === t) n = c;
                else if (n !== u) break
            }
            n ? n.parentNode.insertBefore(l, n.nextSibling) : (t = a.nodeType === 9 ? a.head : a, t.insertBefore(l, t.firstChild))
        }

        function kc(l, t) {
            l.crossOrigin == null && (l.crossOrigin = t.crossOrigin), l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy), l.title == null && (l.title = t.title)
        }

        function Wc(l, t) {
            l.crossOrigin == null && (l.crossOrigin = t.crossOrigin), l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy), l.integrity == null && (l.integrity = t.integrity)
        }
        var zn = null;

        function Io(l, t, a) {
            if (zn === null) {
                var e = new Map,
                    u = zn = new Map;
                u.set(a, e)
            } else u = zn, e = u.get(a), e || (e = new Map, u.set(a, e));
            if (e.has(l)) return e;
            for (e.set(l, null), a = a.getElementsByTagName(l), u = 0; u < a.length; u++) {
                var n = a[u];
                if (!(n[ze] || n[Ll] || l === "link" && n.getAttribute("rel") === "stylesheet") && n.namespaceURI !== "http://www.w3.org/2000/svg") {
                    var i = n.getAttribute(t) || "";
                    i = l + i;
                    var c = e.get(i);
                    c ? c.push(n) : e.set(i, [n])
                }
            }
            return e
        }

        function Po(l, t, a) {
            l = l.ownerDocument || l, l.head.insertBefore(a, t === "title" ? l.querySelector("head > title") : null)
        }

        function Vr(l, t, a) {
            if (a === 1 || t.itemProp != null) return !1;
            switch (l) {
                case "meta":
                case "title":
                    return !0;
                case "style":
                    if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "") break;
                    return !0;
                case "link":
                    if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError) break;
                    switch (t.rel) {
                        case "stylesheet":
                            return l = t.disabled, typeof t.precedence == "string" && l == null;
                        default:
                            return !0
                    }
                case "script":
                    if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string") return !0
            }
            return !1
        }

        function l1(l) {
            return !(l.type === "stylesheet" && (l.state.loading & 3) === 0)
        }
        var ru = null;

        function Kr() {}

        function Jr(l, t, a) {
            if (ru === null) throw Error(m(475));
            var e = ru;
            if (t.type === "stylesheet" && (typeof a.media != "string" || matchMedia(a.media).matches !== !1) && (t.state.loading & 4) === 0) {
                if (t.instance === null) {
                    var u = ge(a.href),
                        n = l.querySelector(ou(u));
                    if (n) {
                        l = n._p, l !== null && typeof l == "object" && typeof l.then == "function" && (e.count++, e = Mn.bind(e), l.then(e, e)), t.state.loading |= 4, t.instance = n, Hl(n);
                        return
                    }
                    n = l.ownerDocument || l, a = $o(a), (u = mt.get(u)) && kc(a, u), n = n.createElement("link"), Hl(n);
                    var i = n;
                    i._p = new Promise(function(c, f) {
                        i.onload = c, i.onerror = f
                    }), wl(n, "link", a), t.instance = n
                }
                e.stylesheets === null && (e.stylesheets = new Map), e.stylesheets.set(t, l), (l = t.state.preload) && (t.state.loading & 3) === 0 && (e.count++, t = Mn.bind(e), l.addEventListener("load", t), l.addEventListener("error", t))
            }
        }

        function kr() {
            if (ru === null) throw Error(m(475));
            var l = ru;
            return l.stylesheets && l.count === 0 && $c(l, l.stylesheets), 0 < l.count ? function(t) {
                var a = setTimeout(function() {
                    if (l.stylesheets && $c(l, l.stylesheets), l.unsuspend) {
                        var e = l.unsuspend;
                        l.unsuspend = null, e()
                    }
                }, 6e4);
                return l.unsuspend = t,
                    function() {
                        l.unsuspend = null, clearTimeout(a)
                    }
            } : null
        }

        function Mn() {
            if (this.count--, this.count === 0) {
                if (this.stylesheets) $c(this, this.stylesheets);
                else if (this.unsuspend) {
                    var l = this.unsuspend;
                    this.unsuspend = null, l()
                }
            }
        }
        var _n = null;

        function $c(l, t) {
            l.stylesheets = null, l.unsuspend !== null && (l.count++, _n = new Map, t.forEach(Wr, l), _n = null, Mn.call(l))
        }

        function Wr(l, t) {
            if (!(t.state.loading & 4)) {
                var a = _n.get(l);
                if (a) var e = a.get(null);
                else {
                    a = new Map, _n.set(l, a);
                    for (var u = l.querySelectorAll("link[data-precedence],style[data-precedence]"), n = 0; n < u.length; n++) {
                        var i = u[n];
                        (i.nodeName === "LINK" || i.getAttribute("media") !== "not all") && (a.set(i.dataset.precedence, i), e = i)
                    }
                    e && a.set(null, e)
                }
                u = t.instance, i = u.getAttribute("data-precedence"), n = a.get(i) || e, n === e && a.set(null, u), a.set(i, u), this.count++, e = Mn.bind(this), u.addEventListener("load", e), u.addEventListener("error", e), n ? n.parentNode.insertBefore(u, n.nextSibling) : (l = l.nodeType === 9 ? l.head : l, l.insertBefore(u, l.firstChild)), t.state.loading |= 4
            }
        }
        var hu = {
            $$typeof: K,
            Provider: null,
            Consumer: null,
            _currentValue: q,
            _currentValue2: q,
            _threadCount: 0
        };

        function $r(l, t, a, e, u, n, i, c) {
            this.tag = 1, this.containerInfo = l, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = Kn(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Kn(0), this.hiddenUpdates = Kn(null), this.identifierPrefix = e, this.onUncaughtError = u, this.onCaughtError = n, this.onRecoverableError = i, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = c, this.incompleteTransitions = new Map
        }

        function t1(l, t, a, e, u, n, i, c, f, h, g, E) {
            return l = new $r(l, t, a, i, c, f, h, E), t = 1, n === !0 && (t |= 24), n = at(3, null, null, t), l.current = n, n.stateNode = l, t = Ri(), t.refCount++, l.pooledCache = t, t.refCount++, n.memoizedState = {
                element: e,
                isDehydrated: a,
                cache: t
            }, Yi(n), l
        }

        function a1(l) {
            return l ? (l = Wa, l) : Wa
        }

        function e1(l, t, a, e, u, n) {
            u = a1(u), e.context === null ? e.context = u : e.pendingContext = u, e = Wt(t), e.payload = {
                element: a
            }, n = n === void 0 ? null : n, n !== null && (e.callback = n), a = $t(l, e, t), a !== null && (ct(a, l, t), Ze(a, l, t))
        }

        function u1(l, t) {
            if (l = l.memoizedState, l !== null && l.dehydrated !== null) {
                var a = l.retryLane;
                l.retryLane = a !== 0 && a < t ? a : t
            }
        }

        function Fc(l, t) {
            u1(l, t), (l = l.alternate) && u1(l, t)
        }

        function n1(l) {
            if (l.tag === 13) {
                var t = ka(l, 67108864);
                t !== null && ct(t, l, 67108864), Fc(l, 67108864)
            }
        }
        var xn = !0;

        function Fr(l, t, a, e) {
            var u = b.T;
            b.T = null;
            var n = _.p;
            try {
                _.p = 2, Ic(l, t, a, e)
            } finally {
                _.p = n, b.T = u
            }
        }

        function Ir(l, t, a, e) {
            var u = b.T;
            b.T = null;
            var n = _.p;
            try {
                _.p = 8, Ic(l, t, a, e)
            } finally {
                _.p = n, b.T = u
            }
        }

        function Ic(l, t, a, e) {
            if (xn) {
                var u = Pc(e);
                if (u === null) wc(l, t, e, On, a), c1(l, e);
                else if (lh(u, l, t, a, e)) e.stopPropagation();
                else if (c1(l, e), t & 4 && -1 < Pr.indexOf(l)) {
                    for (; u !== null;) {
                        var n = Ca(u);
                        if (n !== null) switch (n.tag) {
                            case 3:
                                if (n = n.stateNode, n.current.memoizedState.isDehydrated) {
                                    var i = ma(n.pendingLanes);
                                    if (i !== 0) {
                                        var c = n;
                                        for (c.pendingLanes |= 2, c.entangledLanes |= 2; i;) {
                                            var f = 1 << 31 - lt(i);
                                            c.entanglements[1] |= f, i &= ~f
                                        }
                                        Mt(n), (cl & 6) === 0 && (dn = St() + 500, iu(0))
                                    }
                                }
                                break;
                            case 13:
                                c = ka(n, 2), c !== null && ct(c, n, 2), hn(), Fc(n, 2)
                        }
                        if (n = Pc(e), n === null && wc(l, t, e, On, a), n === u) break;
                        u = n
                    }
                    u !== null && e.stopPropagation()
                } else wc(l, t, e, null, a)
            }
        }

        function Pc(l) {
            return l = ui(l), lf(l)
        }
        var On = null;

        function lf(l) {
            if (On = null, l = Ya(l), l !== null) {
                var t = P(l);
                if (t === null) l = null;
                else {
                    var a = t.tag;
                    if (a === 13) {
                        if (l = el(t), l !== null) return l;
                        l = null
                    } else if (a === 3) {
                        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
                        l = null
                    } else t !== l && (l = null)
                }
            }
            return On = l, null
        }

        function i1(l) {
            switch (l) {
                case "beforetoggle":
                case "cancel":
                case "click":
                case "close":
                case "contextmenu":
                case "copy":
                case "cut":
                case "auxclick":
                case "dblclick":
                case "dragend":
                case "dragstart":
                case "drop":
                case "focusin":
                case "focusout":
                case "input":
                case "invalid":
                case "keydown":
                case "keypress":
                case "keyup":
                case "mousedown":
                case "mouseup":
                case "paste":
                case "pause":
                case "play":
                case "pointercancel":
                case "pointerdown":
                case "pointerup":
                case "ratechange":
                case "reset":
                case "resize":
                case "seeked":
                case "submit":
                case "toggle":
                case "touchcancel":
                case "touchend":
                case "touchstart":
                case "volumechange":
                case "change":
                case "selectionchange":
                case "textInput":
                case "compositionstart":
                case "compositionend":
                case "compositionupdate":
                case "beforeblur":
                case "afterblur":
                case "beforeinput":
                case "blur":
                case "fullscreenchange":
                case "focus":
                case "hashchange":
                case "popstate":
                case "select":
                case "selectstart":
                    return 2;
                case "drag":
                case "dragenter":
                case "dragexit":
                case "dragleave":
                case "dragover":
                case "mousemove":
                case "mouseout":
                case "mouseover":
                case "pointermove":
                case "pointerout":
                case "pointerover":
                case "scroll":
                case "touchmove":
                case "wheel":
                case "mouseenter":
                case "mouseleave":
                case "pointerenter":
                case "pointerleave":
                    return 8;
                case "message":
                    switch (j1()) {
                        case bf:
                            return 2;
                        case Sf:
                            return 8;
                        case bu:
                        case w1:
                            return 32;
                        case Tf:
                            return 268435456;
                        default:
                            return 32
                    }
                default:
                    return 32
            }
        }
        var tf = !1,
            sa = null,
            oa = null,
            da = null,
            vu = new Map,
            yu = new Map,
            ra = [],
            Pr = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");

        function c1(l, t) {
            switch (l) {
                case "focusin":
                case "focusout":
                    sa = null;
                    break;
                case "dragenter":
                case "dragleave":
                    oa = null;
                    break;
                case "mouseover":
                case "mouseout":
                    da = null;
                    break;
                case "pointerover":
                case "pointerout":
                    vu.delete(t.pointerId);
                    break;
                case "gotpointercapture":
                case "lostpointercapture":
                    yu.delete(t.pointerId)
            }
        }

        function mu(l, t, a, e, u, n) {
            return l === null || l.nativeEvent !== n ? (l = {
                blockedOn: t,
                domEventName: a,
                eventSystemFlags: e,
                nativeEvent: n,
                targetContainers: [u]
            }, t !== null && (t = Ca(t), t !== null && n1(t)), l) : (l.eventSystemFlags |= e, t = l.targetContainers, u !== null && t.indexOf(u) === -1 && t.push(u), l)
        }

        function lh(l, t, a, e, u) {
            switch (t) {
                case "focusin":
                    return sa = mu(sa, l, t, a, e, u), !0;
                case "dragenter":
                    return oa = mu(oa, l, t, a, e, u), !0;
                case "mouseover":
                    return da = mu(da, l, t, a, e, u), !0;
                case "pointerover":
                    var n = u.pointerId;
                    return vu.set(n, mu(vu.get(n) || null, l, t, a, e, u)), !0;
                case "gotpointercapture":
                    return n = u.pointerId, yu.set(n, mu(yu.get(n) || null, l, t, a, e, u)), !0
            }
            return !1
        }

        function f1(l) {
            var t = Ya(l.target);
            if (t !== null) {
                var a = P(t);
                if (a !== null) {
                    if (t = a.tag, t === 13) {
                        if (t = el(a), t !== null) {
                            l.blockedOn = t, J1(l.priority, function() {
                                if (a.tag === 13) {
                                    var e = it();
                                    e = Jn(e);
                                    var u = ka(a, e);
                                    u !== null && ct(u, a, e), Fc(a, e)
                                }
                            });
                            return
                        }
                    } else if (t === 3 && a.stateNode.current.memoizedState.isDehydrated) {
                        l.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
                        return
                    }
                }
            }
            l.blockedOn = null
        }

        function Dn(l) {
            if (l.blockedOn !== null) return !1;
            for (var t = l.targetContainers; 0 < t.length;) {
                var a = Pc(l.nativeEvent);
                if (a === null) {
                    a = l.nativeEvent;
                    var e = new a.constructor(a.type, a);
                    ei = e, a.target.dispatchEvent(e), ei = null
                } else return t = Ca(a), t !== null && n1(t), l.blockedOn = a, !1;
                t.shift()
            }
            return !0
        }

        function s1(l, t, a) {
            Dn(l) && a.delete(t)
        }

        function th() {
            tf = !1, sa !== null && Dn(sa) && (sa = null), oa !== null && Dn(oa) && (oa = null), da !== null && Dn(da) && (da = null), vu.forEach(s1), yu.forEach(s1)
        }

        function Un(l, t) {
            l.blockedOn === t && (l.blockedOn = null, tf || (tf = !0, p.unstable_scheduleCallback(p.unstable_NormalPriority, th)))
        }
        var Rn = null;

        function o1(l) {
            Rn !== l && (Rn = l, p.unstable_scheduleCallback(p.unstable_NormalPriority, function() {
                Rn === l && (Rn = null);
                for (var t = 0; t < l.length; t += 3) {
                    var a = l[t],
                        e = l[t + 1],
                        u = l[t + 2];
                    if (typeof e != "function") {
                        if (lf(e || a) === null) continue;
                        break
                    }
                    var n = Ca(a);
                    n !== null && (l.splice(t, 3), t -= 3, lc(n, {
                        pending: !0,
                        data: u,
                        method: a.method,
                        action: e
                    }, e, u))
                }
            }))
        }

        function gu(l) {
            function t(f) {
                return Un(f, l)
            }
            sa !== null && Un(sa, l), oa !== null && Un(oa, l), da !== null && Un(da, l), vu.forEach(t), yu.forEach(t);
            for (var a = 0; a < ra.length; a++) {
                var e = ra[a];
                e.blockedOn === l && (e.blockedOn = null)
            }
            for (; 0 < ra.length && (a = ra[0], a.blockedOn === null);) f1(a), a.blockedOn === null && ra.shift();
            if (a = (l.ownerDocument || l).$$reactFormReplay, a != null)
                for (e = 0; e < a.length; e += 3) {
                    var u = a[e],
                        n = a[e + 1],
                        i = u[Jl] || null;
                    if (typeof n == "function") i || o1(a);
                    else if (i) {
                        var c = null;
                        if (n && n.hasAttribute("formAction")) {
                            if (u = n, i = n[Jl] || null) c = i.formAction;
                            else if (lf(u) !== null) continue
                        } else c = i.action;
                        typeof c == "function" ? a[e + 1] = c : (a.splice(e, 3), e -= 3), o1(a)
                    }
                }
        }

        function af(l) {
            this._internalRoot = l
        }
        Nn.prototype.render = af.prototype.render = function(l) {
            var t = this._internalRoot;
            if (t === null) throw Error(m(409));
            var a = t.current,
                e = it();
            e1(a, e, l, t, null, null)
        }, Nn.prototype.unmount = af.prototype.unmount = function() {
            var l = this._internalRoot;
            if (l !== null) {
                this._internalRoot = null;
                var t = l.containerInfo;
                e1(l.current, 2, null, l, null, null), hn(), t[qa] = null
            }
        };

        function Nn(l) {
            this._internalRoot = l
        }
        Nn.prototype.unstable_scheduleHydration = function(l) {
            if (l) {
                var t = _f();
                l = {
                    blockedOn: null,
                    target: l,
                    priority: t
                };
                for (var a = 0; a < ra.length && t !== 0 && t < ra[a].priority; a++);
                ra.splice(a, 0, l), a === 0 && f1(l)
            }
        };
        var d1 = F.version;
        if (d1 !== "19.1.0") throw Error(m(527, d1, "19.1.0"));
        _.findDOMNode = function(l) {
            var t = l._reactInternals;
            if (t === void 0) throw typeof l.render == "function" ? Error(m(188)) : (l = Object.keys(l).join(","), Error(m(268, l)));
            return l = x(t), l = l !== null ? T(l) : null, l = l === null ? null : l.stateNode, l
        };
        var ah = {
            bundleType: 0,
            version: "19.1.0",
            rendererPackageName: "react-dom",
            currentDispatcherRef: b,
            reconcilerVersion: "19.1.0"
        };
        if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
            var Hn = __REACT_DEVTOOLS_GLOBAL_HOOK__;
            if (!Hn.isDisabled && Hn.supportsFiber) try {
                Te = Hn.inject(ah), Pl = Hn
            } catch {}
        }
        return Se.createRoot = function(l, t) {
            if (!W(l)) throw Error(m(299));
            var a = !1,
                e = "",
                u = _0,
                n = x0,
                i = O0,
                c = null;
            return t != null && (t.unstable_strictMode === !0 && (a = !0), t.identifierPrefix !== void 0 && (e = t.identifierPrefix), t.onUncaughtError !== void 0 && (u = t.onUncaughtError), t.onCaughtError !== void 0 && (n = t.onCaughtError), t.onRecoverableError !== void 0 && (i = t.onRecoverableError), t.unstable_transitionCallbacks !== void 0 && (c = t.unstable_transitionCallbacks)), t = t1(l, 1, !1, null, null, a, e, u, n, i, c, null), l[qa] = t.current, jc(l), new af(t)
        }, Se.hydrateRoot = function(l, t, a) {
            if (!W(l)) throw Error(m(299));
            var e = !1,
                u = "",
                n = _0,
                i = x0,
                c = O0,
                f = null,
                h = null;
            return a != null && (a.unstable_strictMode === !0 && (e = !0), a.identifierPrefix !== void 0 && (u = a.identifierPrefix), a.onUncaughtError !== void 0 && (n = a.onUncaughtError), a.onCaughtError !== void 0 && (i = a.onCaughtError), a.onRecoverableError !== void 0 && (c = a.onRecoverableError), a.unstable_transitionCallbacks !== void 0 && (f = a.unstable_transitionCallbacks), a.formState !== void 0 && (h = a.formState)), t = t1(l, 1, !0, t, a ? ? null, e, u, n, i, c, f, h), t.context = a1(null), a = t.current, e = it(), e = Jn(e), u = Wt(e), u.callback = null, $t(a, u, e), a = e, t.current.lanes = a, Ae(t, a), Mt(t), l[qa] = t.current, jc(l), new Nn(t)
        }, Se.version = "19.1.0", Se
    }
    var vf;

    function S1() {
        if (vf) return Yn.exports;
        vf = 1;

        function p() {
            if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
                __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(p)
            } catch (F) {
                console.error(F)
            }
        }
        return p(), Yn.exports = b1(), Yn.exports
    }
    var T1 = S1(),
        Rl = wn();
    const E1 = "#ff9100",
        A1 = ["ar", "fa", "he", "ur", "he-IL"],
        z1 = () => {
            const [p, F] = Rl.useState(!1);
            return Rl.useEffect(() => {
                const B = () => {
                        let W = !1;
                        return function(P) {
                            (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(P) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(P.substr(0, 4))) && (W = !0)
                        }(navigator.userAgent || navigator.vendor || window.opera), W
                    },
                    m = () => window.innerWidth <= 800 && window.innerHeight <= 600;
                F(B() || m())
            }, []), {
                isMobile: p,
                isDesktop: !p
            }
        },
        M1 = p => {
            const [F, B] = Rl.useState(!1);
            return Rl.useEffect(() => {
                var T;
                const m = () => {
                    const {
                        pathname: z
                    } = window.location, Q = {
                        Homepage: /^\/$/,
                        Collection: /^\/collections\//,
                        Product: /^\/products\//,
                        Cart: /^\/cart$/,
                        Blog: /^\/blogs\//,
                        About: /^\/about$/,
                        Contact: /contact/i,
                        Faqs: /^\/pages\/faqs$/,
                        FrequentlyAskedQuestions: /^\/pages\/frequently-asked-questions$/
                    };
                    for (const [X, ul] of Object.entries(Q))
                        if (ul.test(z)) return X;
                    return null
                };
                if (!p) {
                    B(!1);
                    return
                }
                const W = m(),
                    P = !(p != null && p.hasShowOnThesePages) || !!W && ((T = p.showOnThesePages) == null ? void 0 : T.includes(W)),
                    el = window.location.href,
                    nl = (p.customPageUrls || "").split(",").map(z => z.trim()).filter(Boolean),
                    x = p.hasCustomPageUrls ? nl.some(z => el.includes(z)) : !1;
                B(!!(P || x))
            }, [p]), {
                isValidPage: F
            }
        },
        yf = "https://widget-view.dondy.net/api",
        _1 = async p => (await fetch(`${yf}/reports`, {
            method: "POST",
            body: JSON.stringify(p),
            headers: {
                "Content-Type": "application/json"
            }
        })).json(),
        x1 = async p => (await fetch(`${yf}/WhatsAppWidgetsView/${p}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        })).json();
    var O1 = {};
    const mf = () => {
            const [p, F] = Rl.useState(null), {
                isMobile: B,
                isDesktop: m
            } = z1(), {
                isValidPage: W
            } = M1(p), [P, el] = Rl.useState(!1);
            Rl.useEffect(() => {
                var il;
                (async () => {
                    var K;
                    try {
                        const gl = (K = window.Shopify) == null ? void 0 : K.shop,
                            L = await x1(gl);
                        F(L)
                    } catch (gl) {
                        console.error("Failed to load widget details:", gl)
                    }
                })();
                const vl = (il = window.Shopify) == null ? void 0 : il.locale;
                A1.includes(vl) && el(!0)
            }, []);
            const nl = async (Z = "click_chat") => {
                    var il;
                    const vl = ((il = window.Shopify) == null ? void 0 : il.shop) || O1.VITE_OVERRIDE_SHOP_DOMAIN;
                    if (vl) try {
                        const K = !z();
                        await _1({
                            shopDomain: "https://" + vl,
                            eventType: Z,
                            isUnique: K
                        })
                    } catch (K) {
                        console.error("Error:", K)
                    }
                },
                x = async () => {
                    await nl("chat_window_opened")
                },
                T = async () => {
                    await nl("click_chat")
                },
                z = () => localStorage.getItem("chatClicked") ? !0 : (localStorage.setItem("chatClicked", "true"), !1),
                Q = Z => {
                    if (!(p != null && p.phoneNumber)) return "";
                    let vl = `https://wa.me/${p.phoneNumber}?text=`;
                    !B && p.whatsAppDesktop === !1 && (vl = `https://web.whatsapp.com/send?phone=${p.phoneNumber}&text=`);
                    const il = window.location.href.split("?")[0],
                        K = p.AddPageURL ? encodeURIComponent(il) : "",
                        gl = Z === void 0 ? p.prefilledMessage : Z;
                    return gl && K ? `${vl}${encodeURIComponent(gl)}%0A%0A${K}` : `${vl}${encodeURIComponent(gl)}${K}`
                },
                X = Z => {
                    var _t;
                    if (!((_t = Z == null ? void 0 : Z.timeZone) != null && _t.value) || !Z.hoursRange) return !1;
                    const vl = Z.timeZone.value,
                        il = new Date,
                        K = new Intl.DateTimeFormat("en-US", {
                            timeZone: vl,
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: !1
                        }).format(il),
                        [gl, L] = K.split(":"),
                        Nl = `${gl.padStart(2,"0")}:${L.padStart(2,"0")}`,
                        w = new Intl.DateTimeFormat("en-US", {
                            timeZone: vl,
                            weekday: "long"
                        }).format(il).toLowerCase(),
                        Sl = Z.hoursRange[`${w}From`],
                        Ql = Z.hoursRange[`${w}To`];
                    return !Sl || !Ql ? !1 : Nl >= Sl && Nl <= Ql
                },
                ul = (() => {
                    if (!(p != null && p.phoneNumber) || p.customHours && p.hasCustomHours && !X(p.customHours) || !W) return !1;
                    const {
                        showWidgetOnSelectedDevice: Z
                    } = p;
                    switch (Z) {
                        case "Phone":
                            return B;
                        case "Desktop":
                            return m;
                        case "Both":
                        default:
                            return !0
                    }
                })(),
                ml = (p == null ? void 0 : p.WidgetSize) || "60px",
                _l = (p == null ? void 0 : p.chatSide) || "right";
            return {
                widgetDetails: p,
                getWhatsAppLink: Q,
                isVisible: ul,
                handleClick: nl,
                handleChatWindowOpened: x,
                handleChatClick: T,
                position: _l,
                widgetSize: ml,
                showRTL: P
            }
        },
        gf = Rl.createContext(void 0),
        D1 = ({
            children: p
        }) => {
            const [F, B] = Rl.useState(() => {
                const x = localStorage.getItem("chatMessages");
                return x ? JSON.parse(x) : []
            }), [m, W] = Rl.useState(""), [P, el] = Rl.useState(!1), nl = async x => {
                const T = {
                        text: x,
                        type: "user"
                    },
                    z = [...F, T];
                try {
                    el(!0), B(z), localStorage.setItem("chatMessages", JSON.stringify(z)), W("");
                    const _l = {
                            text: (await (await fetch("https://cdn.chatbot.com/widget/api/v2/chat", {
                                method: "POST",
                                headers: {
                                    Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2ODE0OTg3MzZhYmJlNTAwMDc5NzQyNGMiLCJvcmciOiI1Y2E3MTk0MmQwNDJlYjAwMDc2NTJlZjIiLCJzY29wZSI6ImNoYXQiLCJtZXRhIjp7InNvdXJjZSI6Im9wZW53aWRnZXQiLCJzdG9yeUlkIjoiNjFmMjg0NTFmZGQ3YzUwMDA3MjhiNGY2Iiwic2lkIjoiN2YzZmI1YjAtYzY2ZS00ZGE5LWIyNzAtODhiZWJiOTQ2NGJkIn0sImlhdCI6MTc0NjE4MDIxMSwiZXhwIjoxNzQ2MjA5MDExLCJhdWQiOiJhcGkuY2hhdGJvdC5jb20iLCJpc3MiOiJhcGkuY2hhdGJvdC5jb20iLCJqdGkiOiJiYzM0Y2NjZi0xNjIzLTRkN2ItOTk4OS0yYzA3ZjRlNzIzODYifQ.QF0Ih-s_bhfu5mo41dNtyrsLLqifjWuXrl7oHuYE4_E",
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    inputType: "MESSAGE",
                                    inputValue: x
                                })
                            })).json()).responses.find(vl => vl.type === "BOT_RESPONSE").responses[0].message || "Sorry, I could not process that.",
                            type: "reply"
                        },
                        Z = [...z, _l];
                    B(Z), localStorage.setItem("chatMessages", JSON.stringify(Z))
                } catch (Q) {
                    console.error("Error sending message:", Q);
                    const X = {
                            text: "Sorry, something went wrong.",
                            type: "reply"
                        },
                        ul = [...z, X];
                    B(ul), localStorage.setItem("chatMessages", JSON.stringify(ul))
                } finally {
                    el(!1)
                }
            };
            return $.jsx(gf.Provider, {
                value: {
                    messages: F,
                    input: m,
                    isTyping: P,
                    setInput: W,
                    sendMessage: nl
                },
                children: p
            })
        };

    function U1() {
        const p = Rl.useContext(gf);
        if (p === void 0) throw new Error("useChatContext must be used within a ChatProvider");
        return p
    }
    const R1 = "data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M12%2010.586L16.95%205.63599L18.364%207.04999L13.414%2012L18.364%2016.95L16.95%2018.364L12%2013.414L7.04999%2018.364L5.63599%2016.95L10.586%2012L5.63599%207.04999L7.04999%205.63599L12%2010.586Z'%20fill='white'%3e%3c/path%3e%3c/svg%3e",
        pf = "data:image/svg+xml,%3csvg%20version='1.1'%20id='Layer_1'%20xmlns='http://www.w3.org/2000/svg'%20xmlns:xlink='http://www.w3.org/1999/xlink'%20x='0px'%20y='0px'%20viewBox='0%200%20122.88%20122.88'%20style='enable-background:new%200%200%20122.88%20122.88'%20xml:space='preserve'%3e%3cstyle%20type='text/css'%3e%20.st0{fill:rgb(255,145,0);}%20/*%20formerly%20%231A73E8%20*/%20.st1{fill:%23185ABC;}%20/*%20unchanged%20*/%20.st2{fill:%23FFFFFF;}%20/*%20white%20stays%20the%20same%20*/%20.st3{fill:rgb(255,187,98);}%20/*%20formerly%20%238AB4F8%20*/%20%3c/style%3e%3cg%3e%3cpath%20class='st0'%20d='M122.88,61.41C122.88,27.49,95.39,0,61.47,0S0.06,27.49,0.06,61.41s27.49,61.41,61.41,61.41%20S122.88,95.32,122.88,61.41L122.88,61.41z'/%3e%3cpath%20class='st1'%20d='M83.82,87.93H41.97c-5.95,0-11.14-4.49-11.14-10.45v-0.06v3.48c0,5.95,5.19,11.14,11.14,11.14h41.85%20c6.01,0,11.14-5.25,11.14-11.14v-3.48C94.96,83.38,89.77,87.93,83.82,87.93L83.82,87.93L83.82,87.93z%20M30.77,57.93v-4.75%20l-7.79-12.85c-0.44-0.7-0.63-1.33-0.57-1.96v5.44c0,0.51,0.19,1.01,0.51,1.58L30.77,57.93L30.77,57.93z'/%3e%3cpath%20class='st2'%20d='M83.82,36.28H25.2c-2.34,0-3.67,2.03-2.09,4.18l7.66,13.29v23.74c0,6.08,4.43,11.14,10.45,11.14h42.54%20c6.01,0,11.14-5.13,11.14-11.14V47.48C94.96,41.4,89.83,36.28,83.82,36.28L83.82,36.28z'/%3e%3cpath%20class='st3'%20d='M83.12,53.05H42.67c-1.77,0-3.48-1.08-3.48-2.79c0-1.71,1.71-2.79,3.48-2.79h40.45c1.77,0,3.48,1.08,3.48,2.79%20C86.6,51.98,84.9,53.05,83.12,53.05L83.12,53.05L83.12,53.05z%20M83.12,64.19H42.67c-1.77,0-3.48-1.08-3.48-2.79%20c0-1.71,1.71-2.79,3.48-2.79h40.45c1.77,0,3.48,1.08,3.48,2.79C86.6,63.12,84.9,64.19,83.12,64.19L83.12,64.19L83.12,64.19z%20M71.92,75.4H42.61c-1.77,0-3.48-1.08-3.48-2.79c0-1.71,1.71-2.79,3.48-2.79h29.31c1.77,0,3.48,1.08,3.48,2.79%20C75.4,74.32,73.69,75.4,71.92,75.4L71.92,75.4z'/%3e%3cpath%20class='st1'%20d='M122.88,61.09c-0.13,26.91-17.66,49.76-41.85,57.86c-6.14,2.09-12.72,3.17-19.56,3.17%20c-33.81,0-61.22-27.29-61.41-61.03v0.38c0,33.93,27.48,61.41,61.41,61.41c6.84,0,13.42-1.14,19.56-3.17%20c24.31-8.17,41.85-31.15,41.85-58.24V61.09L122.88,61.09z'/%3e%3cpath%20class='st3'%20d='M80.97,3.17C74.83,1.08,68.25,0,61.41,0C27.48,0,0,27.48,0,61.41v0.38C0.19,28.04,27.6,0.76,61.41,0.76%20c6.84,0,13.42,1.14,19.56,3.17c24.25,8.1,41.72,30.96,41.85,57.86v-0.38C122.88,34.31,105.34,11.33,80.97,3.17L80.97,3.17z'/%3e%3c/g%3e%3c/svg%3e",
        N1 = "data:image/svg+xml,%3csvg%20preserveAspectRatio='xMidYMid%20meet'%20data-bbox='0%200%20358.751%20106'%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20358.751%20106'%20height='106'%20width='359'%20data-type='color'%20role='presentation'%20aria-hidden='true'%20aria-label=''%3e%3cg%3e%3cpath%20fill='%23DD7C15'%20d='M53.452%205.074Q44.38.154%2032.246.155H0v77.39h32.246q12.134%200%2021.206-5.027%209.182-5.138%2014.1-13.992%204.92-8.854%204.92-19.894%200-11.15-4.92-19.894-4.918-8.745-14.1-13.664m2.703%2033.777c0%2011.738-9.516%2021.254-21.254%2021.254a21.2%2021.2%200%200%201-6.763-1.098l-15.24%206.236%203.968-15.14a21.16%2021.16%200%200%201-3.22-11.252c0-11.739%209.516-21.255%2021.255-21.255s21.254%209.516%2021.254%2021.255'%20clip-rule='evenodd'%20fill-rule='evenodd'%20data-color='1'%3e%3c/path%3e%3cpath%20fill='%23DD7C15'%20d='M112.446%2078.894q-8.649%200-15.61-3.692-6.856-3.692-10.864-10.547-3.903-6.856-3.902-16.032%200-9.07%204.008-15.926%204.007-6.962%2010.969-10.653t15.61-3.692%2015.61%203.692q6.96%203.69%2010.969%2010.653%204.008%206.855%204.008%2015.926t-4.114%2016.032q-4.008%206.855-11.074%2010.547-6.961%203.692-15.61%203.692m0-15.61q5.168%200%208.754-3.797%203.691-3.798%203.691-10.864t-3.586-10.864q-3.48-3.797-8.648-3.797-5.274%200-8.755%203.797-3.48%203.692-3.48%2010.864%200%207.066%203.375%2010.864%203.48%203.796%208.649%203.797'%20data-color='1'%3e%3c/path%3e%3cpath%20fill='%23DD7C15'%20d='M189.727%2018.563q10.337%200%2016.454%206.75%206.223%206.645%206.223%2018.353V78.05h-17.93V46.092q0-5.907-3.059-9.177-3.058-3.27-8.227-3.27-5.168%200-8.227%203.27-3.058%203.27-3.058%209.177V78.05h-18.036V19.196h18.036v7.805q2.742-3.902%207.383-6.117%204.64-2.32%2010.441-2.32'%20data-color='1'%3e%3c/path%3e%3cpath%20fill='%23DD7C15'%20d='M222.406%2048.517q0-9.07%203.375-15.926%203.48-6.855%209.387-10.547%205.906-3.692%2013.184-3.692%205.8%200%2010.547%202.426%204.852%202.426%207.594%206.54V0h18.036v78.05h-18.036v-8.438q-2.53%204.22-7.277%206.75-4.64%202.532-10.864%202.532-7.278%200-13.184-3.692-5.907-3.796-9.387-10.653-3.375-6.96-3.375-16.032m44.087.106q0-6.75-3.797-10.653-3.691-3.902-9.07-3.902t-9.176%203.902q-3.692%203.797-3.692%2010.547t3.692%2010.759q3.797%203.902%209.176%203.902t9.07-3.902q3.798-3.903%203.797-10.653'%20data-color='1'%3e%3c/path%3e%3cpath%20fill='%23DD7C15'%20d='M358.751%2019.196%20321.836%20106h-19.407l13.501-29.954-23.943-56.85h20.146l13.606%2036.81%2013.5-36.81z'%20data-color='1'%3e%3c/path%3e%3c/g%3e%3c/svg%3e",
        H1 = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='white'%3e%3cpath%20d='M2%2021l21-9L2%203v7l15%202-15%202v7z'/%3e%3c/svg%3e",
        q1 = ({
            onClose: p,
            chatColor: F,
            position: B,
            shouldAdjustHeight: m,
            chatTheme: W,
            prefilledMessage: P,
            hideBranding: el,
            onMessageSent: nl
        }) => {
            const {
                messages: x,
                input: T,
                isTyping: z,
                setInput: Q,
                sendMessage: X
            } = U1(), ul = Rl.useRef(null), ml = Rl.useRef(null), [_l, Z] = Rl.useState(!1), {
                getWhatsAppLink: vl,
                showRTL: il
            } = mf();
            Rl.useEffect(() => {
                const w = document.getElementById("whatsapp-link");
                return w && (w.style.display = "none"), P && Q(P), () => {
                    w && (w.style.display = "flex")
                }
            }, []), Rl.useEffect(() => {
                m && K()
            }, [m]);
            const K = () => {
                    setTimeout(() => {
                        var w;
                        ul.current && (ul.current.scrollTop = ul.current.scrollHeight), (w = ml.current) == null || w.focus()
                    }, 100)
                },
                gl = async () => {
                    const w = T.trim(),
                        Sl = vl(w);
                    window.open(Sl, "_blank"), nl && nl()
                },
                L = () => {
                    Z(!0), setTimeout(() => {
                        p()
                    }, 200)
                },
                Nl = () => W === "whatsapp" ? "whatsapp-theme" : "";
            return $.jsxs("div", {
                className: `chat-window ${_l?"closing":""} ${Nl()}`,
                style: {
                    position: "fixed",
                    bottom: "20px",
                    [B]: "20px"
                },
                children: [$.jsxs("div", {
                    className: "chat-header",
                    style: {
                        backgroundColor: F
                    },
                    children: [$.jsx("span", {
                        children: "WhatsApp"
                    }), $.jsx("button", {
                        className: "d-widget-close-btn",
                        style: {
                            minWidth: "24px",
                            minHeight: "24px"
                        },
                        onClick: L,
                        children: $.jsx("img", {
                            src: R1,
                            alt: "Close"
                        })
                    })]
                }), $.jsxs("div", {
                    className: "chat-messages",
                    ref: ul,
                    children: [x.map((w, Sl) => $.jsxs("div", {
                        className: `message ${w.type}`,
                        style: w.type === "user" ? {
                            backgroundColor: F
                        } : void 0,
                        children: [w.type === "reply" && $.jsx("img", {
                            src: pf,
                            alt: "Bot",
                            className: "bot-avatar"
                        }), w.text]
                    }, Sl)), z && $.jsxs("div", {
                        className: "message reply",
                        children: [$.jsx("img", {
                            src: pf,
                            alt: "Bot",
                            className: "bot-avatar"
                        }), $.jsxs("div", {
                            className: "typing-indicator",
                            children: [$.jsx("span", {}), $.jsx("span", {}), $.jsx("span", {})]
                        })]
                    })]
                }), $.jsxs("div", {
                    className: "chat-input",
                    children: [$.jsx("input", {
                        ref: ml,
                        type: "text",
                        value: T,
                        disabled: z,
                        style: {
                            maxHeight: "40px"
                        },
                        onChange: w => Q(w.target.value),
                        onKeyDown: w => w.key === "Enter" && gl(),
                        dir: il ? "rtl" : "ltr",
                        onBlur: w => {
                            var Sl, Ql;
                            w.relatedTarget && !((Sl = w.currentTarget.closest(".chat-window")) != null && Sl.contains(w.relatedTarget)) && ((Ql = ml.current) == null || Ql.focus())
                        }
                    }), $.jsx("button", {
                        onClick: gl,
                        style: {
                            backgroundColor: F,
                            padding: "1px 0px"
                        },
                        children: $.jsx("img", {
                            src: H1,
                            alt: "Send"
                        })
                    })]
                }), $.jsx("div", {
                    className: "powered-by",
                    children: !el && $.jsxs($.Fragment, {
                        children: ["Powered by", $.jsx("div", {
                            children: $.jsx("img", {
                                src: N1,
                                alt: "Dondy",
                                style: {
                                    cursor: "pointer",
                                    maxHeight: "16px",
                                    minHeight: "16px",
                                    height: "16px",
                                    width: "auto",
                                    objectFit: "contain",
                                    display: "inline-block",
                                    verticalAlign: "middle",
                                    marginLeft: "10px",
                                    marginRight: "10px"
                                },
                                onClick: () => window.open("https://dondy.net", "_blank")
                            })
                        })]
                    })
                })]
            })
        },
        Y1 = () => {
            var _l, Z, vl;
            const {
                widgetDetails: p,
                getWhatsAppLink: F,
                isVisible: B,
                handleClick: m,
                handleChatWindowOpened: W,
                handleChatClick: P,
                position: el,
                widgetSize: nl
            } = mf(), [x, T] = Rl.useState(!1), z = ((_l = p == null ? void 0 : p.chatWindow) == null ? void 0 : _l.enabled) || !1;
            if (!p) return null;
            const Q = {
                "--whatsapp-link-width": nl,
                "--whatsapp-link-height": nl
            };
            console.log("With new chat widget");
            const X = ["left", "upper-left", "mid-upper-left"].includes(el),
                ul = () => {
                    const il = p.WhatsAppIconSvg;
                    il || console.log("No icon svg");
                    const K = p.TextBesideTheIcon;
                    return K ? (console.log("text", K), $.jsxs("div", {
                        style: Q,
                        className: "whatsapp-flex-container",
                        children: [X && $.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: il
                            }
                        }), $.jsx("span", {
                            className: "whatsapp-text",
                            children: K
                        }), !X && $.jsx("div", {
                            dangerouslySetInnerHTML: {
                                __html: il
                            }
                        })]
                    })) : (console.log("No text"), $.jsx("div", {
                        style: Q,
                        dangerouslySetInnerHTML: {
                            __html: il
                        }
                    }))
                },
                ml = il => {
                    z ? (il.preventDefault(), T(K => !K), W()) : m()
                };
            return B && $.jsxs("div", {
                id: "chat-bubble",
                className: `whatsapp-widget whatsapp-widget-${el} whatsapp-widget-visible`,
                "aria-label": "Open WhatsApp chat",
                children: [$.jsx("a", {
                    id: "whatsapp-link",
                    href: F(),
                    target: "_blank",
                    rel: "noopener noreferrer",
                    onClick: ml,
                    "aria-label": "Send a message via WhatsApp",
                    style: {
                        position: "relative"
                    },
                    children: ul()
                }), z && $.jsx("div", {
                    className: `chat-fade-wrapper ${x?"open":"closing"}`,
                    "data-position": el,
                    children: x && $.jsx(D1, {
                        children: $.jsx(q1, {
                            onClose: () => T(!1),
                            chatColor: E1,
                            position: X ? "left" : "right",
                            shouldAdjustHeight: x,
                            chatTheme: (Z = p == null ? void 0 : p.chatWindow) == null ? void 0 : Z.theme,
                            prefilledMessage: p == null ? void 0 : p.prefilledMessage,
                            hideBranding: (vl = p == null ? void 0 : p.chatWindow) == null ? void 0 : vl.hideBranding,
                            onMessageSent: P
                        })
                    })
                })]
            })
        },
        Qn = document.createElement("div");
    Qn.id = "whatsapp-widget-root", document.body.appendChild(Qn), T1.createRoot(Qn).render($.jsx(Y1, {}))
})();
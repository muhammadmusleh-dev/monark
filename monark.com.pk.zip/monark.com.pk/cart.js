{
    "token": "717b1558ff9b77d6a2995292813d36a2",
    "note": null,
    "attributes": {},
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "PKR",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": [],
    "discount_codes": []
}
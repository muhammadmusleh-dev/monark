(function(shopify) {
    (() => {
        var O = "WebPixel::Render";
        var k = c => shopify.extend(O, c);
        var z = "https://connect.facebook.net/en_US/fbevents.js",
            W = ["default", "title", "default title", ""];

        function X() {
            window.fbq && typeof window.fbq == "function" || (window.fbq = function(...c) {
                var b;
                window.fbq.callMethod ? window.fbq.callMethod.apply(window.fbq, c) : (b = window.fbq.queue) == null || b.push(c)
            }, window._fbq || (window._fbq = window.fbq), window.fbq.push = window.fbq, window.fbq.loaded = !0, window.fbq.version = "2.0", window.fbq.queue = [])
        }

        function F() {
            let c = document.createElement("script");
            return c.setAttribute("async", "true"), c.setAttribute("src", z), c
        }

        function H() {
            var b;
            let c = document.getElementsByTagName("script")[0];
            c === void 0 ? document.head.appendChild(F()) : (b = c.parentNode) == null || b.insertBefore(F(), c)
        }
        X();
        H();
        k(({
            analytics: c,
            browser: b,
            settings: B,
            init: M,
            customerPrivacy: R
        }) => {
            let q = B.pixel_id;

            function g(t, n, e = {}, o = {}) {
                window.fbq("trackShopify", q, t, e, {
                    eventID: n
                }, o)
            }

            function y(t) {
                return (t == null ? void 0 : t.product.id) || (t == null ? void 0 : t.id) || (t == null ? void 0 : t.sku)
            }

            function h(t) {
                return (t == null ? void 0 : t.id) || (t == null ? void 0 : t.sku) || (t == null ? void 0 : t.product.id)
            }

            function P(t) {
                let n = [],
                    e = t.lineItems;
                if (e != null)
                    for (let o of e) {
                        let s = y(o.variant);
                        s != null && n.push(parseInt(s))
                    }
                return n
            }

            function A(t) {
                var e;
                let n = t.lineItems;
                if (n != null) {
                    for (let o of n)
                        if ((e = o.variant) != null && e.product.id) return "product_group"
                }
                return "product"
            }

            function I(t) {
                let n = [],
                    e = t.lineItems;
                if (e != null)
                    for (let o of e) {
                        let s = h(o.variant);
                        s != null && n.push(parseInt(s))
                    }
                return n
            }

            function D(t) {
                var e, o;
                let n = t.lineItems;
                if (n != null) {
                    for (let s of n)
                        if ((e = s.variant) != null && e.id || (o = s.variant) != null && o.sku) return "product"
                }
                return "product_group"
            }

            function x(t) {
                let n = 0,
                    e = t.lineItems;
                if (e != null)
                    for (let o of e) n += o.quantity || 1;
                return n
            }

            function E(t) {
                var o, s, u, i, l, r, d, f;
                let n = [],
                    e = t.lineItems;
                if (e != null)
                    for (let p of e) {
                        let m = ((o = p.variant) == null ? void 0 : o.product.id) || ((s = p.variant) == null ? void 0 : s.id) || ((u = p.variant) == null ? void 0 : u.sku),
                            a = ((i = p.variant) == null ? void 0 : i.id) || ((l = p.variant) == null ? void 0 : l.sku) || ((r = p.variant) == null ? void 0 : r.product.id);
                        if (m != null && a != null) {
                            let _ = {};
                            _.id = m ? parseInt(m) : null, _.sku = a ? parseInt(a) : null, _.item_price = ((f = (d = p.variant) == null ? void 0 : d.price) == null ? void 0 : f.amount) || null, _.quantity = p.quantity || 1, _.currency = t.currencyCode || "USD", n.push(_)
                        }
                    }
                return n
            }

            function w(t) {
                let n = {},
                    e = y(t),
                    o = h(t);
                return e != null && o != null && (n.id = e ? parseInt(e) : null, n.sku = o ? parseInt(o) : null, n.item_price = (t == null ? void 0 : t.price.amount) || null, n.currency = (t == null ? void 0 : t.price.currencyCode) || "USD", n.quantity = 1), n
            }

            function j(t) {
                var e, o;
                let n = t.transactions;
                if (n != null && n.length > 0) {
                    let s = n[0],
                        u = s.gateway || "",
                        i = ((e = s.paymentMethod) == null ? void 0 : e.name) || "",
                        l = ((o = s.paymentMethod) == null ? void 0 : o.type) || "",
                        r = {};
                    return r.gateway = u, r.name = i, r.type = l, r
                }
                return null
            }

            function S(t, n) {
                return n == null || W.includes(n.toLowerCase()) ? t || "" : t + " - " + n
            }

            function v(t) {
                var o, s, u, i, l, r, d, f, p, m, a, _, U, N;
                let n = {};
                n.ct = ((o = t.billingAddress) == null ? void 0 : o.city) || ((s = t.shippingAddress) == null ? void 0 : s.city), n.country = ((u = t.billingAddress) == null ? void 0 : u.countryCode) || ((i = t.shippingAddress) == null ? void 0 : i.countryCode), n.fn = ((l = t.billingAddress) == null ? void 0 : l.firstName) || ((r = t.shippingAddress) == null ? void 0 : r.firstName), n.ln = ((d = t.billingAddress) == null ? void 0 : d.lastName) || ((f = t.shippingAddress) == null ? void 0 : f.lastName), n.ph = t.phone, n.st = ((p = t.billingAddress) == null ? void 0 : p.provinceCode) || ((m = t.shippingAddress) == null ? void 0 : m.provinceCode), n.zp = ((a = t.billingAddress) == null ? void 0 : a.zip) || ((_ = t.shippingAddress) == null ? void 0 : _.zip), n.em = t.email;
                let e = (N = (U = t.order) == null ? void 0 : U.customer) == null ? void 0 : N.id;
                e != null && e.length > 0 && (n.external_id = e), window.fbq("set", "userData", n)
            }

            function T(t) {
                t ? window.fbq("dataProcessingOptions", []) : window.fbq("dataProcessingOptions", ["LDU"], 0, 0)
            }
            let C = M.customerPrivacy.saleOfDataAllowed;
            T(C), window.fbq("init", q, {}, {
                agent: "shopify_web_pixel"
            }), R.subscribe("visitorConsentCollected", t => {
                C = t.customerPrivacy.saleOfDataAllowed, T(C)
            }), c.subscribe("page_viewed", t => {
                g("PageView", t.id)
            }), c.subscribe("search_submitted", t => {
                let n = t.data.searchResult.query || "",
                    {
                        productVariants: e
                    } = t.data.searchResult,
                    o = [];
                for (let s of e) {
                    if (s == null) continue;
                    let u = w(s);
                    o.push(u)
                }
                g("Search", t.id, {
                    search_string: n
                }, {
                    contents: o
                })
            }), c.subscribe("product_viewed", t => {
                let {
                    productVariant: n
                } = t.data, e = y(n), o = e ? [parseInt(e)] : [], s = n.product.id ? "product_group" : "product", u = S(n.product.title, n.title), i = n.product.type || "", l = n.price.currencyCode || "USD", r = n.price.amount || null, d = h(n), f = d ? [parseInt(d)] : [], p = n.id || n.sku ? "product" : "product_group", a = [w(n)];
                g("ViewContent", t.id, {
                    content_ids: o,
                    content_type: s,
                    content_name: u,
                    content_category: i,
                    currency: l,
                    value: r
                }, {
                    product_variant_ids: f,
                    content_type_favor_variant: p,
                    contents: a
                })
            }), c.subscribe("cart_viewed", t => {
                var s, u;
                let {
                    cart: n
                } = t.data, e = [], o = n == null ? void 0 : n.lines;
                if (o != null && o.length > 0)
                    for (let i of o) {
                        let l = y(i == null ? void 0 : i.merchandise),
                            r = h(i == null ? void 0 : i.merchandise);
                        if (l != null && r != null) {
                            let d = {};
                            d.id = l ? parseInt(l) : null, d.sku = r ? parseInt(r) : null, d.item_price = ((s = i == null ? void 0 : i.merchandise) == null ? void 0 : s.price.amount) || null, d.quantity = (i == null ? void 0 : i.quantity) || 1, d.currency = ((u = i == null ? void 0 : i.merchandise) == null ? void 0 : u.price.currencyCode) || "USD", e.push(d)
                        }
                    }
                g("ViewContent", t.id, {
                    contents: e
                }, {
                    shopify_event_name: "cart_viewed"
                })
            }), c.subscribe("collection_viewed", t => {
                let {
                    collection: n
                } = t.data, e = n.productVariants, o = [];
                for (let s of e) {
                    if (s == null) continue;
                    let u = w(s);
                    o.push(u)
                }
                g("ViewContent", t.id, {
                    contents: o
                }, {
                    shopify_event_name: "collection_viewed"
                })
            }), c.subscribe("product_added_to_cart", t => {
                let {
                    cartLine: n
                } = t.data, e = y(n == null ? void 0 : n.merchandise), o = e ? [parseInt(e)] : [], s = n != null && n.merchandise.product.id ? "product_group" : "product", u = S(n == null ? void 0 : n.merchandise.product.title, n == null ? void 0 : n.merchandise.title), i = (n == null ? void 0 : n.merchandise.product.type) || "", l = (n == null ? void 0 : n.merchandise.price.currencyCode) || "USD", r = (n == null ? void 0 : n.merchandise.price.amount) || null, d = (n == null ? void 0 : n.quantity) || 1, f = h(n == null ? void 0 : n.merchandise), p = f ? [parseInt(f)] : [], m = n != null && n.merchandise.id || n != null && n.merchandise.sku ? "product" : "product_group", a = {};
                a.id = e ? parseInt(e) : null, a.sku = f ? parseInt(f) : null, a.item_price = r, a.quantity = d, a.currency = l;
                let _ = [a];
                g("AddToCart", t.id, {
                    content_ids: o,
                    content_type: s,
                    content_name: u,
                    content_category: i,
                    currency: l,
                    value: r,
                    num_items: d
                }, {
                    product_variant_ids: p,
                    content_type_favor_variant: m,
                    contents: _
                })
            }), c.subscribe("checkout_started", t => {
                var f;
                let {
                    checkout: n
                } = t.data;
                v(n);
                let e = P(n),
                    o = A(n),
                    s = n.currencyCode || "USD",
                    u = ((f = n.subtotalPrice) == null ? void 0 : f.amount) || 0,
                    i = x(n),
                    l = I(n),
                    r = D(n),
                    d = E(n);
                g("InitiateCheckout", t.id, {
                    content_ids: e,
                    content_type: o,
                    currency: s,
                    value: u,
                    num_items: i
                }, {
                    product_variant_ids: l,
                    content_type_favor_variant: r,
                    contents: d
                })
            }), c.subscribe("checkout_completed", t => {
                var m, a;
                let {
                    checkout: n
                } = t.data;
                v(n);
                let e = P(n),
                    o = A(n),
                    s = n.currencyCode || "USD",
                    u = ((m = n.totalPrice) == null ? void 0 : m.amount) || 0,
                    i = x(n),
                    l = I(n),
                    r = D(n),
                    d = E(n),
                    f = (a = n.order) == null ? void 0 : a.id,
                    p = j(n);
                g("Purchase", t.id, {
                    content_ids: e,
                    content_type: o,
                    currency: s,
                    value: u,
                    num_items: i
                }, {
                    product_variant_ids: l,
                    content_type_favor_variant: r,
                    contents: d,
                    order_id: f,
                    payment_method: p
                })
            }), c.subscribe("payment_info_submitted", t => {
                var s;
                let {
                    checkout: n
                } = t.data;
                v(n);
                let e = n.currencyCode || "USD",
                    o = ((s = n.totalPrice) == null ? void 0 : s.amount) || 0;
                g("AddPaymentInfo", t.id, {
                    currency: e,
                    value: o
                })
            })
        });
    })();

})(self.webPixelsManager.createShopifyExtend('47153281', 'app'));
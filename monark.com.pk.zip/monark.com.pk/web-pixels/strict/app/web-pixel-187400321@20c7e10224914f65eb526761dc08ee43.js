(() => {
    var ze = Object.create;
    var Z = Object.defineProperty,
        Qe = Object.defineProperties,
        Xe = Object.getOwnPropertyDescriptor,
        $e = Object.getOwnPropertyDescriptors,
        Ze = Object.getOwnPropertyNames,
        ve = Object.getOwnPropertySymbols,
        et = Object.getPrototypeOf,
        Ee = Object.prototype.hasOwnProperty,
        tt = Object.prototype.propertyIsEnumerable;
    var we = (n, e, t) => e in n ? Z(n, e, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }) : n[e] = t,
        W = (n, e) => {
            for (var t in e || (e = {})) Ee.call(e, t) && we(n, t, e[t]);
            if (ve)
                for (var t of ve(e)) tt.call(e, t) && we(n, t, e[t]);
            return n
        },
        be = (n, e) => Qe(n, $e(e));
    var j = (n, e) => () => (n && (e = n(n = 0)), e);
    var nt = (n, e) => () => (e || n((e = {
        exports: {}
    }).exports, e), e.exports);
    var ot = (n, e, t, o) => {
        if (e && typeof e == "object" || typeof e == "function")
            for (let i of Ze(e)) !Ee.call(n, i) && i !== t && Z(n, i, {
                get: () => e[i],
                enumerable: !(o = Xe(e, i)) || o.enumerable
            });
        return n
    };
    var it = (n, e, t) => (t = n != null ? ze(et(n)) : {}, ot(e || !n || !n.__esModule ? Z(t, "default", {
        value: n,
        enumerable: !0
    }) : t, n));
    var R = (n, e, t) => new Promise((o, i) => {
        var r = s => {
                try {
                    l(t.next(s))
                } catch (c) {
                    i(c)
                }
            },
            a = s => {
                try {
                    l(t.throw(s))
                } catch (c) {
                    i(c)
                }
            },
            l = s => s.done ? o(s.value) : Promise.resolve(s.value).then(r, a);
        l((t = t.apply(n, e)).next())
    });
    var Oe, ye = j(() => {
        Oe = "WebPixel::Render"
    });
    var ee, Ie = j(() => {
        ye();
        ee = n => shopify.extend(Oe, n)
    });
    var Te = j(() => {
        Ie()
    });
    var Re = j(() => {
        Te()
    });

    function Ne(n, e, t, o, i, r, a) {
        try {
            var l = n[r](a),
                s = l.value
        } catch (c) {
            return void t(c)
        }
        l.done ? e(s) : Promise.resolve(s).then(o, i)
    }

    function rt(n, e, t) {
        return (e = function(o) {
            var i = function(r, a) {
                if (typeof r != "object" || !r) return r;
                var l = r[Symbol.toPrimitive];
                if (l !== void 0) {
                    var s = l.call(r, a || "default");
                    if (typeof s != "object") return s;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return (a === "string" ? String : Number)(r)
            }(o, "string");
            return typeof i == "symbol" ? i : i + ""
        }(e)) in n ? Object.defineProperty(n, e, {
            value: t,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : n[e] = t, n
    }

    function Ce(n, e) {
        var t = Object.keys(n);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(n);
            e && (o = o.filter(function(i) {
                return Object.getOwnPropertyDescriptor(n, i).enumerable
            })), t.push.apply(t, o)
        }
        return t
    }

    function B(n) {
        for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e] != null ? arguments[e] : {};
            e % 2 ? Ce(Object(t), !0).forEach(function(o) {
                rt(n, o, t[o])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(t)) : Ce(Object(t)).forEach(function(o) {
                Object.defineProperty(n, o, Object.getOwnPropertyDescriptor(t, o))
            })
        }
        return n
    }

    function y(n, e, t, o) {
        return new(t || (t = Promise))(function(i, r) {
            function a(c) {
                try {
                    s(o.next(c))
                } catch (d) {
                    r(d)
                }
            }

            function l(c) {
                try {
                    s(o.throw(c))
                } catch (d) {
                    r(d)
                }
            }

            function s(c) {
                var d;
                c.done ? i(c.value) : (d = c.value, d instanceof t ? d : new t(function(p) {
                    p(d)
                })).then(a, l)
            }
            s((o = o.apply(n, e || [])).next())
        })
    }

    function z(n) {
        return new Promise(function(e, t) {
            n.oncomplete = n.onsuccess = function() {
                return e(n.result)
            }, n.onabort = n.onerror = function() {
                return t(n.error)
            }
        })
    }

    function st(n, e) {
        var t;
        return function(o, i) {
            return function() {
                if (t) return t;
                var r = indexedDB.open(n);
                return r.onupgradeneeded = function() {
                    return r.result.createObjectStore(e)
                }, (t = z(r)).then(function(a) {
                    a.onclose = function() {
                        return t = void 0
                    }
                }, function() {}), t
            }().then(function(r) {
                return i(r.transaction(e, o).objectStore(e))
            })
        }
    }

    function ne() {
        return te || (te = st("keyval-store", "keyval")), te
    }

    function Se(n) {
        var e;
        return !(!n || (e = n, at.call(e) !== "[object Error]") || n.name !== "TypeError" || typeof n.message != "string") && (n.message === "Load failed" ? n.stack === void 0 : ct.has(n.message))
    }

    function Ge(n, e) {
        window.sib && window.sib[n] ? window.sib[n](...e) : window.sib.equeue.push({
            [n]: e
        })
    }

    function mt() {
        try {
            return Intl.DateTimeFormat().resolvedOptions().timeZone
        } catch (n) {
            return null
        }
    }

    function D(n) {
        return [...new URLSearchParams(n).entries()].reduce((e, t) => {
            var [o, i] = t;
            return Object.assign(Object.assign({}, e), {
                [o]: i
            })
        }, {})
    }

    function P() {
        var n = navigator.userAgent,
            e = n.search("Firefox") >= 0,
            t = !!window.chrome,
            o = window.PushManager !== void 0,
            i = (l => {
                var {
                    ua: s,
                    maxTouchPoints: c
                } = l;
                if (!(/iPad|iPhone|iPod|Mac OS X/.test(s) && c > 0)) return !1;
                var d = s.match(/EdgiOS\/(\d+\.\d+)/);
                if (d && d.length >= 2) return parseFloat(d[1]) >= 112;
                var p = s.match(/Version\/(\d+\.\d+)/);
                if (p && p.length >= 2) return parseFloat(p[1]) >= 16.4;
                var g = s.match(/CPU iPhone OS (\d+_\d+)/);
                return !!(g && g.length >= 2) && parseFloat(g[1].replace("_", ".")) >= 16.4
            })({
                ua: n,
                maxTouchPoints: navigator.maxTouchPoints
            }),
            r = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream && !i,
            a = !!window.safari;
        return {
            isiOS: i,
            isSafari: a,
            isApnsSafari: a && !o,
            isFirefox: e,
            isChrome: t,
            isOldIOS: r,
            name: t ? L.CHROME : a ? L.SAFARI : e ? L.FIREFOX : L.OTHER,
            isAndroid: /(android)/i.test(n.toLowerCase())
        }
    }

    function ie(n) {
        var {
            method: e = "GET",
            url: t,
            contentType: o = "application/json",
            acceptType: i = "application/json",
            payload: r
        } = n;
        return new Promise((a, l) => {
            var s = new XMLHttpRequest;
            s.open(e, t, !0), s.setRequestHeader("Content-Type", o), s.setRequestHeader("Accept", i), r ? s.send(o.match(/json/) ? JSON.stringify(r) : r) : s.send(), s.onload = function() {
                var c = s.responseText;
                if (s.status >= 200 && s.status < 400) {
                    var d = i.match(/json/) ? JSON.parse(c) : c;
                    a(d)
                } else l(c)
            }
        })
    }

    function Ye() {
        for (var n = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-", e = "", t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 7; t--;) e += n[~~(64 * Math.random())];
        return e
    }

    function f() {
        for (var n = console, e = arguments.length, t = new Array(e), o = 0; o < e; o++) t[o] = arguments[o];
        Ve.push(t);
        var i = typeof localStorage != "undefined",
            r = typeof location != "undefined";
        (i && localStorage.getItem("pushowl_log_level") === se.DEBUG || r && location.href.match(/poTaskType=debug/)) && n.log("%c\u{1F989}PushOwl", "background: #fb446a; color: white; padding: 2px 0.5em; border-radius: 0.5em;", ...t)
    }

    function K(n) {
        var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        if (console.error("logerror", n, e), !navigator.userAgent.match(/Instagram|FBAN/) && !Se(n) && ![u.NOTIFICATION_PERMISSION.DEFAULT, u.NOTIFICATION_PERMISSION.DENIED, T.NOTIFICATION_NOT_DEFINED, T.OLD_IOS_DEVICE, T.MICROSOFT_EDGE, T.NO_SERVICE_WORKER, T.INCOGNITO, T.NO_FILE_SYSTEM, T.LOCALSTORAGE_NOT_AVAILABLE].includes(n)) {
            var t, o = "";
            window.pushowl && (o = window.pushowl.getSubdomain ? window.pushowl.getSubdomain() : window.pushowl.subdomain), typeof n == "string" ? (t = new Error(n)).name = n : t = n, ht.logException(t, Object.assign({
                breadcrumbs: Ve,
                subdomain: o,
                url: window.location.href
            }, e))
        }
    }
    var te, L, Pe, Ae, T, Q, ke, se, Ue, at, ct, ut, u, De, Ke, Be, N, oe, lt, dt, pt, v, ae, ce, ue, Le, xe, le, de, gt, k, b, ht, Ve, qe, _t, St, M, h, x, m, je, re, I, Fe, Me, fe, A, J, U, pe, G, ge, he, me, _e, Y, Ct, He = j(() => {
        at = Object.prototype.toString, ct = new Set(["network error", "Failed to fetch", "NetworkError when attempting to fetch resource.", "The Internet connection appears to be offline.", "Load failed", "Network request failed", "fetch failed", "terminated"]);
        (function(n) {
            n.CHROME = "chrome", n.FIREFOX = "firefox", n.SAFARI = "safari", n.OTHER = "other"
        })(L || (L = {})),
        function(n) {
            n.ONE_STEP = "oneStep", n.TWO_STEP = "twoStep", n.OFF = "off"
        }(Pe || (Pe = {})),
        function(n) {
            n.CUSTOM_BUTTONS = "custom-buttons", n.FLYOUT_WIDGET = "flyout-widget", n.PARTNER_JS_API = "partner-js-api"
        }(Ae || (Ae = {})),
        function(n) {
            n.NOT_SHOPIFY = "not_shopify", n.STORAGE_NOT_DEFINED = "storage_not_defined", n.LOCALSTORAGE_NOT_AVAILABLE = "localstorage_not_available", n.IN_COMAPTIBLE_BROWSER = "incompatible_browser", n.NO_SERVICE_WORKER = "no_service_worker", n.NO_SUBDOMAIN = "no_subdomain", n.OLD_IOS_DEVICE = "old_ios_device", n.MICROSOFT_EDGE = "microsoft_edge", n.NOT_ADDED_TO_HOME_SCREEN = "not_added_to_home_screen", n.INCOGNITO = "incognito", n.NOTIFICATION_NOT_DEFINED = "notification_not_defined", n.NO_FILE_SYSTEM = "no_file_system", n.DISABLED_RESYNC = "disable_resync"
        }(T || (T = {})),
        function(n) {
            n.NO_SUBSCRIBER_TOKEN = "no_subsriber_token", n.INVALID_SUBSCRIBER_TOKEN = "invalid_subscriber_token", n.PERMISSION_DENIED = "permission_denied", n.PERMISSION_NOT_GRANTED = "permission_not_granted", n.INVALID_STATE_ERROR = "InvalidStateError", n.UNKNOWN_EVENT = "unknown_event"
        }(Q || (Q = {})),
        function(n) {
            n.BACK_IN_STOCK = "back_in_stock", n.PRICE_DROP = "price_drop"
        }(ke || (ke = {})),
        function(n) {
            n.SILENT = "silent", n.DEBUG = "debug"
        }(se || (se = {})),
        function(n) {
            n.CART_DELETED = "cart_deleted", n.CART_UPDATED = "cart_updated", n.PRODUCT_VIEWED = "product_viewed"
        }(Ue || (Ue = {}));
        ut = [{
            name: "track"
        }, {
            name: "identify"
        }, {
            name: "trackLink"
        }, {
            name: "page"
        }, {
            name: "viewProduct",
            isEcommerce: !0
        }, {
            name: "viewCategory",
            isEcommerce: !0
        }, {
            name: "search",
            isEcommerce: !0
        }], u = {
            WIDGET_CONFIG_KEY: {
                HOME: "home",
                PRICE_DROP: "price_drop",
                BACK_IN_STOCK: "back_in_stock"
            },
            EVENT_API_PATH: {
                PRICE_DROP: "price-drop",
                BACK_IN_STOCK: "back-in-stock"
            },
            ENVIRONMENT: {
                staging: "staging",
                production: "production"
            },
            STORAGE_KEYS: {
                NETWORK_REQUEST_QUEUE: "pushowl_network_request_queue",
                VISITOR_TOKEN: "pushowl_visitor_token",
                SESSION_TOKEN: "pushowl_session_token",
                SUBSCRIBER_TOKEN: "pushowl_subscriber_token",
                EMBEDDED_SUBSCRIBER_TOKEN: "pushowl_embedded_subscriber_token",
                OPTIN_SUBSCRIBER_TOKEN: "pushowl_optin_subscriber_token",
                SUBSCRIPTION: "pushowl_subscription",
                SW_SUBSCRIPTION: "pushowl_sw_subscription",
                SW_SUBSCRIBER_TOKEN: "pushowl_sw_subscriber_token",
                EMAIL: "pushowl_email",
                BACK_IN_STOCK_SUBSCRIPTIONS: "pushowl_back_in_stock_subscriptions",
                PRICE_DROP_SUBSCRIPTIONS: "pushowl_price_drop_subscriptions",
                SYNCED_CART_JSON: "pushowl_synced_cart_json",
                SYNCED_CUSTOMER_ID: "pushowl_synced_customer_id",
                SYNCED_AC_EVENTS: "pushowl_ac_events",
                SESSION_PAGEVIEW_COUNT: "pushowl_session_pageview_count",
                SESSION_SUBSCRIBER_CHECK: "pushowl_session_subscriber_check",
                OPTIN_DEFERRED_UNTIL: "pushowl_optin_deferred_until",
                LOG_LEVEL: "pushowl_log_level",
                HAS_RAISED_UNSUBSCRIPTION_EVENT: "pushowl_has_raised_unsubscription_event",
                IS_PERMISSION_GRANTED: "pushowl_is_permission_granted",
                REFERRER: "pushowl_referrer",
                LANDING_PAGE_URL: "pushowl_landing_page_url",
                LANDING_PAGE_URL_PARAMS: "pushowl_landing_page_url_params",
                ORIGINAL_URL_PARAMS: "pushowl_original_url_params",
                IOS_STANDALONE_MODE_LOG: "pushowl_ios_standalone_mode_log",
                INSTALL_PROMPT_SEEN_COUNT: "pushowl_install_prompt_seen_count",
                INSTALL_PROMPT_DISMISSED: "pushowl_install_prompt_dismissed",
                CONSENT: "pushowl_channels_consent",
                PUSHOWL_SUBDOMAIN: "pushowl_subdomain",
                PUSHOWL_ENVIRONMENT: "pushowl_environment",
                CURRENT_CONFIG_KEY: "pushowl_current_config_key",
                PHONE: "pushowl_phone",
                BREVO_BACK_IN_STOCK_PRODUCT_SUBSCRIPTIONS: "pushowl_brevo_back_in_stock_product_subscriptions"
            },
            NOTIFICATION_PERMISSION: {
                DEFAULT: "default",
                GRANTED: "granted",
                DENIED: "denied",
                DISMISSED: "dismissed",
                SERVICE_WORKER_FAILURE: "service_worker_failure"
            },
            DEFAULT_TIMEOUT: {
                DEFAULT: 0,
                MOBILE: 10
            }
        }, De = {
            [u.ENVIRONMENT.staging]: "https://api-staging.powl.io",
            [u.ENVIRONMENT.production]: "https://api.powl.io"
        }, Ke = {
            [u.ENVIRONMENT.staging]: "https://cdn-staging.powl.io/config",
            [u.ENVIRONMENT.production]: "https://cdn.powl.io/config"
        }, Be = {
            [u.ENVIRONMENT.staging]: "web.com.pushowl.staging",
            [u.ENVIRONMENT.production]: "web.com.pushowl.prod"
        }, N = {
            HOME: "home",
            COLLECTION: "collection",
            PRODUCT: "product",
            CART: "cart",
            CHECKOUT: "checkout",
            ORDER: "order",
            ORDERS: "orders",
            THANK_YOU: "thank_you"
        }, oe = {
            CART: "cart",
            ACCOUNT: "account",
            ORDERS: "orders"
        }, lt = "disabled", dt = "wordpress", pt = "prestashop", v = class {
            constructor() {
                this.configKey = "pushowl_shopify_config-".concat(1.5, "-").concat(m.guid), this.permissionKey = "pushowl_permission_not_granted-".concat(1.5, "-").concat(m.guid), this.subscriptionVerifiedKey = "pushowl_subscription_verified-".concat(1.5, "-").concat(m.guid), this.optinSeenCountKey = "pushowl_optin_seen_count", this.embedded_form_viewed_key_prefix = "pushowl_embedded_form_viewed", this.bis_form_viewed_key_prefix = "pushowl_bis_form_viewed"
            }
            get config() {
                var e = window.sessionStorage.getItem(this.configKey),
                    t = null;
                if (e) try {
                    t = JSON.parse(e)
                } catch (o) {
                    t = null
                }
                return t
            }
            set config(e) {
                var t = typeof e == "string" ? e : JSON.stringify(e);
                window.sessionStorage.setItem(this.configKey, t), window.sessionStorage.setItem(u.STORAGE_KEYS.CURRENT_CONFIG_KEY, this.configKey)
            }
            get isPermissionNotGranted() {
                return window.sessionStorage.getItem(this.permissionKey) === "true"
            }
            set isPermissionNotGranted(e) {
                window.sessionStorage.setItem(this.permissionKey, e), window.localStorage.setItem(this.permissionKey, e)
            }
            get subscriptionVerified() {
                return !!window.sessionStorage.getItem(this.subscriptionVerifiedKey)
            }
            set subscriptionVerified(e) {
                window.sessionStorage.setItem(this.subscriptionVerifiedKey, e)
            }
            get optinSeenCount() {
                return parseInt(window.sessionStorage.getItem(this.optinSeenCountKey) || 0, 10)
            }
            set optinSeenCount(e) {
                window.sessionStorage.setItem(this.optinSeenCountKey, e)
            }
            mark_embedded_form_viewed(e) {
                window.sessionStorage.setItem("".concat(this.embedded_form_viewed_key_prefix, "-").concat(e), !0)
            }
            mark_bis_form_viewed(e) {
                window.sessionStorage.setItem("".concat(this.bis_form_viewed_key_prefix, "-").concat(e), !0)
            }
            has_viewed_embedded_form(e) {
                return window.sessionStorage.getItem("".concat(this.embedded_form_viewed_key_prefix, "-").concat(e)) === "true"
            }
            has_viewed_bis_form(e) {
                return window.sessionStorage.getItem("".concat(this.bis_form_viewed_key_prefix, "-").concat(e)) === "true"
            }
            static get installPromptSeenCount() {
                return parseInt(window.sessionStorage.getItem(u.STORAGE_KEYS.INSTALL_PROMPT_SEEN_COUNT) || 0, 10)
            }
            static set installPromptSeenCount(e) {
                window.sessionStorage.setItem(u.STORAGE_KEYS.INSTALL_PROMPT_SEEN_COUNT, e)
            }
            static get landingPageURL() {
                return sessionStorage.getItem(u.STORAGE_KEYS.LANDING_PAGE_URL)
            }
            static set landingPageURL(e) {
                sessionStorage.setItem(u.STORAGE_KEYS.LANDING_PAGE_URL, e)
            }
            static get referrer() {
                return sessionStorage.getItem(u.STORAGE_KEYS.REFERRER)
            }
            static set referrer(e) {
                sessionStorage.setItem(u.STORAGE_KEYS.REFERRER, e)
            }
            static get landingPageURLParams() {
                return sessionStorage.getItem(u.STORAGE_KEYS.LANDING_PAGE_URL_PARAMS)
            }
            static set landingPageURLParams(e) {
                sessionStorage.setItem(u.STORAGE_KEYS.LANDING_PAGE_URL_PARAMS, e)
            }
            static set windowVariablesForOwly(e) {
                (window.Shopify && window.Shopify.customerPrivacy && window.Shopify.customerPrivacy.userCanBeTracked() || !window.Shopify) && sessionStorage.setItem(u.STORAGE_KEYS.PUSHOWL_SUBDOMAIN, e)
            }
        }, ae = class {
            constructor() {
                this.product = null
            }
            static get section() {
                return "home"
            }
            static get productAlias() {
                return "all"
            }
            static get customerId() {}
            static getCart() {}
            getProductDetails() {}
            getRawCurrentProductDetails() {}
        }, ce = class {
            constructor() {}
            currentVariant() {}
        }, ue = class {
            constructor() {}
        }, Le = n => n.startsWith("https://") ? n : n.replace("//cdn.shopify.com", "https://cdn.shopify.com"), xe = n => typeof n == "object" && n !== null && "src" in n ? Le(n.src) : typeof n == "string" ? Le(n) : null, le = class extends ue {
            constructor(e) {
                super(), this.id = e.id, this.name = e.name, this.price = e.price / 100, this.available = e.available, this.featured_image = xe(e.featured_image)
            }
        }, de = class extends ce {
            constructor(e) {
                super(), this.id = e.id, this.title = e.title, this.featured_image = xe(e.featured_image), this.price = qe(e.price);
                var t = e.variants;
                this.variants = t.map(o => new le(o))
            }
            getVariant(e) {
                return e = parseInt(e), this.variants.find(t => t.id == e)
            }
            currentVariant() {
                var e = function(o) {
                    var i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
                    return i || (i = window.location.href), D(new URL(i).search)[o]
                }("variant");
                if (!e) {
                    for (var t of this.variants)
                        if (t.available) return t;
                    return this.variants[0]
                }
                return this.getVariant(e)
            }
        }, gt = /checkouts\/c\/([^\/]*)\/thank_you/, k = class n extends ae {
            constructor() {
                super(), this.productCache = {}
            }
            static get section() {
                try {
                    var {
                        pageType: e
                    } = window.ShopifyAnalytics.meta.page;
                    if (e) return e !== N.PRODUCT && /\/products\/(\S)/.test(location.pathname) && (e = N.PRODUCT), e
                } catch (l) {
                    console.log("Shopify Analytics not set")
                }
                if (window.Shopify !== void 0 && window.Shopify.Checkout && (window.Shopify.Checkout.page === "thank_you" || window.Shopify.Checkout.page === "checkout_one_thank_you")) return N.THANK_YOU;
                var {
                    hostname: t
                } = location, o = location.pathname, i = o.split("/")[0], r = o.split("/")[1];
                if (gt.test(o)) return N.THANK_YOU;
                if (i === "") return N.HOME;
                if (i === oe.CART) return N.CART;
                if (i === oe.ACCOUNT && r === oe.ORDERS) return N.ORDER;
                if (i === "account" && !i) return N.ORDERS;
                if (t === "checkout.shopify.com" || r === "checkouts" || o.indexOf("checkouts") >= 0) return N.CHECKOUT;
                if (window.__st !== void 0 && window.__st.s) {
                    var a = window.__st.s.split("-")[0];
                    if (a === "collections") return N.COLLECTION;
                    if (a === "products") return N.PRODUCT
                }
            }
            static get productAlias() {
                var e = location.pathname.split("/"),
                    t = (e = e.filter(o => o)).map(o => o.toLocaleLowerCase()).lastIndexOf("products");
                return t === -1 ? "" : e[t + 1]
            }
            static get customerId() {
                if (m.mode === "headless") return window.pushowl ? window.pushowl.customerId : "";
                var e = null;
                return window.__st !== void 0 && window.__st.cid ? e = window.__st.cid : window.Shopify !== void 0 && window.Shopify.checkout !== void 0 && window.Shopify.checkout.customer_id && (e = window.Shopify.checkout.customer_id.toString()), e
            }
            static getCart() {
                return ie({
                    url: "/cart.js?random=".concat(Date.now())
                }).then(e => (e.updated_at = new Date().toISOString(), e), () => "Cart API failed")
            }
            static getVisitorCountry() {
                var e, t;
                return y(this, void 0, void 0, function*() {
                    try {
                        var o = yield ie({
                            url: "/browsing_context_suggestions.json"
                        });
                        return ((t = (e = o == null ? void 0 : o.detected_values) === null || e === void 0 ? void 0 : e.country) === null || t === void 0 ? void 0 : t.handle) || null
                    } catch (i) {
                        return null
                    }
                })
            }
            static get pageName() {
                var e = window.location.pathname.match(/\/pages\/([a-z0-9_-]+)$/);
                return e ? e[1] : void 0
            }
            static get collectionName() {
                var e = window.location.pathname.match(/collections\/([a-z0-9_-]+)$/);
                return e ? e[1] : void 0
            }
            static get collectionId() {
                return window.ShopifyAnalytics && window.ShopifyAnalytics.meta && window.ShopifyAnalytics.meta.page ? window.ShopifyAnalytics.meta.page.resourceId : null
            }
            getProductDetails() {
                var e = arguments.length > 0 && arguments[0] !== void 0 && arguments[0],
                    t = (arguments.length > 1 ? arguments[1] : void 0) || n.productAlias;
                return this.productCache[t] && !e ? Promise.resolve(this.productCache[t]) : ie({
                    url: "/products/".concat(t, ".js")
                }).then(o => this.productCache[t] = new de(o))
            }
            getRawCurrentProductDetails() {
                return Promise.resolve(window.ShopifyAnalytics.meta.product)
            }
        };
        b = class {
            static loadTracker(e) {
                var {
                    isNewTracker: t,
                    maKey: o
                } = e;
                if (t) {
                    var i = document.createElement("script");
                    return i.type = "text/javascript", i.async = !0, i.src = "https://cdn.brevo.com/js/sdk-loader.js", document.body.appendChild(i), window.Brevo = window.Brevo || [], window.Brevo.push(["init", {
                        client_key: o,
                        do_not_track_page: !0
                    }]), !0
                }
                return window.sib = {
                    equeue: [],
                    client_key: o
                }, window.sendinblue = {
                    ecommerce: {}
                }, ut.forEach(function(r) {
                    var a = r.name;
                    r.isEcommerce ? window.sendinblue.ecommerce[a] = function() {
                        for (var s = arguments.length, c = new Array(s), d = 0; d < s; d++) c[d] = arguments[d];
                        Ge(a, c)
                    } : window.sendinblue[a] = function() {
                        for (var s = arguments.length, c = new Array(s), d = 0; d < s; d++) c[d] = arguments[d];
                        Ge(a, c)
                    };
                    var l = document.createElement("script");
                    l.type = "text/javascript", l.id = "sendinblue-js", l.async = !0, l.src = "https://sibautomation.com/sa.js?key=".concat(window.sib.client_key), document.body.appendChild(l)
                }), !0
            }
            static set emailId(e) {
                e && e !== "undefined" && (window.sib ? window.sib.email_id = e : window.Brevo && (window.Brevo.email_id = e))
            }
            static get emailId() {
                return window.sib ? window.sib.email_id : window.Brevo ? window.Brevo.email_id : null
            }
            static setPropertiesPayload(e) {
                var t, o = new v;
                if (o.config.flags.brevo_email !== "enabled") return !1;
                o.config.privacy && k.customerId && (e.customerId = k.customerId), !(!((t = o == null ? void 0 : o.config) === null || t === void 0) && t.subscription_confirmation) && h.email && h.email !== "undefined" && (e.email = h.email), h.phone && h.phone !== "undefined" && (e.sms = h.phone)
            }
        };
        b.track = n => {
            var {
                eventName: e,
                eventData: t
            } = n;
            try {
                var o = new v,
                    i = {};
                if (o.config.privacy && k.customerId && (i.customerId = k.customerId), b.setPropertiesPayload(i), o.config.flags.brevo_email !== "enabled") return;
                window.sendinblue ? window.sendinblue.track(e, i, t) : window.Brevo && window.Brevo.push(["track", e, i, t])
            } catch (r) {
                f("Error in brevoTrack", r)
            }
        }, b.identify = (n, e) => {
            if (n) try {
                var t = new v;
                if (!t.config.brevo_ma_key || t.config.flags.brevo_email !== "enabled") return;
                window.sendinblue ? window.sendinblue.identify(n, e) : window.Brevo && window.Brevo.push(function() {
                    window.Brevo.identify({
                        identifiers: {
                            email_id: n
                        },
                        attributes: e
                    })
                })
            } catch (o) {
                f("Error in BrevoUtils.identify", o)
            }
        }, b.viewPage = n => {
            var e = {};
            b.setPropertiesPayload(e) && (window.sendinblue ? window.sendinblue.page(n) : window.Brevo && window.Brevo.push(["page", n || window.location.pathname, e]))
        }, b.viewCategory = n => {
            var e = {};
            b.setPropertiesPayload(e) && (window.sendinblue ? window.sendinblue.ecommerce.viewCategory(String(n)) : window.Brevo && window.Brevo.push(["viewCategory", String(n), e]))
        }, b.search = (n, e) => {
            var t = {};
            b.setPropertiesPayload(t) && (window.sendinblue ? window.sendinblue.ecommerce.search(n, e) : window.Brevo && window.Brevo.push(["search", n, e, t]))
        }, b.viewProduct = n => {
            var e = {};
            b.setPropertiesPayload(e) && (window.sendinblue ? window.sendinblue.ecommerce.viewProduct(String(n)) : window.Brevo && window.Brevo.push(["viewProduct", String(n), e]))
        };
        ht = function() {
            function n(o) {
                o = o || {};
                var i = {
                    url: location.href,
                    headers: {
                        "User-Agent": navigator.userAgent
                    }
                };
                return {
                    event_id: "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function(r) {
                        var a = 16 * Math.random() | 0;
                        return (r === "x" ? a : 3 & a | 8).toString(16)
                    }),
                    platform: "javascript",
                    release: "extension-shared-webpixel",
                    extra: o,
                    request: i
                }
            }

            function e(o) {
                return Math.random() < .95 ? Promise.resolve() : (f("Logging error to Sentry:", o), fetch("https://o79286.ingest.sentry.io/api/1527936/store/?sentry_version=7&sentry_key=8f53de1cdf86490fb8e55518e1a5d035", {
                    method: "post",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(o)
                }))
            }

            function t(o, i) {
                var r = n(i);
                return r.message = o, e(r)
            }
            return {
                log: t,
                logException: function(o, i) {
                    if (o) try {
                        (i = i || {}).errorDump = {
                            str: String(o),
                            stack: o && o.stack
                        };
                        var r = n(i);
                        return r.exception = function(a) {
                            var l = a.stack || "";
                            if (l) {
                                var s = l.split(`
`).map(c => c.trim()).filter(c => c.startsWith("at")).map(function(c) {
                                    var d = "",
                                        p = 0,
                                        g = 0,
                                        _ = "",
                                        S = c.split(/[ ]+/);
                                    if (S[0].trim() === "at" && S.length > 1) {
                                        var w = "";
                                        S.length > 2 ? (d = S[1], w = S[2]) : w = S[1];
                                        var E = (w = w.replace("(", "").replace(")", "")).split(":");
                                        E.length > 1 ? (p = parseInt(E[E.length - 1], 0), g = parseInt(E[E.length - 2], 0), _ = E.slice(0, E.length - 2).join(":")) : console.error("[CDN] Unexpected error frame location format: " + c)
                                    } else console.error("[CDN] Unexpected frame line format: " + c);
                                    return {
                                        in_app: !0,
                                        function: d,
                                        colno: Number(p) || p,
                                        lineno: Number(g) || g,
                                        filename: _
                                    }
                                });
                                return s.reverse(), {
                                    values: [{
                                        type: a.name || "Error",
                                        value: a.message || String(a),
                                        stacktrace: {
                                            frames: s
                                        }
                                    }]
                                }
                            }
                        }(o), e(r)
                    } catch (a) {
                        t(String(a), a), t(String(o), o)
                    }
                }
            }
        }();
        Ve = [];
        qe = function(n) {
            return arguments.length > 1 && arguments[1] !== void 0 && arguments[1] ? n < 1e3 && n % 1 != 0 ? Math.round(100 * n) : Math.round(n) : typeof n == "number" ? n / 100 : n
        }, _t = "(?:".concat("\\d+", "|").concat("[0-9a-f]{24}", "|").concat("[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", "|").concat("(?!v\\d+$)(?=\\d*[a-z])(?=[a-z]*\\d)[a-z\\d]{4,}", ")"), St = new RegExp("^(?:https?:)?//[^/]+|[?#].*$" + "|/".concat(_t, "(?=/|[?#]|$)"), "gi"), M = class {
            constructor(e) {
                var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1];
                this.key = e, this.isSessionStorage = t, this.isSessionStorage ? window.sessionStorage.getItem(e) ? this.subscriptions = window.sessionStorage.getItem(this.key).split(",") : this.subscriptions = [] : window.localStorage.getItem(e) ? this.subscriptions = window.localStorage.getItem(this.key).split(",") : this.subscriptions = []
            }
            subscribe(e) {
                this.isSubscribed(e) || (this.subscriptions.push(e.id.toString()), this.isSessionStorage ? window.sessionStorage[this.key] = this.subscriptions : window.localStorage[this.key] = this.subscriptions)
            }
            isSubscribed(e) {
                return this.subscriptions.indexOf(e.id.toString()) > -1
            }
            refresh() {
                this.isSessionStorage ? this.subscriptions = window.sessionStorage.getItem(this.key).split(",") : this.subscriptions = window.localStorage.getItem(this.key).split(",")
            }
        }, h = class n {
            constructor() {
                this.back_in_stock = new M(u.STORAGE_KEYS.BACK_IN_STOCK_SUBSCRIPTIONS), this.price_drop = new M(u.STORAGE_KEYS.PRICE_DROP_SUBSCRIPTIONS), this.brevo_back_in_stock = new M(u.STORAGE_KEYS.BREVO_BACK_IN_STOCK_PRODUCT_SUBSCRIPTIONS, !0), Promise.all([I.get(u.STORAGE_KEYS.SW_SUBSCRIPTION), I.get(u.STORAGE_KEYS.SW_SUBSCRIBER_TOKEN)]).then(e => {
                    var [t, o] = e;
                    t && o && (this.sw_subscription_data = t, this.sw_subscriber_token = o, n.sw_subscriber_token = o)
                }).catch(e => {
                    f("Error while fetching subscription data", e)
                })
            }
            static getOrCreateToken(e, t) {
                var o = e.getItem(t);
                if (o) return o;
                var i = function() {
                        return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
                    },
                    r = "".concat(i() + i(), "-").concat(i(), "-4").concat(i().substr(0, 3), "-").concat(i(), "-").concat(i()).concat(i()).concat(i()).toLowerCase();
                return e.setItem(t, r), r
            }
            static get queue() {
                try {
                    var e = localStorage.getItem(u.STORAGE_KEYS.NETWORK_REQUEST_QUEUE);
                    return e ? JSON.parse(e) : []
                } catch (t) {
                    return []
                }
            }
            static set queue(e) {
                e ? localStorage.setItem(u.STORAGE_KEYS.NETWORK_REQUEST_QUEUE, JSON.stringify(e)) : localStorage.removeItem(u.STORAGE_KEYS.NETWORK_REQUEST_QUEUE)
            }
            static get email() {
                return localStorage.getItem(u.STORAGE_KEYS.EMAIL)
            }
            static set email(e) {
                localStorage.setItem(u.STORAGE_KEYS.EMAIL, e)
            }
            static get phone() {
                return localStorage.getItem(u.STORAGE_KEYS.PHONE)
            }
            static set phone(e) {
                localStorage.setItem(u.STORAGE_KEYS.PHONE, e)
            }
            static set pushowlEnvironment(e) {
                localStorage.setItem(u.STORAGE_KEYS.PUSHOWL_ENVIRONMENT, e)
            }
            static get consent() {
                var e = localStorage.getItem(u.STORAGE_KEYS.CONSENT);
                if (e) try {
                    return JSON.parse(e)
                } catch (t) {
                    return []
                }
                return []
            }
            static set consent(e) {
                localStorage.setItem(u.STORAGE_KEYS.CONSENT, JSON.stringify(e))
            }
            static get embeddedSubscriberToken() {
                return localStorage.getItem(u.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN)
            }
            static set embeddedSubscriberToken(e) {
                e ? (localStorage.setItem(u.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN, e), I.set(u.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN, e)) : (localStorage.removeItem(u.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN), I.del(u.STORAGE_KEYS.EMBEDDED_SUBSCRIBER_TOKEN))
            }
            static get optinSubscriberToken() {
                return localStorage.getItem(u.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN)
            }
            static set optinSubscriberToken(e) {
                e ? (localStorage.setItem(u.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN, e), I.set(u.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN, e)) : (localStorage.removeItem(u.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN), I.del(u.STORAGE_KEYS.OPTIN_SUBSCRIBER_TOKEN))
            }
            static get subscriberToken() {
                return this.sw_subscriber_token || this.optinSubscriberToken || this.embeddedSubscriberToken || localStorage.getItem(u.STORAGE_KEYS.SUBSCRIBER_TOKEN)
            }
            static set subscriberToken(e) {
                e ? (localStorage.setItem(u.STORAGE_KEYS.SUBSCRIBER_TOKEN, e), I.set(u.STORAGE_KEYS.SUBSCRIBER_TOKEN, e)) : (localStorage.removeItem(u.STORAGE_KEYS.SUBSCRIBER_TOKEN), I.del(u.STORAGE_KEYS.SUBSCRIBER_TOKEN))
            }
            static get installPromptDismissed() {
                return !!localStorage.getItem(u.STORAGE_KEYS.INSTALL_PROMPT_DISMISSED)
            }
            static set installPromptDismissed(e) {
                localStorage.setItem(u.STORAGE_KEYS.INSTALL_PROMPT_DISMISSED, "".concat(e))
            }
            static get hasLoggediOSStandaloneMode() {
                return localStorage.getItem(u.STORAGE_KEYS.IOS_STANDALONE_MODE_LOG)
            }
            static set hasLoggediOSStandaloneMode(e) {
                localStorage.setItem(u.STORAGE_KEYS.IOS_STANDALONE_MODE_LOG, e)
            }
            static get originalURLParams() {
                return localStorage.getItem(u.STORAGE_KEYS.ORIGINAL_URL_PARAMS)
            }
            static set originalURLParams(e) {
                localStorage.setItem(u.STORAGE_KEYS.ORIGINAL_URL_PARAMS, e)
            }
            static get visitorToken() {
                return je() ? this.getOrCreateToken(localStorage, u.STORAGE_KEYS.VISITOR_TOKEN) : (localStorage.removeItem(u.STORAGE_KEYS.VISITOR_TOKEN), null)
            }
            static get sessionToken() {
                return je() ? this.getOrCreateToken(sessionStorage, u.STORAGE_KEYS.SESSION_TOKEN) : (localStorage.removeItem(u.STORAGE_KEYS.SESSION_TOKEN), null)
            }
            static get syncedCustomerId() {
                return localStorage.getItem(u.STORAGE_KEYS.SYNCED_CUSTOMER_ID)
            }
            static set syncedCustomerId(e) {
                localStorage.setItem(u.STORAGE_KEYS.SYNCED_CUSTOMER_ID, e.toString())
            }
            static get synced_cart_json() {
                var e = localStorage.getItem(u.STORAGE_KEYS.SYNCED_CART_JSON);
                return e ? JSON.parse(e) : void 0
            }
            static set synced_cart_json(e) {
                e && (Object.prototype.toString.call(e) !== "[object String]" && (e = JSON.stringify(e)), localStorage.setItem(u.STORAGE_KEYS.SYNCED_CART_JSON, e))
            }
            static get ac_events() {
                try {
                    return JSON.parse(localStorage.getItem(u.STORAGE_KEYS.SYNCED_AC_EVENTS)) || []
                } catch (e) {
                    return []
                }
            }
            static set ac_events(e) {
                var t = typeof e == "string" ? e : JSON.stringify(e);
                localStorage.setItem(u.STORAGE_KEYS.SYNCED_AC_EVENTS, t)
            }
            static get subscription() {
                var e = this.sw_subscription_data || localStorage.getItem(u.STORAGE_KEYS.SUBSCRIPTION),
                    t = null;
                if (e) try {
                    t = JSON.parse(e)
                } catch (o) {
                    t = e
                }
                return t
            }
            static set subscription(e) {
                var t = typeof e == "string" ? e : JSON.stringify(e);
                localStorage.setItem(u.STORAGE_KEYS.SUBSCRIPTION, t), I.set(u.STORAGE_KEYS.SW_SUBSCRIPTION, t)
            }
            static get optinDeferredUntil() {
                return parseInt(localStorage.getItem(u.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL) || 0, 10)
            }
            static set optinDeferredUntil(e) {
                e === null ? localStorage.removeItem(u.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL) : localStorage.setItem(u.STORAGE_KEYS.OPTIN_DEFERRED_UNTIL, e)
            }
            static get logLevel() {
                return localStorage.getItem(u.STORAGE_KEYS.LOG_LEVEL)
            }
            static set logLevel(e) {
                localStorage.setItem(u.STORAGE_KEYS.LOG_LEVEL, e)
            }
            static get hasRaisedUnsubscriptionEvent() {
                return localStorage.getItem(u.STORAGE_KEYS.HAS_RAISED_UNSUBSCRIPTION_EVENT)
            }
            static set hasRaisedUnsubscriptionEvent(e) {
                localStorage.setItem(u.STORAGE_KEYS.HAS_RAISED_UNSUBSCRIPTION_EVENT, e)
            }
            static get isPermissionGranted() {
                return localStorage.getItem(u.STORAGE_KEYS.IS_PERMISSION_GRANTED) === "true"
            }
            static set isPermissionGranted(e) {
                e ? localStorage.setItem(u.STORAGE_KEYS.IS_PERMISSION_GRANTED, e) : localStorage.removeItem(u.STORAGE_KEYS.IS_PERMISSION_GRANTED)
            }
            static handlePostSubscription(e, t) {
                n.subscription = e, n.subscriberToken = t, n.hasRaisedUnsubscriptionEvent = ""
            }
        };
        h.sw_subscriber_token = null;
        x = class {
            static run() {
                (h.queue || []).forEach(e => {
                    setTimeout(() => {
                        this._request(e)
                    }, 1e3 * e.retryCount)
                })
            }
            static _enqueue(e) {
                var t = e;
                return e.id === void 0 && (t = Object.assign({
                    id: Ye()
                }, e)), h.queue = [...h.queue.slice(0, 5), t], t
            }
            static _retryRequest(e) {
                return y(this, void 0, void 0, function*() {
                    var t = Object.assign(Object.assign({}, e), {
                        retryCount: ((e == null ? void 0 : e.retryCount) || 0) + 1
                    });
                    if (t.retryCount > 5) return K("APIRequestEventually", {
                        request: t,
                        connectionType: navigator.connection ? navigator.connection.effectiveType : "NA"
                    }), Promise.reject();
                    var o = this._enqueue(t);
                    setTimeout(() => {
                        this._request(o)
                    }, 1e3 * o.retryCount)
                })
            }
            static _dequeue(e) {
                h.queue = h.queue.filter(t => t.id !== e.id)
            }
            static _request(e) {
                return y(this, void 0, void 0, function*() {
                    try {
                        return this._dequeue(e), yield fe(e)
                    } catch (t) {
                        return Se(t) ? this._retryRequest(e) : (K("APIRequestEventuallyError", {
                            error: t,
                            request: e
                        }), Promise.reject(t))
                    }
                })
            }
            static get(e) {
                var t = this._enqueue(e);
                return this._request(Object.assign(Object.assign({}, t), {
                    method: "GET"
                }))
            }
            static post(e) {
                var t = this._enqueue(e);
                return this._request(Object.assign(Object.assign({}, t), {
                    method: "POST"
                }))
            }
            static put(e) {
                var t = this._enqueue(e);
                return this._request(Object.assign(Object.assign({}, t), {
                    method: "PUT"
                }))
            }
        }, m = class n {
            static get scriptUrl() {
                var e = Array.from(document.getElementsByTagName("script"));
                for (var {
                        src: t = ""
                    } of e)
                    if (/pushowl-\w+\.js/.test(t)) {
                        var o = t.startsWith("http") ? t : "https:".concat(t);
                        if (o.includes("pushowl-shopify")) return o;
                        var i = o
                    }
                return i || window.location.href
            }
            static get environment() {
                if (!n.scriptUrl) return u.ENVIRONMENT.production;
                var e = D(new URL(n.scriptUrl).search.substring(1)).environment;
                e && (e = u.ENVIRONMENT[e]);
                var t = window.pushowlEnvironment || e || u.ENVIRONMENT.production;
                return t !== u.ENVIRONMENT.production && (h.pushowlEnvironment = t), t
            }
            static get isProduction() {
                return n.environment == u.ENVIRONMENT.production
            }
            static get apiEndpoint() {
                return De[n.environment] || De[u.ENVIRONMENT.production]
            }
            static get configApiEndpoint() {
                return Ke[n.environment] || Ke[u.ENVIRONMENT.production]
            }
            static get subdomain() {
                var e, t, o, i, r;
                if (window.pushowlSubdomain) return window.pushowlSubdomain;
                var a = (t = (e = window == null ? void 0 : window.pushowl) === null || e === void 0 ? void 0 : e.subdomain) !== null && t !== void 0 ? t : null,
                    l = n.scriptUrl ? D(new URL(n.scriptUrl).search.substring(1)).subdomain : null,
                    s = !((o = window == null ? void 0 : window.Shopify) === null || o === void 0) && o.shop ? window.Shopify.shop.replace(".myshopify.com", "") : null,
                    c = (() => {
                        if (n.platform === "shopline") {
                            var p = window.location.hostname;
                            if (p && p !== "localhost") {
                                var g = p.split(".");
                                if (g.length > 2) return g[0]
                            }
                        }
                        return null
                    })(),
                    d = (r = (i = a != null ? a : l) !== null && i !== void 0 ? i : s) !== null && r !== void 0 ? r : c;
                return d || f("Subdomain not found. Checked sources:", {
                    fromPushowl: a,
                    fromQuery: l,
                    fromShopify: s,
                    fromShopline: c,
                    scriptUrl: n.scriptUrl,
                    platform: n.platform
                }), window.pushowlSubdomain = d, d
            }
            static get platform() {
                if (!n.scriptUrl) return "shopify";
                var e = D(new URL(n.scriptUrl).search.substring(1)).platform;
                return e && !["shopify", "sendinblue", "bigcommerce", "shopline"].includes(e) && n.logToServer({
                    message: "unknown platform detected",
                    subdomain: n.subdomain,
                    data: {
                        platform: e,
                        script_url: n.scriptUrl
                    }
                }), e || "shopify"
            }
            static get plugin() {
                return n.scriptUrl ? D(new URL(n.scriptUrl).search.substring(1)).plugin : null
            }
            static get guid() {
                if (n.subdomain === "fnova") try {
                    return new Date().toISOString().split("T")[0]
                } catch (t) {
                    return
                }
                if (!n.scriptUrl) return null;
                var e = D(new URL(n.scriptUrl).search.substring(1));
                return window.pushowlGUID || e.guid
            }
            static get visitorId() {
                return n.scriptUrl ? D(new URL(n.scriptUrl).search.substring(1)).visitor_id : null
            }
            static get shopUrl() {
                return location.protocol + "//" + location.host
            }
            static serviceWorkerUrl() {
                var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
                if (e.custom_sw_path && e.custom_sw_path !== "disabled") return "".concat(n.shopUrl).concat(e.custom_sw_path, "?v=2&subdomain=").concat(this.subdomain);
                if (n.platform === "bigcommerce") return "".concat(n.shopUrl, "/pushowl-service-worker.js?v=2&subdomain=").concat(this.subdomain);
                if (n.mode === "headless") {
                    var t = n.platform,
                        o = n.plugin;
                    return e.root_service_worker === "enabled" ? "".concat(window.location.origin, "/service-worker.js?v=2&subdomain=").concat(this.subdomain) : t === "sendinblue" && window.__st && window.Shopify ? "".concat(n.shopUrl, "/apps/sendinblue/service-worker.js?v=2&subdomain=").concat(this.subdomain) : t === "sendinblue" && o === dt ? "".concat(n.shopUrl, "/wp-content/plugins/mailin/js/service-worker.js?v=2&subdomain=").concat(this.subdomain) : t === "sendinblue" && o === pt ? "".concat(n.shopUrl, "/modules/sendinblue/views/js/service-worker.js?v=2&subdomain=").concat(this.subdomain) : "".concat(n.shopUrl, "/").concat(t === "sendinblue" ? "sendinblue" : "pushowl", "/service-worker.js?v=2&subdomain=").concat(this.subdomain)
                }
                return e.should_log === "enabled" ? "".concat(n.shopUrl, "/apps/pushowl/sdks/service-worker-logsink.js?v=2&subdomain=").concat(this.subdomain) : "".concat(n.shopUrl, "/apps/pushowl/sdks/service-worker.js?v=2&subdomain=").concat(this.subdomain)
            }
            static get isWorkerAvailable() {
                return P().isApnsSafari ? Promise.resolve(!0) : new Promise(e => {
                    var t = (new v().config || {}).flags,
                        o = n.serviceWorkerUrl(t),
                        i = t.sw_get_request === "enabled";
                    fetch(o, {
                        method: i ? "GET" : "HEAD"
                    }).then(r => {
                        if (r.status >= 200 && r.status < 300) return e(!0);
                        e(!1)
                    })
                })
            }
            static get webPushId() {
                return Be[this.environment] || Be[u.ENVIRONMENT.production]
            }
            static getServiceWorkerUrlWithIntergrations(e) {
                var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
                    o = Object.keys(t).filter(r => t[r].status === "enabled");
                if (!o.length) return e;
                var i = new URL(e).search;
                return "".concat(e).concat(i ? "&" : "?", "integrations=").concat(o.join(","))
            }
            static logToServer(e) {
                var {
                    message: t,
                    subdomain: o,
                    sessionHash: i = "session",
                    data: r
                } = e;
                return x.post({
                    url: "".concat(n.apiEndpoint, "/logs/v1/"),
                    acceptType: "text/plain",
                    payload: [{
                        level: "warn",
                        subscriber_token: h.subscriberToken,
                        subdomain: o,
                        message: t,
                        session_hash: i,
                        timestamp: new Date().toISOString(),
                        data: Object.assign({
                            release: "extension-shared-webpixel"
                        }, r)
                    }]
                })
            }
            static getPreviewLib(e) {
                var t = n.getPreviewBranch();
                return sessionStorage.setItem("pushowl_branch", t), t === "local" ? "https://localhost:3008/latest/sdks/".concat(e, "?environment=staging&platform=").concat(n.platform) : null
            }
            static loadPreviewLib(e) {
                var t = document.createElement("script"),
                    o = this.getPreviewLib(e);
                t.onload = () => {
                    console.log("preview url loaded ", o)
                }, o && (t.src = o, t.setAttribute("async", ""), document.head.appendChild(t), window.pushowlPreviewLoaded = !0)
            }
            static getPreviewBranch() {
                var e = new URLSearchParams(window.location.search).get("pushowl_branch") || sessionStorage.getItem("pushowl_branch");
                return window.pushowlPreviewLoaded ? null : e
            }
            static isDisabled() {
                var e = new URLSearchParams(window.location.search).get("poTaskType") || sessionStorage.getItem("poTaskType");
                return e && sessionStorage.setItem("pushowl_task_type", e), e === lt
            }
        }, je = () => m.platform !== "shopify" || !m.guid || m.subdomain === "fnova" || !!window.Shopify.customerPrivacy && window.Shopify.customerPrivacy.userCanBeTracked(), re = () => !!window.indexedDB, I = class {
            static set(e, t) {
                return y(this, void 0, void 0, function*() {
                    if (re()) try {
                        (function(o, i) {
                            (arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : ne())("readwrite", function(r) {
                                return r.put(i, o), z(r.transaction)
                            })
                        })(e, t)
                    } catch (o) {
                        f("error in indexedDBUtil", o)
                    }
                })
            }
            static get(e) {
                return y(this, void 0, void 0, function*() {
                    if (re()) try {
                        return function(t) {
                            return (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ne())("readonly", function(o) {
                                return z(o.get(t))
                            })
                        }(e)
                    } catch (t) {
                        return f("error in indexedDBUtil", t), Promise.reject(t)
                    }
                })
            }
            static del(e) {
                return y(this, void 0, void 0, function*() {
                    if (re()) try {
                        (function(t) {
                            (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ne())("readwrite", function(o) {
                                return o.delete(t), z(o.transaction)
                            })
                        })(e)
                    } catch (t) {
                        f("error in indexedDBUtil", t)
                    }
                })
            }
        }, Fe = () => {
            var {
                subdomain: n
            } = m;
            return "".concat(m.apiEndpoint, "/api/v1/").concat(n)
        }, Me = () => {
            var n = new Error("network error");
            return n.name = "TypeError", n
        }, fe = n => {
            var {
                path: e,
                method: t,
                appendPlatform: o = !0,
                url: i = null,
                payload: r = null,
                contentType: a = "application/json",
                acceptType: l = "application/json",
                retryCount: s = null
            } = n;
            return y(void 0, void 0, void 0, function*() {
                var c = i ? new URL(i) : new URL("".concat(Fe()).concat(e));
                return o && c.searchParams.append("platform", m.platform), s && c.searchParams.append("retry_count", "".concat(s)), new Promise((d, p) => {
                    var g = new XMLHttpRequest;
                    g.open(t, c.href, !0), g.setRequestHeader("Content-Type", a), g.setRequestHeader("Accept", l), r ? g.send(a.match(/json/) ? JSON.stringify(r) : r) : g.send(), g.onload = function() {
                        var _ = g.responseText;
                        if (g.status === 429 && p(Me()), g.status >= 200 && g.status < 400) try {
                            var S = l.match(/json/) ? JSON.parse(_) : _;
                            d(S)
                        } catch (E) {
                            d(_)
                        } else {
                            var w = new Error("HTTP Error: ".concat(g.status, " ").concat(c.href));
                            w.name = "HttpError", Object.assign(w, {
                                status: g.status,
                                responseBody: _,
                                url: c.href,
                                method: t,
                                path: e,
                                payload: r,
                                contentType: a,
                                acceptType: l,
                                retryCount: s
                            }), p(w)
                        }
                    }, g.onerror = function() {
                        p(Me())
                    }, g.onabort = function() {
                        var _ = new Error("Request Aborted ".concat(c.href));
                        _.name = "AbortError", Object.assign(_, {
                            url: c.href,
                            method: t,
                            path: e,
                            payload: r,
                            contentType: a,
                            acceptType: l,
                            retryCount: s
                        }), p(_)
                    }
                })
            })
        }, A = class {
            static _request(e) {
                return y(this, void 0, void 0, function*() {
                    return yield fe(e)
                })
            }
            static get(e) {
                return this._request(Object.assign(Object.assign({}, e), {
                    method: "GET"
                }))
            }
            static post(e) {
                return this._request(Object.assign(Object.assign({}, e), {
                    method: "POST"
                }))
            }
            static put(e) {
                return this._request(Object.assign(Object.assign({}, e), {
                    method: "PUT"
                }))
            }
        }, U = class {
            static createRequestObj(e) {
                var t = e;
                return e.id === void 0 && (t = Object.assign({
                    id: Ye()
                }, e)), t
            }
            static _retryRequest(e) {
                return y(this, void 0, void 0, function*() {
                    var t = Object.assign(Object.assign({}, e), {
                        retryCount: ((e == null ? void 0 : e.retryCount) || 0) + 1
                    });
                    if (t.retryCount > 5) return K("APIRequestSimpleRetry", {
                        request: t,
                        connectionType: navigator.connection ? navigator.connection.effectiveType : "NA"
                    }), Promise.reject();
                    var o = this.createRequestObj(t);
                    setTimeout(() => {
                        this._request(o)
                    }, 1e3 * o.retryCount)
                })
            }
            static _request(e) {
                var t, o, i;
                return y(this, void 0, void 0, function*() {
                    try {
                        return yield fe(e)
                    } catch (s) {
                        if (Se(s)) return this._retryRequest(e);
                        var r = (t = s == null ? void 0 : s.status) !== null && t !== void 0 ? t : "n/a",
                            a = (c => {
                                try {
                                    if (!c) return "/";
                                    var d = c.replace(St, _ => _.startsWith("/") ? "/:id" : "").replace(/\/\/+/g, "/"),
                                        p = m.subdomain;
                                    return (g = p ? d.replace(new RegExp("/".concat(p, "(?=/|$)"), "g"), "/:subdomain") : d).length > 1 && g.endsWith("/") ? g.slice(0, -1) : g || "/"
                                } catch (_) {
                                    return K(_), "/"
                                }
                                var g
                            })((o = e.url) !== null && o !== void 0 ? o : "".concat(Fe()).concat((i = e.path) !== null && i !== void 0 ? i : "")),
                            l = e.method;
                        K("APIRequestSimpleRetryError [".concat(l, "] ").concat(a, " (status=").concat(r, ")"), {
                            request: e,
                            status: r,
                            responseBody: s == null ? void 0 : s.responseBody,
                            url: s == null ? void 0 : s.url,
                            method: s == null ? void 0 : s.method,
                            path: s == null ? void 0 : s.path,
                            payload: s == null ? void 0 : s.payload,
                            contentType: s == null ? void 0 : s.contentType,
                            acceptType: s == null ? void 0 : s.acceptType,
                            retryCount: s == null ? void 0 : s.retryCount
                        }), Promise.reject(s)
                    }
                })
            }
            static get(e) {
                return this._request(Object.assign(Object.assign({}, e), {
                    method: "GET"
                }))
            }
            static post(e) {
                return this._request(Object.assign(Object.assign({}, e), {
                    method: "POST"
                }))
            }
            static put(e) {
                return this._request(Object.assign(Object.assign({}, e), {
                    method: "PUT"
                }))
            }
        }, pe = class {
            constructor() {
                var e, t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null,
                    o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
                this.window = t || (typeof window != "undefined" ? window : null), this.document = o || ((e = this.window) === null || e === void 0 ? void 0 : e.document) || (typeof document != "undefined" ? document : null);
                var {
                    subdomain: i
                } = m;
                this.endpoint = m.apiEndpoint, this.subscriber_refresh_endpoint = "".concat(this.endpoint, "/api/v1/accounts/").concat(i, "/subscriber/refresh/"), this.checkout_sync_endpoint = "".concat(this.endpoint, "/api/v1/").concat(i, "/subscriber/event/checkout-sync/")
            }
            initStorage() {
                var e, t, o, i;
                I.set("subscriber_refresh_endpoint", this.subscriber_refresh_endpoint), v.landingPageURL || (v.landingPageURL = ((e = this.document) === null || e === void 0 ? void 0 : e.URL) || ""), v.referrer || (v.referrer = ((t = this.document) === null || t === void 0 ? void 0 : t.referrer) || ""), v.landingPageURLParams || (v.landingPageURLParams = ((o = this.window) === null || o === void 0 || (o = o.location) === null || o === void 0 ? void 0 : o.search) || ""), h.originalURLParams || (h.originalURLParams = ((i = this.window) === null || i === void 0 || (i = i.location) === null || i === void 0 ? void 0 : i.search) || "")
            }
            config() {
                var e = arguments.length > 0 && arguments[0] !== void 0 && arguments[0],
                    t = typeof window != "undefined" ? window.pushowlConfigUrl : null,
                    o = t && t.length > 0 && ((s, c) => {
                        try {
                            return new URL(s).hostname.includes(c)
                        } catch (d) {
                            return !1
                        }
                    })(t, "cdn.shopify.com"),
                    i = (typeof window != "undefined" ? window.pushowlConfigSource : "pushowl") === "shopify" && o,
                    r = m.mode === "headless",
                    a = ["fnova"],
                    l = () => r && a.includes(m.subdomain) ? U.get({
                        url: "".concat(m.configApiEndpoint, "/api/v1/").concat(m.subdomain, "/subscriber/config/widget/?guid=").concat(m.guid)
                    }) : r ? A.get({
                        path: "/subscriber/config/widget/?guid=".concat(m.guid)
                    }) : U.get({
                        url: "".concat(m.configApiEndpoint, "/api/v1/").concat(m.subdomain, "/subscriber/config/widget/?guid=").concat(m.guid)
                    });
                return r || e ? l() : i ? U.get({
                    url: t,
                    appendPlatform: !1,
                    contentType: "text/plain",
                    acceptType: "text/plain"
                }).then(s => {
                    try {
                        return s && typeof s == "object" && s.result !== void 0 ? {
                            result: typeof s.result == "string" ? JSON.parse(s.result) : s.result
                        } : {
                            result: typeof s == "string" ? JSON.parse(s) : s
                        }
                    } catch (d) {
                        var c = {
                            cdnUrl: t,
                            source: "fetchCDNConfig",
                            message: "CDN config JSON parse failed"
                        };
                        try {
                            K(d, c)
                        } catch (p) {
                            f("Error logging parse failure", p, d, c)
                        }
                        return l()
                    }
                }).catch(s => {
                    var c = new Error("Error fetching CDN config from " + t);
                    s && (c.message = "Error fetching CDN config from " + t + ": " + s.message, c.stack = s.stack);
                    var d = {
                        cdnUrl: t,
                        source: "fetchCDNConfig",
                        subdomain: m.subdomain,
                        originalError: JSON.stringify(s)
                    };
                    try {
                        K(c, d)
                    } catch (p) {
                        f("Error logging failed", p, c, d)
                    }
                    return l()
                }) : l()
            }
            sendSubscription(e) {
                var t, o, i, r, a, l = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
                    s = arguments.length > 2 ? arguments[2] : void 0,
                    c = arguments.length > 3 ? arguments[3] : void 0,
                    d = arguments.length > 4 ? arguments[4] : void 0,
                    p = new v;
                if (p.config && p.config.flags && p.config.flags.disable_resync === "enabled" && l) return Promise.reject(T.DISABLED_RESYNC);
                var g = {};
                v.landingPageURLParams.slice(1).split("&").filter(O => O.includes("utm_")).forEach(O => {
                    var [H, $] = O.split("=");
                    g[H] = $
                });
                var _ = {};
                h.originalURLParams.slice(1).split("&").filter(O => O.includes("po_")).forEach(O => {
                    var [H, $] = O.split("=");
                    _[H] = $
                });
                var S = ((t = this.window) === null || t === void 0 || (t = t.location) === null || t === void 0 ? void 0 : t.href) || "",
                    w = new URLSearchParams(((o = this.window) === null || o === void 0 || (o = o.location) === null || o === void 0 ? void 0 : o.search) || ""),
                    E = !0;
                if (w.get("po_url") && (E = !1, S = w.get("po_url")), P().isOldIOS) return console.warn("PushOwl does not support iOS before 16.4"), f("PushOwl does not support iOS before 16.4", "platform: ".concat(navigator.platform), "Browser: ".concat(P().name)), Promise.reject(T.OLD_IOS_DEVICE);
                var F = {
                    subscription: e,
                    browser: P().name,
                    previous_token: h.subscriberToken,
                    website_push_id: s || m.webPushId,
                    customer_id: p.config.privacy ? k.customerId : null,
                    language: ((i = this.window) === null || i === void 0 || (i = i.navigator) === null || i === void 0 ? void 0 : i.language) || "",
                    timezone: mt(),
                    dispatch_method: P().isApnsSafari ? "apns" : "vapid",
                    user_agent: navigator.userAgent,
                    guid: m.guid,
                    optin_seen_count: p.optinSeenCount,
                    context: B(B({
                        isPushowlThemeAppExtentionEnabled: !((r = this.window) === null || r === void 0 || !r.isPushowlThemeAppExtentionEnabled),
                        isiOS: P().isiOS,
                        is_resync: l,
                        subscribe_url: S,
                        session_token: h.sessionToken,
                        visitor_token: h.visitorToken,
                        sib_visitor_id: m.visitorId,
                        widget_source: (a = this.window) === null || a === void 0 ? void 0 : a.poSubscriptionSource,
                        worker_available: E
                    }, g), {}, {
                        permanent: B({}, _),
                        temporary: {
                            referrer: v.referrer,
                            landing_url: v.landingPageURL
                        }
                    }),
                    source: c,
                    source_id: d
                };
                return U.post({
                    url: "".concat(m.apiEndpoint, "/api/v2/accounts/").concat(m.subdomain, "/subscribers/webpush/"),
                    payload: F
                }).then(O => (O && O.result || f("Invalid /subscribe response. response:", O), O.result.token)).catch(() => Promise.reject("Send Subscription API Failed"))
            }
            refreshSubscription(e, t, o) {
                var i, r = {
                    previous_token: e,
                    previous_subscription: t,
                    current_subscription: o
                };
                return r.context = {
                    subscribe_url: ((i = this.window) === null || i === void 0 || (i = i.location) === null || i === void 0 ? void 0 : i.href) || "",
                    session_token: h.sessionToken,
                    visitor_token: h.visitorToken,
                    sib_visitor_id: m.visitorId
                }, P().isOldIOS ? (console.warn("PushOwl does not support iOS before 16.4"), f("PushOwl does not support iOS before 16.4", "platform: ".concat(navigator.platform), "Browser: ".concat(P().name)), Promise.reject(T.OLD_IOS_DEVICE)) : A.post({
                    url: this.subscriber_refresh_endpoint,
                    payload: r
                }).then(a => a.result.token).catch(() => Promise.reject("Refresh Subscription API Failed"))
            }
            syncSubscriber(e) {
                var t, o = {
                    data: [{
                        key: "customer_id",
                        value: e || k.customerId
                    }],
                    token: h.subscriberToken,
                    context: {
                        subscribe_url: ((t = this.window) === null || t === void 0 || (t = t.location) === null || t === void 0 ? void 0 : t.href) || "",
                        session_token: h.sessionToken,
                        visitor_token: h.visitorToken
                    }
                };
                return U.put({
                    url: "".concat(m.apiEndpoint, "/api/v1/accounts/").concat(m.subdomain, "/subscriber/"),
                    payload: o
                })
            }
            syncCart(e, t) {
                var o, i, r = {
                    customer_id: new v().config.privacy && (t || k.customerId || h.syncedCustomerId) || null,
                    cart_json: e,
                    browser: P().name,
                    origin: ((o = this.window) === null || o === void 0 || (o = o.location) === null || o === void 0 ? void 0 : o.origin) || "",
                    subscriber_token: h.subscriberToken,
                    store_root: ((((i = this.window) === null || i === void 0 ? void 0 : i.Shopify) || {}).routes || {}).root || "/"
                };
                return r.subscriber_token ? A.post({
                    path: "/subscriber/event/cart-sync/",
                    payload: r
                }) : Promise.reject(Q.NO_SUBSCRIBER_TOKEN)
            }
            syncProductView(e) {
                var t;
                e.variants && e.variants.length > 0 && (e.variants[0].price = qe(e.variants[0].price));
                var o = {
                    subscriber_token: h.subscriberToken,
                    session: h.sessionToken,
                    viewed_time: ~~(Date.now() / 1e3),
                    product_data: e,
                    store_root: ((((t = this.window) === null || t === void 0 ? void 0 : t.Shopify) || {}).routes || {}).root || "/"
                };
                return A.post({
                    path: "/subscriber/event/product-view/",
                    payload: o
                })
            }
            sendEvent(e, t) {
                return (o = function*() {
                    return U.post({
                        path: "/subscriber/event/".concat(e, "/"),
                        payload: t
                    }).catch(i => Promise.reject("Event Update failed"))
                }, function() {
                    var i = this,
                        r = arguments;
                    return new Promise(function(a, l) {
                        var s = o.apply(i, r);

                        function c(p) {
                            Ne(s, a, l, c, d, "next", p)
                        }

                        function d(p) {
                            Ne(s, a, l, c, d, "throw", p)
                        }
                        c(void 0)
                    })
                })();
                var o
            }
            unsubscribe(e) {
                return e ? x.post({
                    url: "".concat(m.apiEndpoint, "/api/v1/accounts/").concat(m.subdomain, "/subscriber/unsubscribe/"),
                    payload: {
                        token: e,
                        sib_visitor_id: m.visitorId
                    }
                }) : Promise.reject(Q.NO_SUBSCRIBER_TOKEN)
            }
            syncSubscriberTokenAndCheckoutId(e) {
                var t = JSON.stringify({
                    subscriber_token: h.subscriberToken,
                    checkout_token: e
                });
                navigator.sendBeacon(this.checkout_sync_endpoint, t)
            }
            debugLog(e) {
                return x.post({
                    path: "/subscriber/debug/",
                    payload: e
                })
            }
            subscribeThroughPopup(e) {
                var t, {
                    subscriptionData: o,
                    flowId: i,
                    nodeId: r,
                    source: a = "optin_flows"
                } = e;
                (t = a === "embedded_forms" ? h.embeddedSubscriberToken : h.optinSubscriberToken) || (t = localStorage.getItem(u.STORAGE_KEYS.SUBSCRIBER_TOKEN));
                var l = {
                    subscription_data: o,
                    token: t,
                    source: a,
                    source_id: r
                };
                return A.post({
                    path: "/dashboard/optin-flows/".concat(i, "/subscribers/"),
                    payload: l
                })
            }
            subscribeThroughBISForm(e) {
                var {
                    channel: t,
                    subscriptionData: o,
                    variantId: i
                } = e, r = B({
                    channel: t,
                    variant_id: i
                }, o);
                return A.post({
                    url: "".concat(m.apiEndpoint, "/api/v1/").concat(m.subdomain, "/subscriptions/back-in-stock/"),
                    payload: r
                })
            }
            identifyBrevoContactThroughPhoneNumber(e, t) {
                var o, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
                    r = new v().config.brevo_ma_key,
                    a = (o = "sib_cuid", document.cookie.split("; ").reduce((_, S) => {
                        var w = S.split("=");
                        return w[0] === o ? decodeURIComponent(w[1]) : _
                    }, "")),
                    l = {
                        sms: "mailin-sms.com",
                        whatsapp: "mailin-wa.com"
                    },
                    s = Array.isArray(t) ? t : [t];
                if (r && a && e && s.length > 0) {
                    var c, d = s.includes("sms") ? l.sms : l[s[0]],
                        p = h.email ? h.email : "".concat(e.replace(/\D/g, ""), "@").concat(d);
                    b.emailId || (b.emailId = p);
                    var g = {};
                    return s.forEach(_ => {
                        _ === "sms" ? g.sms = e : _ === "whatsapp" && (g.whatsapp = e)
                    }), A.post({
                        url: "https://in-automate.brevo.com/p",
                        appendPlatform: !1,
                        payload: {
                            key: r,
                            sib_type: "identify",
                            cuid: a,
                            ma_url: ((c = this.document) === null || c === void 0 || (c = c.location) === null || c === void 0 ? void 0 : c.href) || "",
                            contact: B(B({}, i), g),
                            email_id: p
                        }
                    })
                }
            }
        }, G = class {
            static subscriptionConfirmation(e, t, o) {
                return e !== "email" ? null : o.subscriptionConfirmation ? {
                    shouldIdentify: !1,
                    channels: ["email"],
                    identifier: "email",
                    reason: "Subscription confirmation is enabled"
                } : null
            }
            static primaryIdentifier(e, t, o) {
                var {
                    identifiers: i
                } = o, r = {
                    email: ["email"],
                    phone: ["sms"]
                }, a = null, l = 1 / 0;
                for (var [s, c] of Object.entries({
                        email: 1,
                        phone: 2
                    })) {
                    var d = s;
                    i[d] && c < l && (a = d, l = c)
                }
                return a && a !== e ? e !== "phone" || o.currentStoredEmail ? {
                    shouldIdentify: !1,
                    channels: [t[0]],
                    identifier: e,
                    reason: "Primary identifier '".concat(a, "' is available")
                } : {
                    shouldIdentify: !0,
                    channels: r[e],
                    identifier: e,
                    reason: "Primary identifier not available"
                } : {
                    shouldIdentify: !0,
                    channels: r[e],
                    identifier: e,
                    reason: "Primary identifier '".concat(e, "' - will identify")
                }
            }
            static deduplication(e, t, o) {
                var i = o.identifiers[e];
                if (!i) return null;
                var r = [];
                for (var a of t) {
                    var l = "".concat(e, ":").concat(a);
                    this.identifiedCombinations.get(l) !== i && (r.push(a), this.identifiedCombinations.set(l, i))
                }
                return r.length > 0 ? {
                    shouldIdentify: !0,
                    channels: r,
                    identifier: e,
                    reason: "New value detected for channels: ".concat(r.join(", "))
                } : {
                    shouldIdentify: !1,
                    channels: [],
                    identifier: e,
                    reason: "Already identified with this value"
                }
            }
        };
        J = G, G.identifiedCombinations = new Map, G.rules = [J.subscriptionConfirmation, J.primaryIdentifier, J.deduplication];
        ge = class {
            static evaluate(e, t, o) {
                var i = G.rules;
                for (var r of i) {
                    var a = r(e, t, o);
                    if (a !== null) return a
                }
                return {
                    shouldIdentify: !0,
                    channels: t,
                    identifier: e,
                    reason: "Default: No rules matched, identifying on all available channels"
                }
            }
        }, he = class {
            static identify(e, t) {
                return y(this, void 0, void 0, function*() {
                    try {
                        var {
                            email: o,
                            cuid: i,
                            properties: r = {}
                        } = e, a = t.brevo_ma_key;
                        if (!a || t.flags.brevo_email !== "enabled") return;
                        var l = t.cuid || i;
                        yield fetch("https://in-automate.brevo.com/p", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                key: a,
                                email_id: o,
                                contact: Object.assign({
                                    email: o
                                }, r),
                                cuid: l,
                                sib_type: "identify"
                            })
                        })
                    } catch (s) {
                        console.debug("BrevoAPIClient.identify error:", s)
                    }
                })
            }
        }, me = class {
            constructor() {
                this.type = "email"
            }
            normalize(e) {
                return (e || "").trim().toLowerCase()
            }
            hasChanged(e, t) {
                return e !== t.currentStoredEmail
            }
            store(e, t) {
                t.localStorage ? t.localStorage.setItem("pushowl_email", e) : h.email = e
            }
            getAvailableChannels() {
                return ["email"]
            }
            identify(e, t, o) {
                var i, r;
                return y(this, void 0, void 0, function*() {
                    var a = Array.isArray(t) ? t : [t];
                    if (a[0] !== "email") throw new Error("Email identifier does not support ".concat(a[0], " channel"));
                    var l = Object.assign({
                        subscribe_url: ((r = (i = o.window) === null || i === void 0 ? void 0 : i.location) === null || r === void 0 ? void 0 : r.href) || ""
                    }, o.properties);
                    o.brevoConfig ? yield he.identify({
                        email: e,
                        properties: l
                    }, o.brevoConfig): b.identify(e, l)
                })
            }
            setIdentifier(e, t) {
                if (t !== "email") throw new Error("Email identifier does not support ".concat(t, " channel"));
                b.emailId = e
            }
        }, _e = class {
            constructor() {
                this.type = "phone"
            }
            normalize(e) {
                var t = (e || "").trim();
                return t ? t.replace(/^\+/, "").replace(/\D/g, "").length < 10 ? "" : t : ""
            }
            hasChanged(e, t) {
                return e !== t.currentStoredPhone
            }
            store(e, t) {
                t.localStorage ? t.localStorage.setItem("pushowl_phone", e) : h.phone = e
            }
            getAvailableChannels() {
                return ["sms"]
            }
            identify(e, t, o) {
                var i, r, a;
                return y(this, void 0, void 0, function*() {
                    var l = Object.assign({
                            subscribe_url: ((r = (i = o.window) === null || i === void 0 ? void 0 : i.location) === null || r === void 0 ? void 0 : r.href) || ""
                        }, o.properties),
                        s = Array.isArray(t) ? t : [t];
                    for (var c of s)
                        if (c !== "sms" && c !== "whatsapp") throw new Error("Phone identifier does not support ".concat(c, " channel"));
                    var d = new pe(o.window, (a = o.window) === null || a === void 0 ? void 0 : a.document);
                    try {
                        yield d.identifyBrevoContactThroughPhoneNumber(e, s, l)
                    } catch (p) {
                        console.debug("Failed to identify phone via ".concat(s.join(", "), ": ").concat(p))
                    }
                })
            }
            setIdentifier(e, t) {}
        }, Y = class {
            constructor() {
                var e, t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null,
                    o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
                this.identifierRegistry = new Map([
                    ["email", new me],
                    ["phone", new _e]
                ]), this.window = t || (typeof window != "undefined" ? window : null), this.localStorage = o || ((e = this.window) === null || e === void 0 ? void 0 : e.localStorage) || (typeof localStorage != "undefined" ? localStorage : null)
            }
            identify(e) {
                var t, o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
                    i = arguments.length > 2 ? arguments[2] : void 0;
                return y(this, void 0, void 0, function*() {
                    f("[ChannelIdentityManager] identify() called", {
                        identifiers: e,
                        properties: o,
                        hasBrevoConfig: !!(i != null && i.brevoConfig)
                    });
                    var r = new v,
                        a = !!(!((t = r == null ? void 0 : r.config) === null || t === void 0) && t.subscription_confirmation),
                        l = this.localStorage ? this.localStorage.getItem("pushowl_email") : h.email,
                        s = this.localStorage ? this.localStorage.getItem("pushowl_phone") : h.phone;
                    f("[ChannelIdentityManager] Context setup", {
                        subscriptionConfirmation: a,
                        currentStoredEmail: l,
                        currentStoredPhone: s
                    });
                    var c = {
                        identifiers: e,
                        properties: o,
                        subscriptionConfirmation: a,
                        currentStoredEmail: l,
                        currentStoredPhone: s,
                        window: this.window,
                        brevoConfig: i == null ? void 0 : i.brevoConfig,
                        localStorage: this.localStorage
                    };
                    for (var [d, p] of this.identifierRegistry) yield this.processIdentifier(d, p, c);
                    f("[ChannelIdentityManager] identify() completed")
                })
            }
            processIdentifier(e, t, o) {
                return y(this, void 0, void 0, function*() {
                    var i = o.identifiers[e];
                    if (f("[ChannelIdentityManager] Processing ".concat(e), {
                            rawValue: i,
                            hasRawValue: !!i
                        }), i) {
                        var r = t.normalize(i);
                        if (f("[ChannelIdentityManager] Normalized ".concat(e), {
                                normalizedValue: r,
                                isValid: !!r
                            }), r) {
                            var a = t.hasChanged(r, o);
                            f("[ChannelIdentityManager] ".concat(e, " change detection"), {
                                hasChanged: a
                            }), a && (f("[ChannelIdentityManager] Storing ".concat(e), {
                                value: r
                            }), t.store(r, o));
                            var l = t.getAvailableChannels(),
                                s = ge.evaluate(e, l, o);
                            f("[ChannelIdentityManager] Rule evaluation for ".concat(e), Object.assign(Object.assign({}, s), {
                                availableChannels: l
                            })), s.shouldIdentify && s.channels.length > 0 ? (f("[ChannelIdentityManager] Identifying ".concat(e, " on channels"), {
                                channels: s.channels
                            }), yield t.identify(r, s.channels, o)) : !s.shouldIdentify && s.channels.length > 0 ? (f("[ChannelIdentityManager] Setting ".concat(e, " identifier only (no identify call)"), {
                                channel: s.channels[0]
                            }), t.setIdentifier(r, s.channels[0])) : f("[ChannelIdentityManager] No action taken for ".concat(e), {
                                reason: "No channels available or should not identify"
                            })
                        } else f("[ChannelIdentityManager] Skipping ".concat(e, " - normalization failed"))
                    } else f("[ChannelIdentityManager] Skipping ".concat(e, " - no raw value"))
                })
            }
        }, Ct = new Y
    });
    var Je = nt(C => {
        Re();
        He();
        var ft = "pushowl_current_config_key",
            We = n => ({
                address1: n ? n.address1 : "",
                address2: n ? n.address2 : "",
                city: n ? n.city : "",
                country: n ? n.country : "",
                country_code: n ? n.countryCode : "",
                first_name: n ? n.firstName : "",
                last_name: n ? n.lastName : "",
                phone: n ? n.phone : "",
                province: n ? n.province : "",
                province_code: n ? n.provinceCode : "",
                zip: n ? n.zip : ""
            }),
            V = (n, e) => ({
                data: {
                    email: n.email,
                    phone: n.phone,
                    buyer_accepts_email_marketing: n.buyerAcceptsEmailMarketing,
                    buyer_accepts_sms_marketing: n.buyerAcceptsSmsMarketing,
                    currency_code: n.currencyCode,
                    discounts_amount: n.discountsAmount ? n.discountsAmount.amount : 0,
                    subtotal_price: n.subtotalPrice.amount,
                    total_price: n.totalPrice.amount,
                    billing_address: We(n.billingAddress),
                    shipping_address: We(n.shippingAddress),
                    items: n.lineItems.map(t => ({
                        title: t.title,
                        quantity: t.quantity,
                        line_price: t.finalLinePrice ? t.finalLinePrice.amount : 0,
                        variant: {
                            id: t.variant.id,
                            title: t.variant.title,
                            display_name: t.variant.displayName ? t.variant.displayName : "",
                            image: {
                                src: t.variant.image.src ? t.variant.image.src.replace("_64x64", "") : null
                            },
                            product: {
                                id: t.variant.product.id,
                                title: t.variant.product.title
                            }
                        }
                    })),
                    checkout_url: e
                },
                id: n.token
            }),
            vt = "https://in-automate.brevo.com/p",
            wt = r => R(null, [r], function*({
                isEmailRequired: n = !0,
                browser: e,
                eventName: t,
                payload: o,
                url: i
            }) {
                try {
                    let a = null,
                        l = null;
                    o.data.buyer_accepts_email_marketing && (a = o.data.email), o.data.buyer_accepts_sms_marketing && (l = o.data.phone);
                    let [s, c, d] = yield Promise.all([e.localStorage.getItem("pushowl_email"), e.localStorage.getItem("pushowl_phone"), e.cookie.get("sib_cuid")]), p = a || s, g = l || c, S = yield new X(e).getConfig();
                    if (S) {
                        let w = S.brevo_ma_key;
                        if (!(w && S.flags.brevo_email === "enabled") || S.flags.disable_brevo_track_events === "enabled") return;
                        let E = {};
                        p && (E.email_id = p), g && (E.sms = g);
                        let F = E.email_id,
                            O = E.sms;
                        (F && n || O || !n) && (F || O) && (!s && a && e.localStorage.setItem("pushowl_email", a), !c && l && e.localStorage.setItem("pushowl_phone", l), yield fetch(vt, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                sib_name: t,
                                sib_type: "track",
                                key: w,
                                contact: E,
                                ma_url: i,
                                cuid: d,
                                event: o
                            })
                        }))
                    }
                } catch (a) {
                    console.log(a)
                }
            }),
            X = class {
                constructor(e) {
                    this.browser = e
                }
                getConfig() {
                    return R(this, null, function*() {
                        try {
                            let e = yield this.browser.sessionStorage.getItem(ft), t = yield this.browser.sessionStorage.getItem(e);
                            return t ? JSON.parse(t) : null
                        } catch (e) {
                            return console.log(e), null
                        }
                    })
                }
            },
            q = r => R(null, [r], function*({
                isEmailRequired: n = !0,
                browser: e,
                eventName: t,
                payload: o,
                url: i
            }) {
                try {
                    let l = yield new X(e).getConfig(), {
                        subscription_confirmation: s
                    } = l || {};
                    if (s && l && l.flags.disable_checkout_events === "enabled" && ["checkout_started", "checkout_completed", "checkout_address_info_submitted", "checkout_contact_info_submitted", "checkout_shipping_info_submitted"].includes(t)) return;
                    yield wt({
                        isEmailRequired: n,
                        browser: e,
                        eventName: t,
                        payload: o,
                        url: i
                    })
                } catch (a) {
                    console.log(a)
                }
            });
        ee(o => R(null, [o], function*({
            analytics: n,
            browser: e,
            init: t
        }) {
            n.subscribe("checkout_started", i => R(null, null, function*() {
                let r = i.context.document.location.href;
                q({
                    browser: e,
                    eventName: "checkout_started",
                    payload: V(i.data.checkout, r),
                    url: r
                })
            })), n.subscribe("checkout_completed", i => R(null, null, function*() {
                let [r, a, l, s, c] = yield Promise.all([e.localStorage.getItem("pushowl_subscriber_token"), e.sessionStorage.getItem("pushowl_session_token"), e.localStorage.getItem("pushowl_visitor_token"), e.sessionStorage.getItem("pushowl_subdomain"), e.sessionStorage.getItem("pushowl_environment")]), d = i.context.document.location.href;
                q({
                    browser: e,
                    eventName: "checkout_completed",
                    payload: V(i.data.checkout, d),
                    url: d
                });
                let {
                    order: {
                        customer: {
                            id: p
                        }
                    }
                } = i.data.checkout;
                if (!r || !s) return;
                let g = c === "staging" ? "https://api-staging.pushowl.com/api" : "https://api.pushowl.com/api";
                try {
                    yield fetch(`${g}/v1/accounts/${s}/subscriber/`, {
                        method: "PUT",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            data: [{
                                key: "customer_id",
                                value: p
                            }],
                            token: r,
                            context: {
                                session_token: a,
                                visitor_token: l
                            }
                        })
                    })
                } catch (_) {
                    console.error(_)
                }
            })), n.subscribe("checkout_address_info_submitted", i => R(null, null, function*() {
                let r = i.context.document.location.href;
                q({
                    browser: e,
                    eventName: "checkout_address_info_submitted",
                    payload: V(i.data.checkout, r),
                    url: r
                })
            })), n.subscribe("checkout_contact_info_submitted", i => R(null, null, function*() {
                let r = i.context.document.location.href;
                q({
                    browser: e,
                    eventName: "checkout_contact_info_submitted",
                    payload: V(i.data.checkout, r),
                    url: r
                })
            })), n.subscribe("checkout_shipping_info_submitted", i => R(null, null, function*() {
                let r = i.context.document.location.href;
                q({
                    browser: e,
                    eventName: "checkout_shipping_info_submitted",
                    payload: V(i.data.checkout, r),
                    url: r
                })
            })), n.subscribe("form_submitted", i => R(null, null, function*() {
                var r;
                if (i.data) try {
                    let a = yield e.sessionStorage.getItem("pushowl_current_config_key"), l = yield e.sessionStorage.getItem(a), s = JSON.parse(l);
                    if (((r = s.flags) == null ? void 0 : r.disable_shopify_form_tracking) === "enabled") return;
                    let {
                        element: c
                    } = i.data, d = /email/i, [p] = c.elements.filter(S => d.test(S.id) || d.test(S.name)).map(S => S.value), g = /phone|tel|mobile|cell/i, [_] = c.elements.filter(S => g.test(S.id) || g.test(S.name)).map(S => S.value);
                    if (p || _) {
                        let S = yield e.cookie.get("sib_cuid");
                        yield new Y(t.context.window, e.localStorage).identify(W(W({}, p && {
                            email: p
                        }), _ && {
                            phone: _
                        }), {}, {
                            brevoConfig: be(W({}, s), {
                                cuid: S
                            })
                        })
                    }
                } catch (a) {
                    console.error(a)
                }
            }))
        }))
    });
    var Kt = it(Je());
})();
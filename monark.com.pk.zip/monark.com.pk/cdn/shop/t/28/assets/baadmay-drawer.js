$(document).ready(function() {
    var domainShop = "monark-clothings.myshopify.com";

    // ---------------- helpers ----------------
    function parseMoney(text) {
        if (!text) return 0;
        var cleaned = String(text).replace(/\u00a0/g, " ").replace(/[^\d]/g, "");
        var num = parseInt(cleaned, 10);
        return isNaN(num) ? 0 : num;
    }

    function getPercentageFromStore() {
        var p = parseFloat(sessionStorage.getItem("percentageAmount"));
        return isNaN(p) ? 0 : p;
    }

    function setPercentageToStore(result) {
        if (!Array.isArray(result) || !result.length) return;
        var fee = result[0] ? .fee;
        var pct = parseInt(fee, 10);
        if (!isNaN(pct)) {
            sessionStorage.setItem("percentageAmount", String(pct / 100));
        }
    }

    function updateShopLimits(result) {
        var maxL = result ? .[0] ? .max_shop_limit ? ? "";
        var minL = result ? .[0] ? .min_shop_limit ? ? "";
        $("#upperlimit, .upperlimit").text(maxL);
        $("#lowerlimit, .lowerlimit").text(minL);
    }

    // --------------- core calc ----------------
    function updateBaadmayPrice1() {
        var $priceEl = $(".t4s-cart__totalPrice").first();
        if ($priceEl.length === 0) return;

        var cartPriceText = $priceEl.text();
        var cartPageTotal = parseMoney(cartPriceText);

        var perctoAddCartPage = getPercentageFromStore(); // e.g., 0.02 for 2%
        var multiCartPrice = cartPageTotal * perctoAddCartPage;
        var finalCartPrice = Math.floor((cartPageTotal + multiCartPrice) / 3);

        var $installmentEl = $(".price-divide-cart");
        if ($installmentEl.length) {
            $installmentEl.text(finalCartPrice.toLocaleString());
        }

        // Hide/show label above 15000 threshold
        var $drawerLbl = $(".drawer-total-label");
        if ($drawerLbl.length) {
            if (cartPageTotal > 30000) {
                $drawerLbl.addClass("drawer-hidden");
            } else {
                $drawerLbl.removeClass("drawer-hidden");
            }
        }
        // Hide/show label above 15000 threshold
        var $drawerLbl = $(".baadmay-cart");
        if ($drawerLbl.length) {
            if (cartPageTotal > 30000) {
                $drawerLbl.addClass("cart-hidden");
            } else {
                $drawerLbl.removeClass("cart-hidden");
            }
        }
    }

    // ---- frame-batched scheduler (no setTimeout) ----
    var rafScheduled = false;

    function scheduleUpdate() {
        if (rafScheduled) return;
        rafScheduled = true;
        requestAnimationFrame(function() {
            rafScheduled = false;
            updateBaadmayPrice1();
        });
    }

    // ---------------- data fetch ----------------
    function fetchBaadmayData() {
        var storedData = sessionStorage.getItem("baadmayData");
        if (storedData) {
            return Promise.resolve(JSON.parse(storedData));
        } else {
            return $.get("https://cms.baadmay.com/Fees?merchant_name=" + domainShop)
                .then(function(data) {
                    sessionStorage.setItem("baadmayData", JSON.stringify(data));
                    return data;
                });
        }
    }

    // --------------- observers ----------------
    var priceObserver = null;
    var cartObserver = null;

    function observePriceNode() {
        // Disconnect any previous price observer
        if (priceObserver) {
            try {
                priceObserver.disconnect();
            } catch (e) {}
            priceObserver = null;
        }

        var node = document.querySelector(".t4s-cart__totalPrice");
        if (!node) return;

        priceObserver = new MutationObserver(function() {
            scheduleUpdate();
        });
        priceObserver.observe(node, {
            characterData: true,
            childList: true,
            subtree: true
        });
    }

    function observeCartContainer() {
        // If your cart drawer / cart area re-renders, observe that container
        if (cartObserver) {
            try {
                cartObserver.disconnect();
            } catch (e) {}
            cartObserver = null;
        }

        // Pick a stable parent that contains cart content; adjust selectors to your theme
        var container =
            document.querySelector("#CartDrawer, .cart-drawer, .ajaxcart, .cart__items, .cart") || document.body;

        cartObserver = new MutationObserver(function(mutations) {
            // If nodes are added/removed (rerender), re-bind the price observer and update
            var relevant = mutations.some(function(m) {
                return m.type === "childList" && (m.addedNodes.length || m.removedNodes.length);
            });
            if (relevant) {
                observePriceNode();
                scheduleUpdate();
            }
        });

        cartObserver.observe(container, {
            childList: true,
            subtree: true
        });
    }

    // ---------------- events (no timers) ----------------
    // Any interaction that can change totals/prices should schedule an update
    $(document).on(
        "input change click",
        `
      .ajax-cart__qty-input,
      .ajax-cart__qty-control--down,
      .ajax-cart__qty-control--up,
      .quantity.cart-update.buttons_added,
      .remove.cart-remove-desktop,
      .single_add_to_cart_button.button,
      [name="quantity"],
      .cart__qty-input
    `,
        function() {
            scheduleUpdate();
        }
    );

    // If theme triggers custom events when cart updates, hook into them
    $(document).on("cart:refresh cart:updated ajaxComplete", function() {
        // Re-attach observers because markup may have been replaced
        observePriceNode();
        observeCartContainer();
        scheduleUpdate();
    });

    // ---------------- init ----------------
    fetchBaadmayData().then(function(data) {
        setPercentageToStore(data);
        updateShopLimits(data);

        // First measurement after we have fees/limits
        updateBaadmayPrice1();

        // Attach observers after initial update
        observePriceNode();
        observeCartContainer();
    });
});
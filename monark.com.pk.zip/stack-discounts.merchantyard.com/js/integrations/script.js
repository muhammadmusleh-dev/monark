! function(t) {
    var e = {};

    function o(r) {
        if (e[r]) return e[r].exports;
        var n = e[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return t[r].call(n.exports, n, n.exports, o), n.l = !0, n.exports
    }
    o.m = t, o.c = e, o.d = function(t, e, r) {
        o.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: r
        })
    }, o.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, o.t = function(t, e) {
        if (1 & e && (t = o(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var r = Object.create(null);
        if (o.r(r), Object.defineProperty(r, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var n in t) o.d(r, n, function(e) {
                return t[e]
            }.bind(null, n));
        return r
    }, o.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return o.d(e, "a", e), e
    }, o.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, o.p = "/", o(o.s = 313)
}({
    24: function(t, e, o) {
        t.exports = o(318)
    },
    313: function(t, e, o) {
        t.exports = o(314)
    },
    314: function(module, exports, __webpack_require__) {
        function _toConsumableArray(t) {
            return _arrayWithoutHoles(t) || _iterableToArray(t) || _unsupportedIterableToArray(t) || _nonIterableSpread()
        }

        function _nonIterableSpread() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }

        function _iterableToArray(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }

        function _arrayWithoutHoles(t) {
            if (Array.isArray(t)) return _arrayLikeToArray(t)
        }

        function _slicedToArray(t, e) {
            return _arrayWithHoles(t) || _iterableToArrayLimit(t, e) || _unsupportedIterableToArray(t, e) || _nonIterableRest()
        }

        function _nonIterableRest() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }

        function _unsupportedIterableToArray(t, e) {
            if (t) {
                if ("string" == typeof t) return _arrayLikeToArray(t, e);
                var o = Object.prototype.toString.call(t).slice(8, -1);
                return "Object" === o && t.constructor && (o = t.constructor.name), "Map" === o || "Set" === o ? Array.from(t) : "Arguments" === o || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o) ? _arrayLikeToArray(t, e) : void 0
            }
        }

        function _arrayLikeToArray(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var o = 0, r = new Array(e); o < e; o++) r[o] = t[o];
            return r
        }

        function _iterableToArrayLimit(t, e) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) {
                var o = [],
                    r = !0,
                    n = !1,
                    i = void 0;
                try {
                    for (var c, a = t[Symbol.iterator](); !(r = (c = a.next()).done) && (o.push(c.value), !e || o.length !== e); r = !0);
                } catch (t) {
                    n = !0, i = t
                } finally {
                    try {
                        r || null == a.return || a.return()
                    } finally {
                        if (n) throw i
                    }
                }
                return o
            }
        }

        function _arrayWithHoles(t) {
            if (Array.isArray(t)) return t
        }
        var cartPageFooterSelector, cartSubtotalPriceSelector, cartDiscountAmountSelector, checkoutButtonSelector, checkoutButtonHtml, giftAddedScript, giftAddedPageReload, javascriptCode, beforeRedirectJSCode, afterValidatingJSCode;
        __webpack_require__(315), __webpack_require__(316), __webpack_require__(317), StackDiscounts.times = 0, StackDiscounts.loading = !0, StackDiscounts.initLoading = !1, StackDiscounts.verifyLoading = !1, StackDiscounts.reload = !1, StackDiscounts.dispatchResizeEvent = 1, StackDiscounts.enableAttributes = 1, StackDiscounts.additionalAttributes = null, StackDiscounts.originalShopCurrency = "", StackDiscounts.checkoutButtonName = "stack-discounts-redirect", StackDiscounts.getCartSubtotal = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                e = window.Shopify && Shopify.routes ? Shopify.routes.root : "/",
                o = Shopify && Shopify.country ? Shopify.country : "",
                r = Shopify && Shopify.currency && 1 == Shopify.currency.rate ? e + "cart.js?_discountyard" : e + "cart.js?_discountyard&currency=" + StackDiscounts.originalShopCurrency + "&country=" + o;
            StackDiscounts.getJSON(r, (function(e, o) {
                StackDiscounts.cart = o, StackDiscounts.cartPrice = o.original_total_price, t && t()
            }))
        };
        var firstInitStackDiscountsCall = !0,
            themeExtensionDiscountFieldPlaceholder = ".discountyard-discount-field-placeholder";
        StackDiscounts.initStackDiscounts = function() {
            if (!StackDiscounts.initLoading && (StackDiscounts.reload || StackDiscounts.oldCartPrice != StackDiscounts.cartPrice)) {
                StackDiscounts.initLoading = !0, StackDiscounts.oldCartPrice = StackDiscounts.cart.original_total_price;
                var t = new XMLHttpRequest;
                t.open("POST", StackDiscounts.provider + "/api/shopify/coupons/init", !0), t.setRequestHeader("Content-type", "application/json;charset=UTF-8"), t.onreadystatechange = function() {
                    if (4 == t.readyState && 200 == t.status && t.responseText) {
                        var e = JSON.parse(t.responseText),
                            o = window.location.href.replace("wwww.", "");
                        if ((o.split(".").length <= 2 || o.includes("myshopify.com") || e.subdomain_multiple_currency) && (window.Shopify && Shopify.currency ? StackDiscounts.originalShopCurrency = Shopify.currency.active : StackDiscounts.originalShopCurrency = e.original_shop_currency), firstInitStackDiscountsCall && (firstInitStackDiscountsCall = !1, e.bundles_count > 0 && StackDiscounts.initProductBundles(), e.labels_count > 0 && (StackDiscounts.initProductLabels(), e.load_more_products_button_selector && document.querySelector(e.load_more_products_button_selector) && document.querySelectorAll(e.load_more_products_button_selector).forEach((function(t) {
                                t.addEventListener("click", (function() {
                                    setTimeout((function() {
                                        StackDiscounts.initProductLabels()
                                    }), 2e3)
                                }))
                            })), e.load_more_products_button_selector)), document.querySelectorAll("#stack-discounts-container").length)
                            for (var r = document.querySelectorAll("#stack-discounts-container"), n = 0; n < r.length; n++) r[n].remove();
                        var i = document.createElement("div");
                        if (i.id = "stack-discounts-container", i.innerHTML = e.html, i.setAttribute("data-discount-value", "0"), i.setAttribute("data-discounts-count", "0"), i.classList.add("stack-discounts-loading"), e.popup_summary) {
                            document.querySelector("#stack-discounts-order-summary") && document.querySelector("#stack-discounts-order-summary").remove();
                            var c = document.createElement("div");
                            if (c.id = "stack-discounts-order-summary", c.innerHTML = e.popup_summary, document.body.append(c), c.querySelector("#order-summary-discount-widget").prepend(i.cloneNode(!0)), e.checkout_button_selector) {
                                var a = e.checkout_button_selector;
                                a = a.replace(".template-cart", "");
                                var s = document.querySelectorAll(a);
                                for (n = 0; n < s.length; n++) {
                                    var u = s[n];
                                    if (!u.classList.contains("stack-discounts-checkout-button")) {
                                        var d = u.cloneNode(!0);
                                        u.parentNode.replaceChild(d, u), d.setAttribute("data-order-summary", "true"), d.addEventListener("click", (function(t) {
                                            t.preventDefault(), StackDiscounts.openOrderSummary()
                                        }), !1)
                                    }
                                }
                            }
                            "1" == StackDiscounts.getQuery("preview") && (StackDiscounts.cart.items.length > 0 ? StackDiscounts.openOrderSummary() : StackDiscounts.getQuery("product_id") && StackDiscounts.addProductToCart(StackDiscounts.getQuery("product_id"), 1).then((function() {
                                window.location.reload()
                            })))
                        }
                        if (e.offers_widget) {
                            document.querySelector("#discountyard-offers-widget-root") && document.querySelector("#discountyard-offers-widget-root").remove();
                            var l = document.createElement("div");
                            l.id = "discountyard-offers-widget-root", l.innerHTML = e.offers_widget, document.body.append(l)
                        }
                        if (e.discounts_side_widget) {
                            document.querySelector("#discountyard-side-widget-root") && document.querySelector("#discountyard-side-widget-root").remove();
                            var p = document.createElement("div");
                            p.id = "discountyard-side-widget-root", p.innerHTML = e.discounts_side_widget, document.body.append(p), p.querySelector(".discountyard-side-widget-discount-field").prepend(i.cloneNode(!0))
                        }
                        var f = document.querySelectorAll(themeExtensionDiscountFieldPlaceholder);
                        for (n = 0; n < f.length; n++) f[n].prepend(i.cloneNode(!0));
                        if (e.enable_cart_embedded)
                            if ("custom" == e.placement_mode) {
                                var h = e.footer_selector ? document.querySelectorAll(e.footer_selector) : [];
                                cartPageFooterSelector = e.footer_selector, cartSubtotalPriceSelector = e.subtotal_selector, cartDiscountAmountSelector = e.discount_amount_selector, checkoutButtonSelector = e.checkout_button_selector;
                                for (n = 0; n < h.length; n++) h[n] && (e.footer_selector_prepend ? h[n].prepend(i.cloneNode(!0)) : h[n].append(i.cloneNode(!0)))
                            } else "automatic" == e.placement_mode && (checkoutButtonSelector = e.checkout_button_selector, document.querySelector(checkoutButtonSelector) && (document.querySelector(checkoutButtonSelector).parentNode.prepend(i.cloneNode(!0)), document.querySelector(checkoutButtonSelector).parentNode.setAttribute("stack-discounts-wrapper", "true"), cartSubtotalPriceSelector = "#stack-discounts-subtotal"));
                        e.checkout_button_html && (checkoutButtonHtml = e.checkout_button_html), StackDiscounts.automaticGifts = e.automatic_gifts, StackDiscounts.placementMode = e.placement_mode, StackDiscounts.getCartSubtotal((function() {
                            StackDiscounts.validateCoupons()
                        })), javascriptCode = e.js_code, giftAddedScript = e.gift_added_script, giftAddedPageReload = e.gift_added_page_reload, beforeRedirectJSCode = e.before_redirect_js_code, afterValidatingJSCode = e.after_validating_js_code, StackDiscounts.enableAttributes = e.enable_attributes, StackDiscounts.dispatchResizeEvent = e.dispatch_resize_event, StackDiscounts.reload = !1, StackDiscounts.enabled = !0, StackDiscounts.initLoading = !1, windowResizeDispatchEvent()
                    }
                }, t.send(JSON.stringify({
                    store_domain: window.SHOPIFY_STORE_DOMAIN ? window.SHOPIFY_STORE_DOMAIN : Shopify && Shopify.shop ? Shopify.shop : Shopify && Shopify.Checkout ? Shopify.Checkout.apiHost : "",
                    cart: JSON.parse(JSON.stringify(StackDiscounts.cart)),
                    theme_name: window.BOOMR ? window.BOOMR.themeName : null,
                    checkout_page: window.Shopify && Shopify.Checkout ? 1 : 0,
                    route: window.Shopify && window.Shopify.routes ? window.Shopify.routes.root : "/"
                }))
            }
        }, StackDiscounts.validateCoupons = function() {
            var redirect = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            window.sd_d = 0, window.sd_n = "", window.sd_product = [];
            var containers = document.querySelectorAll("#stack-discounts-container");
            if (javascriptCode) try {
                eval(javascriptCode)
            } catch (t) {}
            if (containers.length && !StackDiscounts.verifyLoading && StackDiscounts.cart && StackDiscounts.cart.item_count > 0) {
                if (StackDiscounts.getCookie("upsellyard_discount") && StackDiscounts.coupons.push(StackDiscounts.getCookie("upsellyard_discount")), StackDiscounts.automaticGifts) {
                    for (var breakScript = !1, _loop = function _loop() {
                            var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
                                code = _Object$entries$_i[0],
                                gift = _Object$entries$_i[1];
                            gift.is_automatic && StackDiscounts.coupons.push(code);
                            var filteredCodes = StackDiscounts.coupons.filter((function(t) {
                                return t.toLowerCase().trim().includes(code.toLowerCase().trim())
                            }));
                            filteredCodes.length && (giftProduct = StackDiscounts.cart.items.filter((function(t) {
                                return t.variant_id == gift.variant_id && t.quantity >= gift.quantity
                            })), giftProduct.length || gift.minimum_cart_subtotal && !(StackDiscounts.cart.original_total_price / 100 >= gift.minimum_cart_subtotal) || (breakScript = !0, toggleLoadingAnimation(), StackDiscounts.addProductToCart(gift.variant_id, gift.quantity).then((function(response) {
                                if (toggleLoadingAnimation(!0), response.ok) {
                                    if (StackDiscounts.setCookie("gift_discount_code", filteredCodes[0]), giftAddedPageReload || Shopify.checkout) return void setTimeout((function() {
                                        window.location.href = window.location.pathname + "?giftadded=1&discounts=" + filteredCodes[0]
                                    }), 0);
                                    if (giftAddedScript) {
                                        try {
                                            eval(giftAddedScript)
                                        } catch (t) {}
                                        StackDiscounts.setCookie("gift_discount_code", "")
                                    }
                                } else breakScript = !1, console.log(response)
                            }))), giftProduct.length && gift.auto_remove_product && gift.minimum_cart_subtotal && StackDiscounts.cart.original_total_price / 100 < gift.minimum_cart_subtotal && (console.log("remove the gift product"), StackDiscounts.removeProductFromCart(gift.variant_id).then((function(t) {
                                window.location.reload(!0)
                            }))))
                        }, _i = 0, _Object$entries = Object.entries(StackDiscounts.automaticGifts); _i < _Object$entries.length; _i++) {
                        var giftProduct;
                        _loop()
                    }
                    if (!giftAddedPageReload && breakScript) return
                }
                StackDiscounts.verifyLoading = !0, redirect || toggleLoadingAnimation();
                var xhttp = new XMLHttpRequest;
                xhttp.open("POST", StackDiscounts.provider + "/api/shopify/coupons/validate", !0), xhttp.setRequestHeader("Content-type", "application/json;charset=UTF-8"), xhttp.onreadystatechange = function() {
                    if (4 == xhttp.readyState) {
                        if (200 == xhttp.status) {
                            var result = JSON.parse(xhttp.responseText);
                            if (redirect) {
                                var actionAttributes = "",
                                    cartForm = document.querySelector('form[action*="/cart?"]');
                                if (cartForm && cartForm.getAttribute("action")) {
                                    var formAction = cartForm.getAttribute("action").split("?");
                                    formAction.length > 1 && (actionAttributes = "?" + formAction[1].replace("discount", "d"))
                                }
                                return void setTimeout((function() {
                                    var t = result.checkout_url;
                                    if (StackDiscounts.replaceStringFromCheckoutUrl)
                                        for (var e in StackDiscounts.replaceStringFromCheckoutUrl) t = t.replace(e, StackDiscounts.replaceStringFromCheckoutUrl[e]);
                                    window.location.href = t + actionAttributes + (window.appendStringToCheckoutUrl || "")
                                }), window.checkoutRedirectTimeout || 0)
                            }
                            for (var subtotalElements = document.querySelectorAll(".separate-widget-subtotal .value"), i = 0; i < subtotalElements.length; i++) subtotalElements[i].innerHTML = result.subtotal;
                            for (var totalElements = document.querySelectorAll(".separate-widget-total .value"), i = 0; i < totalElements.length; i++) totalElements[i].innerHTML = result.total;
                            var subtotalSelector = cartSubtotalPriceSelector;
                            ("automatic" == StackDiscounts.placementMode || document.querySelector(themeExtensionDiscountFieldPlaceholder)) && (subtotalSelector += ", #stack-discounts-subtotal");
                            for (var priceElements = document.querySelectorAll(subtotalSelector.trim(",")), i = 0; i < priceElements.length; i++) priceElements[i].innerHTML = result.price_html, priceElements[i].parentNode && priceElements[i].parentNode.setAttribute("data-discount-value", result.discount_value);
                            var discountElements = cartDiscountAmountSelector ? document.querySelectorAll(cartDiscountAmountSelector) : [],
                                defaultDiscountElements = document.querySelectorAll(".stack-discounts-discount-value");
                            discountElements.push.apply(discountElements, _toConsumableArray(defaultDiscountElements));
                            for (var i = 0; i < discountElements.length; i++) discountElements[i].innerHTML = result.discount, discountElements[i].parentNode && discountElements[i].parentNode.setAttribute("data-discount-value", result.discount_value);
                            for (var widgetContainers = document.querySelectorAll("#stack-discounts-container"), i = 0; i < widgetContainers.length; i++) widgetContainers[i].setAttribute("data-discount-value", result.discount_value), widgetContainers[i].setAttribute("data-discounts-count", result.valid_coupons.length), widgetContainers[i].setAttribute("data-last-code", result.last_entered_code);
                            if (StackDiscounts.discount_value = result.discount_value, StackDiscounts.subtotal_value = result.subtotal_value, StackDiscounts.total_value = result.total_value, StackDiscounts.free_shipping = result.free_shipping, StackDiscounts.priceHTML = result.price_html, result.discounts_value && (StackDiscounts.discountsValue = result.discounts_value), result.message && 0 != StackDiscounts.times && displayErrorMessage(result.message), renderCouponTags(result.valid_coupons, result.stacked_coupon, result.checkout_url, result.automatic_coupons, result.gift_card), result.cart_items_breakdown && result.cart_items_breakdown_script) {
                                StackDiscounts.cartItemsBreakdown = result.cart_items_breakdown;
                                try {
                                    eval(result.cart_items_breakdown_script)
                                } catch (t) {}
                            }
                            document.body.setAttribute("data-override-automatic-discount", result.override_automatic_discount ? 1 : 0);
                            var validateCouponsEvent = new CustomEvent("stack-discounts-verify", {
                                detail: {
                                    subtotal: result.subtotal_value,
                                    discount: result.discount_value,
                                    total: result.total_value
                                }
                            });
                            if (document.dispatchEvent(validateCouponsEvent), afterValidatingJSCode) try {
                                eval(afterValidatingJSCode)
                            } catch (t) {
                                console.log(t)
                            }
                            if (result.checkout_enabled && window.Shopify && Shopify.Checkout) {
                                if (!result.use_draft_orders || StackDiscounts.getCookie("discount_value") != result.discount_value || StackDiscounts.getCookie("free_shipping") != result.free_shipping) {
                                    if (console.log("CHECKOUT REDIRECT"), console.log(StackDiscounts.getCookie("discount_value"), result.discount_value), console.log(StackDiscounts.getCookie("free_shipping"), result.free_shipping), StackDiscounts.setCookie("free_shipping", result.free_shipping ? 1 : 0), StackDiscounts.setCookie("discount_value", result.discount_value), result.use_draft_orders) return void setTimeout((function() {
                                        window.location.href = result.checkout_url
                                    }), window.checkoutRedirectTimeout || 500);
                                    StackDiscounts.applyCodeToDefaultCheckoutField(result.stacked_coupon)
                                }
                                result.last_entered_code && setTimeout((function() {
                                    StackDiscounts.applyCodeToDefaultCheckoutField(result.last_entered_code)
                                }), 1500)
                            }
                            StackDiscounts.setCookie("free_shipping", result.free_shipping ? 1 : 0), StackDiscounts.setCookie("discount_value", result.discount_value)
                        } else {
                            if (redirect) return void(window.location.href = "/checkout");
                            toggleLoadingAnimation(!0)
                        }
                        if (StackDiscounts.getCookie("gift_discount_code") && giftAddedScript) try {
                            eval(giftAddedScript)
                        } catch (t) {}
                        StackDiscounts.setCookie("gift_discount_code", ""), StackDiscounts.verifyLoading = !1, StackDiscounts.times++
                    }
                }, StackDiscounts.cart && document.querySelector('textarea[name="note"]') && document.querySelector('textarea[name="note"]').value && (StackDiscounts.cart.note = document.querySelector('textarea[name="note"]').value);
                var fields = document.querySelectorAll('form[action*="/cart"] [name*="attributes"]');
                if (fields.length && StackDiscounts.enableAttributes)
                    for (var i = 0; i < fields.length; i++) {
                        var attributeName = fields[i].getAttribute("name").replace(/(^.*\[|\].*$)/g, "");
                        attributeName && ("checkbox" == fields[i].type ? StackDiscounts.cart.attributes[attributeName] = fields[i].checked ? "yes" : "no" : StackDiscounts.cart.attributes[attributeName] = fields[i].value)
                    }
                xhttp.send(JSON.stringify({
                    store_domain: window.SHOPIFY_STORE_DOMAIN ? window.SHOPIFY_STORE_DOMAIN : Shopify && Shopify.shop ? Shopify.shop : Shopify && Shopify.Checkout ? Shopify.Checkout.apiHost : "",
                    checkout_page: window.Shopify && Shopify.Checkout ? 1 : 0,
                    coupons: StackDiscounts.coupons,
                    cart: JSON.parse(JSON.stringify(StackDiscounts.cart)),
                    cid: (window.__st ? window.__st.cid : "") || "",
                    product_options: window.sd_product || [],
                    additional_attributes: StackDiscounts.additionalAttributes,
                    d: window.sd_d || 0,
                    n: window.sd_n || "",
                    sharable_code: window.disableSharableCode ? null : StackDiscounts.getCookie("discount_code") || StackDiscounts.getQuery("discount") || null,
                    sharable_discounts: StackDiscounts.getCookie("sharable_discounts"),
                    shopify_currency: window.Shopify ? window.Shopify.currency : null,
                    country_code: Shopify ? Shopify.country : ""
                }))
            }
        };
        var renderCouponTags = function renderCouponTags(validCoupons, stackedCoupon, checkoutURL) {
                var automaticCoupons = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [],
                    giftCard = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "",
                    discountInputsSelector = ["#stack-discounts-discount-input"];
                void 0 === window.discountInputSelector ? discountInputsSelector.push('[name="discount"]') : window.discountInputSelector && discountInputsSelector.push(window.discountInputSelector);
                for (var discountInputs = document.querySelectorAll(discountInputsSelector.join(",")), i = 0; i < discountInputs.length; i++) discountInputs[i].value = stackedCoupon;
                for (var tagsContainers = document.querySelectorAll(".stack-discounts-tags-wrapper"), i = 0; i < tagsContainers.length; i++) {
                    for (var tags = document.createElement("div"), x = 0; x < validCoupons.length; x++) {
                        var validCoupon = validCoupons[x],
                            hideCloseButton = automaticCoupons.includes(validCoupon),
                            tag = StackDiscounts.createTag(validCoupon, hideCloseButton, validCoupons[x] == giftCard);
                        tags.append(tag)
                    }
                    tagsContainers[i].innerHTML = "", tagsContainers[i].append(tags)
                }
                for (var countBadges = document.querySelectorAll(".discounts-count-badge"), i = 0; i < countBadges.length; i++) countBadges[i].setAttribute("data-discounts-count", validCoupons.length), countBadges[i].innerText = validCoupons.length;
                if (stackedCoupon)
                    if (StackDiscounts.stackedDiscount = stackedCoupon, 1 == window.disableDiscountJSONRequest);
                    else if (1 == window.forceEnableDiscountJSONRequest) {
                    var urlRoot = window.Shopify && Shopify.routes ? Shopify.routes.root : "/";
                    StackDiscounts.getJSON(urlRoot + "discount/" + encodeURIComponent(stackedCoupon))
                }
                var actionAttributes = "";
                if (document.querySelector('form[action*="/cart?"]')) {
                    var formAction = document.querySelector('form[action*="/cart"]').getAttribute("action").split("?");
                    formAction.length > 1 && (actionAttributes = formAction[1].replace("discount", "d"))
                }
                if (checkoutURL && !window.location.href.includes("checkouts")) {
                    var selector = '[name="' + StackDiscounts.checkoutButtonName + '"], [name="upsellyard-checkout"]';
                    "/checkout" != checkoutURL && "/checkout?discount=" != checkoutURL && (selector += ", " + checkoutButtonSelector);
                    var oldCheckoutButtons = document.querySelectorAll(selector);
                    if (oldCheckoutButtons.length)
                        for (var checkoutButtonCallback = function checkoutButtonCallback(e) {
                                if (e.preventDefault(), StackDiscounts.processToCheckout = !0, beforeRedirectJSCode) try {
                                    eval(beforeRedirectJSCode)
                                } catch (e) {
                                    console.log(e)
                                }
                                if (StackDiscounts.processToCheckout) {
                                    if (!window.disableDiscountJSONRequest) {
                                        var _urlRoot = window.Shopify && Shopify.routes ? Shopify.routes.root : "/";
                                        StackDiscounts.getJSON(_urlRoot + "discount/" + encodeURIComponent(stackedCoupon)), console.log("Applied code: " + stackedCoupon)
                                    }
                                    var note = document.querySelector('textarea[name="note"]'),
                                        fields = document.querySelectorAll('form[action*="/cart"] [name*="attributes"]');
                                    StackDiscounts.cart && (note && StackDiscounts.cart.note != note.value || fields.length || StackDiscounts.additionalAttributes) ? StackDiscounts.validateCoupons(!0) : setTimeout((function() {
                                        if (StackDiscounts.replaceStringFromCheckoutUrl)
                                            for (var t in StackDiscounts.replaceStringFromCheckoutUrl) checkoutUrl = checkoutUrl.replace(t, StackDiscounts.replaceStringFromCheckoutUrl[t]);
                                        window.location.href = checkoutURL + (checkoutURL.includes("?") ? "&" : "?") + actionAttributes + (window.appendStringToCheckoutUrl || "")
                                    }), window.checkoutRedirectTimeout || 500)
                                }
                            }, i = 0; i < oldCheckoutButtons.length; i++) {
                            var oldCheckoutButton = oldCheckoutButtons[i];
                            if (!oldCheckoutButton.getAttribute("data-order-summary"))
                                if (checkoutButtonHtml) {
                                    var newCheckoutButton = createElementFromHTML(checkoutButtonHtml);
                                    newCheckoutButton.setAttribute("name", StackDiscounts.checkoutButtonName), newCheckoutButton.addEventListener("click", checkoutButtonCallback, !1), oldCheckoutButton.parentNode.replaceChild(newCheckoutButton, oldCheckoutButton)
                                } else {
                                    var _newCheckoutButton = oldCheckoutButton.cloneNode(!0);
                                    oldCheckoutButton.parentNode.replaceChild(_newCheckoutButton, oldCheckoutButton), _newCheckoutButton.removeAttribute("disabled"), _newCheckoutButton.removeAttribute("form"), _newCheckoutButton.hasAttribute("type") && _newCheckoutButton.setAttribute("type", "button"), _newCheckoutButton.classList.remove("disabled"), _newCheckoutButton.setAttribute("name", StackDiscounts.checkoutButtonName), _newCheckoutButton.addEventListener("click", checkoutButtonCallback, !1)
                                }
                        }
                }
                for (var buttons = document.querySelectorAll(".stack-discounts-checkout-button"), i = 0; i < buttons.length; i++) buttons[i].setAttribute("href", checkoutURL ? checkoutURL + actionAttributes : "/checkout");
                StackDiscounts.coupons = validCoupons, StackDiscounts.setCookie("localcoupons", validCoupons), toggleLoadingAnimation(!0), window.disableCurrencyAppsRender || currencyAppsRerender(), windowResizeDispatchEvent()
            },
            requestOpen;

        function windowResizeDispatchEvent() {
            StackDiscounts.dispatchResizeEvent && setTimeout((function() {
                window.dispatchEvent(new Event("resize"))
            }), 0)
        }

        function currencyAppsRerender() {
            try {
                void 0 !== window.bucksCC && window.bucksCC.rerender(), void 0 !== window.convertCurrencies && window.convertCurrencies(), void 0 !== window.conversionBearAutoCurrencyConverter && window.conversionBearAutoCurrencyConverter.convertPricesOnPage(), document.querySelector(".currency-switcher") && document.querySelector(".currency-switcher").dispatchEvent(new CustomEvent("change")), document.body.dispatchEvent(new Event("refresh_currency"))
            } catch (t) {}
        }

        function createElementFromHTML(t) {
            var e = document.createElement("div");
            return e.innerHTML = t.trim(), e.firstChild
        }

        function toggleLoadingAnimation() {
            var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                e = document.querySelectorAll("#stack-discounts-container");
            e.length && document.body.setAttribute("data-discountyard-loading", "1");
            for (var o = 0; o < e.length; o++) t ? e[o].classList.remove("stack-discounts-loading") : e[o].classList.add("stack-discounts-loading");
            StackDiscounts.loading = !t, t && document.body.removeAttribute("data-discountyard-loading")
        }

        function displayErrorMessage(t) {
            StackDiscounts.toggleErrorMessages(!0, t), setTimeout((function() {
                StackDiscounts.toggleErrorMessages(!1)
            }), window.DiscountYardErrorMessageTimeout || 3e3)
        }
        Shopify && Shopify.checkout && Shopify.checkout.order_id && (window.forceDisableDiscountYard = !0), Shopify && Shopify.Checkout && Shopify.Checkout.isOrderStatusPage && (window.forceDisableDiscountYard = !0), window.forceDisableDiscountYard ? console.log("DiscountYard app is disabled!") : StackDiscounts.getCartSubtotal((function() {
            StackDiscounts.initStackDiscounts()
        })), window.location.href.includes("/cart") && document.body && document.body.setAttribute("is-cart-page", 1), window.forceDisableDiscountYard || (requestOpen = XMLHttpRequest.prototype.open, XMLHttpRequest.prototype.open = function() {
            this.addEventListener("load", (function() {
                this._url && (this._url.includes(["cart.js"]) && "GET" == this._method || this._url.includes(["bundle.thimatic-apps"]) || this._url.includes(["icu=1"]) || "/cart.js" != this._url && !this._url.includes(["/cart/"]) || StackDiscounts.getCartSubtotal((function() {
                    StackDiscounts.initStackDiscounts()
                })))
            })), requestOpen.apply(this, arguments)
        }, function(t, e) {
            "function" == typeof e && (t.fetch = function() {
                var t = e.apply(this, arguments);
                return t.then((function(t) {
                    t.url.includes(["cart.js"]) || t.url.includes(["bundle.thimatic-apps"]) || "/cart.js?_discountyard" == t.url || t.url.includes(["_discountyard"]) || t.url.includes(["icu=1"]) || !t.url.includes(["/cart"]) ? t.url.includes("page=") && setTimeout((function() {
                        StackDiscounts.initProductLabels()
                    }), 2e3) : t.clone().json().then((function(t) {
                        StackDiscounts.getCartSubtotal((function() {
                            StackDiscounts.initStackDiscounts()
                        }))
                    })).catch((function(t) {}))
                })), t
            })
        }(window, window.fetch), setInterval((function() {
            var t = document.querySelectorAll("#stack-discounts-container");
            if (StackDiscounts.enabled && !StackDiscounts.initLoading && !StackDiscounts.verifyLoading && StackDiscounts.times <= 20 && ("custom" == StackDiscounts.placementMode || window.ZipifyPages) && 0 == t.length) {
                cartPageFooterSelector || (cartPageFooterSelector = "#wow-cart-drawer-app .slider-cart-fix-portions");
                for (var e = cartPageFooterSelector ? document.querySelectorAll(cartPageFooterSelector) : [], o = 0; o < e.length; o++) e[o] && !e[o].querySelector("#stack-discounts-container") && (StackDiscounts.reload = !0, StackDiscounts.getCartSubtotal((function() {
                    StackDiscounts.initStackDiscounts()
                })))
            }
        }), 1e3))
    },
    315: function(t, e) {
        function o(t) {
            return function(t) {
                if (Array.isArray(t)) return r(t)
            }(t) || function(t) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
            }(t) || function(t, e) {
                if (!t) return;
                if ("string" == typeof t) return r(t, e);
                var o = Object.prototype.toString.call(t).slice(8, -1);
                "Object" === o && t.constructor && (o = t.constructor.name);
                if ("Map" === o || "Set" === o) return Array.from(t);
                if ("Arguments" === o || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o)) return r(t, e)
            }(t) || function() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }()
        }

        function r(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var o = 0, r = new Array(e); o < e; o++) r[o] = t[o];
            return r
        }
        var n = window.DiscountYardProvider || "https://stack-discounts.merchantyard.com";
        window.StackDiscounts = {
            provider: n
        }, window.StackDiscounts.getJSON = function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                o = new XMLHttpRequest;
            o.open("GET", t, !0), o.onload = function() {
                var t = o.status;
                e && e(200 === t ? null : t, JSON.parse(o.response))
            }, o.send()
        }, window.StackDiscounts.addProductToCart = function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
            return fetch("/cart/add.js", {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    items: [{
                        id: parseInt(t),
                        quantity: parseInt(e)
                    }]
                })
            })
        }, window.StackDiscounts.removeProductFromCart = function(t) {
            var e = {};
            return e[t] = 0, fetch("/cart/update.js", {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    updates: e
                })
            })
        }, window.StackDiscounts.insertAfter = function(t, e) {
            var o = e.parentNode;
            o.lastChild == e ? o.appendChild(t) : o.insertBefore(t, e.nextSibling)
        }, window.StackDiscounts.setCookie = function(t, e) {
            var o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
                r = new Date;
            r.setTime(r.getTime() + 24 * o * 60 * 60 * 1e3);
            var n = "expires=" + r.toUTCString();
            document.cookie = t + "=" + e + ";" + n + ";path=/"
        }, window.StackDiscounts.getCookie = function(t) {
            for (var e = t + "=", o = document.cookie.split(";"), r = 0; r < o.length; r++) {
                for (var n = o[r];
                    " " == n.charAt(0);) n = n.substring(1);
                if (0 == n.indexOf(e)) return n.substring(e.length, n.length)
            }
            return ""
        }, window.StackDiscounts.queryElements = function(t) {
            var e = [];
            if (t)
                if (t.includes("_SHADOWROOT"))
                    for (var r = t.split(","), n = 0; n < r.length; n++) {
                        var i = [];
                        if (r[n].includes("_SHADOWROOT")) {
                            var c = r[n].split("_SHADOWROOT"),
                                a = document.querySelector(c[0]);
                            a && a.shadowRoot && (i = a.shadowRoot.querySelectorAll(c[1]))
                        } else i = document.querySelectorAll(r[n]);
                        i.length && (e = o(e).concat(o(i)))
                    } else e = document.querySelectorAll(t);
            return e
        }, window.StackDiscounts.getQuery = function(t) {
            for (var e = window.location.search.substring(1).split("&"), o = 0; o < e.length; o++) {
                var r = e[o].split("=");
                if (r[0] == t) return r[1]
            }
            return !1
        }, window.StackDiscounts.toggleErrorMessages = function() {
            for (var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", o = document.querySelectorAll(".stack-discounts-message"), r = 0; r < o.length; r++) e && (o[r].querySelector(".message-text").setAttribute("data-message", e), o[r].querySelector(".message-text").innerHTML = e), t ? o[r].classList.add("message--show") : o[r].classList.remove("message--show")
        }, window.StackDiscounts.applyCodeToDefaultCheckoutField = function(t) {
            if (t)
                for (var e = document.querySelectorAll("#checkout_reduction_code"), o = 0; o < e.length; o++) {
                    var r = e[o];
                    if (r && !(r.getAttribute("style") || "").includes("display: none")) {
                        r.value = t, r.dispatchEvent(new window.Event("change", {
                            bubbles: !0
                        }));
                        var n = document.querySelectorAll("#checkout_submit");
                        for (o = 0; o < n.length; o++) {
                            var i = n[o];
                            i && !(i.getAttribute("style") || "").includes("display: none") && (i.classList.remove("btn--disabled"), i.removeAttribute("disabled"), i.click())
                        }
                        setTimeout((function() {
                            r.value = ""
                        }), 3e3)
                    }
                } else {
                    var c = document.querySelector('.tag__button[type="submit"]');
                    c && c.click()
                }
        }, window.StackDiscounts.createTag = function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                o = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                r = document.createElement(e ? "div" : "span");
            r.classList.add("stack-discounts-tag"), r.setAttribute("data-value", t), r.setAttribute("data-is-automatic", e ? 1 : 0), o && r.setAttribute("is-gift-card", 1);
            var n = document.createElement("span");
            if (n.innerHTML = o ? "•••• " + t.slice(t.length - 4) : t, void 0 !== StackDiscounts.discountsValue[t]) {
                n.innerHTML = '<span class="stack-discounts-tag-text">' + t + "</span>";
                var i = document.createElement("span");
                i.classList.add("stack-discounts-tag-value"), i.innerHTML = StackDiscounts.discountsValue[t], n.append(i)
            }
            if (!e) {
                var c = document.createElement("i");
                c.classList.add("stack-discounts-close-tag"), c.setAttribute("data-id", t), c.onclick = function() {
                    var e = window.StackDiscounts.coupons.indexOf(t); - 1 !== e && window.StackDiscounts.coupons.splice(e, 1), StackDiscounts.validateCoupons(), StackDiscounts.setCookie("discount_code", ""), StackDiscounts.setCookie("sharable_discounts", ""), StackDiscounts.setCookie("upsellyard_discount", ""), StackDiscounts.setCookie("gift_discount_code", ""), StackDiscounts.setCookie("localcoupons", "")
                }, n.append(c)
            }
            return r.append(n), r
        };
        var i = StackDiscounts.getCookie("localcoupons");
        if (StackDiscounts.coupons = i ? i.split(",") : [], StackDiscounts.getCookie("discount_code"), StackDiscounts.getQuery("discounts")) {
            var c = StackDiscounts.getQuery("discounts");
            StackDiscounts.setCookie("sharable_discounts", c)
        }
        StackDiscounts.getCookie("gift_discount_code") && StackDiscounts.coupons.push(StackDiscounts.getCookie("gift_discount_code")), window.location.href.includes("/thank_you") && (StackDiscounts.setCookie("localcoupons", []), StackDiscounts.setCookie("discount_code", "")), window.StackDiscounts.inputKeydown = function(t) {
            var e = t.target;
            13 == t.keyCode && t.preventDefault(), 13 == t.keyCode && e.value && (t.preventDefault(), StackDiscounts.addCoupon(t))
        }, window.StackDiscounts.addCoupon = function(t) {
            var e = t.target.closest("#stack-discounts-input-block").querySelector("input");
            if (e && e.value) {
                var o = e.value;
                e.value = "", window.StackDiscounts.coupons.push(o), o == StackDiscounts.getCookie("discount_code") && StackDiscounts.setCookie("discount_code", ""), StackDiscounts.validateCoupons()
            }
        }, window.StackDiscounts.openOrderSummary = function() {
            document.querySelector("#stack-discounts-order-summary") && (StackDiscounts.getCartSubtotal((function() {
                for (var t = "", e = StackDiscounts.cart.items, o = 0; o < e.length; o++) {
                    t += '<tr>\n                    <td class="product__image">\n                        <div class="product-thumbnail">\n                            <div class="product-thumbnail__wrapper">\n                                <img src="' + e[o].image + '">\n                            </div>\n                            <span class="product-thumbnail__quantity">' + e[o].quantity + '</span>\n                        </div>\n                    </td>\n                    <td class="product__description">\n                        <span>' + e[o].title + '</span>\n                    </td>\n                    <td class="product__price">\n                        <span>' + StackDiscounts.formatMoney(e[o].final_line_price / 100) + "</span>\n                    </td>\n                </tr>"
                }
                document.querySelector("#stack-discounts-order-summary-tbody").innerHTML = t, document.querySelector("#stack-discounts-order-summary").classList.add("widget-opened")
            })), document.body.setAttribute("data-order-summary", "1"))
        }, window.StackDiscounts.closeOrderSummary = function() {
            document.querySelector("#stack-discounts-order-summary") && (document.querySelector("#stack-discounts-order-summary").classList.remove("widget-opened"), document.body.setAttribute("data-order-summary", "0"))
        }, window.StackDiscounts.formatMoney = function(t) {
            return Intl.NumberFormat(Shopify.locale, {
                style: "currency",
                currency: Shopify.currency.active
            }).format(t)
        }, StackDiscounts.getQuery("preview"), window.StackDiscounts.closeOffersWidget = function() {
            document.querySelector("#discountyard-offers-widget-root") && (document.querySelector("#discountyard-offers-widget-root").classList.remove("widget-opened"), document.body.setAttribute("data-offer-widget", "0"))
        }, window.StackDiscounts.openOffersWidget = function() {
            document.querySelector("#discountyard-offers-widget-root") && (document.querySelector("#discountyard-offers-widget-root").classList.add("widget-opened"), document.body.setAttribute("data-offer-widget", "1"))
        }, window.StackDiscounts.toggleOffersWidget = function() {
            document.querySelector("#discountyard-offers-widget-root") && (document.querySelector("#discountyard-offers-widget-root").classList.contains("widget-opened") ? StackDiscounts.closeOffersWidget() : StackDiscounts.openOffersWidget())
        };
        for (var a = document.querySelectorAll('[href="/cart"]'), s = 0; s < a.length; s++) a[s].addEventListener("click", (function() {
            StackDiscounts.initStackDiscounts()
        }), !1)
    },
    316: function(module, exports) {
        function _slicedToArray(t, e) {
            return _arrayWithHoles(t) || _iterableToArrayLimit(t, e) || _unsupportedIterableToArray(t, e) || _nonIterableRest()
        }

        function _nonIterableRest() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }

        function _unsupportedIterableToArray(t, e) {
            if (t) {
                if ("string" == typeof t) return _arrayLikeToArray(t, e);
                var o = Object.prototype.toString.call(t).slice(8, -1);
                return "Object" === o && t.constructor && (o = t.constructor.name), "Map" === o || "Set" === o ? Array.from(t) : "Arguments" === o || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o) ? _arrayLikeToArray(t, e) : void 0
            }
        }

        function _arrayLikeToArray(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var o = 0, r = new Array(e); o < e; o++) r[o] = t[o];
            return r
        }

        function _iterableToArrayLimit(t, e) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) {
                var o = [],
                    r = !0,
                    n = !1,
                    i = void 0;
                try {
                    for (var c, a = t[Symbol.iterator](); !(r = (c = a.next()).done) && (o.push(c.value), !e || o.length !== e); r = !0);
                } catch (t) {
                    n = !0, i = t
                } finally {
                    try {
                        r || null == a.return || a.return()
                    } finally {
                        if (n) throw i
                    }
                }
                return o
            }
        }

        function _arrayWithHoles(t) {
            if (Array.isArray(t)) return t
        }
        var productsContainer = "body",
            productItemChildPrependSelector = "",
            excludeProductsContainer = 'form[action*="/cart"], [class*="sharing"], .discountyard-bundles-widget-root, .color-swatch',
            labelPrependLevel = 0;

        function initProductLabels() {
            var xhttp = new XMLHttpRequest;
            xhttp.open("POST", StackDiscounts.provider + "/api/shopify/product-labels/init", !0), xhttp.setRequestHeader("Content-type", "application/json;charset=UTF-8"), xhttp.onreadystatechange = function() {
                if (4 == xhttp.readyState && 200 == xhttp.status && xhttp.responseText) {
                    var result = JSON.parse(xhttp.responseText);
                    if (result.product_labels_css_container && (productsContainer = result.product_labels_css_container), result.product_labels_exclude_css_container && (excludeProductsContainer = result.product_labels_exclude_css_container), result.product_labels_item_child_prepend_selector && (productItemChildPrependSelector = result.product_labels_item_child_prepend_selector), result.product_labels_label_prepend_level && (labelPrependLevel = result.product_labels_label_prepend_level), result.product_labels) {
                        for (var _loop = function() {
                                var t = _slicedToArray(_Object$entries[_i], 2),
                                    e = t[0],
                                    o = t[1];
                                if (decodedProductHandle = decodeURIComponent(e), document.querySelectorAll(productsContainer).forEach((function(t) {
                                        t.querySelectorAll('[data-product-handle="' + decodedProductHandle + '"]').forEach((function(t) {
                                            if (excludeProductsContainer && t.closest(excludeProductsContainer));
                                            else {
                                                var e = document.createElement("div");
                                                e.classList.add("discountyard-product-label-wrapper"), e.innerHTML = o.label;
                                                var r = t;
                                                if (productItemChildPrependSelector && (r = r.querySelector(productItemChildPrependSelector)), r) {
                                                    "IMG" == r.nodeName && (r = r.parentNode);
                                                    for (var n = 0; n < labelPrependLevel; n++) r = r.parentNode;
                                                    r.prepend(e), r.setAttribute("data-has-product-label", "1")
                                                }
                                            }
                                        }))
                                    })), result.show_product_label_on_product_page && result.product_labels_product_page_title_selector) {
                                    var r = getCurrentPageProductHandle();
                                    if (r && r == decodedProductHandle && document.querySelectorAll(result.product_labels_product_page_title_selector).length) {
                                        var n = document.createElement("div");
                                        n.classList.add("product-label--product-page"), n.innerHTML = o.label, document.querySelectorAll(result.product_labels_product_page_title_selector).forEach((function(t) {
                                            t.append(n.cloneNode(!0)), t.setAttribute("data-has-product-page-label", 1)
                                        }))
                                    }
                                }
                            }, _i = 0, _Object$entries = Object.entries(result.product_labels); _i < _Object$entries.length; _i++) {
                            var decodedProductHandle;
                            _loop()
                        }
                        document.body.insertAdjacentHTML("beforeBegin", result.css_styles)
                    }
                    if (result.load_more_products_button_selector && document.querySelector(result.load_more_products_button_selector) && document.querySelectorAll(result.load_more_products_button_selector).forEach((function(t) {
                            t.addEventListener("click", (function() {
                                setTimeout((function() {
                                    StackDiscounts.initProductLabels()
                                }), 2e3)
                            }))
                        })), result.after_product_label_submit_js_code) try {
                        eval(result.after_product_label_submit_js_code)
                    } catch (t) {
                        console.log(t)
                    }
                }
            }, xhttp.send(JSON.stringify({
                store_domain: window.SHOPIFY_STORE_DOMAIN ? window.SHOPIFY_STORE_DOMAIN : Shopify.shop,
                product_handles: getPageProductHandles()
            }))
        }

        function getPageProductHandles() {
            var t = [];
            return document.querySelectorAll('[href*="products/"]').forEach((function(e) {
                if (e.href) {
                    var o = e.href.split("/products/");
                    if (o.length > 1 && o[1]) {
                        var r = o[1].split("?")[0];
                        e.setAttribute("data-product-handle", decodeURIComponent(r)), t.push(decodeURIComponent(r))
                    }
                }
            })), getCurrentPageProductHandle() && t.push(getCurrentPageProductHandle()), t
        }

        function getCurrentPageProductHandle() {
            if (window.location.href.split("/products/").length >= 2) {
                var t = window.location.href.split("/products/")[1].split("?")[0];
                return decodeURIComponent(t)
            }
            return ""
        }
        StackDiscounts.initProductLabels = initProductLabels
    },
    317: function(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(24),
            _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);

        function asyncGeneratorStep(t, e, o, r, n, i, c) {
            try {
                var a = t[i](c),
                    s = a.value
            } catch (t) {
                return void o(t)
            }
            a.done ? e(s) : Promise.resolve(s).then(r, n)
        }

        function _asyncToGenerator(t) {
            return function() {
                var e = this,
                    o = arguments;
                return new Promise((function(r, n) {
                    var i = t.apply(e, o);

                    function c(t) {
                        asyncGeneratorStep(i, r, n, c, a, "next", t)
                    }

                    function a(t) {
                        asyncGeneratorStep(i, r, n, c, a, "throw", t)
                    }
                    c(void 0)
                }))
            }
        }
        var widgetSelector = 'form[action="/cart/add"]',
            priceTemplate = "${price}",
            beforeBundleSubmitJSCode = null;

        function getProductBundles(t) {
            var e = new XMLHttpRequest;
            e.open("POST", StackDiscounts.provider + "/api/shopify/bundles/init", !0), e.setRequestHeader("Content-type", "application/json;charset=UTF-8"), e.onreadystatechange = function() {
                if (4 == e.readyState && 200 == e.status && e.responseText) {
                    var t = JSON.parse(e.responseText);
                    if (t.product_bundles_css_selector && (widgetSelector = t.product_bundles_css_selector), t.price_template && (priceTemplate = t.price_template), t.before_bundle_submit_js_code && (beforeBundleSubmitJSCode = t.before_bundle_submit_js_code), t.widget_html && document.querySelector(widgetSelector)) {
                        var o = document.createElement("div");
                        o.classList.add("discountyard-bundles-widget-root"), o.innerHTML = t.widget_html, t.product_bundles_css_selector_append ? document.querySelector(widgetSelector).append(o) : document.querySelector(widgetSelector).prepend(o), StackDiscounts.calculateBundlesTotal()
                    }
                }
            }, e.send(JSON.stringify({
                store_domain: window.SHOPIFY_STORE_DOMAIN ? window.SHOPIFY_STORE_DOMAIN : Shopify.shop,
                product_handle: t,
                product_id: ShopifyAnalytics && ShopifyAnalytics.meta && ShopifyAnalytics.meta.product ? ShopifyAnalytics.meta.product.id : "",
                shopify_currency: window.Shopify ? window.Shopify.currency : null
            }))
        }

        function initProductBundles() {
            window.location.href.split("/products/").length >= 2 && getProductBundles(window.location.href.split("/products/")[1].split("?")[0])
        }
        StackDiscounts.calculateBundlesTotal = function() {
            for (var t = 0, e = document.querySelectorAll(".discountyard-bundles-widget-root"), o = 0; o < e.length; o++) {
                var r = e[o],
                    n = r.querySelectorAll(".discountyard-bundle-products-info-item");
                for (o = 0; o < n.length; o++) {
                    var i = n[o],
                        c = i.querySelector(".product-bundle-checkbox");
                    if (c && c.checked) {
                        var a = i.querySelector('[name="variant-id"]').selectedOptions[0];
                        t += parseFloat(a.getAttribute("data-price"))
                    }
                }
                var s = priceTemplate.replace("{price}", t.toFixed(2));
                if (r.querySelector("#bundle-discount-value")) {
                    var u = t * (1 - r.querySelector("#bundle-discount-value").value / 100),
                        d = priceTemplate.replace("{price}", u.toFixed(2));
                    r.querySelector(".discountyard-bundle-total-price").innerHTML = "<strike>" + s + "</strike>" + d
                } else r.querySelector(".discountyard-bundle-total-price").innerHTML = s
            }
        }, StackDiscounts.submitBundle = _asyncToGenerator(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark((function _callee() {
            var button, properties, productPageProperties, i, attributeName, variantItems, widget, products, productItem, checkbox, variantSelector, selectedVariant, fetchArray, request, _args = arguments;
            return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap((function _callee$(_context) {
                for (;;) switch (_context.prev = _context.next) {
                    case 0:
                        if (button = _args.length > 0 && void 0 !== _args[0] ? _args[0] : null, StackDiscounts.proceedToBundleCart = !0, beforeBundleSubmitJSCode) try {
                            eval(beforeBundleSubmitJSCode)
                        } catch (t) {
                            console.log(t)
                        }
                        if (StackDiscounts.proceedToBundleCart) {
                            _context.next = 5;
                            break
                        }
                        return _context.abrupt("return");
                    case 5:
                        if (properties = document.querySelectorAll('form[action*="/cart/add"] [name*="properties"]'), productPageProperties = {}, properties.length)
                            for (i = 0; i < properties.length; i++) attributeName = properties[i].getAttribute("name").replace(/(^.*\[|\].*$)/g, ""), attributeName && ("checkbox" == properties[i].type ? productPageProperties[attributeName] = properties[i].checked ? "yes" : "no" : productPageProperties[attributeName] = properties[i].value);
                        for (variantItems = [], widget = button ? button.closest(".discountyard-bundles-widget-root") : document.querySelector(".discountyard-bundles-widget-root"), products = widget.querySelectorAll(".discountyard-bundle-products-info-item"), i = 0; i < products.length; i++) productItem = products[i], checkbox = productItem.querySelector(".product-bundle-checkbox"), checkbox && checkbox.checked && (variantSelector = productItem.querySelector('[name="variant-id"]'), selectedVariant = variantSelector.value, variantItems.push({
                            id: selectedVariant.replace("gid://shopify/ProductVariant/", ""),
                            quantity: 1,
                            properties: 0 == i ? productPageProperties : null
                        }));
                        if (!variantItems.length) {
                            _context.next = 25;
                            break
                        }
                        fetchArray = [], i = 0;
                    case 15:
                        if (!(i < variantItems.length)) {
                            _context.next = 23;
                            break
                        }
                        return _context.next = 18, fetch("/cart/add.js", {
                            method: "POST",
                            credentials: "same-origin",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                items: [variantItems[i]]
                            })
                        });
                    case 18:
                        request = _context.sent, fetchArray.push(request);
                    case 20:
                        i++, _context.next = 15;
                        break;
                    case 23:
                        return _context.next = 25, Promise.all(fetchArray).then((function(t) {
                            if (widget.querySelector("#bundle-discount-code")) {
                                var e = widget.querySelector("#bundle-discount-code").value;
                                window.location.href = "/cart?discounts=" + encodeURIComponent(e)
                            } else window.location.href = "/cart"
                        })).catch((function(t) {
                            console.log(t), window.location.href = "/cart?msg=er"
                        }));
                    case 25:
                    case "end":
                        return _context.stop()
                }
            }), _callee)
        }))), StackDiscounts.initProductBundles = initProductBundles
    },
    318: function(t, e, o) {
        var r = function(t) {
            "use strict";
            var e = Object.prototype,
                o = e.hasOwnProperty,
                r = "function" == typeof Symbol ? Symbol : {},
                n = r.iterator || "@@iterator",
                i = r.asyncIterator || "@@asyncIterator",
                c = r.toStringTag || "@@toStringTag";

            function a(t, e, o) {
                return Object.defineProperty(t, e, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }), t[e]
            }
            try {
                a({}, "")
            } catch (t) {
                a = function(t, e, o) {
                    return t[e] = o
                }
            }

            function s(t, e, o, r) {
                var n = e && e.prototype instanceof l ? e : l,
                    i = Object.create(n.prototype),
                    c = new w(r || []);
                return i._invoke = function(t, e, o) {
                    var r = "suspendedStart";
                    return function(n, i) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === n) throw i;
                            return C()
                        }
                        for (o.method = n, o.arg = i;;) {
                            var c = o.delegate;
                            if (c) {
                                var a = k(c, o);
                                if (a) {
                                    if (a === d) continue;
                                    return a
                                }
                            }
                            if ("next" === o.method) o.sent = o._sent = o.arg;
                            else if ("throw" === o.method) {
                                if ("suspendedStart" === r) throw r = "completed", o.arg;
                                o.dispatchException(o.arg)
                            } else "return" === o.method && o.abrupt("return", o.arg);
                            r = "executing";
                            var s = u(t, e, o);
                            if ("normal" === s.type) {
                                if (r = o.done ? "completed" : "suspendedYield", s.arg === d) continue;
                                return {
                                    value: s.arg,
                                    done: o.done
                                }
                            }
                            "throw" === s.type && (r = "completed", o.method = "throw", o.arg = s.arg)
                        }
                    }
                }(t, o, c), i
            }

            function u(t, e, o) {
                try {
                    return {
                        type: "normal",
                        arg: t.call(e, o)
                    }
                } catch (t) {
                    return {
                        type: "throw",
                        arg: t
                    }
                }
            }
            t.wrap = s;
            var d = {};

            function l() {}

            function p() {}

            function f() {}
            var h = {};
            h[n] = function() {
                return this
            };
            var _ = Object.getPrototypeOf,
                m = _ && _(_(D([])));
            m && m !== e && o.call(m, n) && (h = m);
            var y = f.prototype = l.prototype = Object.create(h);

            function S(t) {
                ["next", "throw", "return"].forEach((function(e) {
                    a(t, e, (function(t) {
                        return this._invoke(e, t)
                    }))
                }))
            }

            function g(t, e) {
                var r;
                this._invoke = function(n, i) {
                    function c() {
                        return new e((function(r, c) {
                            ! function r(n, i, c, a) {
                                var s = u(t[n], t, i);
                                if ("throw" !== s.type) {
                                    var d = s.arg,
                                        l = d.value;
                                    return l && "object" == typeof l && o.call(l, "__await") ? e.resolve(l.__await).then((function(t) {
                                        r("next", t, c, a)
                                    }), (function(t) {
                                        r("throw", t, c, a)
                                    })) : e.resolve(l).then((function(t) {
                                        d.value = t, c(d)
                                    }), (function(t) {
                                        return r("throw", t, c, a)
                                    }))
                                }
                                a(s.arg)
                            }(n, i, r, c)
                        }))
                    }
                    return r = r ? r.then(c, c) : c()
                }
            }

            function k(t, e) {
                var o = t.iterator[e.method];
                if (void 0 === o) {
                    if (e.delegate = null, "throw" === e.method) {
                        if (t.iterator.return && (e.method = "return", e.arg = void 0, k(t, e), "throw" === e.method)) return d;
                        e.method = "throw", e.arg = new TypeError("The iterator does not provide a 'throw' method")
                    }
                    return d
                }
                var r = u(o, t.iterator, e.arg);
                if ("throw" === r.type) return e.method = "throw", e.arg = r.arg, e.delegate = null, d;
                var n = r.arg;
                return n ? n.done ? (e[t.resultName] = n.value, e.next = t.nextLoc, "return" !== e.method && (e.method = "next", e.arg = void 0), e.delegate = null, d) : n : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), e.delegate = null, d)
            }

            function v(t) {
                var e = {
                    tryLoc: t[0]
                };
                1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
            }

            function b(t) {
                var e = t.completion || {};
                e.type = "normal", delete e.arg, t.completion = e
            }

            function w(t) {
                this.tryEntries = [{
                    tryLoc: "root"
                }], t.forEach(v, this), this.reset(!0)
            }

            function D(t) {
                if (t) {
                    var e = t[n];
                    if (e) return e.call(t);
                    if ("function" == typeof t.next) return t;
                    if (!isNaN(t.length)) {
                        var r = -1,
                            i = function e() {
                                for (; ++r < t.length;)
                                    if (o.call(t, r)) return e.value = t[r], e.done = !1, e;
                                return e.value = void 0, e.done = !0, e
                            };
                        return i.next = i
                    }
                }
                return {
                    next: C
                }
            }

            function C() {
                return {
                    value: void 0,
                    done: !0
                }
            }
            return p.prototype = y.constructor = f, f.constructor = p, p.displayName = a(f, c, "GeneratorFunction"), t.isGeneratorFunction = function(t) {
                var e = "function" == typeof t && t.constructor;
                return !!e && (e === p || "GeneratorFunction" === (e.displayName || e.name))
            }, t.mark = function(t) {
                return Object.setPrototypeOf ? Object.setPrototypeOf(t, f) : (t.__proto__ = f, a(t, c, "GeneratorFunction")), t.prototype = Object.create(y), t
            }, t.awrap = function(t) {
                return {
                    __await: t
                }
            }, S(g.prototype), g.prototype[i] = function() {
                return this
            }, t.AsyncIterator = g, t.async = function(e, o, r, n, i) {
                void 0 === i && (i = Promise);
                var c = new g(s(e, o, r, n), i);
                return t.isGeneratorFunction(o) ? c : c.next().then((function(t) {
                    return t.done ? t.value : c.next()
                }))
            }, S(y), a(y, c, "Generator"), y[n] = function() {
                return this
            }, y.toString = function() {
                return "[object Generator]"
            }, t.keys = function(t) {
                var e = [];
                for (var o in t) e.push(o);
                return e.reverse(),
                    function o() {
                        for (; e.length;) {
                            var r = e.pop();
                            if (r in t) return o.value = r, o.done = !1, o
                        }
                        return o.done = !0, o
                    }
            }, t.values = D, w.prototype = {
                constructor: w,
                reset: function(t) {
                    if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(b), !t)
                        for (var e in this) "t" === e.charAt(0) && o.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0)
                },
                stop: function() {
                    this.done = !0;
                    var t = this.tryEntries[0].completion;
                    if ("throw" === t.type) throw t.arg;
                    return this.rval
                },
                dispatchException: function(t) {
                    if (this.done) throw t;
                    var e = this;

                    function r(o, r) {
                        return c.type = "throw", c.arg = t, e.next = o, r && (e.method = "next", e.arg = void 0), !!r
                    }
                    for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                        var i = this.tryEntries[n],
                            c = i.completion;
                        if ("root" === i.tryLoc) return r("end");
                        if (i.tryLoc <= this.prev) {
                            var a = o.call(i, "catchLoc"),
                                s = o.call(i, "finallyLoc");
                            if (a && s) {
                                if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                                if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                            } else if (a) {
                                if (this.prev < i.catchLoc) return r(i.catchLoc, !0)
                            } else {
                                if (!s) throw new Error("try statement without catch or finally");
                                if (this.prev < i.finallyLoc) return r(i.finallyLoc)
                            }
                        }
                    }
                },
                abrupt: function(t, e) {
                    for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                        var n = this.tryEntries[r];
                        if (n.tryLoc <= this.prev && o.call(n, "finallyLoc") && this.prev < n.finallyLoc) {
                            var i = n;
                            break
                        }
                    }
                    i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
                    var c = i ? i.completion : {};
                    return c.type = t, c.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, d) : this.complete(c)
                },
                complete: function(t, e) {
                    if ("throw" === t.type) throw t.arg;
                    return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), d
                },
                finish: function(t) {
                    for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                        var o = this.tryEntries[e];
                        if (o.finallyLoc === t) return this.complete(o.completion, o.afterLoc), b(o), d
                    }
                },
                catch: function(t) {
                    for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                        var o = this.tryEntries[e];
                        if (o.tryLoc === t) {
                            var r = o.completion;
                            if ("throw" === r.type) {
                                var n = r.arg;
                                b(o)
                            }
                            return n
                        }
                    }
                    throw new Error("illegal catch attempt")
                },
                delegateYield: function(t, e, o) {
                    return this.delegate = {
                        iterator: D(t),
                        resultName: e,
                        nextLoc: o
                    }, "next" === this.method && (this.arg = void 0), d
                }
            }, t
        }(t.exports);
        try {
            regeneratorRuntime = r
        } catch (t) {
            Function("r", "regeneratorRuntime = r")(r)
        }
    }
});